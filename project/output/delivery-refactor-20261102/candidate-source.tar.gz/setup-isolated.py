import os, shlex, subprocess
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

base=Path('/var/lib/wenheng/acceptance/delivery-refactor-20261102')
db='wenheng_test_delivery_20261102'
assert base.is_dir() and base.name=='delivery-refactor-20261102'
values={}
for line in Path('/etc/wenheng/test.env').read_text().splitlines():
    if '=' in line and not line.lstrip().startswith('#'):
        k,v=line.removeprefix('export ').split('=',1)
        values[k.strip()]=shlex.split(v)[0]
url=urlsplit(values.get('TEST_DATABASE_URL') or values['DATABASE_URL'])
assert 'test' in url.path and url.hostname in ('localhost','127.0.0.1')
exists=subprocess.check_output(['runuser','-u','postgres','--','psql','-Atqc',f"SELECT count(*) FROM pg_database WHERE datname='{db}'"],text=True).strip()
if exists=='0': subprocess.run(['runuser','-u','postgres','--','createdb','--owner=wenheng_test',db],check=True)
settings={'DATABASE_URL':urlunsplit(url._replace(path='/'+db)),'NODE_ENV':'test','WENHENG_PROJECT_ROOT':'/var/lib/wenheng/acceptance/workflow-optimization-20261102/resource-candidate-v2','WENHENG_WORKFLOW_RESOURCE_ROOT':'/var/lib/wenheng/acceptance/workflow-optimization-20261102/resource-candidate-v2','WENHENG_LIUREN_PROTOCOL':'liuren-v3','WENHENG_ENCRYPTION_KEY':'ab'*32,'AUTH_SECRET':'synthetic-isolated-delivery-test-secret-20261102','SETTINGS_RECORD_KEY':'delivery-refactor-isolated','BETTER_AUTH_URL':'http://127.0.0.1:3192','APP_BASE_URL':'http://127.0.0.1:3192','OPENCODE_BIN':'/opt/wenheng-runtime/tools/bin/opencode'}
env=base/'test.env'
env.write_text('\n'.join(k+'='+shlex.quote(v) for k,v in settings.items())+'\n')
os.chmod(env,0o600)
modules=base/'candidate/node_modules'
if not modules.exists(): modules.symlink_to('/opt/wenheng/releases/20261102-workflow-optimization-01/node_modules',target_is_directory=True)
print('Isolated test database and candidate prepared; production configuration untouched.')
