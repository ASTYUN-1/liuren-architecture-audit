import assert from 'node:assert/strict';
import {test,after} from 'node:test';
import {createHmac} from 'node:crypto';
import {verifyMonitorSample,storeMonitorSample,resourceMonitor} from '../src/server/resource-monitor';
import {monitorAlerts,monitorPoint,type ResourceSnapshot,type MonitorNode} from '../src/lib/resource-monitor';
import {sqlClient} from '../src/server/db';
const key='a1'.repeat(32),now=Date.now();
const sample=(at=now):ResourceSnapshot=>({node:'hk',at:new Date(at).toISOString(),bootId:'test-boot',uptimeSeconds:10,cpu:{percent:20,cores:2,load1:0,iowaitPercent:0},memory:{total:1000,available:800,swapTotal:0,swapUsed:0},disks:[{id:'system',total:1000,available:800}],network:{rxBps:null,txBps:null,dayRx:0,dayTx:0,monthRx:0,monthTx:0,trackingSince:new Date(at).toISOString(),interfaceCount:1},services:[{id:'nginx',state:'active'}]});
function signed(value:unknown,at=now,node='hk'){const raw=JSON.stringify(value),stamp=String(at),headers=new Headers({'x-wenheng-node':node,'x-wenheng-time':stamp,'x-wenheng-signature':createHmac('sha256',Buffer.from(key,'hex')).update(node+'\n'+stamp+'\n'+raw).digest('hex')});return {raw,headers};}
test('machine authentication accepts a bound node and rejects tampering, stale clocks and unknown keys',()=>{
 const {raw,headers}=signed(sample());assert.equal(verifyMonitorSample(raw,headers,{hk:key},now).node,'hk');
 assert.throws(()=>verifyMonitorSample(raw+' ',headers,{hk:key},now),{status:401});
 assert.throws(()=>verifyMonitorSample(raw,headers,{hk:key},now+121000),{status:401});
 assert.throws(()=>verifyMonitorSample(raw,headers,{},now),{status:401});
 const mismatch=signed({...sample(),node:'cn'});assert.throws(()=>verifyMonitorSample(mismatch.raw,mismatch.headers,{hk:key},now),{status:400});
});
test('collector payload rejects arbitrary fields, impossible metrics and invalid timestamps',()=>{
 for(const payload of [{...sample(),secret:'must not store'},{...sample(),memory:{...sample().memory,available:2000}},{...sample(),cpu:{...sample().cpu,percent:101}},{...sample(),at:new Date(now-3000).toISOString()}]){const {raw,headers}=signed(payload);assert.throws(()=>verifyMonitorSample(raw,headers,{hk:key},now),{status:400});}
});
const node=(s=sample(),stale=false):MonitorNode=>({id:'hk',sample:s,stale,receivedAt:s.at,history:[]});
test('stale and missing metrics never report healthy',()=>{assert.equal(monitorAlerts([node(sample(),true)],true)[0].code,'stale');assert.equal(monitorAlerts([{...node(),sample:null}],true)[0].code,'stale');assert.equal(monitorAlerts([],false)[0].code,'worker');});
test('CPU warnings require five continuous minutes; gaps and spikes do not count',()=>{
 const n=node();n.sample!.cpu.percent=90;n.history=Array.from({length:6},(_,i)=>monitorPoint({...n.sample!,at:new Date(now-(5-i)*60000).toISOString()}));
 assert(monitorAlerts([n],true).some(a=>a.code==='cpu'));
 n.history[2].cpu=20;assert(!monitorAlerts([n],true).some(a=>a.code==='cpu'));
 n.history.splice(2,1);assert(!monitorAlerts([n],true).some(a=>a.code==='cpu'));
});
test('low resources and stopped services generate concrete alerts',()=>{const s=sample();s.memory.available=40;s.disks[0].available=100;s.services[0].state='failed';const a=monitorAlerts([node(s)],true);assert.deepEqual(a.map(x=>[x.code,x.level]),[['memory','critical'],['disk','warning'],['service','critical']]);});
test('administrator and verified-email gates run before any DB access',async()=>{
 for(const a of [{id:'test',isAdmin:false,emailVerified:true},{id:'test',isAdmin:true,emailVerified:false}])await assert.rejects(()=>resourceMonitor(a as any,'1h'),{status:403});
 await assert.rejects(()=>resourceMonitor({isAdmin:true,emailVerified:true} as any,'forever'),{status:400});
});
const isolated=!!process.env.MONITOR_DB_TEST;
test('isolated DB: per-minute upsert, replay rejection, bounded history and retention',{skip:!isolated},async()=>{
 const url=new URL(process.env.DATABASE_URL!);assert.equal(url.pathname,'/wenheng_test_account');assert(['127.0.0.1','localhost'].includes(url.hostname));
 const db=sqlClient();await db`TRUNCATE resource_monitor_samples`;
 const base=Math.floor(Date.now()/60000)*60000;
 const stale=sample(base-8*86400000);await db`INSERT INTO resource_monitor_samples(node_id,bucket,sampled_at,payload) VALUES('cn',${stale.at},${stale.at},${db.json({...stale,node:'cn'})})`;
 assert.equal((await storeMonitorSample(sample(base+1000))).accepted,true);
 assert.equal((await storeMonitorSample(sample(base+1000))).accepted,false);
 assert.equal((await storeMonitorSample(sample(base))).accepted,false);
 assert.equal((await storeMonitorSample(sample(base+2000))).accepted,true);
 assert.equal(Number((await db`SELECT count(*) AS n FROM resource_monitor_samples`)[0].n),1);
 assert.equal((await storeMonitorSample(sample(base-60000))).accepted,true);
 const result=await resourceMonitor({isAdmin:true,emailVerified:true} as any,'1h');assert.equal(result.nodes.length,4);assert.equal(result.nodes.find(n=>n.id==='hk')!.history.length,2);assert.equal(result.nodes.find(n=>n.id==='cn')!.stale,true);
 await db`TRUNCATE resource_monitor_samples`;
});
after(async()=>{if(isolated)await sqlClient().end();});
