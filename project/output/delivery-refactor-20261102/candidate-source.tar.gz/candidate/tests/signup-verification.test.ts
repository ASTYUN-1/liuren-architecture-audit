import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { SMTPServer } from "smtp-server";
import { sqlClient } from "../src/server/db";

if (!process.env.DATABASE_URL || !new URL(process.env.DATABASE_URL).pathname.includes("wenheng_test")) throw Error("isolated test DB required");
const testKey = "signup-verification-" + randomUUID(), email = testKey + "@example.invalid", origin = "http://127.0.0.1:3199";
Object.assign(process.env, { NODE_ENV: "test", SETTINGS_RECORD_KEY: testKey, APP_URL: origin, BETTER_AUTH_SECRET: "isolated-signup-verification-secret-20261017" });
let body = "", deliveries = 0;
const smtp = new SMTPServer({ authOptional: true, disabledCommands: ["STARTTLS"], onData(stream, _session, callback) { let raw = ""; stream.on("data", chunk => raw += chunk); stream.on("end", () => { body = raw.replace(/=\r?\n/g, "").replace(/=([0-9A-F]{2})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16))); deliveries++; callback(); }); } });
const db = sqlClient();
before(async () => { await new Promise<void>((resolve, reject) => { smtp.once("error", reject); smtp.listen(12526, "127.0.0.1", resolve); }); await db`INSERT INTO service_settings(key,value) VALUES(${'test:' + testKey},${db.json({ emailProvider: "smtp", smtpHost: "127.0.0.1", smtpPort: 12526, smtpSecure: false, smtpFrom: "test@example.invalid" })})`; });
after(async () => { await db`DELETE FROM "user" WHERE email=${email}`; await db`DELETE FROM service_settings WHERE key=${'test:' + testKey}`; await db.end(); await new Promise<void>(resolve => smtp.close(() => resolve())); });

test("注册立即发送验证链接，未验证会话保持未验证，点击同源回调后才完成验证", async () => {
  const { getAuth } = await import("../src/server/auth");
  const response = await getAuth().handler(new Request(origin + "/api/auth/sign-up/email", { method: "POST", headers: { Origin: origin, "Content-Type": "application/json" }, body: JSON.stringify({ username: "verify_"+randomUUID().replaceAll("-", "").slice(0,12), name: "仅测试 · 注册验证", email, password: "synthetic-signup-password-123", callbackURL: "/verify-email" }) }));
  assert.equal(response.status, 200); const data = await response.json(); assert.equal(data.user.emailVerified, false);
  assert.equal(deliveries, 1); const link = body.match(/http:\/\/127\.0\.0\.1:3199\/api\/auth\/verify-email[^\s<>]+/)?.[0]; assert.ok(link, "signup must send a real link to the local SMTP sink");
  const url = new URL(link); assert.equal(url.searchParams.get("callbackURL"), "/verify-email");
  assert.equal((await db`SELECT email_verified FROM "user" WHERE email=${email}`)[0].email_verified, false);
  const verified = await getAuth().handler(new Request(url, { headers: { Origin: origin } })); assert.equal(verified.status, 302); assert.equal(new URL(verified.headers.get("location")!, origin).pathname, "/verify-email");
  assert.equal((await db`SELECT email_verified FROM "user" WHERE email=${email}`)[0].email_verified, true); assert.ok(verified.headers.getSetCookie().some(cookie => cookie.includes("session_token=")));
  assert.equal(deliveries, 1, "verification itself must not send another notification");
});
