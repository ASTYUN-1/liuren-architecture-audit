import test from 'node:test';
import assert from 'node:assert/strict';
import {estimateAnalysisProgress} from '../src/lib/analysis-progress';

const start='2026-10-19T08:00:00Z',epoch=Date.parse(start);
test('预估从零增长、存在停顿、持续等待不超过90且不自行完成',()=>{
  for(const id of ['initial-task','followup-task','a']){
    const values=Array.from({length:1201},(_,second)=>estimateAnalysisProgress(id,start,epoch+second*1000));
    assert.equal(values[0],0);assert.equal(values.at(-1),90);
    assert(values.every((value,i)=>value>=0&&value<=90&&(i===0||value>=values[i-1])));
    assert(values.some((value,i)=>i>15&&value===values[i-10]&&value>0&&value<90));
    assert.equal(estimateAnalysisProgress(id,start,epoch+86400000),90);
  }
});
test('重访同任务估算一致，新任务重新从零开始；无效和未来时间安全处理',()=>{
  const first=estimateAnalysisProgress('one',start,epoch+120000);
  assert(first>0);assert.equal(estimateAnalysisProgress('one',start,epoch+120000),first);
  assert.equal(estimateAnalysisProgress('two',new Date(epoch+120000).toISOString(),epoch+120000),0);
  assert.equal(estimateAnalysisProgress('one','invalid',epoch),0);
  assert.equal(estimateAnalysisProgress('one',start,Number.NaN),0);
  assert.equal(estimateAnalysisProgress('one',start,epoch-1000),0);
});
