import {test} from 'node:test';
import assert from 'node:assert/strict';
import {trustedAppOrigins,requestAppOrigin} from '../src/server/origins';
test('secondary entry is explicit; forged hosts fall back to canonical origin',()=>{
  const previous={APP_URL:process.env.APP_URL,APP_ORIGINS:process.env.APP_ORIGINS};
  try{
    process.env.APP_URL='https://wen.qiluhub.com';
    process.env.APP_ORIGINS='https://cn-wen.qiluhub.com';
    assert.deepEqual(trustedAppOrigins(),['https://wen.qiluhub.com','https://cn-wen.qiluhub.com']);
    assert.equal(requestAppOrigin(new Request('http://localhost/invite/test',{headers:{host:'cn-wen.qiluhub.com'}})),'https://cn-wen.qiluhub.com');
    assert.equal(requestAppOrigin(new Request('http://localhost/invite/test',{headers:{host:'attacker.invalid','x-forwarded-host':'cn-wen.qiluhub.com'}})),'https://wen.qiluhub.com');
  }finally{for(const [key,value] of Object.entries(previous)){if(value===undefined)delete process.env[key];else process.env[key]=value;}}
});
