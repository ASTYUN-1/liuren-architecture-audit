import test from "node:test";
import assert from "node:assert/strict";
import { runInterpretation } from "../src/agent/runtime";
import type { CaseInput } from "../src/server/contracts";
import { KnowledgeRelease, REQUIRED_SKILLS } from "../src/agent/knowledge";
import { calculateChart, DEFAULT_RULES } from "../src/engine/liuren";
import {startRandomChart,stopRandomChart} from "../src/engine/random-chart";

// Follow the latest lossless context/chart delivery before advancing judgment.
function pendingBoundJson(body:any){
 const latest=new Map<string,any>();
 function inspect(value:any):void{if(typeof value==='string'){try{inspect(JSON.parse(value));}catch{}return;}if(Array.isArray(value)){value.forEach(inspect);return;}if(!value||typeof value!=='object')return;if(value.paginated===true&&['fixed-chart','case-context'].includes(value.id))latest.set(value.id,value);Object.values(value).forEach(inspect);}
 inspect(body.messages);return [...latest.values()].filter(v=>!v.complete&&v.missingPages?.length).map(v=>({name:v.id==='fixed-chart'?'wenheng_calculate_chart':'wenheng_read_case',args:{page:v.missingPages[0],expectedHash:v.deliveryHash,maxPages:3}}));
}

test("实际OpenCode可越过200模型请求且保留准确计数",{skip:process.env.WENHENG_RUNTIME_FIXTURE!=="1",timeout:90000},async()=>{
 const original=globalThis.fetch;let requests=0,toolRounds=0;
 globalThis.fetch=(async(url:any,init:any)=>{
  if(String(url)!=="https://api.deepseek.com/v1/chat/completions")return original(url,init);
  const body=JSON.parse(init.body);requests++;
  const hasTool=body.tools?.some((t:any)=>t.function.name==="wenheng_search_knowledge");
  const actions=hasTool&&toolRounds<205?[{id:`extended_${++toolRounds}`,type:"function",function:{name:"wenheng_search_knowledge",arguments:JSON.stringify({query:`extended_request_${toolRounds}`,scope:"skills"})}}]:[];
  return new Response(JSON.stringify({id:`extended_${requests}`,created:1,model:"deepseek-flash",choices:[{index:0,message:{role:"assistant",content:actions.length?null:"fixture done without report",reasoning_content:"fixture",...(actions.length?{tool_calls:actions}:{})},finish_reason:actions.length?"tool_calls":"stop"}],usage:{prompt_tokens:100,completion_tokens:100}}),{status:200});
 }) as typeof fetch;
 try{
  await assert.rejects(runInterpretation({taskId:"extended",caseId:"extended",kind:"initial",input:{question:"隔离模型轮次上限验证",locale:"zh",mode:"time",time:"2026-10-15T05:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[],apiKey:"not-a-real-key",signal:AbortSignal.timeout(75000)}),error=>{
   const e=error as Error&{usage?:{requests:number;toolCalls:number}};assert.equal(e.message,"report_not_submitted");assert.equal(e.usage?.requests,206);assert.equal(e.usage?.toolCalls,205);return true;
  });
  assert.equal(requests,206);assert.equal(toolRounds,205);
 }finally{globalThis.fetch=original;}
});

test("实际 OpenCode 工具次数超过200仍继续，不绕过最终交付校验",{skip:process.env.WENHENG_RUNTIME_FIXTURE!=="1",timeout:90000},async()=>{
 const original=globalThis.fetch;let requests=0,toolRounds=0;
 globalThis.fetch=(async(url:any,init:any)=>{
  if(String(url)!=="https://api.deepseek.com/v1/chat/completions")return original(url,init);
  const body=JSON.parse(init.body);requests++;
  const hasTool=body.tools?.some((t:any)=>t.function.name==="wenheng_search_knowledge");
  if(hasTool)toolRounds++;
  // Vary literal queries so OpenCode's separate identical-call loop guard does
  // not terminate first; this test specifically exercises our shared tool limit.
  const actions=hasTool&&toolRounds<=18?Array.from({length:12},(_,i)=>({id:`limit_${toolRounds}_${i}`,type:"function",function:{name:"wenheng_search_knowledge",arguments:JSON.stringify({query:`fixture_budget_${toolRounds}_${i}`,scope:"skills"})}})):[];
  return new Response(JSON.stringify({id:`limit_${requests}`,created:1,model:"deepseek-flash",choices:[{index:0,message:{role:"assistant",content:actions.length?null:"fixture done",reasoning_content:"fixture",...(actions.length?{tool_calls:actions}:{})},finish_reason:actions.length?"tool_calls":"stop"}],usage:{prompt_tokens:100,completion_tokens:100}}),{status:200});
 }) as typeof fetch;
 try{
  await assert.rejects(runInterpretation({taskId:"limit",caseId:"limit",kind:"initial",input:{question:"隔离额度失败测试",locale:"zh",mode:"time",time:"2026-10-15T05:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[],apiKey:"not-a-real-key",signal:AbortSignal.timeout(75000)}),error=>{
   const e=error as Error&{usage?:{toolCalls:number;requests:number}};assert.equal(e.message,"report_not_submitted",JSON.stringify({requests,toolRounds,toolCalls:e.usage?.toolCalls,usageRequests:e.usage?.requests}));assert.equal(e.usage?.toolCalls,216);return true;
  });
  assert.equal(requests,19);
 }finally{globalThis.fetch=original;}
});

// Explicit fixture mode: the real local OpenCode process, MCP transport and model
// gateway run, while this test intercepts the fixed official HTTP endpoint. It
// never makes a paid API request and cannot be activated in production worker.
test("实际 OpenCode + MCP + 网关澄清链路：无真实模型付费",{skip:process.env.WENHENG_RUNTIME_FIXTURE!=="1",timeout:90000},async()=>{
  const original=globalThis.fetch;let supplierCalls=0,reasoningReturned=false;
  globalThis.fetch=(async(url:any,init:any)=>{
    if(String(url)!=="https://api.deepseek.com/v1/chat/completions")return original(url,init);
    supplierCalls++;const body=JSON.parse(init.body);assert.equal(body.model,"deepseek-flash");assert.equal(body.reasoning_effort,"high");assert.deepEqual(body.thinking,{type:"enabled"});
    const tool=body.tools?.find((t:any)=>t.function.name==="wenheng_submit_clarification"),already=body.messages.some((m:any)=>m.role==="tool");
    if(already)reasoningReturned=body.messages.some((m:any)=>m.role==="assistant"&&m.reasoning_content==="fixture-only thinking");
    const message=tool&&!already?{role:"assistant",content:null,reasoning_content:"fixture-only thinking",tool_calls:[{id:"call_fixture",type:"function",function:{name:tool.function.name,arguments:JSON.stringify({question:"请说明你提到的对方是否就是原问题中的同一位前任？"})}}]}:{role:"assistant",content:tool?"已提交澄清，请补充。":"Private task"};
    return new Response(JSON.stringify({id:`fixture_${supplierCalls}`,created:1,model:"deepseek-flash",choices:[{index:0,message,finish_reason:message.tool_calls?"tool_calls":"stop"}],usage:{prompt_tokens:100,completion_tokens:100,prompt_cache_hit_tokens:0}}),{status:200,headers:{"Content-Type":"application/json"}});
  }) as typeof fetch;
  const input:CaseInput={question:"我们能复合吗",locale:"zh",mode:"time",time:"2026-10-15T05:00:00Z",timeZone:"Asia/Shanghai",participants:[{role:"本人",gender:"female",birthYear:1995}]};
  try{const r=await runInterpretation({taskId:"fixture",caseId:"fixture",kind:"initial",input,history:[],apiKey:"not-a-real-key",signal:AbortSignal.timeout(75000)});assert(r.clarification?.includes("同一位前任"));assert.equal(r.report,undefined);assert(supplierCalls>=2);assert(reasoningReturned,"连续工具调用必须完整回传 reasoning_content");assert.equal(r.usage.requests,supplierCalls);}finally{globalThis.fetch=original;}
});

test("实际 OpenCode 单主模型 + 八技能 + 双路检索 + 案例出处 + 报告提交沿用选定随机盘",{skip:process.env.WENHENG_RUNTIME_FIXTURE!=="1",timeout:90000},async()=>{
  const original=globalThis.fetch,release=new KnowledgeRelease();let calls=0;
  const selected=stopRandomChart(startRandomChart(DEFAULT_RULES).ticket,8);
  const input:CaseInput={question:"我们能复合吗",locale:"zh",mode:"number",time:selected.time,number:selected.number,rules:selected.rules,random:{ticket:selected.ticket},timeZone:"Asia/Shanghai",participants:[{role:"本人",gender:"female",birthYear:1995}]},chart=calculateChart(input);
  const sample=release.search({category:"感情占",query:input.question})[0];assert(sample);
  const reference=release.searchText({query:"书籍库/经典古籍/佚名/壬归.txt",scope:"references"}).results[0];
  const quote=(id:string)=>release.read(id).text.slice(-160).trim();
  const toolCall=(name:string,args:any)=>({id:`fixture_${++calls}`,type:"function",function:{name,arguments:JSON.stringify(args)}});
  const reads=(ids:string[])=>ids.flatMap(id=>{const first=release.page(id);return Array.from({length:first.pageCount},(_,i)=>toolCall("wenheng_read_knowledge",{id,page:i+1,expectedHash:first.deliveryHash}));});
  globalThis.fetch=(async(url:any,init:any)=>{
    if(String(url)!=="https://api.deepseek.com/v1/chat/completions")return original(url,init);
    const body=JSON.parse(init.body),names=body.tools?.map((t:any)=>t.function.name)??[],past=body.messages.flatMap((m:any)=>m.tool_calls??[]).map((t:any)=>t.function.name),main=names.includes("wenheng_submit_report");
    let actions:any[]=[];
    const pagination=pendingBoundJson(body);
    if(pagination.length)actions=pagination.map(p=>toolCall(p.name,p.args));
    else if(main){
      if(!past.includes("wenheng_calculate_chart"))actions=[toolCall("wenheng_read_case",{}),toolCall("wenheng_calculate_chart",{}),...reads(["skill:daliuren/SKILL.md",...REQUIRED_SKILLS.map(s=>`skill:${s}/SKILL.md`),"skill:liuren-cases/SKILL.md"])];
      else if(!past.includes("wenheng_record_stage"))actions=REQUIRED_SKILLS.map(skill=>toolCall("wenheng_record_stage",{skill,chartHash:chart.hash,finding:"本条是集成测试的受控输出，只证明工作流执行与引用契约，不代表任何真实的解读质量。",facts:[{path:"sike.0.1",value:chart.facts.sike[0][1]},{path:"sanchuan.0.3",value:chart.facts.sanchuan[0][3]}],citations:[{id:`skill:${skill}/SKILL.md`,quote:quote(`skill:${skill}/SKILL.md`)}]}));
      else if(!past.includes("wenheng_search_cases"))actions=[toolCall("wenheng_search_cases",{category:"感情占"}),...reads([sample.id]),...(release.fineGrainedEnabled?[toolCall("wenheng_search_experience",{query:"空亡 合",category:"感情占"})]:[]),...(reference?[toolCall("wenheng_search_knowledge",{query:"书籍库/经典古籍/佚名/壬归.txt",scope:"references"}),...reads([reference.id])]:[])];
      else if(!past.includes("wenheng_submit_report"))actions=[toolCall("wenheng_submit_report",{title:"集成测试专用，不能交付客户",summary:"这一内容由测试fixture生成，只用于验证真实工具协议与主模型亲自执行。",content:"测试fixture内容：只验证执行链、固定盘、来源引用和任务交付协议。不表示真实模型的解读质量。".repeat(8),citations:[{id:`skill:${REQUIRED_SKILLS[0]}/SKILL.md`,quote:quote(`skill:${REQUIRED_SKILLS[0]}/SKILL.md`)},{id:`skill:${REQUIRED_SKILLS[1]}/SKILL.md`,quote:quote(`skill:${REQUIRED_SKILLS[1]}/SKILL.md`)},{id:sample.id,quote:quote(sample.id)},...(reference?[{id:reference.id,quote:quote(reference.id)}]:[])],warnings:["集成测试专用"]})];
    }else if(names.includes("wenheng_search_cases")&&!past.includes("wenheng_search_cases"))actions=[toolCall("wenheng_read_case",{}),toolCall("wenheng_calculate_chart",{}),...reads(["skill:liuren-cases/SKILL.md"]),toolCall("wenheng_search_cases",{category:"感情占"}),...reads([sample.id]),...(reference?[toolCall("wenheng_search_knowledge",{query:"书籍库/经典古籍/佚名/壬归.txt",scope:"references"}),...reads([reference.id])]:[])];
    if(main)for(const message of body.messages.filter((m:any)=>m.role==="tool")){const text=JSON.stringify(message.content);if(/workflow_incomplete|citation_not_read|tool_limit_exceeded|not permitted|denied/.test(text))console.error("FIXTURE_TOOL_DIAGNOSTIC",text.slice(0,2200));}
    const message=actions.length?{role:"assistant",content:null,reasoning_content:"fixture-only thinking",tool_calls:actions}:{role:"assistant",content:main?"已提交测试报告。":"案例工具已执行；相似：占类同为感情。差异：具体人物、时空不同。不能照搬结果。"};
    return new Response(JSON.stringify({id:`fixture_response_${calls}`,created:1,model:"deepseek-flash",choices:[{index:0,message,finish_reason:actions.length?"tool_calls":"stop"}],usage:{prompt_tokens:100,completion_tokens:100}}),{status:200,headers:{"Content-Type":"application/json"}});
  }) as typeof fetch;
  try{const r=await runInterpretation({taskId:"fixture",caseId:"fixture",kind:"initial",input,previousChart:chart,history:[],apiKey:"not-a-real-key",signal:AbortSignal.timeout(75000)});assert(r.report?.title.includes("集成测试"));assert.equal(r.chart.hash,chart.hash);assert.equal(r.report?.chart?.hash,chart.hash);assert.equal(r.usage.completedStages.length,8);assert(r.evidence.some(e=>e.id===sample.id));if(reference)assert(r.evidence.some(e=>e.id===reference.id&&e.provenance?.sourceHash));assert(r.usage.toolCalls>40);assert(r.usage.knowledgeCoverage.every(c=>c.complete));}finally{globalThis.fetch=original;}
});
