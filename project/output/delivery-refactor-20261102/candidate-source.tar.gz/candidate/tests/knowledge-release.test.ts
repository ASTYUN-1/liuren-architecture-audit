import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync,writeFileSync,mkdtempSync,mkdirSync,rmSync,existsSync} from "node:fs";
import {join} from "node:path";
import {tmpdir} from "node:os";
import {createHash} from "node:crypto";
import {KnowledgeRelease,caseCategoryAliases} from "../src/agent/knowledge";
import {PROJECT_ROOT} from "../src/engine/liuren";
import {loadKnowledgeManifest} from "../src/agent/knowledge-manifest";
import {ToolAudit} from "../src/agent/tools";
import {spawnSync} from "node:child_process";
import {fileURLToPath} from "node:url";

test("发布清单绑定源文、索引和片段；源文件被修改或路径越界即拒绝加载",t=>{
 const root=mkdtempSync(join(tmpdir(),"knowledge-manifest-"));t.after(()=>rmSync(root,{recursive:true,force:true}));
 const sha=(s:string)=>createHash("sha256").update(s).digest("hex");
 const text="原书片段必须可追溯，不可偷换。",index="normalized index";
 mkdirSync(join(root,"sources"));writeFileSync(join(root,"sources/book.md"),text);writeFileSync(join(root,"index.md"),index);
 const m={schemaVersion:1,policyVersion:"test",files:{"sources/book.md":sha(text),"index.md":sha(index)},documents:[{id:"reference:"+"a".repeat(20),file:"sources/book.md",source:"sources/book.md",hash:sha(text),kind:"reference",title:"book",meta:{},provenance:{sourceHash:sha(text),encoding:"utf-8",indexSource:"index.md",indexHash:sha(index),feedback:"unknown"}}]};
 const save=()=>writeFileSync(join(root,"knowledge-manifest.json"),JSON.stringify(m));save();
 const first=loadKnowledgeManifest(root)!;assert.equal(first.documents[0].text,text);
 m.documents[0].meta={tag:"new metadata"};save();assert.notEqual(loadKnowledgeManifest(root)!.hash,first.hash);
 writeFileSync(join(root,"index.md"),"stale");assert.throws(()=>loadKnowledgeManifest(root),/hash_mismatch/);writeFileSync(join(root,"index.md"),index);
 m.documents[0].provenance.indexHash="0".repeat(64);save();assert.throws(()=>loadKnowledgeManifest(root),/binding_mismatch/);
 (m.files as Record<string,string>)["../outside"]=sha(text);save();assert.throws(()=>loadKnowledgeManifest(root),/invalid_knowledge_manifest_path/);
 const policy=join(root,"website-skills/wenheng-public-output");mkdirSync(policy,{recursive:true});writeFileSync(join(policy,"SKILL.md"),readFileSync(join(PROJECT_ROOT,"website-skills/wenheng-public-output/SKILL.md")));
 const runtimeUrl=new URL("../src/agent/runtime.ts",import.meta.url).href;
 const code=`import assert from 'node:assert/strict';const {runInterpretation,InterpretationError}=await import(${JSON.stringify(runtimeUrl)});let calls=0;globalThis.fetch=async()=>{calls++;throw Error('Unexpected network');};try{await runInterpretation({taskId:'synthetic',caseId:'synthetic',kind:'initial',input:{question:'隔离测试',locale:'zh',mode:'time',time:'2026-10-15T07:00:00Z',timeZone:'Asia/Shanghai',participants:[]},history:[],apiKey:'fixture-only'});assert.fail('Expected invalid manifest');}catch(e){assert(e instanceof InterpretationError);assert.equal(e.code,'knowledge_release_invalid');assert.equal(e.usage.costCny,0);assert.equal(e.usage.requests,0);assert.equal(e.usage.toolCalls,0);}assert.equal(calls,0);`;
 const result=spawnSync(process.execPath,["--import","tsx","--input-type=module","--eval",code],{cwd:fileURLToPath(new URL("..",import.meta.url)),env:{...process.env,NODE_ENV:"test",WENHENG_PROJECT_ROOT:root,WENHENG_RUNTIME_FIXTURE:"0"},encoding:"utf8",timeout:30000,windowsHide:true});assert.equal(result.status,0,result.stderr||result.error?.message||"Child process failed");
});

test("安全别名对称，但危险跨类不互认；质量与阈值不授予自动采信",()=>{
 assert.deepEqual(caseCategoryAliases("考试占"),caseCategoryAliases("学业占"));
 for(const [a,b] of [["感情占","胎产占"],["疾病占","灾厄占"],["出行占","行人占"],["事业占","比赛占"]])assert(!caseCategoryAliases(a).includes(b));
 const k=new KnowledgeRelease();assert.deepEqual(k.search({category:"学业占"}).map(x=>x.id),k.search({category:"考试占"}).map(x=>x.id));
 for(const category of k.caseCategories()){
  const results=k.search({category});assert(results.every(x=>caseCategoryAliases(category).includes(x.meta["占类"])&&x.kind!=="reference"&&x.automaticAcceptance===false));
  assert(results.every(x=>x.rawScore===25&&(k.fineGrainedEnabled?x.qualityFactor===1&&typeof x.relevance_score==="number":x.matchLevel==="weak-background"&&x.threshold===60&&x.fallbackThreshold===45)));
  assert(Buffer.byteLength(JSON.stringify(results))<(k.fineGrainedEnabled?60000:14000));
 }
});

test("实际资料包：七古籍、通用经验、应期提取可发现，57份来源逐段复原",{skip:!existsSync(join(PROJECT_ROOT,"knowledge-manifest.json"))},()=>{
 const k=new KnowledgeRelease(),m=JSON.parse(readFileSync(join(PROJECT_ROOT,"knowledge-manifest.json"),"utf8"));
 for(const name of ["壬归","一字诀玉连环","北海闲人指南问答","六壬针见血","壬占汇选","六壬断案-补丁","六壬存验"]){
  const found=k.searchText({query:"经验日志/古籍-"+name,scope:"references"});assert(found.results.length>0,name);assert(found.results.every(x=>x.kind==="reference"));
 }
 for(const query of ["1-案例库经验提取","提取-大六壬应期断诀窍"]){assert(k.searchText({query,scope:"references"}).total>0);}
 for(const d of m.documents.filter((d:any)=>d.kind==="reference"&&d.source.startsWith("经验日志/")&&!d.meta["经验条目"])){assert.equal(k.page(d.id).pageCount,1);assert(Buffer.byteLength(k.page(d.id).text)<=6000);}
 assert.equal(k.searchText({query:"金手链",scope:"cases",category:"失物占"}).results.filter(x=>x.source.includes("金手链")).length,2);
 const missing=m.documents.find((d:any)=>d.source.endsWith("金手链反吟玄武临亥妇人拾走.md"));
 assert.equal(missing.meta["三传"],"卯酉卯");assert(missing.metadataConflicts.some((c:any)=>c.field==="三传"&&c.index==="卯酉"));
 assert(m.documents.some((d:any)=>Object.values(d.metadataOrigins??{}).includes("index")));
 assert(m.documents.some((d:any)=>d.provenance.feedback==="partial"));
 assert.equal(m.books.length,57);assert.equal(m.documents.filter((d:any)=>d.kind==="case").length,m.retrieval?m.retrieval.caseStatus.case_files:171);
 for(const book of m.books){
  const docs=m.documents.filter((d:any)=>d.source===book.source).sort((a:any,b:any)=>a.provenance.section-b.provenance.section);
  let decoded="",offset=0;
  for(const d of docs){const p=k.page(d.id);assert.equal(p.pageCount,1);assert.equal(p.provenance?.decodedByteStart,offset);assert(Buffer.byteLength(p.text)<=6000);decoded+=p.text;offset+=Buffer.byteLength(p.text);assert.equal(p.provenance?.decodedByteEnd,offset);}
  assert.equal(createHash("sha256").update(decoded).digest("hex"),book.decodedHash);
  assert.equal(offset,book.decodedBytes);assert(!decoded.includes("\uFFFD"));
 }
 const ref=k.searchText({query:"书籍库/经典古籍/佚名/壬归.txt",scope:"references"}).results[0];assert(ref);
 const audit=new ToolAudit({taskId:"synthetic",caseId:"synthetic",kind:"initial",input:{question:"虚构隔离测试",locale:"zh",mode:"time",time:"2026-10-15T07:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[]},k);
 const text=k.page(ref.id).text;assert.throws(()=>audit.cite(ref.id,text.slice(0,50)),/citation_not_read/);audit.readPage(ref.id);
 const e=audit.cite(ref.id,text.slice(0,50));assert.equal(e.provenance?.sourceHash,m.books.find((x:any)=>x.source===ref.source).hash);assert(!audit.caseHits.has(ref.id));
 const seen=new Set<string>();let offset=0;
 for(;;){const page=k.references(offset);assert(page.results.length<=5);for(const r of page.results){assert(!seen.has(r.source));seen.add(r.source);}if(page.nextOffset===null){assert.equal(seen.size,page.total);break;}offset=page.nextOffset;}
});
