import test from "node:test";
import assert from "node:assert/strict";
import {createServer} from "node:http";
import {runInterpretation} from "../src/agent/runtime";
import {closeModelTransport} from "../src/agent/model-transport";
// Explicit opt-in only. Two real 310-second localhost waits, zero paid API.
test("真实310秒首header与body静默：上游transport和OpenCode网关均越过300秒",{skip:process.env.WENHENG_LONG_WAIT_FIXTURE!=="1",timeout:410000},async()=>{
 const original=globalThis.fetch,wait=310000,timers=new Set<ReturnType<typeof setTimeout>>();let supplierCalls=0;
 const server=createServer((req,res)=>{const finish=()=>{const frame=(delta:any,finish_reason:any=null)=>({id:'synthetic',object:'chat.completion.chunk',created:1,model:'deepseek-flash',choices:[{index:0,delta,finish_reason}]});res.end(`data: ${JSON.stringify(frame({content:'Synthetic delayed completion'}))}\n\ndata: ${JSON.stringify(frame({},'stop'))}\n\ndata: ${JSON.stringify({choices:[],usage:{prompt_tokens:1,completion_tokens:1}})}\n\ndata: [DONE]\n\n`);};if(req.url==='/body'){res.writeHead(200,{'content-type':'text/event-stream'});res.write(': initial upstream heartbeat\n\n');}const timer=setTimeout(()=>{timers.delete(timer);if(!res.headersSent)res.writeHead(200,{'content-type':'text/event-stream'});finish();},wait);timers.add(timer);});
 await new Promise<void>(ok=>server.listen(0,'127.0.0.1',ok));const a=server.address();assert(a&&typeof a==='object');
 globalThis.fetch=(async(url:any,init:any)=>{if(String(url)!=='https://api.deepseek.com/v1/chat/completions')return original(url,init);const n=++supplierCalls;assert(n<=2,'No duplicate supplier requests permitted');const body=JSON.parse(init.body);assert.equal(body.stream,true);assert(init.dispatcher);return original(`http://127.0.0.1:${a.port}/${n===1?'headers':'body'}`,init);}) as typeof fetch;
 const results:{durationMs:number;requests:number;firstDeltaMs?:number;toolCalls:number}[]=[];
 try{
  await Promise.all([0,1].map(async index=>{const start=Date.now();await assert.rejects(runInterpretation({taskId:`long-${index}`,caseId:`long-${index}`,kind:'initial',audience:'practitioner',input:{question:'Synthetic local timeout verification',locale:'en',mode:'time',time:'2026-10-15T05:00:00Z',timeZone:'Asia/Shanghai',participants:[]},history:[],apiKey:'not-a-real-key',signal:AbortSignal.timeout(380000)},{protocol:'liuren-v3'}),e=>{const error=e as Error&{usage:any};assert.equal(error.message,'report_not_submitted');const delta=error.usage.performanceSummary.events.find((v:any)=>v.type==='model_first_delta');assert(delta?.firstDeltaMs>=300000);assert.equal(error.usage.requests,1);results.push({durationMs:Date.now()-start,requests:error.usage.requests,firstDeltaMs:delta.firstDeltaMs,toolCalls:error.usage.toolCalls});return true;});}));
  assert.equal(supplierCalls,2);console.log('LOCAL_LONG_WAIT_EVIDENCE',JSON.stringify({paidApiRequests:0,supplierCalls,results}));
 }finally{globalThis.fetch=original;for(const timer of timers)clearTimeout(timer);server.closeAllConnections();await new Promise<void>(ok=>server.close(()=>ok()));await closeModelTransport();}
});
