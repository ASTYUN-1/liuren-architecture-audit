import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {sqlClient} from '../src/server/db';
import {applyPractitioner,practitionerProfile,reviewPractitioner,certificationQueue,taskOutputAudience} from '../src/server/practitioner-certification';
import {managePractitioners,readConversationShare} from '../src/server/conversation-sharing';
import {caseDetail,patchCase} from '../src/server/service';
import {parseInput} from '../src/server/validation';
import type {Actor} from '../src/server/http';
if(!process.env.DATABASE_URL||new URL(process.env.DATABASE_URL).hostname!=='127.0.0.1'||!['55424','5432',''].includes(new URL(process.env.DATABASE_URL).port)||!['/wenheng_test_account','/wenheng_test_beta','/wenheng_test_runtime_20261101'].includes(new URL(process.env.DATABASE_URL).pathname))throw Error('Isolated local database required');
const db=sqlClient();const make=(verified=true):Actor=>{const id='cert-'+randomUUID();return {id,name:'Synthetic',email:id+'@example.invalid',emailVerified:verified,isAdmin:false};};
const user=make(),admin={...make(),isAdmin:true},unverified=make(false),partner=make(),other=make(),ids=[user,admin,unverified,partner,other].map(a=>a.id),caseId=randomUUID();
before(async()=>{for(const a of [user,admin,unverified,partner,other])await db`INSERT INTO "user"(id,email,name,email_verified) VALUES(${a.id},${a.email},${a.name},${a.emailVerified})`;await db`INSERT INTO cases(id,user_id,title) VALUES(${caseId},${user.id},'Synthetic own case')`;await db`INSERT INTO case_inputs(case_id,version,input) VALUES(${caseId},1,'{}')`;});
after(async()=>{await db`DELETE FROM tasks WHERE user_id IN ${db(ids)}`;await db`DELETE FROM case_inputs WHERE case_id=${caseId}`;await db`DELETE FROM cases WHERE user_id IN ${db(ids)}`;await db`DELETE FROM audit_log WHERE actor_id IN ${db(ids)}`;await db`DELETE FROM "user" WHERE id IN ${db(ids)}`;await db.end();});
async function review(action:string,actor=user){const p=await practitionerProfile(actor.id);return reviewPractitioner(admin,{userId:actor.id,action,note:'合成审核备注',revision:p.certification!.revision});}
test('申请不授予权限，邮箱、备注和管理员权限均由服务端验证',async()=>{
 await assert.rejects(()=>applyPractitioner(unverified,{note:'已研习六壬多年，申请专业表达'}),{code:'EMAIL_UNVERIFIED'});
 await assert.rejects(()=>applyPractitioner(user,{note:'太短'}),{code:'INVALID_INPUT'});
 const p=await applyPractitioner(user,{note:'已研习六壬多年，申请专业表达',status:'approved',tier:'official'});assert.equal(p.tier,'user');assert.equal(p.professionalOutput,false);assert.equal(p.certification!.status,'pending');
 await assert.rejects(()=>applyPractitioner(user,{note:'重复申请不应该创建第二份审核'}),{code:'CERTIFICATION_EXISTS'});
 await assert.rejects(()=>certificationQueue(user),{code:'FORBIDDEN'});await assert.rejects(()=>reviewPractitioner(user,{userId:user.id,action:'approve',note:'试图自批',revision:1}),{code:'FORBIDDEN'});
});
test('人工通过普通认证，只开启专业输出，不能读取分享或他人档案',async()=>{
 await review('approve');const p=await practitionerProfile(user.id);assert.equal(p.tier,'practitioner');assert.equal(p.professionalOutput,true);assert.equal(p.canReadShared,false);assert.deepEqual(p.advisorIds,[]);
 await assert.rejects(()=>readConversationShare(user,'WHC-FAKE'),{code:'SHARE_UNAVAILABLE'});
 await assert.rejects(()=>caseDetail(user,randomUUID()),{code:'NOT_FOUND'});await assert.rejects(()=>caseDetail(other,caseId),{code:'NOT_FOUND'});
 await assert.rejects(()=>reviewPractitioner(admin,{userId:user.id,action:'approve',note:'过期审核页面',revision:1}),{code:'REVIEW_CHANGED'});
});
test('每任务受众由数据库选定，重试不随身份变动，下一任务恢复普通输出',async()=>{
 const taskId=randomUUID();await db`INSERT INTO tasks(id,case_id,user_id,kind,input_version,idempotency_key) VALUES(${taskId},${caseId},${user.id},'initial',1,${randomUUID()})`;
 const selected=await db.begin(tx=>taskOutputAudience(tx,{id:taskId,user_id:user.id}));assert.equal(selected,'practitioner');await review('revoke');
 const [row]=await db`SELECT id,user_id,output_audience FROM tasks WHERE id=${taskId}`;
 assert.equal(await db.begin(tx=>taskOutputAudience(tx,{id:row.id,user_id:row.user_id,output_audience:row.output_audience})),'practitioner');
 await db`UPDATE tasks SET status='succeeded' WHERE id=${taskId}`;const next=randomUUID();await db`INSERT INTO tasks(id,case_id,user_id,kind,input_version,idempotency_key) VALUES(${next},${caseId},${user.id},'followup',1,${randomUUID()})`;
 assert.equal(await db.begin(tx=>taskOutputAudience(tx,{id:next,user_id:user.id})),'public');
 assert.equal((await practitionerProfile(user.id)).professionalOutput,false);
});
test('重新申请与驳回留存备注，申请版本防止旧审核覆盖',async()=>{
 const p=await applyPractitioner(user,{note:'补充研习经历和常用方法，再次申请认证'});assert.equal(p.certification!.status,'pending');await review('reject');assert.equal((await practitionerProfile(user.id)).certification!.reviewNote,'合成审核备注');
 await applyPractitioner(user,{note:'再次补充独立研习证明并申请认证'});await review('approve');
});
test('官方合作授权与普通认证独立，未验证邮箱不能获得专业能力',async()=>{
 await managePractitioners(admin,{action:'grant',advisorId:'congkui',email:partner.email});let p=await practitionerProfile(partner.id);assert.equal(p.tier,'official');assert.equal(p.professionalOutput,true);assert.equal(p.canReadShared,true);assert.deepEqual(p.advisorIds,['congkui']);
 await db`UPDATE "user" SET email_verified=false WHERE id=${partner.id}`;p=await practitionerProfile(partner.id);assert.equal(p.tier,'user');assert.equal(p.professionalOutput,false);assert.equal(p.canReadShared,false);
 await db`UPDATE "user" SET email_verified=true WHERE id=${partner.id}`;await managePractitioners(admin,{action:'revoke',advisorId:'congkui',email:partner.email});p=await practitionerProfile(partner.id);assert.equal(p.professionalOutput,false);
});
test('输入不能选择受众，审核队列仅管理员可读且不暴露敏感配置',async()=>{
 const input=parseInput({question:'合成权限检查问题',mode:'time',time:'2026-10-24T00:00:00Z',timeZone:'Asia/Shanghai',participants:[],audience:'practitioner',output_audience:'practitioner'});assert(!('audience' in input));assert(!('output_audience' in input));
 const rows=await certificationQueue(admin);assert(rows.some(r=>r.userId===user.id));assert.doesNotMatch(JSON.stringify(rows),/reviewed_by|password|token|secret|internal_evidence/);
});

test('专业用户可切换自己的输出，任务重试固定受众；普通用户不能提权',async()=>{
 await assert.rejects(()=>patchCase(other,caseId,{outputStyle:'practitioner'}),{code:'NOT_FOUND'});
 const foreign=randomUUID();await db`INSERT INTO cases(id,user_id,title) VALUES(${foreign},${other.id},'Synthetic ordinary')`;
 await assert.rejects(()=>patchCase(other,foreign,{outputStyle:'practitioner'}),{code:'FORBIDDEN'});
 await assert.rejects(()=>patchCase(user,caseId,{outputStyle:'internal'}),{code:'INVALID_INPUT'});
 await patchCase(user,caseId,{outputStyle:'public'});
 await db`UPDATE tasks SET status='succeeded' WHERE case_id=${caseId}`;
 const id=randomUUID();await db`INSERT INTO tasks(id,case_id,user_id,kind,input_version,idempotency_key) VALUES(${id},${caseId},${user.id},'followup',1,${randomUUID()})`;
 assert.equal(await db.begin(tx=>taskOutputAudience(tx,{id,user_id:user.id})),'public');
 await patchCase(user,caseId,{outputStyle:'practitioner'});
 assert.equal(await db.begin(tx=>taskOutputAudience(tx,{id,user_id:user.id,output_audience:'public'})),'public');
 await db`UPDATE tasks SET status='succeeded' WHERE id=${id}`;
 const next=randomUUID();await db`INSERT INTO tasks(id,case_id,user_id,kind,input_version,idempotency_key) VALUES(${next},${caseId},${user.id},'followup',1,${randomUUID()})`;
 assert.equal(await db.begin(tx=>taskOutputAudience(tx,{id:next,user_id:user.id})),'practitioner');
});

test('研习备注未上线：拒绝接口写入且数据库无字段',async()=>{
 await assert.rejects(()=>patchCase(user,caseId,{privateNote:'must not save',noteRevision:0}),{code:'FEATURE_UNAVAILABLE'});
 assert.equal((await db`SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name='cases' AND column_name LIKE 'private_note%'`).length,0);
 const c=await caseDetail(user,caseId);assert(!('privateNote' in c));assert(!('noteRevision' in c));
});
