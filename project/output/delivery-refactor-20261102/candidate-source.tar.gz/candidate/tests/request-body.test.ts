import {test} from 'node:test';
import assert from 'node:assert/strict';
import {body,AppError} from '../src/server/http';
import {POST as notify} from '../src/app/api/payments/nbzhifu/notify/route';

function streamed(chunks:Uint8Array[],headers:Record<string,string>={}) {
  let cancelled=false,reads=0;
  const stream=new ReadableStream<Uint8Array>({pull(controller){reads++;const next=chunks.shift();if(next)controller.enqueue(next);else controller.close();},cancel(){cancelled=true;}},{highWaterMark:0});
  const request=new Request('https://example.invalid/api',{method:'POST',headers,body:stream,duplex:'half'} as RequestInit);
  return {request,cancelled:()=>cancelled,reads:()=>reads};
}
test('JSON byte boundary accepts valid UTF-8 and rejects malformed JSON',async()=>{
  const text=JSON.stringify({q:'问'.repeat(10920)});
  assert.ok(Buffer.byteLength(text)<=32768);
  assert.equal((await body(new Request('https://example.invalid',{method:'POST',body:text}))).q.length,10920);
  await assert.rejects(()=>body(new Request('https://example.invalid',{method:'POST',body:'{'})),(e:unknown)=>e instanceof AppError&&e.code==='INVALID_JSON');
});
test('chunked JSON stops at 32KiB bytes even with missing or false length',async()=>{
  for(const headers of [{} as Record<string,string>,{'Content-Length':'1'}]) {
    const s=streamed([Buffer.alloc(16384),Buffer.from('问'.repeat(6000)),Buffer.alloc(16384)],headers);
    await assert.rejects(()=>body(s.request),(e:unknown)=>e instanceof AppError&&e.status===413);
    assert.equal(s.cancelled(),true);assert.equal(s.reads(),2);
  }
});
test('payment callback rejects duplicate fields and oversized streams before any supplier call',async()=>{
  const original=globalThis.fetch;let calls=0;
  globalThis.fetch=(async()=>{calls++;throw Error('No external calls allowed');}) as typeof fetch;
  try {
    const duplicate=await notify(new Request('https://example.invalid/notify',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'pid=1&pid=2'}));
    assert.equal(duplicate.status,400);
    const s=streamed([Buffer.alloc(8192),Buffer.alloc(8193),Buffer.alloc(1024)],{'Content-Type':'application/x-www-form-urlencoded','Content-Length':'1'});
    assert.equal((await notify(s.request)).status,413);assert.equal(s.cancelled(),true);assert.equal(s.reads(),2);assert.equal(calls,0);
  } finally {globalThis.fetch=original;}
});
