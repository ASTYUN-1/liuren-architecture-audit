import test from "node:test";
import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {mkdtempSync,mkdirSync,writeFileSync,rmSync} from "node:fs";
import {join} from "node:path";
import {tmpdir} from "node:os";
import {Client} from "@modelcontextprotocol/sdk/client/index.js";
import {InMemoryTransport} from "@modelcontextprotocol/sdk/inMemory.js";
import {KnowledgeRelease,REQUIRED_SKILLS,KNOWLEDGE_PAGE_BYTES} from "../src/agent/knowledge";
import {ToolAudit,createTaskTools} from "../src/agent/tools";

test("真实 MCP 保留调用计数，超过200次继续运行且未提交不能冒充成功",async()=>{
 const audit=new ToolAudit({taskId:"budget",caseId:"budget",kind:"initial",input:{question:"隔离工具额度测试",locale:"zh",mode:"time",time:"2026-10-15T07:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[]},new KnowledgeRelease());
 const server=createTaskTools(audit),client=new Client({name:"budget-test",version:"1"}),[a,b]=InMemoryTransport.createLinkedPair();
 await Promise.all([server.connect(b),client.connect(a)]);
 try{
  for(let i=1;i<=250;i++){
   const result=await client.callTool({name:"read_case",arguments:{}});assert(!result.isError);
   const content=result.content as {type:string;text:string}[];
   assert.deepEqual(JSON.parse(content[0].text).toolBudget,{used:i});
  }
  assert.equal(audit.calls,250);assert.equal(audit.terminalError,undefined);assert.equal(audit.candidate,undefined);
  assert.throws(()=>audit.assertComplete(),/report_not_submitted/);
 }finally{await client.close();await server.close();}
});

test("UTF-8 分页不丢字，包含末尾原文；页码/哈希/任意路径受限",t=>{
 const root=mkdtempSync(join(tmpdir(),"wenheng-pages-"));t.after(()=>rmSync(root,{recursive:true,force:true}));
 for(const name of ["daliuren",...REQUIRED_SKILLS]){const dir=join(root,".opencode/skills",name);mkdirSync(dir,{recursive:true});writeFileSync(join(dir,"SKILL.md"),"中文😀𠮷\n".repeat(5000)+"不可丢失的尾部规则");}
 for(const dir of ["案例项目库","经验日志"])mkdirSync(join(root,dir));
 const k=new KnowledgeRelease(root),id="skill:daliuren/SKILL.md",first=k.page(id);
 const pages=Array.from({length:first.pageCount},(_,i)=>k.page(id,i+1,first.deliveryHash));
 assert(pages.every(p=>Buffer.byteLength(p.text)<=KNOWLEDGE_PAGE_BYTES&&!p.text.includes("\uFFFD")));
 const text=pages.map(p=>p.text).join("");assert.equal(text,k.read(id).text);assert(text.endsWith("不可丢失的尾部规则"));
 assert.equal(createHash("sha256").update(text).digest("hex"),first.deliveryHash);
 for(const page of [0,-1,1.5,NaN,first.pageCount+1])assert.throws(()=>k.page(id,page),/invalid_knowledge_page/);
 assert.throws(()=>k.page(id,2),/knowledge_hash_mismatch/);assert.throws(()=>k.page(id,1,"0".repeat(64)),/knowledge_hash_mismatch/);
 assert.throws(()=>k.page("../../.env"),/unknown_knowledge_id/);
 assert(pages.every((p,i)=>p.byteStart===(i?pages[i-1].byteEnd:0)));assert.equal(pages.at(-1)!.byteEnd,first.totalBytes);
});

test("真实 MCP 只在全部页覆盖后允许引用/步骤，检索片段不授予已读权限",async()=>{
 const k=new KnowledgeRelease(),audit=new ToolAudit({taskId:"synthetic",caseId:"synthetic",kind:"initial",input:{question:"虚构隔离测试",locale:"zh",mode:"time",time:"2026-10-15T07:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[]},k);
 const server=createTaskTools(audit),client=new Client({name:"knowledge-test",version:"1"});const [a,b]=InMemoryTransport.createLinkedPair();
 await Promise.all([server.connect(b),client.connect(a)]);
 const call=(name:string,args:Record<string,unknown>)=>client.callTool({name,arguments:args});
 try{
  const id="skill:daliuren/SKILL.md",first=k.page(id);assert(first.pageCount>1);
  const result=await call("read_knowledge",{id});assert(!result.isError);assert(Buffer.byteLength(JSON.stringify(result))<16000);
  await call("read_knowledge",{id});assert(!audit.readIds.has(id));
  assert.throws(()=>audit.cite(id,k.read(id).text.slice(-80)),/citation_not_read/);
  const skill=REQUIRED_SKILLS[0],stageId=`skill:${skill}/SKILL.md`;
  const stage=await call("record_stage",{skill,chartHash:audit.chart.hash,finding:"隔离测试验证未完整读取资料时不能记录分析步骤。".repeat(2),facts:[{path:"sizhu.d",value:audit.chart.facts.sizhu.d},{path:"sizhu.d",value:audit.chart.facts.sizhu.d}],citations:[{id:stageId,quote:k.read(stageId).text.slice(-80)}]});assert(stage.isError);
  for(const args of [{id,page:2},{id,page:2,expectedHash:"0".repeat(64)},{id:"../../.env"},{id,page:99999,expectedHash:first.deliveryHash}])assert((await call("read_knowledge",args)).isError);
  const search=await call("search_knowledge",{query:"三传",scope:"skills"});assert(!search.isError);assert.equal(audit.readIds.size,0);
  for(let page=first.pageCount;page>=2;page--)assert(!(await call("read_knowledge",{id,page,expectedHash:first.deliveryHash})).isError);
  assert(audit.readIds.has(id));assert.doesNotThrow(()=>audit.cite(id,k.read(id).text.slice(-80)));
  assert.equal(audit.coverage().find(c=>c.id===id)?.complete,true);
 }finally{await client.close();await server.close();}
});

test("字面全文检索有界、分类隔离、返回可补读页码；拒绝无分类跨案例搜索",()=>{
 const k=new KnowledgeRelease();
 for(const query of ["", " ","中".repeat(101)])assert.throws(()=>k.searchText({query,scope:"skills"}),/invalid_search_query/);
 for(const scope of ["cases","all"] as const)assert.throws(()=>k.searchText({query:"三传",scope}),/exact_case_category_required/);
 assert.equal(k.searchText({query:".*[",scope:"skills"}).total,0);
 assert.throws(()=>k.searchText({query:"三传",scope:"skills",offset:-1}),/invalid_search_options/);
 const r=k.searchText({query:"三传",scope:"skills"});assert(r.total>0);assert(r.results.length<=5);assert(Buffer.byteLength(JSON.stringify(r))<12000);
 for(const hit of r.results){assert(k.read(hit.id).text.includes(hit.snippet));assert(k.page(hit.id,hit.page,hit.deliveryHash).text.includes("三传"));}
 const cases=k.searchText({query:"占",scope:"cases",category:"感情占"});assert(cases.results.length>0);assert(cases.results.every(r=>r.category==="感情占"&&r.id.startsWith("case:")));
});
