import test from 'node:test';
import assert from 'node:assert/strict';
import {formatCaseTranscript} from '../src/lib/case-transcript';
import {appendClarificationMessages} from '../src/lib/clarification-messages';
import type {CaseDetail, TurnView} from '../src/server/contracts';

function example(): CaseDetail {
  return {id:'fixture',title:'Synthetic case',status:'ready',archived:false,favorite:false,
    createdAt:'2026-10-26',updatedAt:'2026-10-26',remainingTurns:1,usedTurns:1,grantedTurns:2,canPurchaseAddon:false,
    inputVersion:2,input:{question:'Current question\nSecond line',locale:'zh',mode:'time',timeZone:'Asia/Shanghai',participants:[]},
    report:{title:'Answer',summary:'',content:'Current answer'},previousReports:[],turns:[],tasks:[],orders:[]};
}
function turn(id:string, version:number, answer:string|null): TurnView {
  return {id,inputVersion:version,question:'Question '+id,answer,clarification:null,status:answer?'succeeded':'queued',createdAt:'2026-10-26'};
}
test('first question precedes report; all follow-up questions survive without an answer',()=>{
  const item=example();item.turns=[turn('answered',2,'Follow-up answer'),turn('waiting',2,null)];
  const result=formatCaseTranscript(item);
  assert(result.includes('Current question\nSecond line'));
  assert(result.indexOf('Current question')<result.indexOf('Current answer'));
  assert(result.indexOf('Question answered')<result.indexOf('Follow-up answer'));
  assert(result.includes('Question waiting'));
  assert(result.includes('尚未交付回答（queued）'));
});
test('previous question, report and turns remain together before corrected version',()=>{
  const item=example();item.previousReports=[{inputVersion:1,input:{...item.input,question:'Original question'},report:{title:'Old',summary:'',content:'Original answer'},supersededAt:'2026-10-26'}];
  item.turns=[turn('old',1,'Old follow-up answer'),turn('new',2,'New follow-up answer')];
  const result=formatCaseTranscript(item);
  for(const [before,after] of [['Original question','Original answer'],['Original answer','Question old'],['Old follow-up answer','Current question'],['Current answer','Question new']])assert(result.indexOf(before)<result.indexOf(after));
  assert.equal(result.split('Question old').length,2);
});
test('initial supplements and pending clarification are exported, no invented answer',()=>{
  const item=example();item.report=null;
  item.tasks=[{id:'task',inputVersion:2,kind:'initial',question:'Additional background',clarification:'Please specify the time',error:null,status:'succeeded',createdAt:'2026-10-26'}];
  item.turns=[{...turn('clarify',2,null),clarification:'Which person?'}];
  const result=formatCaseTranscript(item);
  for(const text of ['Additional background','Please specify the time','Question clarify','Which person?','主报告尚未交付'])assert(result.includes(text));
  assert(!result.includes('AI · 回答：'));
});
test('missing historical input does not borrow current question or lose orphan turns',()=>{
  const item=example();item.previousReports=[{inputVersion:1,report:null,supersededAt:'2026-10-26'}];item.turns=[turn('orphan',3,'Answer from unavailable version')];
  const result=formatCaseTranscript(item);
  assert(result.includes('原提问不可读取'));
  assert.equal(result.split('Current question').length,2);
  assert(result.includes('Question orphan'));
});
test('clarified follow-up retains the original question exactly once through two rounds',()=>{
  const first=appendClarificationMessages([], 'Original follow-up', 'First clarification', 'First response');
  const second=appendClarificationMessages(first, 'Original follow-up\n补充：First response', 'Second clarification', 'Second response');
  assert.equal(first.length,3);
  assert.deepEqual(second.map(m=>m.content),['Original follow-up','First clarification','First response','Second clarification','Second response']);
  const item=example();item.turns=[{...turn('clarified',2,'Final reply'),question:'COMBINED TEXT MUST NOT DUPLICATE',clarificationMessages:second}];
  const result=formatCaseTranscript(item);
  assert(!result.includes('COMBINED TEXT'));
  assert.equal(result.split('Original follow-up').length,2);
  assert(result.indexOf('Second response')<result.indexOf('Final reply'));
});

test('submitted metadata and times survive export without leaking internal receipts',()=>{
  const item=example();item.inputSavedAt='2026-10-26T08:30:00Z';
  item.input={...item.input,mode:'solar',time:'2026-10-25T01:15:00Z',longitude:120.5,number:123,
    participants:[{role:'父亲',gender:'male',birthYear:1968,birthDate:'1968-03-05',lifeBranch:'申'}],
    intent:{receipt:'PRIVATE_RECEIPT_NEVER_EXPORT',summary:'内部摘要'}};
  const result=formatCaseTranscript(item);
  for(const text of ['2026/10/26','16:30:00','2026/10/25','09:15:00','120.5°','123','父亲','1968年生','1968-03-05','年命 申'])assert(result.includes(text),text);
  assert(!result.includes('PRIVATE_RECEIPT'));assert(!result.includes('内部摘要'));
});

test('clarification reply timestamps are kept independently, unknown prompt times stay absent',()=>{
  const history=appendClarificationMessages([], 'Original', 'Please add context', 'My context', '2026-10-26T08:31:00Z','2026-10-26T08:30:00Z');
  assert.equal(history[0].at,'2026-10-26T08:30:00Z');assert.equal(history[1].at,undefined);assert.equal(history[2].at,'2026-10-26T08:31:00Z');
});
