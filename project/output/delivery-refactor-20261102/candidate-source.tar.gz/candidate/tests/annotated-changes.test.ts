import test from 'node:test';
import assert from 'node:assert/strict';
import {parseInput} from '../src/server/validation';
import {calculateChart,normalizeChartInput} from '../src/engine/liuren';
import locations from '../src/lib/china-locations.json';
const input={question:'这次合作应如何安排？',mode:'number',number:14,time:'2026-10-14T22:10:00+08:00',timeZone:'Asia/Shanghai'};
test('选填人物资料可直接起盘，缺少性别不虚构行年',()=>{
 const a=calculateChart(parseInput(input));assert.equal(a.participants.length,0);assert.ok(a.warnings.some(v=>v.includes('资料不足')));
 const b=calculateChart(parseInput({...input,participants:[{role:'本人',birthYear:1990}]}));assert.equal(b.facts.userinfo[0].gender,undefined);assert.equal(b.facts.userinfo[0].xingnian,undefined);
});
test('报数使用指定日期并按十二支取余，小时输入不覆盖报数时辰',()=>{
 const a=normalizeChartInput(parseInput(input)),b=normalizeChartInput(parseInput({...input,time:'2026-10-14T01:00:00+08:00'}));
 assert.equal(a.date,'2026-10-14');assert.equal(a.branch,'丑');assert.equal(a.time,'02:00');assert.equal(b.branch,a.branch);assert.equal(b.date,a.date);
 const c=normalizeChartInput(parseInput({...input,time:'2025-02-03T12:00:00+08:00'}));assert.equal(c.date,'2025-02-03');assert.equal(c.branch,'丑');
 const now=Date.now(),fresh=parseInput({...input,time:undefined});assert.ok(Math.abs(+new Date(fresh.time!)-now)<1500);
});
test('本地坐标表涵盖34地区624地点，度分转换正确且西部地点可查',()=>{
 assert.equal(new Set(locations.map(v=>v.province)).size,34);assert.equal(locations.length,624);
 assert.equal(locations.find(v=>v.name==='北京')?.longitude,116.4);assert.equal(locations.find(v=>v.name==='乌鲁木齐')?.longitude,87.6);
 for(const p of locations){assert.ok(p.longitude>=73&&p.longitude<=135);assert.ok(p.latitude>=18&&p.latitude<=54);}
});
