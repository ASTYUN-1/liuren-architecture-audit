// Real runtime tests must mock the exact supplier endpoint before calling this
// transport. Fail closed for every other external URL, independent of API keys.
if(process.env.WENHENG_RUNTIME_FIXTURE==="1"){
  const localFetch=globalThis.fetch;
  globalThis.fetch=(async(input:RequestInfo|URL,init?:RequestInit)=>{
    const url=new URL(input instanceof Request?input.url:String(input));
    if(!["127.0.0.1","localhost","[::1]"].includes(url.hostname))throw new Error("fixture_external_network_blocked");
    return localFetch(input,init);
  }) as typeof fetch;
}
