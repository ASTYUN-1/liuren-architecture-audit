import {test} from "node:test";
import assert from "node:assert/strict";
import vm from "node:vm";
import {startRandomChart,stopRandomChart} from "../src/engine/random-chart";
import {calculateChart,createEngineContext,DEFAULT_RULES,plateHash} from "../src/engine/liuren";
import {readRandomTicket} from "../src/engine/random-ticket";
import {DIAL_BRANCHES,rotationForNumber,numberForRotation} from "../src/lib/random-chart";
import {parseInput} from "../src/server/validation";
import {ToolAudit} from "../src/agent/tools";
import {KnowledgeRelease} from "../src/agent/knowledge";
import {calculateSelfChart} from "../src/engine/self-chart";
import type {CaseInput} from "../src/server/contracts";
process.env.BETTER_AUTH_SECRET ||= "isolated-random-chart-test-secret-at-least-32";
const people:CaseInput["participants"]=[{role:"本人",gender:"female",birthYear:1995}];
function selectionInput(v:ReturnType<typeof stopRandomChart>):CaseInput{return {question:"测试：本次合作能否达成？",locale:"zh",mode:"number",time:v.time,timeZone:"America/New_York",number:v.number,rules:v.rules,participants:people,random:{ticket:v.ticket}};}

test("十二落点均匀离散，天盘月将落宫与报数活时互为逆映射",()=>{
  for(const m of DIAL_BRANCHES)for(let n=1;n<=12;n++){
    const angle=rotationForNumber(m,n);assert.equal(numberForRotation(m,angle),n);
    assert.equal(numberForRotation(m,angle+720),n);assert.equal(numberForRotation(m,angle-360),n);
    assert.equal((DIAL_BRANCHES.indexOf(m)+angle/30)%12,n-1);
  }
});

test("随机定盘十二课均与原引擎月将加时一致，年月日和月将冻结，不靠虚构时刻换将",t=>{
  const times=["2026-10-15T15:45:00.000Z","2026-11-22T12:30:00.000Z"];
  for(const time of times){
    t.mock.method(Date,"now",()=>Date.parse(time));
    const seed=startRandomChart(DEFAULT_RULES,time),anchor=readRandomTicket(seed.ticket,"seed");
    const original=calculateChart({question:"节气对照",locale:"zh",mode:"time",time,timeZone:"Asia/Shanghai",participants:[],rules:DEFAULT_RULES});
    for(let number=1;number<=12;number++){
      const result=stopRandomChart(seed.ticket,number),c=calculateChart(parseInput(selectionInput(result)));
      assert.equal(result.chart.monthGeneral,seed.chart.monthGeneral);
      assert.deepEqual(result.chart.pillars.slice(0,3),seed.chart.pillars.slice(0,3));
      assert.deepEqual(c.facts.jieqi,original.facts.jieqi);
      assert.equal(result.chart.palaces[number-1].heaven,seed.chart.monthGeneral);
      const ctx=createEngineContext(),p=anchor.pillars;
      ctx.inputJson=JSON.stringify({Date:c.normalized.date,Time:c.normalized.time,zhenghuoshi:"四柱",...anchor.rules,user:[],cundang:{ws:""},sizhu:{yg:p.y[0],yz:p.y[1],mz:p.m[1],dg:p.d[0],dz:p.d[1],hz:DIAL_BRANCHES[number-1],yuejiang:anchor.monthGeneral}});
      const native=JSON.parse(vm.runInContext("JSON.stringify(LiuRenPaiPan(JSON.parse(inputJson)))",ctx));
      assert.equal(plateHash(c.facts),plateHash(native));
      assert.equal(readRandomTicket(result.ticket,"selection").plateHash,plateHash(c.facts));
    }
    t.mock.restoreAll();
  }
});

test("随机回执拒绝篡改，过期启动票不可停止；已确认课式可跨登录沿用",t=>{
  const seed=startRandomChart(DEFAULT_RULES),selected=stopRandomChart(seed.ticket,5),input=selectionInput(selected);
  for(const changed of [{number:6},{time:new Date(Date.parse(input.time!)+60000).toISOString()},{rules:{...DEFAULT_RULES,zhouye:"夜贵"}},{mode:"time"},{longitude:116.4},{random:{ticket:selected.ticket.slice(0,-8)+"tampered"}}])assert.throws(()=>parseInput({...input,...changed}));
  const future=Date.now()+16*60000;t.mock.method(Date,"now",()=>future);
  assert.throws(()=>stopRandomChart(seed.ticket,1),/expired/);
  assert.doesNotThrow(()=>parseInput(input));
});

test("AI 初次与追问读取已存快照，无快照拒绝随机盘；问题和人物变动不改变天地四课三传",()=>{
  const s=stopRandomChart(startRandomChart(DEFAULT_RULES).ticket,8),input=parseInput(selectionInput(s)),saved=calculateChart(input),release=new KnowledgeRelease();
  assert.throws(()=>new ToolAudit({taskId:"t",caseId:"c",kind:"initial",input,history:[]},release),/fixed_chart_required/);
  for(const kind of ["initial","followup"] as const){const a=new ToolAudit({taskId:"t",caseId:"c",kind,input,history:[],previousChart:saved},release);assert.equal(a.chart.hash,saved.hash);assert.deepEqual(a.chart.facts,saved.facts);assert.notEqual(a.chart,saved);}
  const changed=calculateChart({...input,question:"另一个问题仅供输入测试",participants:[{role:"本人",gender:"male",birthYear:1990}]});
  assert.equal(plateHash(changed.facts),plateHash(saved.facts));
  assert.throws(()=>new ToolAudit({taskId:"t",caseId:"c",kind:"initial",input,history:[],previousChart:{...saved,facts:{...saved.facts,yuejiang:"假"}}},release),/fixed_chart_invalid/);
});

test("问事真太阳时与自助引擎一致，跨日/经度边界保留原始绝对时间",()=>{
  for(const longitude of [116.4,-74,-180,180]){
    const input=parseInput({question:"真太阳时对照测试",locale:"zh",mode:"solar",time:"2026-10-15T00:04:00+08:00",timeZone:"Asia/Shanghai",longitude,participants:people,rules:DEFAULT_RULES});
    const c=calculateChart(input),other=calculateSelfChart({method:"solar",date:"2026-10-15",time:"00:04",calendar:"solar",leapMonth:false,longitude,pillars:{year:"",month:"",day:"",hour:"",monthGeneral:""},rules:DEFAULT_RULES,participants:people}).chart;
    assert.equal(c.normalized.date,other.date);assert.equal(c.normalized.time,other.time);assert.deepEqual(c.facts.sanchuan,other.transmissions);assert.equal(c.normalized.instant,"2026-10-14T16:04:00.000Z");
  }
  assert.throws(()=>parseInput({question:"真太阳时测试",mode:"solar",participants:people}),/经度/);
});
