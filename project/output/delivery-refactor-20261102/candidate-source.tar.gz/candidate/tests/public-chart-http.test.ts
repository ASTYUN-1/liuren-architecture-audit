import test from "node:test";
import assert from "node:assert/strict";
import {sqlClient} from "../src/server/db";
if(!process.env.DATABASE_URL||!/wenheng_test/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error("Isolated wenheng_test required");
const origin=process.env.APP_URL||"http://127.0.0.1:3100";
const input={method:"time",date:"2026-10-15",time:"13:04",calendar:"solar",leapMonth:false,pillars:{year:"丙午",month:"戌",day:"壬戌",hour:"未",monthGeneral:"辰"},rules:{guiren:"甲戊庚牛羊",zhouye:"自动选择",shehai:"孟仲季",yuejiang:"中气换将"},participants:[{role:"本人",gender:"male",birthYear:1990}]};
test("匿名免费排盘成功；两个接口共用防刷限额；付费档案和后台仍需登录",async()=>{
  const db=sqlClient();
  const send=(path:string,value:unknown,extra:Record<string,string>={})=>fetch(origin+path,{method:"POST",headers:{Origin:origin,"Content-Type":"application/json",...extra},body:JSON.stringify(value)});
  await db`DELETE FROM rate_limits WHERE key LIKE 'public-chart:%'`;
  try {
    const first=await send("/api/chart/professional",{input});assert.equal(first.status,200);assert.equal((await first.json()).data.chart.palaces.length,12);
    assert.equal((await send("/api/chart",{input:{question:"自助排盘",locale:"zh",mode:"time",timeZone:"Asia/Shanghai",participants:input.participants}})).status,200);
    assert.equal((await send("/api/cases",{input})).status,401);
    assert.equal((await fetch(origin+"/api/admin/users")).status,401);
    assert.equal((await send("/api/chart/professional",{input},{Origin:"https://wrong.invalid"})).status,403);
    for(let i=0;i<8;i++)assert.equal((await send("/api/chart/professional",{input})).status,200);
    const blocked=await send("/api/chart",{input},{"X-Forwarded-For":"8.8.8.8","CF-Connecting-IP":"1.2.3.4"});assert.equal(blocked.status,429);
  } finally {await db`DELETE FROM rate_limits WHERE key LIKE 'public-chart:%'`;await db.end();}
});
