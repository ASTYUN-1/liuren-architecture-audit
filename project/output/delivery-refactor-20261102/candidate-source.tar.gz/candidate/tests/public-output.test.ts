import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { join, resolve, sep } from "node:path";
import { tmpdir } from "node:os";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";
import { loadPublicOutputPolicy, buildPublicMainPrompt, assertPublicText, preparePublicWarnings } from "../src/agent/public-output";
import { productionConfig } from "../src/agent/runtime";
import { KnowledgeRelease, REQUIRED_SKILLS } from "../src/agent/knowledge";
import { ToolAudit, createTaskTools } from "../src/agent/tools";
import { calculateChart, publicChart } from "../src/engine/liuren";
import type { CaseInput } from "../src/server/contracts";

const header = '---\nname: wenheng-public-output\ndescription: Website-only public output constraints.\nmetadata:\n  version: "1.0.0"\n---\n';
test("加载失败明确报错；校验名称、版本和非空正文，错误不回显私有路径", t => {
  const root = mkdtempSync(join(tmpdir(), "wenheng-public-output-test-"));
  t.after(() => { assert(resolve(root).startsWith(resolve(tmpdir()) + sep + "wenheng-public-output-test-")); rmSync(root, { recursive: true, force: true }); });
  assert.throws(() => loadPublicOutputPolicy(root), { message: "public_output_policy_not_configured" });
  const dir = join(root, "website-skills", "wenheng-public-output"); mkdirSync(dir, { recursive: true });
  const file = join(dir, "SKILL.md");
  for (const source of ["missing frontmatter", header, header.replace("wenheng-public-output", "wrong-name") + "body", header.replace("1.0.0", "9.0.0") + "body", header.replace('"1.0.0"', '"1.0.0') + "body"]) {
    writeFileSync(file, source);
    assert.throws(() => loadPublicOutputPolicy(root), { message: "public_output_policy_invalid" });
  }
  const source = header + "# 完整规则\n" + "不可丢失的完整约束。".repeat(10000) + "\nEND_OF_POLICY";
  writeFileSync(file, source);
  const policy = loadPublicOutputPolicy(root);
  assert.equal(policy.text, source);
  assert.equal(policy.hash, createHash("sha256").update(source).digest("hex"));
  assert.equal(policy.version, "1.0.0");
  const prompt = buildPublicMainPrompt("base-analysis", policy);
  assert(prompt.includes(source));
  const config = productionConfig("http://127.0.0.1:1", "fixture", policy);
  assert(config.agent["liuren-main"].prompt.includes(source));
  assert.equal(config.agent["liuren-cases"].disable, true);
  assert(!("steps" in config.agent["liuren-main"]));
});

test("交付的真实规则完整加入默认网站主提示，专业技能仍通过原证据流程加载", () => {
  const policy = loadPublicOutputPolicy();
  const config = productionConfig("http://127.0.0.1:1", "fixture");
  assert(config.agent["liuren-main"].prompt.includes(policy.text));
  assert(config.agent["liuren-main"].prompt.includes("八个必做方法 skill"));
  assert(config.agent["liuren-main"].prompt.includes("内部 citations"));
  assert.equal(config.agent["liuren-cases"].disable, true);
  const release = new KnowledgeRelease();
  assert(!release.list().some(doc => doc.id.includes("wenheng-public-output")));
  assert(release.read("skill:daliuren/SKILL.md").text.includes("不降低分析"));
  assert(release.read("skill:liuren-cases/SKILL.md").text.includes("内部材料仍必须包含来源id"));
});

test("拒绝明显内部标识，普通数字、日期、业务词和公网业务链接可用", () => {
  for (const text of [
    "来源：C:\\private\\case.md", "来源：C:/private/case.md", "来源：\\\\server\\cases\\entry.md", "来源：/opt/wenheng/resources/case.md",
    "来源：[记录](/home/worker/cases.md)", "file:///tmp/report.md", "skill:sanbu-duanke/SKILL.md", "case:0123456789abcdef0123",
    "参考 case 10 的做法", "参考 CASE-10", "参考案例编号：10", "案例项目库/感情占/记录.md", ".opencode/skills/daliuren/SKILL.md",
    "website-skills/wenheng-public-output/SKILL.md", "调用 read_knowledge", "wenheng_submit_report 完成", "使用 sanbu-duanke", '内部 {"chartHash":"abc"}',
    "<script>alert(1)</script>", "DEEPSEEK_API_KEY=do-not-echo",
  ]) {
    assert.throws(() => assertPublicText("content", text), { message: "public_output_rejected:content" }, text);
  }
  for (const text of [
    "10 月 17 日前沟通，预算 1000 元，优先确认合同。", "案例与经验只能作参考，具体条件仍需核实。", "请查看 https://example.com/home/products?case=10 ，核对业务合同。",
    "请在 2026/10/17 之前给出反馈。", "The customer has 10 cases pending. Please confirm the contract on 2026-10-17.",
    "本盘类神受制，结合三传变化，落实仍有阻力；这不能直接证明对方已经拒绝。空亡的影响须结合本题条件判断。",
  ]) assert.doesNotThrow(() => assertPublicText("content", text));
});

test("引擎警告只作已知定向白话转换，未知限制原样保留且同样过闸门", () => {
  const source = [
    "纯四柱未提供真实日期，不生成节气、年龄、行年或公历应期。",
    "四柱真实日期已核对；未提供精确时刻，不推测交节时分。",
    "本人出生日期处于立春换年日，缺出生时刻，年命及行年起算需确认。",
    "对方仅提供出生年份，本命按该年立春后年柱暂取；立春前出生需补充日期确认。",
    "人物资料不足的年命、行年判断省略；已知本命保留。",
    "补充材料尚未核实，不能确定合同已签署。",
  ];
  const zh = preparePublicWarnings(source, ["请核对近期是否有新的书面通知。"], "zh");
  assert.equal(zh.length, 7);
  assert(zh[0].includes("真实日期") && zh[0].includes("年龄") && zh[0].includes("节气") && zh[0].includes("不提供具体公历日期"));
  assert(zh[1].includes("准确时刻")); assert(zh[2].includes("本人") && zh[2].includes("立春当天"));
  assert(zh[3].includes("对方") && zh[3].includes("立春之前") && zh[3].includes("暂按"));
  assert(zh[4].includes("省略") && zh[4].includes("保留")); assert.equal(zh[5], source[5]);
  assert.equal(zh[6], "请核对近期是否有新的书面通知。");
  assert(preparePublicWarnings(source.slice(0, 5), [], "en").every(text => !/[年命行节]/.test(text)));
  assert.throws(() => preparePublicWarnings(["未知警告含 /opt/wenheng/private"], [], "zh"), { message: "public_output_rejected:warnings[0]" });
});

const input: CaseInput = { question: "我们能复合吗", locale: "zh", mode: "time", time: "2026-10-15T05:00:00Z", timeZone: "Asia/Shanghai", participants: [] };
test("运行入口缺少或损坏规则时零模型调用、零成本、零预留，避免被 worker 当作丢失进程估费", t => {
  const root = mkdtempSync(join(tmpdir(), "wenheng-public-output-test-"));
  t.after(() => { assert(resolve(root).startsWith(resolve(tmpdir()) + sep + "wenheng-public-output-test-")); rmSync(root, { recursive: true, force: true }); });
  const runtimeUrl = new URL("../src/agent/runtime.ts", import.meta.url).href;
  for (const expected of ["public_output_policy_not_configured", "public_output_policy_invalid"]) {
    if (expected.endsWith("invalid")) {
      const dir = join(root, "website-skills", "wenheng-public-output"); mkdirSync(dir, { recursive: true }); writeFileSync(join(dir, "SKILL.md"), "invalid policy");
    }
    const code = `
      import assert from 'node:assert/strict';
      const {runInterpretation,InterpretationError}=await import(${JSON.stringify(runtimeUrl)});
      let fetchCalls=0; globalThis.fetch=async()=>{fetchCalls++;throw new Error('Unexpected request');};
      try {await runInterpretation({taskId:'synthetic',caseId:'synthetic',kind:'initial',input:${JSON.stringify(input)},history:[],apiKey:'fixture-only'});assert.fail('Expected policy failure');}
      catch(error){assert(error instanceof InterpretationError);assert.equal(error.code,${JSON.stringify(expected)});assert.equal(error.usage.costCny,0);assert.equal(error.usage.reservedCny,0);assert.equal(error.usage.requests,0);assert.equal(error.usage.toolCalls,0);}
      assert.equal(fetchCalls,0);
    `;
    const result = spawnSync(process.execPath, ["--import", "tsx", "--input-type=module", "--eval", code], {
      cwd: fileURLToPath(new URL("..", import.meta.url)), env: { ...process.env, WENHENG_PROJECT_ROOT: root, NODE_ENV: "test", WENHENG_RUNTIME_FIXTURE: "0" }, encoding: "utf8", timeout: 30000, windowsHide: true,
    });
    assert.equal(result.status, 0, result.stderr || result.error?.message || "Child process failed");
  }
});

function preparedAudit(kind: "initial" | "followup" = "initial", eventInput = input) {
  const release = new KnowledgeRelease();
  const audit = new ToolAudit({ taskId: "synthetic-public-output", caseId: "synthetic", kind, input: eventInput, history: [], ...(kind === "followup" ? { previousChart: calculateChart(eventInput) } : {}) }, release);
  // Simulate already accepted analysis stages; these tests isolate the actual
  // MCP submission boundary, not model reasoning or predictive accuracy.
  audit.chartRead = true; audit.caseSearched = true; audit.experienceSearched = true;
  audit.readIds.add("skill:daliuren/SKILL.md");
  for (const skill of REQUIRED_SKILLS) audit.stages.set(skill, { fixture: true });
  const caseHit = release.search({ category: "感情占" })[0]; assert(caseHit);
  audit.caseHits.add(caseHit.id);
  const ids = [`skill:${REQUIRED_SKILLS[0]}/SKILL.md`, `skill:${REQUIRED_SKILLS[1]}/SKILL.md`, caseHit.id];
  const citations = ids.map(id => { audit.readIds.add(id); return { id, quote: release.read(id).text.slice(-100).trim() }; });
  const report = { title: "关于这段关系的判断", summary: "目前仍有沟通的余地，但能否推进，需要观察对方是否愿意给出明确而持续的回应。", content: "目前看仍有沟通的余地，但不宜把一次回应视为关系已经恢复。建议先用一次简短、没有施压的沟通确认对方意愿，再观察是否有持续行动。若对方持续回避，请尊重边界，暂停追问。".repeat(4), warnings: ["当前结论以已提供的背景为限。"], citations };
  return { audit, report };
}
async function withTools(audit: ToolAudit, body: (client: Client) => Promise<void>) {
  const server = createTaskTools(audit), client = new Client({ name: "public-output-tests", version: "1.0.0" });
  const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
  await Promise.all([server.connect(serverTransport), client.connect(clientTransport)]);
  try { await body(client); } finally { await client.close(); await server.close(); }
}

test("真实 MCP submit_report 校验所有公开字段，拒绝时不保存候选或回显泄漏原文", async () => {
  for (const kind of ["initial", "followup"] as const) for (const field of ["title", "summary", "content", "warnings"] as const) {
    const { audit, report } = preparedAudit(kind);
    const marker = " C:\\private\\very-secret-record.md";
    const bad = { ...report, [field]: field === "warnings" ? [marker] : report[field] + marker };
    await withTools(audit, async client => {
      const result = await client.callTool({ name: "submit_report", arguments: bad });
      assert.equal(result.isError, true, kind + ":" + field);
      assert(JSON.stringify(result).includes("public_output_rejected:" + field));
      assert(!JSON.stringify(result).includes("very-secret-record"));
      assert.equal(audit.candidate, undefined);
      assert.equal(audit.evidence.length, 0);
    });
  }
});

test("真实 MCP 成功主报告保留内部 citations，公开字段白话且原公开盘面不改", async () => {
  const { audit, report } = preparedAudit();
  const expectedChart = publicChart(audit.chart);
  await withTools(audit, async client => {
    const result = await client.callTool({ name: "submit_report", arguments: report });
    assert(!result.isError, JSON.stringify(result));
    assert.equal(audit.candidate?.report?.content, report.content);
    assert.deepEqual(audit.candidate?.report?.chart, expectedChart);
    assert.deepEqual(audit.evidence.map(e => ({ id: e.id, quote: e.quote })), report.citations);
    assert(audit.evidence.some(e => e.id.startsWith("case:") && e.source));
    assert(!JSON.stringify(audit.candidate).includes('"citations"'));
    assert(!JSON.stringify(audit.candidate).includes("case:"));
    assert(audit.candidate?.report?.warnings?.some(w => w.includes("人物资料尚不完整")));
  });
});

test("真实 MCP 追问只交付通过校验的正文；未知引擎泄漏警告拒绝保存", async () => {
  const { audit, report } = preparedAudit("followup");
  await withTools(audit, async client => {
    const result = await client.callTool({ name: "submit_report", arguments: report });
    assert(!result.isError); assert.deepEqual(audit.candidate, { answer: report.content });
  });
  const other = preparedAudit(); other.audit.chart.warnings.push("未知限制位于 /opt/wenheng/private");
  await withTools(other.audit, async client => {
    const result = await client.callTool({ name: "submit_report", arguments: other.report });
    assert.equal(result.isError, true); assert.equal(other.audit.candidate, undefined);
  });
});

test("用户人物称谓恰似内部编号时，固定引擎警告使用中性称谓，保留限制且不改变原盘", async () => {
  for (const locale of ["zh", "en"] as const) for (const role of ["case-010", "read_case", "业务合作人"]) {
    const eventInput: CaseInput = { ...input, locale, participants: [{ role, gender: "female", birthYear: 1995 }] };
    const { audit, report } = preparedAudit("initial", eventInput);
    const originalChart = structuredClone(audit.chart);
    assert(audit.chart.warnings.some(warning => warning.startsWith(role + "仅提供出生年份")));
    await withTools(audit, async client => {
      const result = await client.callTool({ name: "submit_report", arguments: report });
      assert(!result.isError, JSON.stringify(result));
      const warnings = audit.candidate?.report?.warnings?.join(" ") ?? "";
      const expectedRole = role === "业务合作人" ? role : locale === "zh" ? "该人物" : "this person";
      assert(warnings.includes(expectedRole));
      assert(warnings.includes(locale === "zh" ? "出生年份" : "birth year"));
      assert(warnings.includes(locale === "zh" ? "立春之前" : "before that boundary"));
      assert.deepEqual(audit.chart, originalChart);
    });
  }
});

test("真实 MCP 澄清使用同一公开闸门，正常补充问题保持可交付", async () => {
  const { audit } = preparedAudit();
  await withTools(audit, async client => {
    const rejected = await client.callTool({ name: "submit_clarification", arguments: { question: "请按 case 10 补充资料" } });
    assert.equal(rejected.isError, true); assert.equal(audit.candidate, undefined);
    const question = "你说的对方是否就是原问题中的同一个人？";
    const accepted = await client.callTool({ name: "submit_clarification", arguments: { question } });
    assert(!accepted.isError); assert.deepEqual(audit.candidate, { clarification: question });
  });
});

test("公开格式合格不能绕过原有八步完成及真实引用门槛", async () => {
  const { audit, report } = preparedAudit(); audit.stages.delete(REQUIRED_SKILLS[0]);
  await withTools(audit, async client => {
    const result = await client.callTool({ name: "submit_report", arguments: report });
    assert.equal(result.isError, true); assert(JSON.stringify(result).includes("workflow_incomplete")); assert.equal(audit.candidate, undefined);
  });
  const other = preparedAudit(); other.report.citations[0].quote = "这是一条不存在于来源中的伪造引文，不得接受。";
  await withTools(other.audit, async client => {
    const result = await client.callTool({ name: "submit_report", arguments: other.report });
    assert.equal(result.isError, true); assert(JSON.stringify(result).includes("unverified_citation")); assert.equal(other.audit.candidate, undefined);
  });
  const noCase = preparedAudit(), extra = `skill:${REQUIRED_SKILLS[2]}/SKILL.md`;
  noCase.audit.readIds.add(extra);
  noCase.report.citations[2] = { id: extra, quote: noCase.audit.release.read(extra).text.slice(-100).trim() };
  await withTools(noCase.audit, async client => {
    const result = await client.callTool({ name: "submit_report", arguments: noCase.report });
    assert.equal(result.isError, true); assert(JSON.stringify(result).includes("caseCitationRequired")); assert.equal(noCase.audit.candidate, undefined);
  });
});
