import test from 'node:test';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {InMemoryTransport} from '@modelcontextprotocol/sdk/inMemory.js';
import {KnowledgeRelease} from '../src/agent/knowledge';
import {ToolAudit,createTaskTools} from '../src/agent/tools';
import {reportSubmissionSchema,type DeliveryDraft} from '../src/agent/delivery';
import {loadPublicOutputPolicy} from '../src/agent/public-output';
const root=resolve(process.env.WENHENG_WORKFLOW_RESOURCE_ROOT??'../../workflow-optimization-20261102/resource-candidate-v2');
const input={question:'是否录用，何时入职',locale:'zh' as const,mode:'time' as const,time:'2026-10-23T07:00:00Z',timeZone:'Asia/Shanghai',participants:[]};
const body='目前不能确定录用结果，需要核实招聘方是否已形成正式决定。现有材料没有确认通知、待遇与入职安排，不能用流程顺利替代结果已经落实。时间也应以招聘方明确通知为准，在信息补齐之前保留判断，不据此安排离职。';
const submission=()=>reportSubmissionSchema.parse({content:body,answers:[{questionId:'Q1',status:'undetermined',answer:'录用与时间均未确定，等待正式通知。',limitations:['缺少已确认的通知与入职安排。']}]});
function setup(onDraft?:(d:DeliveryDraft)=>Promise<void>,signal?:AbortSignal){const k=new KnowledgeRelease(root,{protocol:'liuren-v3'});const a=new ToolAudit({taskId:'synthetic',caseId:'synthetic',kind:'initial',input,history:[],deliveryProtocol:'delivery-v2',onDraft,signal},k);return {a,k,d:a.delivery!};}
function read(a:ToolAudit){let r=a.readChart();while(r.paginated&&!r.complete)r=a.readChart(r.missingPages[0],r.deliveryHash,3);a.readContext();}
function policy(a:ToolAudit){const p=loadPublicOutputPolicy(root);let r=a.prepareOutput('report',p,1,undefined,3);while(!r.complete)r=a.prepareOutput('report',p,r.missingPages[0],p.hash,3);}
function ready(a:ToolAudit){read(a);policy(a);}
async function connect(a:ToolAudit){const server=createTaskTools(a,loadPublicOutputPolicy(root)),client=new Client({name:'synthetic',version:'1'}),[x,y]=InMemoryTransport.createLinkedPair();await Promise.all([server.connect(y),client.connect(x)]);const call=async(name:string,args:unknown)=>{const r=await client.callTool({name,arguments:args as any});return {error:r.isError,data:JSON.parse((r.content as {text:string}[])[0].text)};};return {call,close:async()=>{await client.close();await server.close();}};}

test('rejected draft is durably saved before policy and all final checks, then retained with exact issues',async()=>{
 const saved:DeliveryDraft[]=[];const {a,d}=setup(async x=>{saved.push(x);});read(a);
 const r=await d.submit(submission());assert.equal(r.accepted,false);assert.equal(saved[0].issues.length,0);assert.equal(saved[0].submission.content,body);assert(saved[1].issues.some(x=>x.rule==='OUTPUT_POLICY_INCOMPLETE'));assert.equal(a.candidate,undefined);
});
test('noncritical audit gaps and unusable case hits do not discard a readable limited answer',async()=>{
 const {a,d}=setup();ready(a);a.caseHits.add('synthetic-unadopted');const r=await d.submit(submission());assert(r.accepted);a.assertComplete();assert.equal(d.receipt?.outcome,'limited');assert(a.candidate?.report?.content.includes('带限制回答'));assert.equal(a.candidate?.report?.delivery?.outcome,'limited');assert(!JSON.stringify(a.candidate?.report).includes('draftVersion'));assert(d.diagnostics().issues.some(x=>x.severity==='warning'));
});
test('answered claims need verified chart facts and fully delivered adopted method, without a citation quota',async()=>{
 const {a,k,d}=setup();ready(a);const s=submission();s.answers[0]={questionId:'Q1',status:'answered',answer:'此处只验证支持结构，不作真实录用预测。',limitations:[]};
 assert(d.check(s).issues.some(x=>x.rule==='ANSWER_BASIS_REQUIRED'));
 const id=k.liurenRuntime!.modules.positioning.id,p=k.page(id);s.answers[0].basis={facts:[{path:'sizhu.d',value:'wrong'}],sourceIds:[id],explanation:'合成验收核对固定盘事实与已读方法关联。'};
 const bad=d.check(s);assert(bad.issues.some(x=>x.rule==='FACT_MISMATCH'));assert(bad.issues.some(x=>x.rule==='SOURCE_INCOMPLETE'&&x.sourceId===id&&x.missingPages?.length===p.pageCount));
 for(let n=1;n<=p.pageCount;n++)a.readPage(id,n,p.deliveryHash);s.answers[0].basis.facts[0].value=a.chart.facts.sizhu.d;
 const first=await d.submit(s);assert(first.accepted);assert.equal(d.receipt?.outcome,'limited','actual required reading gaps must not be charged as a complete report');
 for(const source of [k.liurenRuntime!.entryId,...k.liurenRuntime!.required.map(key=>k.liurenRuntime!.modules[key].id),...a.contract!.readingPlan().map(x=>x.id)]){const page=k.page(source);for(let n=1;n<=page.pageCount;n++)a.readPage(source,n,page.deliveryHash);}
 const r=await d.submit(s);assert(r.accepted);assert.equal(d.receipt?.outcome,'complete');assert.equal(a.evidence.length,0);
});
test('unread, cross-task and forged quotes block adopted evidence with a precise source',async()=>{
 const {a,k,d}=setup();ready(a);const s=submission(),id=k.liurenRuntime!.modules.positioning.id;s.citations=[{id,quote:'这是不存在的合成引文'}];
 assert(d.check(s).issues.some(x=>x.rule==='SOURCE_INCOMPLETE'&&x.sourceId===id));const p=k.page(id);for(let n=1;n<=p.pageCount;n++)a.readPage(id,n,p.deliveryHash);
 assert(d.check(s).issues.some(x=>x.rule==='QUOTE_MISMATCH'));s.citations=[{id:'other-task-private-source',quote:'不存在'}];assert.equal((await d.submit(s)).accepted,false);
});
test('multiple blockers identify independent fields; patching preserves an existing body',async()=>{
 const {a,d}=setup();ready(a);const c=await connect(a);try{const s=submission();s.content+='\ncheck_readiness';s.answers[0].limitations=[];
 const failed=await c.call('submit_report',s);assert.equal(failed.data.accepted,false);assert(failed.data.issues.some((x:any)=>x.field==='content'));assert(failed.data.issues.some((x:any)=>x.rule==='LIMITATION_REQUIRED'));
 const fixed=await c.call('repair_report',{draftVersion:failed.data.draftVersion,patch:{content:body,answers:submission().answers}});assert.equal(fixed.data.accepted,true);assert.equal(d.draft?.submission.content,body);
 const stale=await c.call('repair_report',{draftVersion:failed.data.draftVersion,patch:{title:'旧修订'}});assert.equal(stale.error,true);
 }finally{await c.close();}
});
test('unrelated successful reads cannot reset the unresolved issue or no-progress rounds',async()=>{
 const {a,d}=setup();ready(a);const s=submission();s.answers[0].limitations=[];
 for(let n=0;n<3;n++){await d.submit(s);a.readContext();d.check();}
 assert(d.repairStalled);const id=d.diagnostics().issues.find(x=>x.rule==='LIMITATION_REQUIRED')!.id;assert.equal(d.diagnostics().issues.find(x=>x.id===id)?.state,'active');
 s.answers[0].limitations=['缺少正式通知。'];assert((await d.submit(s)).accepted);assert.equal(d.diagnostics().issues.find(x=>x.id===id)?.state,'resolved');
});
test('cancellation while saving cannot accept or publish the candidate',async()=>{
 const abort=new AbortController();const {a,d}=setup(async()=>{abort.abort(new Error('synthetic_cancel'));},abort.signal);ready(a);await assert.rejects(()=>d.submit(submission()),/synthetic_cancel/);assert.equal(a.candidate,undefined);assert.equal(d.receipt,undefined);assert.equal(d.draft?.submission.content,body);
});
test('snapshot change during durable save invalidates confirmation',async()=>{
 let a!:ToolAudit;const f=setup(async()=>{a.delivery!.changed();});a=f.a;ready(a);await assert.rejects(()=>f.d.submit(submission()),/snapshot_changed/);assert.equal(a.candidate,undefined);
});
test('draft persistence failure cannot produce a delivered result',async()=>{
 const {a,d}=setup(async()=>{throw new Error('synthetic_storage_failure');});ready(a);await assert.rejects(()=>d.submit(submission()),/delivery_storage_unavailable/);assert.equal(d.fatalError,'delivery_storage_unavailable');assert.equal(a.candidate,undefined);
});
test('new protocol binds optional metadata while explicit stale identity is rejected',async()=>{
 const {a}=setup();read(a);const c=await connect(a);try{const q={questionId:'Q1',originalQuestion:'是否录用',target:'本次应聘',dimension:'result',stage:'面试之后',successCriterion:'正式录用通知',domains:[],mechanisms:[]};assert.equal((await c.call('register_questions',{questions:[q]})).error,undefined);
 const base={schemaVersion:3,workflow:Array.from({length:11},(_,i)=>({stage:i+1,summary:'合成结构验收，不作专业预测。',status:'checked',sourceIds:[],facts:[]}))};
 assert.equal((await c.call('record_workflow',{...base,chartHash:'stale'})).data.code,'shared_workflow_identity_mismatch');assert.equal((await c.call('record_workflow',base)).data.code,'judgment_modules_incomplete');
 }finally{await c.close();}
});
test('unsafe markup, private fields and explicit truncation remain hard blockers',()=>{
 const {a,d}=setup();ready(a);for(const text of ['<iframe src="https://example.invalid"></iframe>','[output truncated]','DEEPSEEK_API_KEY']){const s=submission();s.content+='\n'+text;assert.equal(d.check(s).canSubmit,false);assert(!JSON.stringify(d.diagnostics()).includes(text));}
});
test('structured diagnostics paginate without losing active issues or returning the submitted body',()=>{
 const {a,d}=setup();ready(a);const s=submission();s.citations=Array.from({length:30},(_,i)=>({id:'synthetic-source-'+i,quote:'private-quote'}));d.draft={id:'synthetic',version:1,snapshot:0,hash:'synthetic',submission:s,issues:[],at:new Date().toISOString()};const r=d.check(),ids:string[]=[];let offset:number|null=0;while(offset!==null){const page=d.page(r,offset);assert(Buffer.byteLength(JSON.stringify(page))<40*1024);ids.push(...page.issues.map(x=>x.id));offset=page.nextOffset;}assert.equal(ids.length,r.issueTotal);assert.equal(new Set(ids).size,ids.length);assert(!JSON.stringify(d.diagnostics()).includes('private-quote'));assert(!JSON.stringify(d.diagnostics()).includes(body));
});

test('single-question repair keeps the other answer, citations, warnings and global limitations intact',async()=>{
 const {a,k,d}=setup();ready(a);const c=await connect(a);try{
 const q=(questionId:string,originalQuestion:string)=>({questionId,originalQuestion,target:'本次招聘',dimension:'result',stage:'面试之后',successCriterion:'正式通知',domains:[],mechanisms:[]});
 assert.equal((await c.call('register_questions',{questions:[q('Q1','是否录用'),q('Q2','何时入职')]})).error,undefined);
 const id=k.liurenRuntime!.modules.positioning.id,p=k.page(id);for(let n=1;n<=p.pageCount;n++)a.readPage(id,n,p.deliveryHash);
 const s=submission();s.citations=[{id,quote:k.read(id).text.slice(-80)}];s.warnings=['这是合成验收。'];s.outcome='limited';s.limitations=['实际通知未核实。'];s.answers.push({questionId:'Q2',status:'undetermined',answer:'无法确定具体入职时间。',limitations:[]});
 const failed=await c.call('submit_report',s);assert.equal(failed.data.accepted,false);
 const fixed=await c.call('repair_report',{draftVersion:failed.data.draftVersion,patch:{title:'局部修复验收'},answerPatches:[{questionId:'Q2',patch:{limitations:['缺少已经确认的入职安排。']}}]});assert.equal(fixed.data.accepted,true);
 assert.deepEqual(d.draft?.submission.answers[0],s.answers[0]);assert.deepEqual(d.draft?.submission.citations,s.citations);assert.deepEqual(d.draft?.submission.warnings,s.warnings);assert.deepEqual(d.draft?.submission.limitations,s.limitations);assert.equal(d.draft?.submission.outcome,'limited');assert.equal(d.draft?.submission.content,body);
 a.candidate!.report!.content+='changed';assert.throws(()=>a.assertComplete(),/delivery_content_changed/);
 }finally{await c.close();}
});
