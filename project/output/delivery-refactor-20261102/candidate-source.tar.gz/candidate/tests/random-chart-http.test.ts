import {test} from "node:test";
import assert from "node:assert/strict";
import {sqlClient} from "../src/server/db";
if(!process.env.DATABASE_URL||!/wenheng_test/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error("Isolated wenheng_test required");
const origin=process.env.APP_URL||"http://127.0.0.1:3100";
test("匿名启动停止并取得真实十二宫，坏回执和异源拒绝，分析仍需账户",async()=>{
  const db=sqlClient(),send=(value:unknown,from=origin)=>fetch(origin+"/api/chart/random",{method:"POST",headers:{Origin:from,"Content-Type":"application/json"},body:JSON.stringify(value)});
  await db`DELETE FROM rate_limits WHERE key LIKE 'public-chart:%'`;
  try{
    const first=await send({action:"start",rules:{}});assert.equal(first.status,200);const seed=(await first.json()).data;
    const stop=await send({action:"stop",ticket:seed.ticket,number:9});assert.equal(stop.status,200);const selected=(await stop.json()).data;
    assert.equal(selected.chart.palaces.length,12);assert.equal(selected.chart.palaces[8].heaven,seed.chart.monthGeneral);assert.equal(selected.chart.hourBranch,"申");assert(selected.ticket);
    assert.equal((await send({action:"stop",ticket:seed.ticket+"bad",number:9})).status,400);
    assert.equal((await send({action:"stop",ticket:seed.ticket,number:0})).status,400);
    assert.equal((await send({action:"start",rules:{}},"https://wrong.invalid")).status,403);
    const caseResponse=await fetch(origin+"/api/cases",{method:"POST",headers:{Origin:origin,"Content-Type":"application/json"},body:JSON.stringify({input:{}})});assert.equal(caseResponse.status,401);
  }finally{await db`DELETE FROM rate_limits WHERE key LIKE 'public-chart:%'`;await db.end();}
});
