import test from "node:test";
import assert from "node:assert/strict";
import { runInterpretation } from "../src/agent/runtime";
import type { CaseInput } from "../src/server/contracts";
import { KnowledgeRelease, REQUIRED_SKILLS } from "../src/agent/knowledge";
import { calculateChart, DEFAULT_RULES } from "../src/engine/liuren";
import {startRandomChart,stopRandomChart} from "../src/engine/random-chart";

test("实际OpenCode可越过200模型请求且保留准确计数",{skip:process.env.WENHENG_RUNTIME_FIXTURE!=="1",timeout:300000},async()=>{
 const original=globalThis.fetch;let requests=0,toolRounds=0;
 globalThis.fetch=(async(url:any,init:any)=>{
  if(String(url)!=="https://api.deepseek.com/v1/chat/completions")return original(url,init);
  const body=JSON.parse(init.body);requests++;
  const hasTool=body.tools?.some((t:any)=>t.function.name==="wenheng_search_knowledge");
  const actions=hasTool&&toolRounds<205?[{id:`extended_${++toolRounds}`,type:"function",function:{name:"wenheng_search_knowledge",arguments:JSON.stringify({query:`extended_request_${toolRounds}`,scope:"skills"})}}]:[];
  return new Response(JSON.stringify({id:`extended_${requests}`,created:1,model:"deepseek-flash",choices:[{index:0,message:{role:"assistant",content:actions.length?null:"fixture done without report",reasoning_content:"fixture",...(actions.length?{tool_calls:actions}:{})},finish_reason:actions.length?"tool_calls":"stop"}],usage:{prompt_tokens:100,completion_tokens:100}}),{status:200});
 }) as typeof fetch;
 try{
  await assert.rejects(runInterpretation({taskId:"extended",caseId:"extended",kind:"initial",input:{question:"隔离模型轮次上限验证",locale:"zh",mode:"time",time:"2026-10-15T05:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[],apiKey:"not-a-real-key",signal:AbortSignal.timeout(270000)},{protocol:"liuren-v3"}),error=>{
   const e=error as Error&{usage?:{requests:number;toolCalls:number}};assert.equal(e.message,"report_not_submitted");assert.equal(e.usage?.requests,206);assert.equal(e.usage?.toolCalls,205);return true;
  });
  assert.equal(requests,206);assert.equal(toolRounds,205);
 }finally{globalThis.fetch=original;}
});

test("实际 OpenCode 工具次数超过200仍继续，不绕过最终交付校验",{skip:process.env.WENHENG_RUNTIME_FIXTURE!=="1",timeout:300000},async()=>{
 const original=globalThis.fetch;let requests=0,toolRounds=0;
 globalThis.fetch=(async(url:any,init:any)=>{
  if(String(url)!=="https://api.deepseek.com/v1/chat/completions")return original(url,init);
  const body=JSON.parse(init.body);requests++;
  const hasTool=body.tools?.some((t:any)=>t.function.name==="wenheng_search_knowledge");
  if(hasTool)toolRounds++;
  // Vary literal queries so OpenCode's separate identical-call loop guard does
  // not terminate first; this test specifically exercises our shared tool limit.
  const actions=hasTool&&toolRounds<=18?Array.from({length:12},(_,i)=>({id:`limit_${toolRounds}_${i}`,type:"function",function:{name:"wenheng_search_knowledge",arguments:JSON.stringify({query:`fixture_budget_${toolRounds}_${i}`,scope:"skills"})}})):[];
  return new Response(JSON.stringify({id:`limit_${requests}`,created:1,model:"deepseek-flash",choices:[{index:0,message:{role:"assistant",content:actions.length?null:"fixture done",reasoning_content:"fixture",...(actions.length?{tool_calls:actions}:{})},finish_reason:actions.length?"tool_calls":"stop"}],usage:{prompt_tokens:100,completion_tokens:100}}),{status:200});
 }) as typeof fetch;
 try{
  await assert.rejects(runInterpretation({taskId:"limit",caseId:"limit",kind:"initial",input:{question:"隔离额度失败测试",locale:"zh",mode:"time",time:"2026-10-15T05:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[],apiKey:"not-a-real-key",signal:AbortSignal.timeout(270000)},{protocol:"liuren-v3"}),error=>{
   const e=error as Error&{usage?:{toolCalls:number;requests:number}};assert.equal(e.message,"report_not_submitted",JSON.stringify({requests,toolRounds,toolCalls:e.usage?.toolCalls,usageRequests:e.usage?.requests}));assert.equal(e.usage?.toolCalls,216);return true;
  });
  assert.equal(requests,19);
 }finally{globalThis.fetch=original;}
});

