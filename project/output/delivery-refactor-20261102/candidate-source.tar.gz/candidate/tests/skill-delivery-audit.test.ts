import test from "node:test";
import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {mkdirSync,writeFileSync} from "node:fs";
import {KnowledgeRelease,REQUIRED_SKILLS} from "../src/agent/knowledge";
import {runInterpretation} from "../src/agent/runtime";

// Real OpenCode + MCP transport; intercept only the official supplier endpoint.
// Reconstruct pages from the NEXT actual model request, not the MCP server copy.
test("分页后的完整 skill 真正送达 OpenCode 模型请求，逐字与哈希校验",{skip:process.env.WENHENG_RUNTIME_FIXTURE!=="1",timeout:90000},async()=>{
 const original=globalThis.fetch,release=new KnowledgeRelease();
 const ids=["daliuren",...REQUIRED_SKILLS,"lianai-panduan"].map(s=>`skill:${s}/SKILL.md`);
 if(release.references().total){
  for(const query of ["书籍库/经典古籍/佚名/壬归.txt","经验日志/古籍-壬归"]){const ref=release.searchText({query,scope:"references"}).results[0];assert(ref);ids.push(ref.id);}
 }
 const received=new Map<string,Map<number,string>>();let calls=0,clarified=false,catalogReceived=false,referenceSearchReceived=false;
 const pending=ids.flatMap(id=>{const first=release.page(id);return Array.from({length:first.pageCount},(_,i)=>({id,page:i+1,expectedHash:first.deliveryHash}));});
 const plannedCalls=pending.length;assert(plannedCalls+3<=64);
 function inspect(value:unknown):void {
  if(typeof value==="string"){try{const v=JSON.parse(value);if(v&&typeof v==="object")inspect(v);}catch{}return;}
  if(Array.isArray(value)){value.forEach(inspect);return;}
  if(!value||typeof value!=="object")return;
  const v=value as any;
  if(Array.isArray(v.documents)&&Array.isArray(v.requiredStages)){assert.equal(v.documents.length,release.list().length);catalogReceived=true;}
  if(v.match==="literal"&&Array.isArray(v.results)&&v.results.some((r:any)=>r.kind==="reference"))referenceSearchReceived=true;
  if(ids.includes(v.id)&&typeof v.text==="string"&&Number.isInteger(v.page)&&v.deliveryHash){
   assert.equal(v.deliveryHash,release.page(v.id).deliveryHash);
   const pages=received.get(v.id)??new Map();pages.set(v.page,v.text);received.set(v.id,pages);
  }
  Object.values(v).forEach(inspect);
 }
 globalThis.fetch=(async(url:any,init:any)=>{
  if(String(url)!=="https://api.deepseek.com/v1/chat/completions")return original(url,init);
  const body=JSON.parse(init.body);inspect(body.messages);calls++;
  assert.equal(body.reasoning_effort,"high");assert.deepEqual(body.thinking,{type:"enabled"});
  const actions=pending.length?pending.splice(0,12).map((args,index)=>({id:`read_${calls}_${index}`,type:"function",function:{name:"wenheng_read_knowledge",arguments:JSON.stringify(args)}})):!clarified?[{id:"clarify",type:"function",function:{name:"wenheng_submit_clarification",arguments:JSON.stringify({question:"隔离文档送达审计结束，本任务不生成预测报告。"})}}]:[];
  if(calls===1){actions.push({id:"catalog",type:"function",function:{name:"wenheng_list_knowledge",arguments:"{}"}});if(release.references().total)actions.push({id:"reference_search",type:"function",function:{name:"wenheng_search_knowledge",arguments:JSON.stringify({query:"经验日志/古籍-壬归",scope:"references"})}});}
  if(!pending.length&&actions.some(a=>a.id==="clarify"))clarified=true;
  return new Response(JSON.stringify({id:`audit_${calls}`,created:1,model:"deepseek-flash",choices:[{index:0,message:{role:"assistant",content:actions.length?null:"文档审计结束",reasoning_content:"fixture-only",...(actions.length?{tool_calls:actions}:{})},finish_reason:actions.length?"tool_calls":"stop"}],usage:{prompt_tokens:100,completion_tokens:100}}),{status:200});
 }) as typeof fetch;
 try{
  const run=await runInterpretation({taskId:"skill-delivery-audit",caseId:"synthetic",kind:"initial",input:{question:"虚构文档传递测试",locale:"zh",mode:"time",time:"2026-10-15T07:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[],apiKey:"fixture-only"});
  const results=ids.map(id=>{const p=release.page(id),seen=received.get(id),text=Array.from({length:p.pageCount},(_,i)=>seen?.get(i+1)??"").join("");return {id,bytes:p.totalBytes,pages:p.pageCount,receivedPages:seen?.size??0,deliveryHash:p.deliveryHash,receivedHash:createHash("sha256").update(text).digest("hex"),complete:seen?.size===p.pageCount&&text===release.read(id).text};});
  mkdirSync("test-results/ai-rule-audit",{recursive:true});
  writeFileSync("test-results/ai-rule-audit/skill-delivery.json",JSON.stringify({results,requests:calls,toolCalls:run.usage.toolCalls,coverage:run.usage.knowledgeCoverage},null,2));
  assert(results.every(r=>r.complete&&r.receivedHash===r.deliveryHash),JSON.stringify(results));
  assert(run.usage.knowledgeCoverage.every(c=>c.complete));assert(catalogReceived,"完整技能目录必须真正到达下一轮模型请求");if(release.references().total)assert(referenceSearchReceived);
 }finally{globalThis.fetch=original;}
});
