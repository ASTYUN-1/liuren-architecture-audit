import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {SMTPServer} from 'smtp-server';
import {sqlClient} from '../src/server/db';
import {type Actor} from '../src/server/http';
import {creditPoints,finishHold,reservePoints,walletTotals,walletView,returnServiceCredits,rechargeCode} from '../src/server/points';
import {requestHuman,humanAction,maintainPoints} from '../src/server/human-assist';
import {humanAssistAdminView,quickRedeemHuman} from '../src/server/human-assist-admin';
import {defaultPointsConfig,savePointsConfig} from '../src/server/points-config';

if(!process.env.DATABASE_URL||!new URL(process.env.DATABASE_URL).pathname.includes('wenheng_test'))throw Error('isolated test database required');
const key='human-redeem-'+randomUUID(),origin='http://127.0.0.1:3199';
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:key,APP_URL:origin,BETTER_AUTH_SECRET:'isolated-human-redemption-secret-20261017',WENHENG_ENCRYPTION_KEY:'ab'.repeat(32),ADMIN_REQUIRE_2FA:'false'});
const db=sqlClient(),smtp=new SMTPServer({authOptional:true,disabledCommands:['STARTTLS'],onData(s,_session,done){s.resume();s.on('end',done);}}),caseId=randomUUID();
let owner:Actor,admin:Actor,ownerCookie='',adminCookie='';
const redeem={action:'redeem',serviceCompleted:true,summary:'已通过联系完成本次报告复核，解释重点与不确定性。'};
before(async()=>{
 await new Promise<void>(resolve=>smtp.listen(12539,'127.0.0.1',resolve));
 await db`INSERT INTO service_settings(key,value) VALUES(${'test:'+key},${db.json({emailProvider:'smtp',smtpHost:'127.0.0.1',smtpPort:12539,smtpSecure:false,smtpFrom:'test@example.invalid'})})`;
 const {getAuth}=await import('../src/server/auth');
 for(const isAdmin of [false,true]){
  const email=(isAdmin?'operator-':'customer-')+key+'@example.invalid';
  const r=await getAuth().handler(new Request(origin+'/api/auth/sign-up/email',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({name:isAdmin?'核销测试运营':'核销测试用户',email,password:'synthetic-redemption-test-password'})}));
  assert.equal(r.status,200);const user=(await r.json()).user,cookie=r.headers.getSetCookie().map(s=>s.split(';')[0]).join('; ');
  await db`UPDATE "user" SET email_verified=true WHERE id=${user.id}`;
  const a:Actor={...user,emailVerified:true,isAdmin};if(isAdmin){admin=a;adminCookie=cookie;}else{owner=a;ownerCookie=cookie;}
 }
 process.env.ADMIN_EMAILS=admin.email;
 await db`INSERT INTO cases(id,user_id,title,status,report) VALUES(${caseId},${owner.id},'核销测试档案','ready',${db.json({content:'synthetic report'})})`;
 // The operator has no practitioner role. Redemption must depend only on operator authorization.
 await db`INSERT INTO advisor_accounts(advisor_id,user_id) VALUES('congkui',${owner.id})`;
 const config={...defaultPointsConfig(),mode:'points' as const,humanEnabled:true};config.advisors=config.advisors.map(a=>({...a,wechatId:'test_contact',accepting:true}));await savePointsConfig(admin,config);
 await creditPoints(admin,{userId:owner.id,kind:'bonus',units:100000,reason:'隔离测试余额',idempotencyKey:randomUUID()});
});
after(async()=>{
 const ids=[owner?.id,admin?.id].filter(Boolean);
 if(ids.length){
  for(const table of ['human_assists','point_ledger','point_holds','point_lots','point_profiles'])await db.unsafe(`DELETE FROM ${table} WHERE user_id IN ($1,$2)`,ids);
  await db`DELETE FROM cases WHERE id=${caseId}`;await db`DELETE FROM audit_log WHERE actor_id IN ${db(ids)}`;
  await db`DELETE FROM rate_limits WHERE key IN (${'admin-human:'+admin?.id},${'admin-points:'+admin?.id})`;
  await db`DELETE FROM "user" WHERE id IN ${db(ids)}`;
 }
 await db`DELETE FROM service_settings WHERE key LIKE ${'test:'+key+'%'}`;await db.end();await new Promise<void>(resolve=>smtp.close(()=>resolve()));
});
async function book(state='pending'){
 const h=await requestHuman(owner,{caseId,advisorId:'congkui',question:'请复核这个隔离测试问题',idempotencyKey:randomUUID()});
 if(state!=='pending')await humanAction(admin,h.id,{action:'accept'});
 if(state==='review')await humanAction(admin,h.id,{action:'deliver',summary:'这是原来的服务摘要，供用户确认。'});
 if(state==='disputed')await humanAction(owner,h.id,{action:'dispute',reason:'需要核对是否实际提供服务'});
 return h;
}
async function hold(id:string){return (await db`SELECT * FROM point_holds WHERE id=${id}`)[0];}
async function route(method:string,cookie='',data?:unknown,extra:Record<string,string>={}){
 const {GET,POST}=await import('../src/app/api/admin/human-assists/route');
 return (method==='GET'?GET:POST)(new Request(origin+'/api/admin/human-assists',{method,headers:{Origin:origin,Cookie:cookie,'Content-Type':'application/json',...extra},body:data?JSON.stringify(data):undefined}),{});
}

test('operator can redeem pending, accepted and review; frozen balance becomes actual charge once',async()=>{
 for(const state of ['pending','accepted','review']){
  const before=await walletTotals(db,owner.id),h=await book(state),reserved=await walletTotals(db,owner.id);
  assert.equal(reserved.available,before.available-1500);assert.equal(reserved.frozen,before.frozen+1500);
  const r=await humanAction(admin,h.id,redeem);assert.equal(r.chargedUnits,1500);
  const after=await walletTotals(db,owner.id);assert.equal(after.available,reserved.available);assert.equal(after.frozen,before.frozen);
  const settled=await hold(h.id);assert.equal(settled.status,'settled');assert.equal(settled.snapshot.humanRedemption.operatorId,admin.id);
  const [booking]=await db`SELECT status,summary,deadline FROM human_assists WHERE id=${h.id}`;assert.equal(booking.status,'completed');assert.equal(booking.summary,redeem.summary);
  const [audit]=await db`SELECT actor_id,details FROM audit_log WHERE target_id=${h.id} AND action='human:redeem'`;assert.equal(audit.actor_id,admin.id);assert.equal(audit.details.chargedUnits,1500);
  const wallet=await walletView(owner);assert.equal(wallet.assists.find(a=>a.id===h.id)!.status,'completed');assert.equal(wallet.ledger.find(l=>l.hold_id===h.id&&l.action==='settled')!.charged_units,1500);
 }
});

test('quick redemption accepts the exact booking ID or live share code and remains idempotent',async()=>{
 const h=await book();const before=await walletTotals(db,owner.id);
 await assert.rejects(()=>quickRedeemHuman(owner,h.id),{code:'FORBIDDEN'});
 await assert.rejects(()=>quickRedeemHuman(admin,'no-such-booking-code'),{code:'NOT_FOUND'});
 const done=await quickRedeemHuman(admin,h.id);assert.equal(done.chargedUnits,1500);
 assert.equal((await walletTotals(db,owner.id)).frozen,before.frozen-1500);
 const retry=await quickRedeemHuman(admin,h.share.code);assert.equal(retry.alreadyCompleted,true);
 const [n]=await db`SELECT count(*)::int AS n FROM point_ledger WHERE hold_id=${h.id} AND action='settled'`;assert.equal(n.n,1);
 const h2=await book();await quickRedeemHuman(admin,h2.share.code);assert.equal((await hold(h2.id)).charged_units,1500);
 const h3=await book();await humanAction(owner,h3.id,{action:'cancel'});await assert.rejects(()=>quickRedeemHuman(admin,h3.share.code));assert.equal((await hold(h3.id)).charged_units,0);
});
test('concurrent retries settle once and preserve first summary; maintenance ignores completed booking',async()=>{
 const h=await book();const results=await Promise.all(Array.from({length:6},()=>humanAction(admin,h.id,redeem)));
 assert.equal(results.filter(r=>r.alreadyCompleted===false).length,1);
 await humanAction(admin,h.id,{...redeem,summary:'重复提交不应该覆盖原来的服务摘要和操作人。'});
 const [ledger]=await db`SELECT count(*)::int AS n FROM point_ledger WHERE hold_id=${h.id} AND action='settled'`;assert.equal(ledger.n,1);
 assert.equal((await db`SELECT count(*)::int AS n FROM audit_log WHERE target_id=${h.id} AND action='human:redeem'`)[0].n,1);
 const before=await walletTotals(db,owner.id);await db`UPDATE human_assists SET deadline=now()-interval '1 minute' WHERE id=${h.id}`;await maintainPoints();assert.deepEqual(await walletTotals(db,owner.id),before);assert.equal((await hold(h.id)).charged_units,1500);
});
test('authorization, explicit confirmation and valid summary required before any financial change',async()=>{
 const h=await book(),before=await hold(h.id);
 for(const a of [owner,{...admin,emailVerified:false}])await assert.rejects(()=>humanAction(a,h.id,redeem),{code:'FORBIDDEN'});
 for(const data of [{...redeem,serviceCompleted:false},{...redeem,serviceCompleted:'true'},{...redeem,summary:'太短'},{...redeem,summary:' '.repeat(12)}])await assert.rejects(()=>humanAction(admin,h.id,data),{code:'INVALID_INPUT'});
 assert.deepEqual(await hold(h.id),before);
});
test('cancelled, refunded, disputed, expired and inconsistent holds cannot be redeemed',async()=>{
 const cancelled=await book();await humanAction(owner,cancelled.id,{action:'cancel'});
 const refunded=await book();await humanAction(admin,refunded.id,{action:'refund',reason:'未提供服务，测试退回'});
 const disputed=await book('disputed'),expired=await book();await db`UPDATE human_assists SET deadline=now()-interval '1 minute' WHERE id=${expired.id}`;
 const released=await book();await db.begin(tx=>finishHold(tx,released.id,0,'synthetic inconsistent release'));
 const wrongCase=await book();await db`UPDATE point_holds SET case_id=${randomUUID()} WHERE id=${wrongCase.id}`;
 for(const h of [cancelled,refunded,disputed,expired,released,wrongCase]){const before=await hold(h.id);await assert.rejects(()=>humanAction(admin,h.id,redeem));assert.deepEqual(await hold(h.id),before);}
 assert.equal((await db`SELECT summary FROM human_assists WHERE id=${refunded.id}`)[0].summary,'未提供服务，测试退回');
});
test('cancellation and redemption races have one terminal outcome and a balanced ledger',async()=>{
 for(let i=0;i<4;i++){
  const h=await book();await Promise.allSettled([humanAction(owner,h.id,{action:'cancel'}),humanAction(admin,h.id,redeem)]);
  const r=await hold(h.id),[booking]=await db`SELECT status FROM human_assists WHERE id=${h.id}`;
  assert.equal(booking.status,r.status==='settled'?'completed':'cancelled');
  const [n]=await db`SELECT count(*)::int AS n FROM point_ledger WHERE hold_id=${h.id} AND action IN ('settled','released')`;assert.equal(n.n,1);
 }
 const [net]=await db`SELECT sum(available_delta)::int AS available,sum(frozen_delta)::int AS frozen FROM point_ledger WHERE user_id=${owner.id}`;const total=await walletTotals(db,owner.id);assert.equal(net.available,total.available);assert.equal(net.frozen,total.frozen);
});
test('booked amount is authoritative; after-settlement refund retains existing accounting',async()=>{
 const h=await db.begin(async tx=>{const h=await reservePoints(tx,owner.id,'human',1234,randomUUID(),{fixedUnits:1234,advisorId:'congkui'},caseId);await tx`INSERT INTO human_assists(id,user_id,case_id,advisor_id,question) VALUES(${h.id},${owner.id},${caseId},'congkui','历史价格隔离测试')`;return h;});
 const r=await humanAction(admin,h.id,{...redeem,units:1,chargedUnits:1});assert.equal(r.chargedUnits,1234);
 const before=await walletTotals(db,owner.id);await returnServiceCredits(admin,h.id,{units:234,reason:'隔离测试部分售后退分',idempotencyKey:randomUUID()});assert.equal((await walletTotals(db,owner.id)).available,before.available+234);assert.equal((await hold(h.id)).refunded_units,234);
 await humanAction(admin,h.id,redeem);assert.equal((await hold(h.id)).refunded_units,234);
});
test('a retry after customer or automatic confirmation is safe and does not create operator audit',async()=>{
 for(const auto of [false,true]){const h=await book('review');if(auto){await db`UPDATE human_assists SET deadline=now()-interval '1 second' WHERE id=${h.id}`;await maintainPoints();}else await humanAction(owner,h.id,{action:'confirm'});
  const before=await hold(h.id);assert.equal((await humanAction(admin,h.id,redeem)).alreadyCompleted,true);assert.deepEqual(await hold(h.id),before);
  assert.equal((await db`SELECT count(*)::int AS n FROM audit_log WHERE target_id=${h.id} AND action='human:redeem'`)[0].n,0);
 }
});
test('admin view supports active/history and account/code/booking search; no private snapshot leaked',async()=>{
 for(const a of [owner,{...admin,emailVerified:false}])await assert.rejects(()=>humanAssistAdminView(a,new URLSearchParams()),{code:'FORBIDDEN'});
 const h=await book();await humanAction(admin,h.id,redeem);
 for(const q of [owner.name,owner.email,rechargeCode(owner.id),h.id]){const view=await humanAssistAdminView(admin,new URLSearchParams({scope:'history',q}));assert.ok(view.assists.some(r=>r.id===h.id));}
 const history=await humanAssistAdminView(admin,new URLSearchParams({scope:'history',q:h.id})),r=history.assists[0];assert.equal(r.operator_name,admin.name);assert.equal(r.charged_units,1500);assert.equal(r.advisor_name,'从魁');assert.ok(r.settled_at);assert.doesNotMatch(JSON.stringify(history),/allocations|encrypted_code|token_hash|humanRedemption/);
 const active=await humanAssistAdminView(admin,new URLSearchParams({q:owner.email}));assert.ok(active.assists.every(r=>!['completed','refunded','cancelled'].includes(r.status)));
 assert.equal((await humanAssistAdminView(admin,new URLSearchParams({q:"' OR true --"}))).assists.length,0);
 for(const params of [{scope:'invalid'},{page:'-1'},{page:'0.5'}] as Record<string,string>[])await assert.rejects(()=>humanAssistAdminView(admin,new URLSearchParams(params)),{code:'INVALID_INPUT'});
});
test('real API enforces session, verified operator and origin, and accepts authenticated redemption',async()=>{
 assert.equal((await route('GET')).status,401);assert.equal((await route('GET',ownerCookie)).status,403);
 assert.equal((await route('POST',adminCookie,{}, {Origin:'https://untrusted.invalid'})).status,403);
 await db`UPDATE "user" SET email_verified=false WHERE id=${admin.id}`;assert.equal((await route('GET',adminCookie)).status,403);await db`UPDATE "user" SET email_verified=true WHERE id=${admin.id}`;
 assert.equal((await route('GET',adminCookie)).status,200);
 const h=await book();assert.equal((await route('POST',ownerCookie,{id:h.id,...redeem})).status,403);
 assert.equal((await route('POST',adminCookie,{action:'redeem'})).status,400);
 const r=await route('POST',adminCookie,{id:h.id,...redeem});assert.equal(r.status,200);assert.equal((await r.json()).data.chargedUnits,1500);assert.equal((await hold(h.id)).status,'settled');
});
