import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {sqlClient} from '../src/server/db';
import {createCase,caseDetail,deleteCase,createTurn,exportCase,purgeLocked} from '../src/server/service';
import {correctCaseInput,requireTurnIntent} from '../src/server/case-intent';
import {signIntent} from '../src/server/input-intent';
import {calculateChart} from '../src/engine/liuren';
import type {Actor} from '../src/server/http';
import type {CaseInput} from '../src/server/contracts';
if(!process.env.DATABASE_URL||!/wenheng_test/.test(new URL(process.env.DATABASE_URL).pathname))throw Error('Refusing non-test DB');
process.env.BETTER_AUTH_SECRET='isolated-correction-fixture-secret-long-enough';
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:randomUUID(),AI_ENABLED:'true',DEEPSEEK_API_KEY:'fixture-no-real-key'});
const db=sqlClient(),a:Actor={id:'intent-'+randomUUID(),name:'test',email:'intent-'+randomUUID()+'@example.invalid',emailVerified:true,isAdmin:false};
const input:CaseInput={question:'用2005年1月12日14:49起课看升职',locale:'zh',mode:'time',time:'2026-10-17T10:49:00.000Z',timeZone:'Asia/Shanghai',participants:[]};
before(async()=>{await db`INSERT INTO service_settings(key,value) VALUES(${'test:'+process.env.SETTINGS_RECORD_KEY+':workerHeartbeat'},${db.json({at:new Date().toISOString()})})`;await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${a.id},'test',${a.email},true)`;});
after(async()=>{await db`DELETE FROM audit_log WHERE actor_id=${a.id}`;for(const table of ['tasks','case_inputs','deletion_tombstones'])await db.unsafe(`DELETE FROM ${table} WHERE case_id IN (SELECT id FROM cases WHERE user_id=$1)`,[a.id]);await db`DELETE FROM cases WHERE user_id=${a.id}`;await db`DELETE FROM "user" WHERE id=${a.id}`;await db`DELETE FROM service_settings WHERE key LIKE ${'test:'+process.env.SETTINGS_RECORD_KEY+'%'}`;await db.end();});
function proposal(id:string,version:number,question:string,repair=true){const next={...input,time:'2005-01-12T06:49:00.000Z',timeSource:'custom' as const};return {...next,intent:{summary:'更正历史时间',receipt:signIntent(a,next,'更正历史时间',{caseId:id,inputVersion:version,question,action:'configure',repair})}};}
test('同档案纠正保存旧报告/原盘、另建版本、首次系统纠正无积分冻结且幂等',async()=>{
 const c=await createCase(a,{input}),chart=calculateChart(input);await db`UPDATE cases SET status='ready',report=${db.json({title:'旧报告',content:'旧时间的结论'})},internal_chart=${db.json(chart as any)} WHERE id=${c.id}`;
 const request='请按原要求更正',p=proposal(c.id,1,request),key=randomUUID(),data={input:p,question:request,idempotencyKey:key};
 const fresh=await correctCaseInput(a,c.id,data);assert.equal(fresh.inputVersion,2);assert.equal(fresh.input.question,input.question);assert.equal(fresh.input.chartRequest,request);assert.equal(fresh.report,null);assert.equal(fresh.status,'queued');assert.equal(fresh.previousReports?.[0].report?.content,'旧时间的结论');assert.equal(fresh.previousReports?.[0].input?.question,input.question);assert.equal(fresh.tasks[0].systemCorrection,true);
 const [task]=await db`SELECT * FROM tasks WHERE case_id=${c.id}`;assert.equal(task.point_hold_id,null);assert.equal(task.entitlement_id,null);assert.equal(task.input_version,2);
 assert.equal((await correctCaseInput(a,c.id,data)).inputVersion,2);
 await assert.rejects(()=>correctCaseInput(a,c.id,{...data,idempotencyKey:randomUUID()}),{code:'INPUT_REVIEW_REQUIRED'});
 const [saved]=await db`SELECT previous_chart FROM case_inputs WHERE case_id=${c.id} AND version=1`;assert.equal(saved.previous_chart.hash,chart.hash);
});
test('未授权账户、活动任务和过期版本不能纠正',async()=>{
 const c=await createCase(a,{input}),q='更正时间',data={input:proposal(c.id,1,q),question:q,idempotencyKey:randomUUID()};
 await assert.rejects(()=>correctCaseInput({...a,id:'other'},c.id,data),{code:'NOT_FOUND'});
 await db`INSERT INTO tasks(id,case_id,user_id,kind,input_version,idempotency_key) VALUES(${randomUUID()},${c.id},${a.id},'initial',1,${randomUUID()})`;
 await assert.rejects(()=>correctCaseInput(a,c.id,data),{code:'TASK_ACTIVE'});
});
test('用户新改主意仅保存待确认草稿，不自动发起收费；普通追问凭据不得作为改盘凭据',async()=>{
 const c=await createCase(a,{input}),q='我现在想换个时间',p=proposal(c.id,1,q,false);
 const next=await correctCaseInput(a,c.id,{input:p,question:q,idempotencyKey:randomUUID()});assert.equal(next.status,'draft');assert.equal(next.tasks.length,0);
 await assert.rejects(()=>requireTurnIntent(a,c.id,{intentInput:p,question:q}),{code:'INPUT_REVIEW_REQUIRED'});
 const plain={...next.input};delete plain.intent;plain.intent={summary:'继续原版本',receipt:signIntent(a,plain,'继续原版本',{caseId:c.id,inputVersion:2,question:'继续分析',action:'keep'})};
 await requireTurnIntent(a,c.id,{intentInput:plain,question:'继续分析'});
 await deleteCase(a,c.id,true);assert.equal((await db`SELECT version FROM case_inputs WHERE case_id=${c.id}`).length,0);
});
test('模型的修复标记不能给已确认的新机制档案自动授予免费解读',async()=>{
 const confirmed={...input,intent:{summary:'已确认',receipt:signIntent(a,input,'已确认',{action:'keep'})}};
 const c=await createCase(a,{input:confirmed});await db`UPDATE cases SET status='ready',report=${db.json({content:'已确认设定的报告'})} WHERE id=${c.id}`;
 const q='我改用另一时间',p=proposal(c.id,1,q,true),fresh=await correctCaseInput(a,c.id,{input:p,question:q,idempotencyKey:randomUUID()});
 assert.equal(fresh.status,'draft');assert.equal(fresh.tasks.length,0);
});

test('免费系统纠正若需补充背景，可在原任务继续，不误要求旧订单或积分',async()=>{
 const c=await createCase(a,{input});await db`UPDATE cases SET status='ready',report=${db.json({content:'旧报告'})} WHERE id=${c.id}`;
 const q='按原请求更正',fresh=await correctCaseInput(a,c.id,{input:proposal(c.id,1,q),question:q,idempotencyKey:randomUUID()}),task=fresh.tasks[0];
 await db`UPDATE tasks SET status='succeeded',clarification='请补充事件背景' WHERE id=${task.id}`;await db`UPDATE cases SET status='needsClarification' WHERE id=${c.id}`;
 await createTurn(a,c.id,{question:'补充同一事件的具体背景',clarificationTaskId:task.id,idempotencyKey:randomUUID()});
 const [resumed]=await db`SELECT status,system_correction,point_hold_id,input_version FROM tasks WHERE id=${task.id}`;assert.equal(resumed.status,'queued');assert.equal(resumed.system_correction,true);assert.equal(resumed.point_hold_id,null);assert.equal(resumed.input_version,2);
 const detail=await caseDetail(a,c.id);
 assert.deepEqual(detail.tasks[0].clarificationMessages?.slice(-2).map(({role,content})=>({role,content})),[{role:'assistant',content:'请补充事件背景'},{role:'user',content:'补充同一事件的具体背景'}]);
 await db`UPDATE tasks SET status='succeeded',clarification='还需要具体时间' WHERE id=${task.id}`;
 await db`UPDATE cases SET status='needsClarification' WHERE id=${c.id}`;
 await createTurn(a,c.id,{question:'当天上午九点',clarificationTaskId:task.id,idempotencyKey:randomUUID()});
 const next=await caseDetail(a,c.id),history=next.tasks[0].clarificationMessages!;
 assert.deepEqual(history.slice(-4).map(({role,content})=>({role,content})),[{role:'assistant',content:'请补充事件背景'},{role:'user',content:'补充同一事件的具体背景'},{role:'assistant',content:'还需要具体时间'},{role:'user',content:'当天上午九点'}]);
 assert(history.filter(m=>m.role==='user').every(m=>m.at&&Number.isFinite(Date.parse(m.at))));
 const exported=await (await exportCase(a,c.id)).text();
 for(const text of ['请补充事件背景','补充同一事件的具体背景','还需要具体时间','当天上午九点'])assert(exported.includes(text));
 await assert.rejects(()=>caseDetail({...a,id:'unrelated-user'},c.id),{code:'NOT_FOUND'});
 await db`UPDATE tasks SET status='succeeded',clarification='第三次补充' WHERE id=${task.id}`;
 await assert.rejects(()=>createTurn(a,c.id,{question:'不应保存',clarificationTaskId:task.id,idempotencyKey:randomUUID()}),{code:'CLARIFICATION_LIMIT'});
 assert.deepEqual((await caseDetail(a,c.id)).tasks[0].clarificationMessages,history);
 await db.begin(async tx=>{await purgeLocked(tx,c.id);});
 const [purged]=await db`SELECT clarification_messages,question FROM tasks WHERE id=${task.id}`;
 assert.deepEqual(purged.clarification_messages,[]);assert.equal(purged.question,null);
});
