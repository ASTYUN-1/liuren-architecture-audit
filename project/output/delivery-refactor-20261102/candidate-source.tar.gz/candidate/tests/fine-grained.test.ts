import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { KnowledgeRelease } from "../src/agent/knowledge";
import { PROJECT_ROOT } from "../src/engine/liuren";
import { ToolAudit, createTaskTools } from "../src/agent/tools";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";

test("冻结新索引连接原档：问题、六维、反馈身份分列，初级资料不入正式检索",()=>{
 const k=new KnowledgeRelease();if(!k.fineGrainedEnabled)return;
 for(const name of ["kaoshi-panduan","jibing-panduan","shiwu-xunren"])
  assert(k.list().some(d=>d.id===`skill:${name}/SKILL.md`));
 for(const category of ["感情占","胎产占","疾病占","灾厄占","出行占","行人占"]){
  const hits=k.search({category,query:"能否 成败"});
  const safe=category==="疾病占"?["健康占","疾病占"]:[category];
  for(const hit of hits){
   assert(safe.includes(hit.meta["占类"]));assert.equal(hit.qualityFactor,1);
   assert.equal(hit.automaticAcceptance,false);assert.equal(typeof hit.relevance_score,"number");
   assert.equal(typeof hit.six_dimension_total,"number");assert(hit.origin_keys.length>0);
   assert(!hit.source.startsWith("docs/初级案例整理"));
   const d=k.read(hit.id);assert(d.text.includes(hit.unit.question_location.text.slice(0,8))||hit.unit.extraction_status.includes("标题"));
  }
 }
 const m=JSON.parse(readFileSync(join(PROJECT_ROOT,"knowledge-manifest.json"),"utf8"));
 assert.equal(m.retrieval.archivedExperienceStatus.curated_entries,808);
 assert(m.files["docs/初级案例整理/初级案例资料/qqwb20261019-有效201例-修订版/analysis_manifest.json"]);
 assert(!m.documents.some((d:any)=>d.source.startsWith("docs/初级案例整理")));
});

test("细粒度经验可读可引用，保留验证身份与关联项，检索不授予已读权限",async()=>{
 const k=new KnowledgeRelease();if(!k.fineGrainedEnabled)return;
 const audit=new ToolAudit({taskId:"fine-test",caseId:"fine-test",kind:"initial",input:{question:"虚构测试问题",locale:"zh",mode:"time",time:"2026-10-15T07:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[]},k);
 const server=createTaskTools(audit),client=new Client({name:"fine-test",version:"1"}),[a,b]=InMemoryTransport.createLinkedPair();
 await Promise.all([server.connect(b),client.connect(a)]);
 try{
  const result=await client.callTool({name:"search_experience",arguments:{query:"铸印 救神",category:"健康占"}});
  assert(!result.isError,JSON.stringify(result));assert(audit.experienceSearched);
  const packet=JSON.parse((result.content as {text:string}[])[0].text);assert(packet.results.length>0);
  assert(packet.results.length<=5);assert.equal(audit.readIds.size,0);
  for(const hit of packet.results){
   assert(hit.entry.verification);assert.equal(hit.entry.independent_validation_increment,0);
   assert(!/八字|推命|终身/.test(hit.source));
   const d=k.read(hit.id);const quote=hit.entry.source_excerpt.slice(0,80);assert(d.text.includes(quote));
   assert.throws(()=>audit.cite(hit.id,quote),/citation_not_read/);
   const first=k.page(hit.id);for(let i=1;i<=first.pageCount;i++)audit.readPage(hit.id,i,first.deliveryHash);
   assert.doesNotThrow(()=>audit.cite(hit.id,quote));
   for(const related of hit.related)assert(k.read(related.read_id).text.length>0);
  }
 }finally{await client.close();await server.close();}
});
