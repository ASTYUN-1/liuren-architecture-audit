import {test} from 'node:test';
import assert from 'node:assert/strict';
import {inputIntentResponse} from '../src/server/input-intent-response';
import {AppError} from '../src/server/http';
import {requestIntent} from '../src/agent/input-intent';
import {resolveInput,signIntent} from '../src/server/input-intent';
import {safePerformance} from '../src/server/runtime-performance';

test('input review sends keepalive whitespace and preserves the final JSON envelope',async()=>{
 let release!:(v:unknown)=>void;const done=new Promise(r=>{release=r;});
 const response=inputIntentResponse(new Request('http://localhost/input'),()=>done,{heartbeatMs:5,maxMs:1000});
 assert.equal(response.headers.get('X-Accel-Buffering'),'no');
 const reader=response.body!.getReader();assert.equal(new TextDecoder().decode((await reader.read()).value),'\n');
 assert.equal(new TextDecoder().decode((await reader.read()).value),'\n');
 release({action:'keep'});let text='';for(;;){const value=await reader.read();if(value.done)break;text+=new TextDecoder().decode(value.value);}
 assert.deepEqual(JSON.parse(text),{data:{action:'keep'}});
});
test('errors after stream headers preserve their business status and terminal envelope',async()=>{
 const response=inputIntentResponse(new Request('http://localhost/input'),async()=>{throw new AppError('INTENT_UNAVAILABLE','supplier unavailable',503);});
 assert.deepEqual(await response.json(),{error:{code:'INTENT_UNAVAILABLE',message:'supplier unavailable',status:503}});
});
test('closing a review stream aborts only its own supplier request',async()=>{
 let first:AbortSignal|undefined,second:AbortSignal|undefined;
 const a=inputIntentResponse(new Request('http://localhost/a'),async signal=>{first=signal;return new Promise(()=>{});},{heartbeatMs:100,maxMs:500});
 const b=inputIntentResponse(new Request('http://localhost/b'),async signal=>{second=signal;return new Promise(()=>{});},{heartbeatMs:100,maxMs:500});
 await Promise.resolve();await a.body!.cancel();assert.equal(first!.aborted,true);assert.equal(second!.aborted,false);await b.body!.cancel();
});
test('input total execution deadline aborts the supplier and emits a terminal error',async()=>{
 let signal:AbortSignal|undefined;
 const response=inputIntentResponse(new Request('http://localhost/input'),async s=>{signal=s;return new Promise(()=>{});},{heartbeatMs:5,maxMs:20});
 const result=await response.json();assert.equal(signal!.aborted,true);assert.equal(result.error.code,'INTENT_TIMEOUT');assert.equal(result.error.status,504);
});
test('supplier input transport inherits cancellation instead of a separate 90-second timer',async()=>{
 const abort=new AbortController();let signal:AbortSignal|undefined;
 const task=requestIntent({question:'测试问题',locale:'zh',mode:'time',time:'2026-11-02T00:00:00+08:00',timeZone:'Asia/Shanghai',participants:[]} as any,'synthetic-key',{signal:abort.signal},async(_url,init)=>{
  signal=init.signal!;return await new Promise<Response>((_resolve,reject)=>signal!.addEventListener('abort',()=>reject(signal!.reason),{once:true}));
 });
 abort.abort();await assert.rejects(task);assert.equal(signal!.aborted,true);
});
test('unchanged freshly signed initial confirmation is reused without model or database work',async()=>{
 process.env.BETTER_AUTH_SECRET='synthetic-confirmation-secret-'.repeat(3);
 const actor={id:'synthetic-owner',email:'synthetic@example.invalid',name:'synthetic',emailVerified:true,isAdmin:false};
 const input:any={question:'测试完整确认复用',locale:'zh',mode:'time',time:'2026-11-02T00:00:00+08:00',timeZone:'Asia/Shanghai',participants:[]};
 input.intent={summary:'已确认起课设定',receipt:signIntent(actor,input,'已确认起课设定',{action:'keep'})};
 const original=globalThis.fetch;globalThis.fetch=(async()=>{throw new Error('confirmed_input_must_not_call_supplier');}) as typeof fetch;
 try{const result=await resolveInput(actor,input);assert.equal(result.action,'keep');assert.deepEqual(result.input,input);}finally{globalThis.fetch=original;}
});
test('persisted performance is bounded and projects only operational fields',()=>{
 const raw={version:1,events:Array.from({length:130},()=>({type:'model_end',atMs:42,durationMs:10,content:'private body',apiKey:'never return',code:'supplier_http_502'})),modelRequests:130,modelDurationMs:1300,toolCalls:0,toolDurationMs:0,droppedEvents:0,question:'private'};
 const safe=safePerformance(raw)!;assert.equal(safe.events.length,120);assert.equal(safe.droppedEvents,10);assert.equal(JSON.stringify(safe).includes('private'),false);assert.equal(JSON.stringify(safe).includes('apiKey'),false);assert.equal(safe.events[0].code,'supplier_http_502');
});
