import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {PgBoss} from 'pg-boss';
import {sqlClient} from '../src/server/db';
import {adminNotices,readAdminNotices} from '../src/server/admin-notices';
import {expireUnfinishedTasks} from '../src/server/task-expiry';
import {reservePoints,creditPoints,walletTotals} from '../src/server/points';
import {createCase,createTurn} from '../src/server/service';
import type {Actor} from '../src/server/http';
if(!process.env.DATABASE_URL||!/wenheng_test|wenheng-test|test_wenheng/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error('Refusing non-test database');
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:randomUUID(),WENHENG_ENCRYPTION_KEY:'ab'.repeat(32),DEEPSEEK_API_KEY:'not-a-real-key',AI_ENABLED:'true'});
const db=sqlClient(),id='notice-'+randomUUID(),id2='notice-'+randomUUID(),owner:Actor={id,name:'isolated',email:id+'@example.invalid',emailVerified:true,isAdmin:false},admin={...owner,isAdmin:true},admin2={...admin,id:id2,email:id2+'@example.invalid'};
const input={question:'隔离任务有效期验证',locale:'zh',mode:'time',time:'2026-10-15T00:00:00+08:00',timeZone:'Asia/Shanghai',participants:[]};
const taskIds:string[]=[];
before(async()=>{await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${id},'isolated',${owner.email},true),(${id2},'operator 2',${admin2.email},true)`;await creditPoints(admin,{userId:id,kind:'bonus',units:10000,reason:'隔离验证',idempotencyKey:randomUUID()});});
after(async()=>{
 await db`DELETE FROM admin_notice_reads WHERE operator_id IN (${id},${id2})`;
 await db`DELETE FROM practitioner_certifications WHERE user_id=${id}`;
 await db`UPDATE tasks SET point_hold_id=NULL WHERE user_id=${id}`;
 await db`DELETE FROM point_ledger WHERE user_id=${id}`;await db`DELETE FROM point_holds WHERE user_id=${id}`;await db`DELETE FROM point_lots WHERE user_id=${id}`;
 for(const table of ['tasks','case_inputs','cases'])await db.unsafe(`DELETE FROM ${table} WHERE ${table==='case_inputs'?'case_id IN (SELECT id FROM cases WHERE user_id=$1)':'user_id=$1'}`,[id]);
 await db`DELETE FROM point_profiles WHERE user_id=${id}`;await db`DELETE FROM audit_log WHERE actor_id=${id} OR target_id=ANY(${taskIds})`;
 await db`DELETE FROM "user" WHERE id IN (${id},${id2})`;await db.end();
});
test('卦师申请角标精确、按运营账号隔离，标已读不代表已审批；重新申请再次提醒',async()=>{
 await db`INSERT INTO practitioner_certifications(user_id,status,application_note) VALUES(${id},'pending','isolated application')`;
 await assert.rejects(()=>adminNotices(owner));await assert.rejects(()=>readAdminNotices(owner,{keys:['x']}));
 let v=await adminNotices(admin);const item=v.modules.practitioners!.items.find(i=>i.key.startsWith('cert:'+id+':'))!;assert(item);
 const before=v.modules.practitioners!.unread;await readAdminNotices(admin,{keys:[item.key]});await readAdminNotices(admin,{keys:[item.key]});v=await adminNotices(admin);assert.equal(v.modules.practitioners!.unread,before-1);assert(v.modules.practitioners!.pending>0);
 assert((await adminNotices(admin2)).modules.practitioners!.items.some(i=>i.key===item.key));
 await db`UPDATE practitioner_certifications SET revision=revision+1,applied_at=now() WHERE user_id=${id}`;
 const updated=(await adminNotices(admin)).modules.practitioners!.items.find(i=>i.key.startsWith('cert:'+id+':'))!;assert(updated);assert.notEqual(updated.key,item.key);
 await readAdminNotices(admin,{keys:[item.key,'cert:future:1']});assert((await adminNotices(admin)).modules.practitioners!.items.some(i=>i.key===updated.key));
 await db`UPDATE practitioner_certifications SET status='rejected' WHERE user_id=${id}`;assert(!(await adminNotices(admin)).modules.practitioners?.items.some(i=>i.key===updated.key));
});
async function fixture(status:string,age:number,clarification:string|null=null,hold=false){
 const c=await createCase(owner,{input}),taskId=randomUUID();taskIds.push(taskId);
 const h=hold?await db.begin(tx=>reservePoints(tx,id,'initial',1000,randomUUID(),{},c.id,taskId)):null;
 await db`INSERT INTO tasks(id,case_id,user_id,kind,status,input_version,idempotency_key,clarification,created_at,point_hold_id,worker_token,lease_expires_at) VALUES(${taskId},${c.id},${id},'initial',${status},1,${randomUUID()},${clarification},now()-${age}*interval '1 day',${h?.id??null},${status==='running'?randomUUID():null},${status==='running'?new Date(Date.now()+120000):null})`;
 return {taskId,c,h};
}
test('7天取消排队/运行/失败/待补充任务，释放冻结且并发清理幂等；已交付与7天内任务保留',async()=>{
 const before=await walletTotals(db,id),old=await fixture('running',8,null,true),queued=await fixture('queued',8),failed=await fixture('failed',8),waiting=await fixture('succeeded',8,'awaiting input'),delivered=await fixture('succeeded',8),recent=await fixture('queued',6);
 await Promise.all([expireUnfinishedTasks(),expireUnfinishedTasks()]);
 for(const f of [old,queued,failed,waiting]){const [t]=await db`SELECT status,worker_token,lease_expires_at FROM tasks WHERE id=${f.taskId}`;assert.equal(t.status,'cancelled');assert.equal(t.worker_token,null);assert.equal(t.lease_expires_at,null);}
 const [h]=await db`SELECT status,charged_units FROM point_holds WHERE id=${old.h!.id}`;assert.equal(h.status,'released');assert.equal(h.charged_units,0);assert.equal((await walletTotals(db,id)).available,before.available);
 for(const [f,state] of [[delivered,'succeeded'],[recent,'queued']] as const){const [t]=await db`SELECT status FROM tasks WHERE id=${f.taskId}`;assert.equal(t.status,state);}
 const [n]=await db`SELECT count(*)::int AS n FROM audit_log WHERE target_id=${old.taskId} AND action='taskAutoCancelled'`;assert.equal(n.n,1);
});
test('真实pg-boss stately队列两个不同任务同时执行，同一任务重复入队被拒绝',async()=>{
 const boss=new PgBoss({connectionString:process.env.DATABASE_URL}),queue='isolated-concurrency-'+randomUUID();await boss.start();
 let active=0,peak=0;const seen=new Set<string>();let release!:()=>void;const barrier=new Promise<void>(r=>{release=r;});let ready!:()=>void;const both=new Promise<void>(r=>{ready=r;});
 try{await boss.createQueue(queue,{policy:'stately',retryLimit:0,expireInSeconds:20});await boss.send(queue,{id:'a'},{singletonKey:'a'});assert.equal(await boss.send(queue,{id:'a'},{singletonKey:'a'}),null);await boss.send(queue,{id:'b'},{singletonKey:'b'});
  await boss.work<{id:string}>(queue,{batchSize:1,localConcurrency:2,pollingIntervalSeconds:1},async jobs=>{for(const j of jobs){active++;peak=Math.max(peak,active);seen.add(j.data.id);if(active===2)ready();await barrier;active--;}});
  await Promise.race([both,new Promise((_,reject)=>setTimeout(()=>reject(new Error('parallel workers did not overlap')),7000))]);assert.equal(peak,2);assert.equal(seen.size,2);
 }finally{release();await boss.stop({graceful:true,timeout:10000});}
});
