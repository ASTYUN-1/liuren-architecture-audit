import {test} from 'node:test';
import assert from 'node:assert/strict';
import {ExecutionControl,TASK_MAX_MS,TASK_IDLE_MS,QUEUE_EXPIRE_SECONDS,workerConcurrency} from '../src/agent/execution-control';
import {shouldRetryTask} from '../src/server/task-retry';

test('有进展的复杂任务越过10分钟，30分钟才触发总时限；心跳不算分析进展',()=>{
 let now=0;const c=new ExecutionControl(()=>now);
 for(now=60_000;now<TASK_MAX_MS;now+=60_000){c.progress();assert.equal(c.check(),undefined);}
 assert.equal(c.check(),'interpretation_timeout');assert.equal(shouldRetryTask('interpretation_timeout',1),false);
});
test('无进展仅作观察，长推理保留30分钟整项边界',()=>{
 let now=0;const c=new ExecutionControl(()=>now);now=TASK_IDLE_MS;assert.equal(c.check(),undefined);assert.equal(c.snapshot().stalled,true);now=TASK_MAX_MS-1;assert.equal(c.check(),undefined);now=TASK_MAX_MS;assert.equal(c.check(),'interpretation_timeout');assert(QUEUE_EXPIRE_SECONDS*1000>TASK_MAX_MS);
});

test('工具错误可修正；五次相同连续错误终止，不整轮重做',()=>{
 const c=new ExecutionControl();for(let i=0;i<4;i++)c.toolResult(false,'record_judgment:chart_fact_mismatch');assert.equal(c.check(),undefined);c.toolResult(true,'read_knowledge:');
 for(let i=0;i<4;i++)c.toolResult(false,'record_judgment:chart_fact_mismatch');assert.equal(c.check(),undefined);c.toolResult(false,'record_judgment:chart_fact_mismatch');assert.equal(c.check(),'workflow_error_loop');assert.equal(shouldRetryTask('workflow_error_loop',1),false);
});
test('并发默认2，可配置为1至4，拒绝无限或无效并发',()=>{assert.equal(workerConcurrency(''),2);assert.equal(workerConcurrency('2'),2);assert.equal(workerConcurrency('4'),4);for(const n of ['0','20','NaN','2.5'])assert.throws(()=>workerConcurrency(n));});
test('已发起任何上游请求不整轮重试，仅零使用启动失败可重试',()=>{assert.equal(shouldRetryTask('supplier_http_503',1,{requests:1,toolCalls:0}),false);assert.equal(shouldRetryTask('supplier_http_503',1,{requests:20,toolCalls:30}),false);assert.equal(shouldRetryTask('opencode_unavailable',1,{requests:0,toolCalls:0}),true);});
