import test from "node:test";
import "./helpers/fixture-network-guard";
import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {readFileSync,writeFileSync,mkdirSync,existsSync} from "node:fs";
import {resolve} from "node:path";
import {Client} from "@modelcontextprotocol/sdk/client/index.js";
import {InMemoryTransport} from "@modelcontextprotocol/sdk/inMemory.js";
import {KnowledgeRelease} from "../src/agent/knowledge";
import {moduleReadPlan} from "../src/agent/liuren-routing";
import {ToolAudit,createTaskTools} from "../src/agent/tools";
import {runInterpretation,configuredProtocol,productionConfig} from "../src/agent/runtime";
import {loadPublicOutputPolicy,publicOutputPolicyPage} from "../src/agent/public-output";
import type {Judgment} from "../src/agent/liuren-contract";

const root=resolve(process.env.WENHENG_MODULAR_TEST_ROOT??"../output/网站六壬新版上线-20261023/resources");
const input={question:"为爷爷占病，问这次住院后的恢复情况",locale:"zh" as const,mode:"time" as const,time:"2026-10-23T07:00:00Z",timeZone:"Asia/Shanghai",participants:[{role:"患者",gender:"male" as const,birthYear:1939}]};
const question={questionId:"Q1",originalQuestion:input.question,target:"指定患者本次住院恢复",dimension:"result" as const,stage:"本次病程",successCriterion:"患者身体恢复程度，以患者为事件主体",domains:["illness"],mechanisms:[],conditions:["nianming"]};
function setup(){const k=new KnowledgeRelease(root,{protocol:"liuren-v3"});const audit=new ToolAudit({taskId:"synthetic-modular",caseId:"synthetic",kind:"initial",input,history:[],audience:"practitioner"},k);return {k,audit};}
function makeRecord(audit:ToolAudit,k:KnowledgeRelease):Judgment{
 const runtime=k.liurenRuntime!,position=runtime.modules.positioning.id,illness=runtime.modules.illness.id;
 const plan=moduleReadPlan(runtime,question.domains,question.conditions);
 return {schemaVersion:3,chartHash:audit.chart.hash,runtimeVersion:runtime.version,questionId:"Q1",questionRevision:1,target:question.target,dimension:question.dimension,successCriterion:question.successCriterion,
 roles:[{id:"patient",entity:"日干定位指定患者，代问亲属关系另列；仅为合成结构验收",anchorFacts:[{path:"sizhu.d",value:audit.chart.facts.sizhu.d}],mappingSourceIds:[position,illness]}],
 relations:[{id:"R1",fromRole:"patient",toRole:"patient",factRefs:[{path:"sizhu.d",value:audit.chart.facts.sizhu.d}],methodIds:[position,illness],assessment:"unknown",scope:"result",reason:"合成结构验收只核字段，不预测真实病程",effect:"ordinary",effectiveness:"candidate",limitations:["没有进行真实术理判断"]}],
 counterEvidence:{status:"searched-none",refs:[],searchScope:"合成测试检查检索工具调用与资料送达",disposition:"不从结构测试产生真实吉凶判断"},decision:{status:"undetermined",answer:"合成测试不提供实际病程预测",dependsOn:["R1"]},unresolved:[],retrievalRefs:[],
 workflow:Array.from({length:11},(_,i)=>({stage:i+1,summary:"合成验收：本环节仅检查资料完整送达与事实锚点，不证明规则应用正确或病程预测准确。",status:i===8?"not-applicable":"checked",sourceIds:plan.filter(x=>x.stage===i+1).map(x=>x.id),facts:[{path:"sizhu.d",value:audit.chart.facts.sizhu.d}]}))};
}
const publicReport=(citations:{id:string;quote:string}[])=>({title:"住院恢复情况",summary:"本次是隔离的流程验收，不提供实际病程结论；患者与代问者需要分别定位。",content:"本次资料只用于核对流程，不据此判断实际病程。"+"患者是本次事件的主体，需要把患者身体状态、治疗环境、支持因素和限制分别核实。代问者与患者之间的亲属关系不能直接替换患者的位置。过程、结果、程度和时间也需要分别说明；依据不足的部分保留未定，不能仅凭某一项迹象下结论。请根据医院的检查结果和医嘱了解真实病情。".repeat(3),warnings:[],citations});

for(const kind of ["initial","followup"] as const)test(`专业${kind}跳过网站Skill，但完整判断、来源与隐私门禁生效`,async()=>{
 const {k,audit:initial}=setup(),audit=kind==="initial"?initial:new ToolAudit({...initial.input,kind,question:input.question,previousChart:initial.chart},k);
 const server=createTaskTools(audit),client=new Client({name:"professional",version:"1"}),[a,b]=InMemoryTransport.createLinkedPair();await Promise.all([server.connect(b),client.connect(a)]);
 const call=async(name:string,args:Record<string,unknown>={})=>{let result=await client.callTool({name,arguments:args});if(name==="calculate_chart"){let page=JSON.parse((result.content as {text:string}[])[0].text);while(page.paginated&&!page.complete){result=await client.callTool({name,arguments:{page:page.missingPages[0],expectedHash:page.deliveryHash,maxPages:3}});assert(!result.isError);page=JSON.parse((result.content as {text:string}[])[0].text);}}return result;};
 try{
  assert(!(await client.listTools()).tools.some(t=>t.name==="prepare_public_output"));assert((await call("submit_report",publicReport([]))).isError);
  await call("calculate_chart");assert(!(await call("register_questions",{questions:[question]})).isError);
  const ids=[k.liurenRuntime!.entryId,...audit.contract!.readingPlan().map(x=>x.id)];
  for(const id of ids){const p=k.page(id);for(let page=1;page<=p.pageCount;page++)assert(!(await call("read_knowledge",{id,page,expectedHash:p.deliveryHash})).isError);}
  assert(!(await call("record_judgment",makeRecord(audit,k))).isError);await call("search_cases",{query:input.question,category:"疾病占"});await call("search_experience",{query:"占病 患者定位",category:"疾病占"});
  const citations=ids.slice(1,4).map(id=>({id,quote:k.read(id).text.slice(-80)}));
  for(const id of [...audit.caseHits].slice(0,1)){const p=k.page(id);for(let page=1;page<=p.pageCount;page++)await call("read_knowledge",{id,page,expectedHash:p.deliveryHash});citations.push({id,quote:k.read(id).text.slice(-80)});}
  const report={...publicReport(citations),title:"取用、理气与课传制救",content:"依《壬归》核取用、理气、课传制救与八煞九宝。"+publicReport(citations).content};
  for(const leak of [" /etc/wenheng/private.env"," DEEPSEEK_API_KEY"," 案例编号: private_123"])assert((await call("submit_report",{...report,content:report.content+leak})).isError);
  assert(!(await call("submit_report",report)).isError);audit.assertComplete();assert.equal(audit.outputCoverage(),undefined);assert.equal(audit.contract!.records.size,1);assert(audit.evidence.length>=3);assert(kind==="initial"?audit.candidate!.report?.content.includes("八煞九宝"):audit.candidate!.answer?.includes("八煞九宝"));
 }finally{await client.close();await server.close();}
});
test("专业提示保留十一环节及权限边界，无普通末步路由或格式Skill",()=>{
 const c=productionConfig("http://127.0.0.1:1","synthetic",undefined,"liuren-v3","practitioner"),p=c.agent["liuren-main"].prompt;
 assert(p.includes("执行十一环节"));assert(p.includes("当前交付对象为已认证卦师"));assert(!p.includes("prepare_public_output"));assert(!p.includes("website_public_output_policy"));assert(p.includes("后台配置"));assert.equal(c.agent["liuren-main"].permission.task["*"],"deny");
});
test("专业澄清直接提交，仍拒绝内部路径泄露",async()=>{
 const {audit}=setup(),server=createTaskTools(audit),client=new Client({name:"clarify-pro",version:"1"}),[a,b]=InMemoryTransport.createLinkedPair();await Promise.all([server.connect(b),client.connect(a)]);
 try{assert((await client.callTool({name:"submit_clarification",arguments:{question:"请提供 /etc/wenheng/private.env"}})).isError);assert(!(await client.callTool({name:"submit_clarification",arguments:{question:"请确认本次所问的是哪位患者的病程？"}})).isError);audit.assertComplete();}finally{await client.close();await server.close();}
});

for(const runtimeKind of ["initial","followup"] as const)test(`真实OpenCode与模拟供应商（${runtimeKind}）：完整专业判断交付且不传递网站输出Skill`,{skip:process.env.WENHENG_RUNTIME_FIXTURE!=="1",timeout:120000},async()=>{
 const {k,audit}=setup(),record=makeRecord(audit,k),runtime=k.liurenRuntime!,policy=loadPublicOutputPolicy(root);
 const ids=[runtime.entryId,...moduleReadPlan(runtime,question.domains,question.conditions).map(x=>x.id)];
 const pending=ids.flatMap(id=>{const p=k.page(id);return Array.from({length:p.pageCount},(_,i)=>({id,page:i+1,expectedHash:p.deliveryHash}));});
 const sample=k.search({query:input.question,category:"疾病占"})[0];
 const citations=ids.slice(1,4).map(id=>({id,quote:k.read(id).text.slice(-80)}));
 if(sample)citations.push({id:sample.id,quote:k.read(sample.id).text.slice(-80)});
 const received=new Map<string,Map<number,string>>(),outputPages=new Map<number,string>();const chartPages=new Set<number>();let chartPageCount=0,chartDeliveryHash="";let requests=0,phase=0,accepted=false,reportAccepted=false;const original=globalThis.fetch;
 function inspect(value:any):void{if(typeof value==="string"){let parsed;try{parsed=JSON.parse(value);}catch{return;}inspect(parsed);return;}if(Array.isArray(value)){value.forEach(inspect);return;}if(!value||typeof value!=="object")return;if(value.id==="fixed-chart"&&value.paginated){chartPageCount=value.pageCount;chartDeliveryHash=value.deliveryHash;for(const p of value.pages)chartPages.add(p.page);}if(ids.includes(value.id)&&Number.isInteger(value.page)&&typeof value.text==="string"){assert.equal(value.pageHash,createHash("sha256").update(value.text).digest("hex"));const pages=received.get(value.id)??new Map();pages.set(value.page,value.text);received.set(value.id,pages);}if(value.id==="website:wenheng-public-output"){assert.equal(value.pageHash,createHash("sha256").update(value.text).digest("hex"));outputPages.set(value.page,value.text);}if(value.accepted&&value.recordCount===1)accepted=true;if(value.accepted&&value.chartHash)reportAccepted=true;Object.values(value).forEach(inspect);}
 globalThis.fetch=(async(url:any,init:any)=>{
  const target=url instanceof Request?url.url:String(url);if(target!=="https://api.deepseek.com/v1/chat/completions")return original(url,init);
  const body=JSON.parse(init.body);inspect(body.messages);requests++;
  if(phase<5){assert(!JSON.stringify(body).includes("## 专业判断的公开表达"));assert.equal(outputPages.size,0);}
  const action=(name:string,args:unknown,index=0)=>({id:`mod_${requests}_${index}`,type:"function",function:{name:"wenheng_"+name,arguments:JSON.stringify(args)}});
  let actions:any[]=[];
  const missingChart=Array.from({length:chartPageCount},(_,i)=>i+1).filter(n=>!chartPages.has(n));
  if(missingChart.length)actions=[action("calculate_chart",{page:missingChart[0],expectedHash:chartDeliveryHash,maxPages:3})];
  else if(phase===0){actions=[action("read_case",{},0),action("calculate_chart",{},1),action("list_knowledge",{},2)];phase++;}
  else if(phase===1){actions=[action("register_questions",{questions:[question]})];phase++;}
  else if(pending.length)actions=pending.splice(0,8).map((arg,i)=>action("read_knowledge",arg,i));
  else if(phase===2){actions=[action("record_judgment",record)];phase++;}
  else if(phase===3){assert(accepted);actions=[action("search_cases",{query:input.question,category:"疾病占"},0),action("search_experience",{query:"占病 患者定位",category:"疾病占"},1)];if(sample){const p=k.page(sample.id);pending.push(...Array.from({length:p.pageCount},(_,i)=>({id:sample.id,page:i+1,expectedHash:p.deliveryHash})));}phase++;}
  else if(phase===4){actions=[action("submit_report",publicReport(citations))];phase=6;}

  return new Response(JSON.stringify({id:`fixture_${requests}`,created:1,model:"deepseek-flash",choices:[{index:0,message:{role:"assistant",content:actions.length?null:"验收结束",reasoning_content:"fixture-only",...(actions.length?{tool_calls:actions}:{})},finish_reason:actions.length?"tool_calls":"stop"}],usage:{prompt_tokens:1,completion_tokens:1}}),{status:200});
 }) as typeof fetch;
 try{
  const result=await runInterpretation({audience:"practitioner",taskId:"professional-delivery",caseId:"synthetic",kind:runtimeKind,input,history:[],apiKey:"fixture-only",...(runtimeKind==="followup"?{previousChart:audit.chart,question:input.question}:{})},{protocol:"liuren-v3",knowledgeRoot:root});
  const checks=ids.map(id=>{const p=k.page(id),pages=received.get(id),text=Array.from({length:p.pageCount},(_,i)=>pages?.get(i+1)??"").join("");return {id,pages:p.pageCount,hash:createHash("sha256").update(text).digest("hex"),complete:text===k.read(id).text};});
  assert(checks.every(x=>x.complete&&x.hash===k.page(x.id).deliveryHash));assert.equal(result.usage.protocol,"liuren-v3");assert.equal(result.usage.judgmentRecords?.length,1);assert.equal(result.judgmentRecords?.[0].workflow?.length,11);assert.equal(reportAccepted,true);assert.deepEqual(result.judgmentRecords![0],record);assert.equal(result.usage.publicOutputDelivery,undefined);assert.equal(result.usage.outputAudience,"practitioner");assert.equal(result.usage.publicOutputHash,null);assert.equal(outputPages.size,0);
  assert(runtimeKind==="initial"?result.report:result.answer);
  const out=resolve(process.env.WENHENG_MODULAR_RECEIPT_DIR??"../output/practitioner-local-20261024/runtime-receipts");mkdirSync(out,{recursive:true});writeFileSync(resolve(out,runtimeKind==="initial"?"actual-opencode-professional-delivery.json":"actual-opencode-professional-followup-delivery.json"),JSON.stringify({identity:"synthetic-supplier-not-predictive-accuracy",kind:runtimeKind,release:runtime.release,checks,requests,toolCalls:result.usage.toolCalls,judgmentRecorded:accepted,reportAccepted,outputPolicy:{notLoaded:true,professionalAudience:true}},null,2));
 }finally{globalThis.fetch=original;}
});
