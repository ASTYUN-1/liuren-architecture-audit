import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runInterpretation} from '../src/agent/runtime';
import type {CaseInput} from '../src/server/contracts';

const input=(label:string):CaseInput=>({question:'隔离并发'+label,locale:'zh',mode:'time',time:'2026-10-15T05:00:00Z',timeZone:'Asia/Shanghai',participants:[]});
const wire=(message:any,finish='tool_calls',output=100)=>new Response(JSON.stringify({id:'fixture-'+Math.random(),created:1,model:'deepseek-flash',choices:[{index:0,message,finish_reason:finish}],usage:{prompt_tokens:100,completion_tokens:output,prompt_cache_hit_tokens:0}}),{status:200,headers:{'Content-Type':'application/json'}});
const call=(name:string,args:unknown)=>({role:'assistant',content:null,reasoning_content:'fixture',tool_calls:[{id:'fixture-'+Math.random(),type:'function',function:{name,arguments:JSON.stringify(args)}}]});
const toolText=(body:any)=>body.messages.filter((m:any)=>m.role==='tool').map((m:any)=>typeof m.content==='string'?m.content:JSON.stringify(m.content)).join('\n');
test('两个真实OpenCode进程与MCP并发，盘面和工具上下文互不串用；供应商全程模拟',{skip:process.env.WENHENG_RUNTIME_FIXTURE!=='1',timeout:90000},async()=>{
 const original=globalThis.fetch;let waiting=0;let release!:()=>void;const barrier=new Promise<void>(r=>{release=r;});
 globalThis.fetch=(async(url:any,init:any)=>{
  if(String(url)!=='https://api.deepseek.com/v1/chat/completions')return original(url,init);
  const body=JSON.parse(init.body);if(!body.tools?.some((t:any)=>t.function.name==='wenheng_read_case'))return wire({role:'assistant',content:'Private task'},'stop');
  const text=toolText(body);
  if(text.includes('"accepted":true'))return wire({role:'assistant',content:'已提交'},'stop');
  if(!text.includes('隔离并发')){waiting++;if(waiting===2)release();await Promise.race([barrier,new Promise((_,reject)=>setTimeout(()=>reject(new Error('runtime concurrency barrier timed out')),15000))]);return wire(call('wenheng_read_case',{}));}
  assert(!(text.includes('隔离并发甲')&&text.includes('隔离并发乙')),'tool contexts mixed across tasks');
  return wire(call('wenheng_submit_clarification',{question:'请补充隔离并发'+(text.includes('隔离并发甲')?'甲':'乙')+'的具体背景资料。'}));
 }) as typeof fetch;
 try{const run=(label:string)=>runInterpretation({audience:'practitioner',taskId:'parallel-'+label,caseId:'parallel-'+label,kind:'initial',input:input(label),history:[],apiKey:'not-a-real-key',signal:AbortSignal.timeout(75000)},{protocol:'liuren-v3'});
  const [a,b]=await Promise.all([run('甲'),run('乙')]);assert.equal(waiting,2);assert(a.clarification?.includes('并发甲'));assert(b.clarification?.includes('并发乙'));assert.notEqual(a.chart.hash,b.chart.hash);
 }finally{globalThis.fetch=original;release();}
});
test('输出截断后在原会话恢复一次，保留已读上下文，不重新读取整轮',{skip:process.env.WENHENG_RUNTIME_FIXTURE!=='1',timeout:90000},async()=>{
 const original=globalThis.fetch;let truncated=false,readCalls=0,recovered=false;const progress:string[]=[];
 globalThis.fetch=(async(url:any,init:any)=>{
  if(String(url)!=='https://api.deepseek.com/v1/chat/completions')return original(url,init);
  const body=JSON.parse(init.body);if(!body.tools?.some((t:any)=>t.function.name==='wenheng_read_case'))return wire({role:'assistant',content:'Private task'},'stop');
  const text=toolText(body);
  if(text.includes('"accepted":true'))return wire({role:'assistant',content:'已提交'},'stop');
  if(!text.includes('隔离并发恢复')){readCalls++;return wire(call('wenheng_read_case',{}));}
  if(!truncated){truncated=true;return wire({role:'assistant',content:null,reasoning_content:'fixture only'},'length',32768);}
  assert(JSON.stringify(body.messages).includes('上一轮单次输出达到长度上限'));recovered=true;
  return wire(call('wenheng_submit_clarification',{question:'请补充隔离恢复测试中的具体事件背景。'}));
 }) as typeof fetch;
 try{const r=await runInterpretation({audience:'practitioner',taskId:'recover',caseId:'recover',kind:'initial',input:input('恢复'),history:[],apiKey:'not-a-real-key',onProgress:s=>{progress.push(s);},signal:AbortSignal.timeout(75000)},{protocol:'liuren-v3'});assert(r.clarification);assert(recovered);assert.equal(readCalls,1);assert.equal(progress.filter(s=>s==='output_retry').length,1);
 }finally{globalThis.fetch=original;}
});
