import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {sqlClient} from '../src/server/db';
import {createCase,caseDetail,lockCase,deleteCase,taskView} from '../src/server/service';
import {saveDeliveryDraft} from '../src/server/delivery-store';
import {settleDelivery} from '../src/server/delivery-settlement';
import {creditPoints,reservePoints,walletTotals} from '../src/server/points';
import {recordUsage} from '../src/server/points-ai';
import {quotePoints} from '../src/lib/points-pricing';
import type {Actor} from '../src/server/http';
import type {DeliveryDraft} from '../src/agent/delivery';
if(!process.env.DATABASE_URL||!/wenheng_test_delivery_/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error('Refusing non-isolated delivery test DB');
globalThis.fetch=(async()=>{throw new Error('test_external_network_forbidden');}) as typeof fetch;
const db=sqlClient(),userId='delivery-'+randomUUID(),otherId='delivery-'+randomUUID();
const owner:Actor={id:userId,name:'synthetic',email:userId+'@example.invalid',emailVerified:true,isAdmin:false},other={...owner,id:otherId,email:otherId+'@example.invalid'},admin={...owner,isAdmin:true};
const input={question:'纯合成隔离交付验收',locale:'zh',mode:'time',time:'2026-11-02T00:00:00+08:00',timeZone:'Asia/Shanghai',participants:[]};
before(async()=>{await db.unsafe(readFileSync('db/019_delivery_drafts.sql','utf8'));for(const a of [owner,other]){await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${a.id},'synthetic',${a.email},true)`;await creditPoints(admin,{userId:a.id,kind:'bonus',units:100000,reason:'synthetic isolated tests',idempotencyKey:randomUUID()});}});
after(async()=>{await db.end();}); // Retain only synthetic evidence in this disposable database.
async function fixture(points=true,kind='initial'){
 const c=await createCase(owner,{input}),id=randomUUID(),token=randomUUID();
 await db.begin(async tx=>{await lockCase(tx,c.id,owner.id);const snapshot=quotePoints('initial',100),h=points?await reservePoints(tx,owner.id,'initial',snapshot.reserveUnits,randomUUID(),snapshot,c.id,id):null;
 await tx`INSERT INTO tasks(id,case_id,user_id,kind,status,input_version,idempotency_key,point_hold_id,attempts,worker_token) VALUES(${id},${c.id},${owner.id},${kind},'running',1,${randomUUID()},${h?.id??null},1,${token})`;await tx`UPDATE cases SET status='running' WHERE id=${c.id}`;});
 return {caseId:c.id,taskId:id,token};
}
function draft(n=1):DeliveryDraft{return {id:randomUUID(),version:n,snapshot:0,hash:'synthetic-hash',submission:{content:'PRIVATE-SYNTHETIC-DRAFT',citations:[],warnings:[],answers:[{questionId:'Q1',status:'undetermined',answer:'合成未定回答',limitations:['仅为合成验收']}],outcome:'limited',limitations:[]},issues:[],at:new Date().toISOString()};}
async function settle(f:Awaited<ReturnType<typeof fixture>>,outcome:'complete'|'limited',twice=true){await db.begin(async tx=>{const c=await lockCase(tx,f.caseId,owner.id),[t]=await tx`SELECT * FROM tasks WHERE id=${f.taskId} FOR UPDATE`;await settleDelivery(tx,t,c,outcome);if(twice)await settleDelivery(tx,t,c,outcome);await tx`UPDATE tasks SET status='succeeded',worker_token=NULL,delivery_result=${tx.json({outcome,limitations:[]})} WHERE id=${t.id}`;});}
async function legacy(f:Awaited<ReturnType<typeof fixture>>,kind='base',reserved=0){const orderId=randomUUID(),eid=randomUUID();await db`INSERT INTO orders(id,user_id,case_id,kind,amount_cents,status,input_version,idempotency_key) VALUES(${orderId},${owner.id},${f.caseId},${kind},2990,'paid',1,${randomUUID()})`;await db`INSERT INTO entitlements(id,case_id,order_id,granted,reserved) VALUES(${eid},${f.caseId},${orderId},2,${reserved})`;if(reserved)await db`UPDATE tasks SET entitlement_id=${eid} WHERE id=${f.taskId}`;return {orderId,eid};}

test('migration preserves existing tasks as legacy and binds new tasks to v2, including rerun',async()=>{await db.begin(async tx=>{await tx`CREATE TEMP TABLE tasks(id text PRIMARY KEY) ON COMMIT DROP`;await tx`INSERT INTO tasks(id) VALUES('old')`;const migration=readFileSync('db/019_delivery_drafts.sql','utf8');await tx.unsafe(migration);await tx`INSERT INTO tasks(id) VALUES('new')`;await tx.unsafe(migration);const rows=await tx`SELECT id,delivery_protocol FROM tasks ORDER BY id`;assert.deepEqual(rows.map(x=>[x.id,x.delivery_protocol]),[['new','delivery-v2'],['old','legacy']]);});});
test('durable drafts retain three versions, update diagnostics in place and never appear in public task views',async()=>{
 const f=await fixture();for(let n=1;n<=4;n++){const d=draft(n);await saveDeliveryDraft(f.taskId,f.caseId,f.token,1,d);d.issues=[];await saveDeliveryDraft(f.taskId,f.caseId,f.token,1,d);}
 const [t]=await db`SELECT * FROM tasks WHERE id=${f.taskId}`;assert.deepEqual(t.delivery_drafts.map((x:any)=>x.version),[2,3,4]);assert(!JSON.stringify(taskView(t)).includes('PRIVATE-SYNTHETIC-DRAFT'));assert(!JSON.stringify(await caseDetail(owner,f.caseId)).includes('PRIVATE-SYNTHETIC-DRAFT'));await assert.rejects(()=>caseDetail(other,f.caseId),{code:'NOT_FOUND'});
});
test('wrong worker, case, input version, canceled and deleted tasks cannot persist drafts',async()=>{
 const f=await fixture();await assert.rejects(()=>saveDeliveryDraft(f.taskId,f.caseId,randomUUID(),1,draft()),/task_stopped/);await assert.rejects(()=>saveDeliveryDraft(f.taskId,f.caseId,f.token,2,draft()),/task_stopped/);
 const wrong=await fixture();await assert.rejects(()=>saveDeliveryDraft(f.taskId,wrong.caseId,f.token,1,draft()),/task_stopped/);
 await db`UPDATE tasks SET status='cancelled' WHERE id=${f.taskId}`;await assert.rejects(()=>saveDeliveryDraft(f.taskId,f.caseId,f.token,1,draft()),/task_stopped/);
 await db`UPDATE cases SET deleted_at=now() WHERE id=${wrong.caseId}`;await assert.rejects(()=>saveDeliveryDraft(wrong.taskId,wrong.caseId,wrong.token,1,draft()),/task_stopped/);
});
test('limited points answer releases the entire hold once, even with recorded supplier cost',async()=>{
 const before=await walletTotals(db,owner.id),f=await fixture();await recordUsage(f.taskId,1,{requestId:randomUUID(),responseId:'synthetic',input:10,output:10,cached:0,costNano:'1000000',verified:true,billable:true});await settle(f,'limited');
 const [h]=await db`SELECT h.* FROM point_holds h JOIN tasks t ON h.id=t.point_hold_id WHERE t.id=${f.taskId}`;assert.equal(h.status,'released');assert.equal(h.charged_units,0);assert.deepEqual(await walletTotals(db,owner.id),before);const [l]=await db`SELECT count(*)::int AS n FROM point_ledger WHERE hold_id=${h.id} AND action='released'`;assert.equal(l.n,1);
});
test('complete points answer uses existing settlement and repeated confirmation cannot double-charge',async()=>{const f=await fixture();await settle(f,'complete');const [h]=await db`SELECT h.* FROM point_holds h JOIN tasks t ON h.id=t.point_hold_id WHERE t.id=${f.taskId}`;assert.equal(h.status,'settled');assert(h.charged_units>0);const [l]=await db`SELECT count(*)::int AS n FROM point_ledger WHERE hold_id=${h.id} AND action='settled'`;assert.equal(l.n,1);});
test('limited legacy follow-up restores reservation; complete follow-up consumes exactly once',async()=>{
 for(const outcome of ['limited','complete'] as const){const f=await fixture(false,'followup'),{eid}=await legacy(f,'addon',1);await settle(f,outcome);const [e]=await db`SELECT * FROM entitlements WHERE id=${eid}`;assert.equal(e.reserved,0);assert.equal(e.used,outcome==='limited'?0:1);const [l]=await db`SELECT count(*)::int AS n FROM entitlement_ledger WHERE task_id=${f.taskId}`;assert.equal(l.n,1);}
});
test('cash-paid limited initial answer requests a real refund, without fabricating refunded funds',async()=>{
 const f=await fixture(false),{orderId,eid}=await legacy(f);await settle(f,'limited');const [o]=await db`SELECT * FROM orders WHERE id=${orderId}`;assert.equal(o.status,'refundPending');assert.equal(o.refund_requested_cents,2990);assert.equal(o.refunded_cents,0);const [e]=await db`SELECT frozen FROM entitlements WHERE id=${eid}`;assert.equal(e.frozen,2);
});
test('permanent deletion clears private drafts, diagnostics and delivery receipt',async()=>{const f=await fixture();await saveDeliveryDraft(f.taskId,f.caseId,f.token,1,draft());await db`UPDATE tasks SET delivery_result=${db.json({outcome:'limited',limitations:[]})},usage=${db.json({deliveryDiagnostics:{protocol:'delivery-v2'}})} WHERE id=${f.taskId}`;await deleteCase(owner,f.caseId,true);const [t]=await db`SELECT delivery_drafts,delivery_result,usage FROM tasks WHERE id=${f.taskId}`;assert.equal(t.delivery_drafts,null);assert.equal(t.delivery_result,null);assert.equal(t.usage,null);});
test('database erasure guard also protects a rollback using legacy purge SQL',async()=>{const f=await fixture();await saveDeliveryDraft(f.taskId,f.caseId,f.token,1,draft());await db`UPDATE tasks SET status='cancelled',delivery_result=${db.json({outcome:'limited',limitations:[]})} WHERE id=${f.taskId}`;await db`UPDATE cases SET permanently_deleted=true WHERE id=${f.caseId}`;const [t]=await db`SELECT delivery_drafts,delivery_result FROM tasks WHERE id=${f.taskId}`;assert.equal(t.delivery_drafts,null);assert.equal(t.delivery_result,null);});
