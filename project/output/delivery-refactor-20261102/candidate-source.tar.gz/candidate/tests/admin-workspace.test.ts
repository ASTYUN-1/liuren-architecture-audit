import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {sqlClient} from '../src/server/db';
import type {Actor} from '../src/server/http';
import {adminUsers,adminUserRecords,adminCaseView} from '../src/server/users';
import {adminOverview} from '../src/server/service';
if(!process.env.DATABASE_URL||!new URL(process.env.DATABASE_URL).pathname.includes('wenheng_test'))throw Error('isolated test database required');
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:randomUUID(),WENHENG_ENCRYPTION_KEY:'ab'.repeat(32)});
const db=sqlClient(),id='admin-ui-'+randomUUID(),caseId=randomUUID(),taskId=randomUUID(),holdId=randomUUID(),lotId=randomUUID();
const user:Actor={id,email:id+'@example.invalid',name:'后台统计测试',emailVerified:true,isAdmin:false},admin={...user,isAdmin:true};
before(async()=>{
 await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${id},${user.name},${user.email},true)`;
 await db`INSERT INTO cases(id,user_id,title,status,input_version,report) VALUES(${caseId},${id},'能否完成合作','ready',1,${db.json({title:'合成报告',content:'可公开阅读的完整报告内容',citations:'DO_NOT_EXPOSE_INTERNAL_CITATIONS'})})`;
 await db`INSERT INTO case_inputs(case_id,version,input) VALUES(${caseId},1,${db.json({question:'本次合作能否顺利完成？',participants:[{private:'DO_NOT_EXPOSE_BIRTH'}]})})`;
 await db`INSERT INTO point_lots(id,user_id,kind,original_units,available_units,frozen_units,reason,actor_id,idempotency_key) VALUES(${lotId},${id},'bonus',1000,750,100,'合成统计样本',${id},${randomUUID()})`;
 await db`INSERT INTO point_holds(id,user_id,kind,case_id,status,units,charged_units,refunded_units,allocations,snapshot,idempotency_key) VALUES(${holdId},${id},'initial',${caseId},'settled',200,200,50,'[]','{}',${randomUUID()})`;
 await db`INSERT INTO tasks(id,case_id,user_id,kind,status,input_version,idempotency_key,point_hold_id,usage,internal_evidence) VALUES(${taskId},${caseId},${id},'initial','succeeded',1,${randomUUID()},${holdId},${db.json({requests:3,costCny:99,apiKey:'DO_NOT_EXPOSE_API_KEY'})},${db.json({private:'DO_NOT_EXPOSE_EVIDENCE'})})`;
 await db`INSERT INTO point_debts(hold_id,user_id,original_units,outstanding_units) VALUES(${holdId},${id},70,70)`;
 for(const [n,cost,verified,billable] of [[1,100000000,true,true],[2,200000000,true,false],[3,0,false,false]] as const)await db`INSERT INTO point_usage_events(id,task_id,attempt,request_id,model,price_version,input_tokens,output_tokens,cached_tokens,cost_nano_cny,verified,billable) VALUES(${randomUUID()},${taskId},${n},${'fixture-'+n},'deepseek-flash','test',1,1,0,${cost},${verified},${billable})`;
});
after(async()=>{
 await db`DELETE FROM point_usage_events WHERE task_id=${taskId}`;await db`DELETE FROM audit_log WHERE actor_id=${id}`;
 await db`DELETE FROM tasks WHERE user_id=${id}`;await db`DELETE FROM point_debts WHERE user_id=${id}`;await db`DELETE FROM point_holds WHERE user_id=${id}`;await db`DELETE FROM point_lots WHERE user_id=${id}`;
 await db`DELETE FROM case_inputs WHERE case_id=${caseId}`;await db`DELETE FROM cases WHERE user_id=${id}`;await db`DELETE FROM "user" WHERE id=${id}`;await db.end();
});
test('user summary counts debt once and reports net consumption without treating released holds as spending',async()=>{
 const result=await adminUsers(admin,id,1),u=result.users[0];assert.equal(result.total,1);assert.equal(u.availableUnits,680);assert.equal(u.frozenUnits,100);assert.equal(u.debtUnits,70);assert.equal(u.consumedUnits,150);assert.equal(u.cases,1);
 const records=await adminUserRecords(admin,id);assert.equal(records.cases[0].title,'能否完成合作');assert.equal(JSON.stringify(records).includes('DO_NOT_EXPOSE'),false);
 await assert.rejects(()=>adminUsers(user,'',1),{code:'FORBIDDEN'});
});
test('task view joins user and case, uses actual usage events across attempts and exposes no private metadata',async()=>{
 const data=await adminOverview(admin),t=data.tasks.find(t=>t.id===taskId)!;assert.equal(t.userName,user.name);assert.equal(t.userEmail,user.email);assert.equal(t.caseTitle,'能否完成合作');assert.equal(t.consumedUnits,150);assert.equal(t.providerCostCny,0.3);assert.equal(t.unknownUsage,1);assert.equal(JSON.stringify(data).includes('DO_NOT_EXPOSE'),false);
});
test('only verified operators can read public case content and access is audited',async()=>{
 await assert.rejects(()=>adminCaseView(user,caseId),{code:'FORBIDDEN'});await assert.rejects(()=>adminCaseView({...admin,emailVerified:false},caseId),{code:'FORBIDDEN'});
 const view=await adminCaseView(admin,caseId);assert.equal(view.report?.content,'可公开阅读的完整报告内容');assert.equal(view.question,'本次合作能否顺利完成？');assert.equal(JSON.stringify(view).includes('DO_NOT_EXPOSE'),false);
 assert.equal((await db`SELECT count(*)::int AS n FROM audit_log WHERE actor_id=${id} AND target_id=${caseId} AND action='admin:readCase'`)[0].n,1);
 await db`UPDATE cases SET permanently_deleted=true WHERE id=${caseId}`;await assert.rejects(()=>adminCaseView(admin,caseId),{code:'NOT_FOUND'});await db`UPDATE cases SET permanently_deleted=false WHERE id=${caseId}`;
});
