import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { mkdtemp, readdir, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import sharp from "sharp";
import { SMTPServer } from "smtp-server";
import { sqlClient } from "../src/server/db";
import { MAX_AVATAR_BYTES, safeAvatarUrl } from "../src/lib/avatar";
import { compressAvatar } from "../src/server/avatars";

if (!process.env.DATABASE_URL || !new URL(process.env.DATABASE_URL).pathname.includes('wenheng_test')) throw Error('isolated test DB required');
const key='avatars-'+randomUUID(), email=key+'@example.invalid', origin='http://127.0.0.1:3199';
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:key,APP_URL:origin,BETTER_AUTH_SECRET:'isolated-avatar-test-secret-20261017'});
const db=sqlClient(), smtp=new SMTPServer({authOptional:true,disabledCommands:['STARTTLS'],onData(s,_session,done){s.resume();s.on('end',done);}});
let cookie='', userId='', dir='', jpeg:Buffer, image:string;
before(async()=>{
 dir=await mkdtemp(join(tmpdir(),'wenheng-avatar-test-'));process.env.AVATAR_DIR=dir;
 await new Promise<void>(resolve=>smtp.listen(12527,'127.0.0.1',resolve));
 await db`INSERT INTO service_settings(key,value) VALUES(${'test:'+key},${db.json({emailProvider:'smtp',smtpHost:'127.0.0.1',smtpPort:12527,smtpSecure:false,smtpFrom:'test@example.invalid'})})`;
 const {getAuth}=await import('../src/server/auth');
 const r=await getAuth().handler(new Request(origin+'/api/auth/sign-up/email',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({username:'avatar_'+randomUUID().replaceAll('-','').slice(0,12),name:'头像测试',email,password:'synthetic-avatar-password-123',image:'/avatars/'+randomUUID()+'.webp'})}));
 assert.equal(r.status,200);userId=(await r.json()).user.id;cookie=r.headers.getSetCookie().map(s=>s.split(';')[0]).join('; ');
 assert.equal((await db`SELECT image FROM "user" WHERE id=${userId}`)[0].image,null,'signup cannot inject avatar URL');
 jpeg=await sharp({create:{width:640,height:400,channels:3,background:'#567b62'}}).jpeg().withMetadata({orientation:6}).toBuffer();
});
after(async()=>{await db`DELETE FROM "user" WHERE id=${userId}`;await db`DELETE FROM service_settings WHERE key=${'test:'+key}`;await db`DELETE FROM rate_limits WHERE key=${'avatar:'+userId}`;await db.end();await new Promise<void>(resolve=>smtp.close(()=>resolve()));if(dir)await rm(dir,{recursive:true,force:true});});
async function request(method:string,body?:Buffer,extra:Record<string,string>={}){const {PUT,DELETE}=await import('../src/app/api/account/avatar/route');return (method==='PUT'?PUT:DELETE)(new Request(origin+'/api/account/avatar',{method,headers:{Origin:origin,Cookie:cookie,'Content-Type':'image/jpeg',...extra},body:body?new Uint8Array(body):undefined}),{});}

test('authenticated upload decodes, crops, compresses, strips metadata and is reflected in me',async()=>{
 const r=await request('PUT',jpeg);assert.equal(r.status,200);image=(await r.json()).data.image;assert.ok(safeAvatarUrl(image));
 const {avatarResponse}=await import('../src/server/avatars');const served=await avatarResponse(image.split('/').pop()!,new Request(origin+image));assert.equal(served.status,200);assert.match(served.headers.get('cache-control')!,/max-age/);assert.equal(served.headers.get('content-type'),'image/webp');
 const output=Buffer.from(await served.arrayBuffer()),meta=await sharp(output).metadata();assert.equal(meta.width,256);assert.equal(meta.height,256);assert.equal(meta.format,'webp');assert.equal(meta.exif,undefined);assert.ok(output.length<100*1024);assert.ok(output.length<jpeg.length);
 const {GET}=await import('../src/app/api/me/route');const me=await GET(new Request(origin+'/api/me',{headers:{Cookie:cookie}}),{});assert.equal((await me.json()).data.user.image,image);
 const cached=await avatarResponse(image.split('/').pop()!,new Request(origin+image,{headers:{'if-none-match':served.headers.get('etag')!}}));assert.equal(cached.status,304);
});
test('2MB is accepted; replacement deletes the old file and changes cache URL',async()=>{
 const padded=Buffer.concat([jpeg,Buffer.alloc(MAX_AVATAR_BYTES-jpeg.length)]),r=await request('PUT',padded);assert.equal(r.status,200);const next=(await r.json()).data.image;assert.notEqual(next,image);assert.deepEqual(await readdir(dir),[next.split('/').pop()]);image=next;
});
test('oversized payloads are rejected even with a false Content-Length',async()=>{
 for(const headers of [{'Content-Length':String(MAX_AVATAR_BYTES+1)},{'Content-Length':'1'}]){const r=await request('PUT',Buffer.alloc(MAX_AVATAR_BYTES+1),headers);assert.equal(r.status,413);}
 assert.equal((await db`SELECT image FROM "user" WHERE id=${userId}`)[0].image,image);
});
test('wrong origin, unauthenticated writes and direct auth image updates are rejected',async()=>{
 assert.equal((await request('DELETE',undefined,{Origin:'https://untrusted.invalid'})).status,403);
 assert.equal((await request('DELETE',undefined,{Cookie:''})).status,401);
 const {getAuth}=await import('../src/server/auth');const r=await getAuth().handler(new Request(origin+'/api/auth/update-user',{method:'POST',headers:{Origin:origin,Cookie:cookie,'Content-Type':'application/json'},body:JSON.stringify({image:'https://untrusted.invalid/avatar.jpg'})}));assert.equal(r.status,400);
 assert.equal((await db`SELECT image FROM "user" WHERE id=${userId}`)[0].image,image);
});
test('invalid and non-raster uploads are rejected without replacing current avatar',async()=>{
 for(const input of [Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>'),Buffer.from('GIF89a'),jpeg.subarray(0,20)])await assert.rejects(()=>compressAvatar(input));
 const webp=await sharp(jpeg).webp().toBuffer(),png=await sharp(jpeg).png().toBuffer();for(const input of [webp,png])assert.equal((await sharp(await compressAvatar(input)).metadata()).format,'webp');
 assert.equal(safeAvatarUrl('https://untrusted.invalid/a.webp'),null);assert.equal(safeAvatarUrl('/avatars/../../secret.webp'),null);
});
test('reset restores initial avatar and removes file; unknown files return 404',async()=>{
 const r=await request('DELETE');assert.equal(r.status,200);assert.equal((await r.json()).data.image,null);assert.deepEqual(await readdir(dir),[]);
 const {avatarResponse}=await import('../src/server/avatars');assert.equal((await avatarResponse(image.split('/').pop()!,new Request(origin+image))).status,404);
 assert.equal((await avatarResponse('../secret',new Request(origin+'/avatars/secret'))).status,404);
});
test('completed account deletion removes its stored avatar',async()=>{
 const id=randomUUID(),actor={id,name:'注销头像测试',email:randomUUID()+'@example.invalid',emailVerified:true,isAdmin:false};
 await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${id},${actor.name},${actor.email},true)`;
 try {
  const {setAvatar}=await import('../src/server/avatars');const stored=await setAvatar(actor,await compressAvatar(jpeg));assert.ok(stored.image);
  await db`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${id},'accountDeletionRequested',${id},'{}')`;
  const {completeAccountDeletion}=await import('../src/server/operations');await completeAccountDeletion({id:userId,name:'测试管理员',email,emailVerified:true,isAdmin:true},id,'仅隔离测试');
  assert.equal((await db`SELECT image FROM "user" WHERE id=${id}`)[0].image,null);assert.deepEqual(await readdir(dir),[]);
 } finally {await db`DELETE FROM audit_log WHERE target_id=${id}`;await db`DELETE FROM "user" WHERE id=${id}`;}
});
