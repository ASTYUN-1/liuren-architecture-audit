import test from 'node:test';
import assert from 'node:assert/strict';
import {applyIntent,requestIntent,intentPayload,type IntentDecision} from '../src/agent/input-intent';
import {signIntent,verifyIntent} from '../src/server/input-intent';
import {startRandomChart,stopRandomChart} from '../src/engine/random-chart';
import {calculateChart} from '../src/engine/liuren';
import type {CaseInput} from '../src/server/contracts';
process.env.BETTER_AUTH_SECRET='isolated-intent-fixture-only-secret-at-least-32';
const now='2026-10-17T12:00:00.000Z';
const base:CaseInput={question:'按二〇〇五年一月十二日下午两点四十九起课，问该男子能否升正科。',locale:'zh',mode:'time',time:'2026-10-17T10:49:01.806Z',timeZone:'Asia/Shanghai',participants:[],timeSource:'current'};
const decision=(p:Partial<IntentDecision>={}):IntentDecision=>({action:'configure',timeIntent:'explicit',parameters:{mode:'time',time:'2005-01-12T14:49:00+08:00'},summary:'按指定的历史时间起课',evidence:['二〇〇五年一月十二日下午两点四十九'],repairEvidence:[],clarification:undefined,...p});
test('AI请求采用Flash/high，中文意图交由模型理解而非数字正则',async()=>{
 let calls=0;const fake:typeof fetch=async(_url,init)=>{calls++;const body=JSON.parse(String(init?.body));assert.equal(body.model,'deepseek-flash');assert.equal(body.reasoning_effort,'high');assert.deepEqual(body.thinking,{type:'enabled'});assert.equal(body.tools,undefined);assert.equal(JSON.parse(body.messages[1].content).referenceNow,now);return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify(decision())}}]});};
 const d=await requestIntent(base,'fixture-only',{now},fake),r=applyIntent(base,d,{now});assert.equal(calls,1);assert.equal(r.input.time,'2005-01-12T06:49:00.000Z');assert.equal(calculateChart(r.input).normalized.date,'2005-01-12');
});
test('无起课要求才沿用默认；手动设定保留，当前时间由服务端固定',()=>{
 const keep=decision({action:'keep',timeIntent:'default',parameters:{},evidence:[]});
 assert.equal(applyIntent(base,keep,{now}).input.time,now);
 assert.equal(applyIntent({...base,timeSource:'custom'},keep,{now}).input.time,base.time);
 assert.equal(applyIntent(base,keep,{now,question:'继续说说'}).input.time,base.time);
 assert.equal(applyIntent(base,{...keep,timeIntent:'current'},{now}).input.time,now);
 assert.throws(()=>applyIntent({...base,timeSource:'custom'},{...keep,timeIntent:'current'},{now}),/intent_keep_invalid/);
});
test('汉字报数优先于页面时间方式，缺失的辅助报数控件不阻塞AI',()=>{
 const input={...base,mode:'number' as const,question:'按报数一百二十八来看这件合作。'};
 const r=applyIntent(input,decision({timeIntent:'default',parameters:{mode:'number',number:128},evidence:['报数一百二十八']}),{now});
 assert.equal(r.input.number,128);assert.equal(calculateChart(r.input).normalized.branch,'未');assert.equal(r.input.time,now);
});
test('背景日期不自动覆盖；歧义只澄清，不排盘或出报告',()=>{
 const d=decision({action:'clarify',parameters:{},clarification:'这个日期是起课日期还是事件发生日期？',evidence:[]});
 const r=applyIntent(base,d,{now});assert.equal(r.input,base);assert.equal(r.repair,false);
});
test('用现在和方式切换清除旧模式字段；人物不能由本命反推年份',()=>{
 const input={...base,mode:'number' as const,number:8,question:'不用报数了，用现在的时间起课，该男子子命。'};
 const r=applyIntent(input,decision({timeIntent:'current',parameters:{mode:'time',participants:[{role:'该男子',gender:'male',lifeBranch:'子'}]},evidence:['用现在的时间起课']}),{now});
 assert.equal(r.input.time,now);assert.equal(r.input.mode,'time');assert.equal(r.input.number,undefined);assert.equal(r.input.participants[0].birthYear,undefined);
});
test('明确更正可解除随机盘，普通追问保持原随机结果',()=>{
 const seed=startRandomChart({}),sel=stopRandomChart(seed.ticket,3),input={...base,mode:'number' as const,number:sel.number,time:sel.time,rules:sel.rules,random:{ticket:sel.ticket}};
 const r=applyIntent(input,decision(),{now,question:'按二〇〇五年一月十二日下午两点四十九更正'});assert.equal(r.input.random,undefined);assert.equal(r.input.mode,'time');
 const keep=applyIntent(input,decision({action:'keep',timeIntent:'default',parameters:{},evidence:[]}),{now,question:'继续分析'});assert.deepEqual(keep.input.random,input.random);assert.equal(keep.input.time,sel.time);
});
test('自然语言随机起课由服务器生成合法签名随机结果，模型不能自选数',()=>{
 const r=applyIntent({...base,question:'请随机起课判断合作'},decision({timeIntent:'default',parameters:{mode:'random'},evidence:['随机起课']}),{now});
 assert(r.input.random);assert(r.input.number!>=1&&r.input.number!<=12);calculateChart(r.input);
 assert.throws(()=>applyIntent({...base,question:'随机起课'},decision({timeIntent:'default',parameters:{mode:'random',number:3},evidence:['随机起课']}),{now}),/intent_random_conflict/);
});
test('拒绝不存在的日期、伪造证据、越权参数和不支持规则',()=>{
 assert.throws(()=>applyIntent(base,decision({parameters:{time:'2005-02-30T14:49:00+08:00'}}),{now}),/intent_invalid_date/);
 assert.throws(()=>applyIntent(base,decision({evidence:['并不存在的用户原话']}),{now}),/intent_evidence_invalid/);
 assert.throws(()=>applyIntent(base,{...decision(),parameters:{apiKey:'injection'}},{now}));
 assert.throws(()=>applyIntent(base,decision({parameters:{time:'2005-01-12T14:49:00+08:00',rules:{yuejiang:'任意规则' as any}}}),{now}));
});
test('错误原请求的修复与用户新改主意分开；普通追问不可静默改参',()=>{
 assert.equal(applyIntent(base,decision({repairEvidence:['二〇〇五年一月十二日下午两点四十九']}),{now,question:'请按原要求更正'}).repair,true);
 assert.equal(applyIntent(base,decision(),{now,question:'改个时间'}).repair,false);
 assert.throws(()=>applyIntent(base,decision({action:'keep'}),{now,question:'继续'}),/intent_keep_invalid/);
});
test('重申已经生效的相同时间仍属于正常追问，不创建收费新版本',()=>{
 const r=applyIntent({...base,timeSource:'custom',time:'2005-01-12T06:49:00.000Z'},decision(),{now,question:'继续按二〇〇五年一月十二日下午两点四十九分析'});
 assert.equal(r.decision.action,'keep');assert.equal(r.repair,false);
});
test('输入凭据绑定账户、内容、摘要、档案版本及追问；篡改/重放不可通过',()=>{
 const a={id:'fixture-owner'},input=applyIntent(base,decision(),{now}).input,binding={action:'configure' as const,caseId:'case-fixture',inputVersion:1,question:'更正时间',repair:true};
 input.intent={summary:'历史时间',receipt:signIntent(a,input,'历史时间',binding)};
 assert.equal(verifyIntent(a,input,binding,true).repair,true);
 for(const [owner,value,b] of [[{id:'other'},input,binding],[a,{...input,time:now},binding],[a,{...input,intent:{...input.intent,summary:'篡改'}},binding],[a,input,{...binding,inputVersion:2}],[a,input,{...binding,question:'其他请求'}]] as const)assert.throws(()=>verifyIntent(owner,value,b),{code:'INPUT_REVIEW_REQUIRED'});
});
test('供应商失败或截断不默默降级为当前时间',async()=>{
 for(const fake of [async()=>new Response('',{status:503}),async()=>Response.json({choices:[{finish_reason:'length',message:{content:'{}'}}]})])await assert.rejects(()=>requestIntent(base,'fixture',{now},fake as typeof fetch));
 assert.equal(intentPayload(base,{history:Array.from({length:10},()=>({question:'补充',answer:'不应送旧结论'}))}).history.length,6);
 assert(!JSON.stringify(intentPayload(base,{history:[{question:'继续',answer:'不应送旧结论'}]})).includes('不应送旧结论'));
});

test('兼容模型可选空值与单条原文格式，不放宽实际参数或引用校验',()=>{
 const r=applyIntent(base,{...decision(),parameters:{...decision().parameters,rules:[],longitude:null},evidence:'二〇〇五年一月十二日下午两点四十九',repairEvidence:'',clarification:null},{now});assert.equal(r.input.time,'2005-01-12T06:49:00.000Z');
 assert.throws(()=>applyIntent(base,{...decision(),repairEvidence:'无原文'},{now}),/intent_evidence_invalid/);
});
