import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { sqlClient } from '../src/server/db';
import { defaultPointsConfig, pointsConfig, savePointsConfig } from '../src/server/points-config';
import type { Actor } from '../src/server/http';

if (!process.env.DATABASE_URL || !/wenheng_test|wenheng-test|test_wenheng/.test(new URL(process.env.DATABASE_URL).pathname)) throw new Error('Refusing non-test DB');
Object.assign(process.env, { NODE_ENV: 'test', SETTINGS_RECORD_KEY: randomUUID() });
const db = sqlClient();
const admin: Actor = { id: 'contact-config-test', name: 'Test', email: 'test@example.invalid', emailVerified: true, isAdmin: true };
after(async () => {
  await db`DELETE FROM service_settings WHERE key=${'test:' + process.env.SETTINGS_RECORD_KEY + ':points'}`;
  await db.end();
});

test('legacy contact settings without a type remain WeChat after save', async () => {
  const config = defaultPointsConfig();
  config.advisors[0].wechatId = 'legacy_wechat';
  const saved = await savePointsConfig(admin, config);
  assert.equal(saved.advisors[0].contactType, 'wechat');
  assert.equal(saved.advisors[0].wechatId, 'legacy_wechat');
});

test('QQ contact type persists through config updates while official top-up stays WeChat', async () => {
  const config = defaultPointsConfig();
  config.wechatId = 'topup_wechat';
  config.topupEnabled = true;
  config.advisors[0] = { ...config.advisors[0], contactType: 'qq', wechatId: '123456789' };
  await savePointsConfig(admin, config);
  const loaded = await pointsConfig();
  assert.equal(loaded.advisors[0].contactType, 'qq');
  assert.equal(loaded.advisors[0].wechatId, '123456789');
  assert.equal(loaded.wechatId, 'topup_wechat');
  const partialOldClient = { ...loaded, advisors: loaded.advisors.map(({ contactType, ...advisor }) => advisor) };
  assert.equal((await savePointsConfig(admin, partialOldClient)).advisors[0].contactType, 'qq');
});

test('invalid contact type or QQ number cannot overwrite saved contacts', async () => {
  const before = await pointsConfig();
  for (const advisor of [{ ...before.advisors[0], contactType: 'other' }, { ...before.advisors[0], wechatId: 'not_qq' }]) {
    await assert.rejects(() => savePointsConfig(admin, { ...before, advisors: [advisor, ...before.advisors.slice(1)] }));
    assert.deepEqual(await pointsConfig(), before);
  }
  await assert.rejects(() => savePointsConfig({ ...admin, isAdmin: false }, before));
});
