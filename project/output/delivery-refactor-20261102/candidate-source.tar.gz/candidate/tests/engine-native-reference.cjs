const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const ctx=vm.createContext({console:{log(){},error(){}},window:{indexedDB:{open(){return {}}}},vm_glob:{USER_ALL_DATA:{pages_config:{zhuti_config:{zhuti_bord_clor:'#182A28'}}}},setTimeout(){},setInterval(){},clearInterval(){}});
for(const f of ['lunar.js','data.js','api.js','guize.js','paipan.js'])vm.runInContext(fs.readFileSync(path.join(process.argv[2],'排盘工具魔改/js',f),'utf8'),ctx,{timeout:5000});
ctx.input=JSON.parse(process.argv[3]);const p=vm.runInContext('LiuRenPaiPan(input)',ctx,{timeout:10000});process.stdout.write(JSON.stringify(Object.fromEntries(['sizhu','yuejiang','sike','sanchuan','tianpan','shenpan'].map(k=>[k,p[k]]))));
