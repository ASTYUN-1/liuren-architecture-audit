/** Integration tests against an isolated PostgreSQL database; never a production DB. */
import {test,after,before} from "node:test";
import assert from "node:assert/strict";
import {randomUUID} from "node:crypto";
import {sqlClient,authDb} from "../src/server/db";
import {createCase,createOrder,confirmPayment,createTurn,requestRefund,confirmRefund,caseDetail,deleteCase,patchCase,exportCase,totals,submitPayment} from "../src/server/service";
import {encryptSecret,decryptSecret,getSettings,updateSettings,publicService,testConnection} from "../src/server/settings";
import {type Actor} from "../src/server/http";
import {adminOverview} from "../src/server/service";
import {completeAccountDeletion} from "../src/server/operations";
if(!process.env.DATABASE_URL||!/wenheng_test|wenheng-test|test_wenheng/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error("Refusing tests outside isolated wenheng_test database");
Object.assign(process.env,{NODE_ENV:"test"});process.env.SETTINGS_RECORD_KEY=randomUUID();process.env.WENHENG_ENCRYPTION_KEY="ab".repeat(32);process.env.SMTP_HOST="test.invalid";process.env.SMTP_FROM="test@example.invalid";process.env.DEEPSEEK_API_KEY="not-a-real-key";process.env.AI_ENABLED="true";process.env.MANUAL_PAYMENT_ENABLED="true";process.env.PAYMENT_QR_URL="https://example.invalid/payment.png";
const db=sqlClient();const owner:Actor={id:"test-"+randomUUID(),name:"Test owner",email:"owner-"+randomUUID()+"@example.invalid",emailVerified:true,isAdmin:false};const other:Actor={...owner,id:"test-"+randomUUID(),email:"other-"+randomUUID()+"@example.invalid"};const admin:Actor={...owner,isAdmin:true};
const input={question:"这次分手能否复合？",locale:"zh",mode:"time",timeZone:"Asia/Shanghai",time:"2026-10-15T00:00:00+08:00",participants:[{role:"本人",gender:"female",birthYear:1995}]};
before(async()=>{await db`INSERT INTO service_settings(key,value) VALUES(${"test:"+process.env.SETTINGS_RECORD_KEY+":workerHeartbeat"},${db.json({at:new Date().toISOString()})})`;await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${owner.id},${owner.name},${owner.email},true),(${other.id},${other.name},${other.email},true)`;});
after(async()=>{
  for(const table of ["entitlement_ledger","tasks","entitlements","orders","case_inputs","deletion_tombstones"]){
    await db.unsafe(`DELETE FROM ${table} WHERE case_id IN (SELECT id FROM cases WHERE user_id IN ($1,$2))`,[owner.id,other.id]);
  }
  await db`DELETE FROM cases WHERE user_id IN (${owner.id},${other.id})`;
  await db`DELETE FROM audit_log WHERE actor_id=${owner.id}`;
  await db`DELETE FROM "user" WHERE id IN (${owner.id},${other.id})`;
  await db`DELETE FROM service_settings WHERE key=${"test:"+process.env.SETTINGS_RECORD_KEY}`;
  await db`DELETE FROM service_settings WHERE key=${"test:"+process.env.SETTINGS_RECORD_KEY+":workerHeartbeat"}`;
  await db.end();
});async function paidCase(){const c=await createCase(owner,{input});const order=await createOrder(owner,c.id,{kind:"base",idempotencyKey:randomUUID()});await confirmPayment(admin,order.id,{reference:randomUUID()});await db`UPDATE tasks SET status='succeeded' WHERE case_id=${c.id}`;await db`UPDATE cases SET status='ready',report=${db.json({title:"测试",summary:"测试结论",content:"测试解读文本",chart:{secret:"chart must never export"}})} WHERE id=${c.id}`;return {c,order};}
test("认证Drizzle初始化不能破坏业务原生JSON数据库写入",async()=>{authDb();const c=await createCase(owner,{title:"认证连接隔离回归",input});assert.equal(c.input.question,input.question);assert.equal(c.input.time,"2026-10-14T16:00:00.000Z");});
test("运营摘要只含归属和安全元数据，待退款阻止完成删除",async()=>{
 const {c,order}=await paidCase();const [task]=await db`SELECT id FROM tasks WHERE case_id=${c.id} LIMIT 1`;
 const secret="PRIVATE_PROMPT_AND_API_SECRET_DO_NOT_RETURN";
 await db`UPDATE tasks SET usage=${db.json({requests:3,inputTokens:100,outputTokens:50,costCny:0.2,model:"deepseek-flash",supplier:"DeepSeek official",engineVersion:"legacy-beijing-midnight-v1-1234567890abcdef",knowledgeVersion:"test-release",prompt:secret,apiKey:secret,reasoning:secret})},internal_evidence=${db.json({secret})} WHERE id=${task.id}`;
 await db`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},'system','taskFailed',${task.id},${db.json({code:"model_budget_exceeded",raw:secret})})`;
 const beforeDeletion=await adminOverview(admin);const usageTask=beforeDeletion.tasks.find(t=>t.id===task.id)!;
 assert.equal(usageTask.usage?.costCny,0.2);assert.equal(usageTask.usage?.requests,3);assert.equal(usageTask.usage?.engineVersion,"legacy-beijing-midnight-v1-1234567890abcdef");assert.equal(usageTask.failureCode,"model_budget_exceeded");assert.equal(JSON.stringify(beforeDeletion).includes(secret),false);
 await deleteCase(owner,c.id,true);
 await db`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${owner.id},'accountDeletionRequested',${owner.id},${db.json({secret})})`;
 // Fixture deletion above has a delivered base report. Create an actual pending
 // refund to demonstrate the deletion completion gate and operator summary.
 await db`UPDATE orders SET status='refundPending',refund_requested_cents=2990 WHERE id=${order.id}`;
 await assert.rejects(()=>adminOverview(owner),/Administrator/);
 let view=await adminOverview(admin);let req=view.deletionRequests.find(r=>r.userId===owner.id)!;
 assert.equal(req.pendingRefundCents,2990);assert.equal(req.canComplete,false);
 assert.ok(view.ledger.some(l=>l.caseId===c.id&&l.userId===owner.id&&l.orderId===order.id));
 assert.equal(JSON.stringify(view).includes(secret),false);
 await assert.rejects(()=>completeAccountDeletion({...admin,id:other.id},owner.id,'测试待退款阻挡'),/退款/);
 await confirmRefund(admin,order.id,randomUUID());
 view=await adminOverview(admin);req=view.deletionRequests.find(r=>r.userId===owner.id)!;
 // Another regression test draft is intentionally still present, and independently
 // prevents deletion rather than silently destroying unrelated retained cases.
 assert.equal(req.pendingRefundCount,0);assert.equal(req.canComplete,false);
 await assert.rejects(()=>completeAccountDeletion({...admin,id:other.id},owner.id,'测试剩余档案阻挡'),/档案/);
 await db`DELETE FROM audit_log WHERE target_id=${owner.id} AND action='accountDeletionRequested'`;
});
test("worker心跳缺失或超过90秒会关闭AI和新收费，恢复心跳可恢复",async()=>{
 const key="test:"+process.env.SETTINGS_RECORD_KEY+":workerHeartbeat";
 await db`DELETE FROM service_settings WHERE key=${key}`;
 let service=await publicService();assert.equal(service.workerOnline,false);assert.equal(service.aiEnabled,false);assert.equal(service.paymentsEnabled,false);
 await db`INSERT INTO service_settings(key,value) VALUES(${key},${db.json({at:new Date(Date.now()-91000).toISOString()})})`;
 service=await publicService();assert.equal(service.workerOnline,false);assert.equal(service.paymentsEnabled,false);
 await db`UPDATE service_settings SET value=${db.json({at:new Date().toISOString()})} WHERE key=${key}`;
 service=await publicService();assert.equal(service.workerOnline,true);assert.equal(service.aiEnabled,true);assert.equal(service.paymentsEnabled,true);
});
test("暂停新收费不封锁已购追问，且已付款参考在维护时仍能提交",async()=>{
 const {c}=await paidCase();
 const draft=await createCase(owner,{input});
 const order=await createOrder(owner,draft.id,{kind:'base',idempotencyKey:randomUUID()});
 try{
  await updateSettings(admin,{paymentsEnabled:false});
  const service=await publicService();
  assert.equal(service.paymentsEnabled,false);assert.equal(service.paymentUnavailableReason,'paymentsPaused');
  assert.equal(service.paymentQrIsPlaceholder,false);assert.equal(service.aiEnabled,true);
  await assert.rejects(()=>createOrder(owner,draft.id,{kind:'base',idempotencyKey:randomUUID()}),/暂未开放新订单/);
  const submitted=await submitPayment(owner,order.id,{paymentReference:'maintenance-receipt-'+order.id});
  assert.equal(submitted.status,'submitted');assert.equal((await totals(db,draft.id)).granted,0);
  const followup=await createTurn(owner,c.id,{question:'新订单暂停时使用已购次数',idempotencyKey:randomUUID()});
  assert.equal(followup.status,'queued');assert.equal((await totals(db,c.id)).remaining,1);
 }finally{await updateSettings(admin,{paymentsEnabled:true});}
});

test("缺失收款码与运营暂停具有不同状态原因，恢复配置后可再次下单",async()=>{
 try{
  await updateSettings(admin,{paymentQrUrl:'/payment-placeholder.svg'});
  let service=await publicService();assert.equal(service.paymentsEnabled,false);assert.equal(service.paymentUnavailableReason,'paymentCodeMissing');
  await updateSettings(admin,{paymentQrUrl:'https://example.invalid/payment.png'});
  service=await publicService();assert.equal(service.paymentsEnabled,true);assert.equal(service.paymentUnavailableReason,null);
 }finally{await updateSettings(admin,{paymentQrUrl:'https://example.invalid/payment.png'});}
});

test("模型连接HTTP200但缺deepseek-flash不得验证成功",async()=>{
 const original=globalThis.fetch;
 try{
   globalThis.fetch=async()=>Response.json({data:[{id:"other-model"}]});
   await assert.rejects(()=>testConnection(admin,"ai"),/deepseek-flash/);
   globalThis.fetch=async()=>Response.json({data:[{id:"deepseek-flash"}]});
   assert.equal((await testConnection(admin,"ai")).ok,true);
 }finally{globalThis.fetch=original;}
});
test("旧版本取消订单迟到到账可完整退款，并不抢占新版本基础订单",async()=>{const c=await createCase(owner,{input});const old=await createOrder(owner,c.id,{kind:'base',idempotencyKey:randomUUID()});await patchCase(owner,c.id,{input:{...input,question:'已更改的同一测试问题'}});const current=await createOrder(owner,c.id,{kind:'base',idempotencyKey:randomUUID()});const late=await confirmPayment(admin,old.id,{reference:randomUUID()});assert.equal(late.status,'refundPending');assert.equal(late.refundRequestedCents,2990);assert.equal((await totals(db,c.id)).granted,0);await confirmRefund(admin,old.id,randomUUID());await confirmPayment(admin,current.id,{reference:randomUUID()});assert.equal((await totals(db,c.id)).granted,2);});
test("付款自报仅提交参考；重复并发管理员确认只授予一次",async()=>{const c=await createCase(owner,{input});const key=randomUUID();const orders=await Promise.all(Array.from({length:5},()=>createOrder(owner,c.id,{kind:"base",idempotencyKey:key})));assert.equal(new Set(orders.map(o=>o.id)).size,1);const o=orders[0];await submitPayment(owner,o.id,{paymentReference:"用户填写的截图编号"});assert.equal((await totals(db,c.id)).granted,0);await Promise.all(Array.from({length:4},()=>confirmPayment(admin,o.id,{reference:"actual-receipt-"+o.id})));assert.equal((await totals(db,c.id)).granted,2);assert.equal((await db`SELECT id FROM tasks WHERE case_id=${c.id}`).length,1);});
test("跨用户读取、改写、导出都被拒绝",async()=>{const c=await createCase(owner,{input});await assert.rejects(()=>caseDetail(other,c.id));await assert.rejects(()=>patchCase(other,c.id,{title:"hijack"}));await assert.rejects(()=>exportCase(other,c.id));});
test("并发追问仅一条活跃任务，幂等不会双扣，先预留不算使用",async()=>{const {c}=await paidCase();const key=randomUUID();const answers=await Promise.all(Array.from({length:4},()=>createTurn(owner,c.id,{question:"我该如何联系对方？",idempotencyKey:key})));assert.equal(new Set(answers.map(x=>x.id)).size,1);const t=await totals(db,c.id);assert.equal(t.used,0);assert.equal(t.remaining,1);await assert.rejects(()=>createTurn(owner,c.id,{question:"还想问一次",idempotencyKey:randomUUID()}));});
test("并发加购守住两包与八次上限；满额仍保留余额",async()=>{const {c}=await paidCase();const added=await Promise.allSettled(Array.from({length:6},()=>createOrder(owner,c.id,{kind:"addon",idempotencyKey:randomUUID()})));const successes=added.filter(x=>x.status==="fulfilled");assert.equal(successes.length,2);for(const p of successes){if(p.status==="fulfilled")await confirmPayment(admin,p.value.id,{reference:randomUUID()});}const t=await totals(db,c.id);assert.equal(t.granted,8);assert.equal(t.remaining,8);assert.equal(t.canPurchaseAddon,false);await createTurn(owner,c.id,{question:"下一步该怎么做？",idempotencyKey:randomUUID()});});
test("追加退款冻结未用次数；实际确认退款撤回；全退可重新买",async()=>{const {c}=await paidCase();const o=await createOrder(owner,c.id,{kind:"addon",idempotencyKey:randomUUID()});await confirmPayment(admin,o.id,{reference:randomUUID()});const pending=await requestRefund(owner,o.id,"退还未用额度");assert.equal(pending.refundRequestedCents,990);assert.equal((await totals(db,c.id)).remaining,2);await confirmRefund(admin,o.id,randomUUID());assert.equal((await totals(db,c.id)).granted,2);await createOrder(owner,c.id,{kind:"addon",idempotencyKey:randomUUID()});});
test("归档不损失权益；删除取消任务且永久删除后仍可实际退款",async()=>{const {c}=await paidCase();const o=await createOrder(owner,c.id,{kind:"addon",idempotencyKey:randomUUID()});await confirmPayment(admin,o.id,{reference:randomUUID()});await patchCase(owner,c.id,{archived:true});assert.equal((await totals(db,c.id)).remaining,5);await createTurn(owner,c.id,{question:"请补充建议",idempotencyKey:randomUUID()});const deleted=await deleteCase(owner,c.id,true);assert.equal(deleted.refundPending,true);assert.equal((await db`SELECT status FROM tasks WHERE case_id=${c.id} AND kind='followup'`)[0].status,"cancelled");await confirmRefund(admin,o.id,randomUUID());await assert.rejects(()=>caseDetail(owner,c.id));assert.equal((await db`SELECT input FROM case_inputs WHERE case_id=${c.id}`).length,0);});
test("官方导出只有报告对话，无chart JSON/内部盘面",async()=>{const {c}=await paidCase();const response=await exportCase(owner,c.id);const exported=await response.text();assert.match(exported,/测试解读文本/);assert.doesNotMatch(exported,/chart must never export|secret/);});
test("加密配置不返回密钥，AEAD篡改拒绝",async()=>{const secret="sensitive-not-real-key";const cipher=encryptSecret(secret);assert.notEqual(cipher,secret);assert.equal(decryptSecret(cipher),secret);const parts=cipher.split(".");parts[2]=Buffer.from("tampered").toString("base64");assert.throws(()=>decryptSecret(parts.join(".")));await updateSettings(admin,{deepseekApiKey:secret,smtpPassword:"test-secret"});const json=JSON.stringify(await getSettings());assert.doesNotMatch(json,/sensitive-not-real-key|test-secret/);assert.match(json,/hasDeepseekApiKey/);});
test("并发草稿限制10，正式容量100在收款前拒绝",async()=>{const drafts=await Promise.allSettled(Array.from({length:12},()=>createCase(other,{input})));const created=drafts.filter(x=>x.status==='fulfilled');assert.equal(created.length,10);await db`INSERT INTO cases(id,user_id,title,status) SELECT gen_random_uuid(),${other.id},'Capacity test','ready' FROM generate_series(1,100)`;const first=created[0];if(first.status==='fulfilled')await assert.rejects(()=>createOrder(other,first.value.id,{kind:'base',idempotencyKey:randomUUID()}),/100/);assert.equal((await db`SELECT id FROM orders WHERE user_id=${other.id}`).length,0);});
test("澄清释放后已退款的权益不能复活，永久删除不能恢复",async()=>{const {c}=await paidCase();const o=await createOrder(owner,c.id,{kind:'addon',idempotencyKey:randomUUID()});await confirmPayment(admin,o.id,{reference:randomUUID()});const [e]=await db`SELECT id FROM entitlements WHERE order_id=${o.id}`;const id=randomUUID();await db`INSERT INTO tasks(id,case_id,user_id,kind,status,input_version,question,idempotency_key,entitlement_id,clarification) VALUES(${id},${c.id},${owner.id},'followup','succeeded',1,'澄清中的问题',${randomUUID()},${e.id},'请补充情况')`;await requestRefund(owner,o.id,'退还追加包');await confirmRefund(admin,o.id,randomUUID());await assert.rejects(()=>createTurn(owner,c.id,{question:'补充信息',idempotencyKey:randomUUID(),clarificationTaskId:id}),/退款或冻结/);await deleteCase(owner,c.id,true);await assert.rejects(()=>patchCase(owner,c.id,{restore:true}),/永久删除/);});
test("worker恢复持久任务但缺模型时不得生成假报告或扣次",async()=>{const {c}=await paidCase();const task=await createTurn(owner,c.id,{question:'测试worker持久恢复',idempotencyKey:randomUUID()});await updateSettings(admin,{aiEnabled:false,clearDeepseekApiKey:true});const {executeTask}=await import('../src/server/worker');await executeTask(task.id);const [row]=await db`SELECT status,attempts,answer FROM tasks WHERE id=${task.id}`;assert.equal(row.status,'failed');assert.equal(row.attempts,1);assert.equal(row.answer,null);const t=await totals(db,c.id);assert.equal(t.used,0);assert.equal(t.remaining,2);});





