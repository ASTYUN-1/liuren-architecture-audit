import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {proxyModel,readJson,ModelUsageTracker,MODEL_REQUEST_MAX_BYTES,INTERNAL_JSON_REQUEST_MAX_BYTES} from '../src/agent/gateway';
import {closeModelTransport} from '../src/agent/model-transport';
import {modelExecutionCode} from '../src/agent/session-completion';
test('模型请求单独允许16MiB，MCP仍2MB；超限明确报错且不访问供应商',async()=>{
 const original=globalThis.fetch;let supplierCalls=0;
 globalThis.fetch=(async(url:any,init:any)=>{if(String(url)!=='https://api.deepseek.com/v1/chat/completions')return original(url,init);supplierCalls++;assert.equal(JSON.parse(init.body).messages[0].content.length,3*1024*1024);return new Response(JSON.stringify({id:'body-limit-fixture',created:1,model:'deepseek-flash',choices:[{index:0,message:{role:'assistant',content:'ok'},finish_reason:'stop'}],usage:{prompt_tokens:1,completion_tokens:1}}));}) as typeof fetch;
 const budget=new ModelUsageTracker(),server=createServer((req,res)=>{if(req.url==='/model')void proxyModel(req,res,'synthetic-key',budget,new AbortController().signal);else void readJson(req).then(()=>{res.end('ok');}).catch(e=>{res.writeHead(400,{'content-type':'application/json'});res.end(JSON.stringify({error:{message:e.message}}));});});
 await new Promise<void>(ok=>server.listen(0,'127.0.0.1',ok));const a=server.address();assert(a&&typeof a==='object');const base=`http://127.0.0.1:${a.port}`;
 const send=(path:string,length:number)=>fetch(base+path,{method:'POST',body:JSON.stringify({model:'deepseek-flash',messages:[{role:'user',content:'x'.repeat(length)}]})});
 try{
  assert.equal(MODEL_REQUEST_MAX_BYTES,16*1024*1024);assert.equal(INTERNAL_JSON_REQUEST_MAX_BYTES,2_000_000);
  const allowed=await send('/model',3*1024*1024);assert.equal(allowed.status,200);assert((await allowed.text()).includes('[DONE]'));
  const mcp=await send('/mcp',3*1024*1024);assert.equal(mcp.status,400);assert.equal((await mcp.json()).error.message,'request_too_large');
  const model=await send('/model',MODEL_REQUEST_MAX_BYTES);assert.equal(model.status,400);assert.equal((await model.json()).error.message,'model_request_too_large');assert.equal(supplierCalls,1);assert.equal(budget.usage.requests,1);
  assert.equal(modelExecutionCode({data:{responseBody:JSON.stringify({error:{message:'model_request_too_large'}})}}),'model_request_too_large');
 }finally{globalThis.fetch=original;server.closeAllConnections();await new Promise<void>(ok=>server.close(()=>ok()));await closeModelTransport();}
});
