import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {PgBoss} from 'pg-boss';
import {sqlClient} from '../src/server/db';
import {createCase,lockCase} from '../src/server/service';
import {creditPoints,reservePoints,walletTotals} from '../src/server/points';
import {cancelPointTask,recordUsage,settleAi,resolveUsageReview} from '../src/server/points-ai';
import {adminNotices} from '../src/server/admin-notices';
import {watchTaskCancellation} from '../src/server/task-cancellation-signal';
import {dispatchTasks,QUEUE_REDISPATCH_SECONDS} from '../src/server/task-dispatch';
import {QUEUE} from '../src/server/queue';
import {QUEUE_EXPIRE_SECONDS} from '../src/agent/execution-control';
import {quotePoints} from '../src/lib/points-pricing';
import {acquireInputLease} from '../src/server/input-intent-lease';
import {executeTask} from '../src/server/worker';
import type {Actor} from '../src/server/http';
if(!process.env.DATABASE_URL||!/wenheng_test|wenheng-test|test_wenheng/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error('Refusing non-test DB');
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:randomUUID(),WENHENG_ENCRYPTION_KEY:'ab'.repeat(32),DEEPSEEK_API_KEY:'synthetic-do-not-call',AI_ENABLED:'true'});
// No model invocation belongs in this suite, including through a retry path.
globalThis.fetch=(async()=>{throw new Error('test_external_network_forbidden');}) as typeof fetch;
const db=sqlClient(),ids=['server-opt-'+randomUUID(),'server-opt-'+randomUUID()];
const actor=(id:string):Actor=>({id,name:'synthetic',email:id+'@example.invalid',emailVerified:true,isAdmin:false}),owner=actor(ids[0]),other=actor(ids[1]),admin={...owner,isAdmin:true};
const input={question:'纯合成隔离任务',locale:'zh',mode:'time',time:'2026-11-02T00:00:00+08:00',timeZone:'Asia/Shanghai',participants:[]};
let boss:PgBoss;
async function fixture(a=owner,status='queued'){
 const c=await createCase(a,{input}),taskId=randomUUID();const snapshot=quotePoints('initial',100);
 await db.begin(async tx=>{await lockCase(tx,c.id,a.id);const h=await reservePoints(tx,a.id,'initial',snapshot.reserveUnits,randomUUID(),snapshot,c.id,taskId);await tx`INSERT INTO tasks(id,case_id,user_id,kind,status,input_version,idempotency_key,point_hold_id,attempts,worker_token) VALUES(${taskId},${c.id},${a.id},'initial',${status},1,${randomUUID()},${h.id},1,${status==='running'?randomUUID():null})`;await tx`UPDATE cases SET status=${status} WHERE id=${c.id}`;});
 return {caseId:c.id,taskId};
}
before(async()=>{for(const a of [owner,other]){await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${a.id},'synthetic',${a.email},true)`;await creditPoints(admin,{userId:a.id,kind:'bonus',units:100000,reason:'synthetic isolation only',idempotencyKey:randomUUID()});}boss=new PgBoss({connectionString:process.env.DATABASE_URL});await boss.start();await boss.createQueue(QUEUE,{policy:'exclusive',retryLimit:0,expireInSeconds:QUEUE_EXPIRE_SECONDS});});
after(async()=>{await boss.deleteQueue(QUEUE);await boss.stop({graceful:true,timeout:1000});await db`DELETE FROM point_usage_events WHERE task_id IN (SELECT id FROM tasks WHERE user_id IN (${ids[0]},${ids[1]}))`;await db`UPDATE tasks SET point_hold_id=NULL WHERE user_id IN (${ids[0]},${ids[1]})`;await db`DELETE FROM point_ledger WHERE user_id IN (${ids[0]},${ids[1]})`;await db`DELETE FROM point_debts WHERE user_id IN (${ids[0]},${ids[1]})`;await db`DELETE FROM point_holds WHERE user_id IN (${ids[0]},${ids[1]})`;await db`DELETE FROM point_lots WHERE user_id IN (${ids[0]},${ids[1]})`;await db`DELETE FROM audit_log WHERE actor_id IN (${ids[0]},${ids[1]}) OR target_id IN (SELECT id::text FROM tasks WHERE user_id IN (${ids[0]},${ids[1]}))`;await db`DELETE FROM tasks WHERE user_id IN (${ids[0]},${ids[1]})`;await db`DELETE FROM case_inputs WHERE case_id IN (SELECT id FROM cases WHERE user_id IN (${ids[0]},${ids[1]}))`;await db`DELETE FROM cases WHERE user_id IN (${ids[0]},${ids[1]})`;await db`DELETE FROM "user" WHERE id IN (${ids[0]},${ids[1]})`;await db.end();});
test('users can stop more than three running tasks; repeated cancellation releases exactly once and notifies immediately',async()=>{
 const before=await walletTotals(db,owner.id);
 for(let i=0;i<5;i++){const f=await fixture(owner,'running'),abort=new AbortController();const unwatch=await watchTaskCancellation(f.taskId,abort);const stopped=new Promise<void>((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('cancellation notify was not delivered')),1500);abort.signal.addEventListener('abort',()=>{clearTimeout(timeout);resolve();},{once:true});});await Promise.all([cancelPointTask(owner,f.taskId),cancelPointTask(owner,f.taskId)]);await stopped;unwatch();const [count]=await db`SELECT count(*)::int AS n FROM point_ledger WHERE hold_id=(SELECT point_hold_id FROM tasks WHERE id=${f.taskId}) AND action='released'`;assert.equal(count.n,1);}
 assert.deepEqual(await walletTotals(db,owner.id),before);
});
test('free input reviews prevent duplicate concurrent work across accounts without a daily usage cap',async()=>{
 const one=await acquireInputLease(owner.id,'synthetic-input-1');
 await assert.rejects(()=>acquireInputLease(owner.id,'synthetic-input-1'),{code:'INPUT_REVIEW_ACTIVE'});
 const two=await acquireInputLease(owner.id,'synthetic-input-2');
 await assert.rejects(()=>acquireInputLease(owner.id,'synthetic-input-3'),{code:'INPUT_REVIEW_BUSY'});
 const independent=await acquireInputLease(other.id,'synthetic-input-1');await one();
 const next=await acquireInputLease(owner.id,'synthetic-input-3');await Promise.all([two(),next(),independent()]);
 for(let i=0;i<45;i++){const release=await acquireInputLease(owner.id,'synthetic-sequential-'+i);await release();}
});
test('execution elapsed time survives retries while queued waiting is excluded',async()=>{
 const f=await fixture();
 await db`UPDATE tasks SET execution_elapsed_ms=1799000,status='running',worker_token=${randomUUID()} WHERE id=${f.taskId}`;
 await db`UPDATE tasks SET execution_started_at=now()-interval '2 seconds' WHERE id=${f.taskId}`;
 await db`UPDATE tasks SET status='queued',worker_token=NULL WHERE id=${f.taskId}`;
 const [first]=await db`SELECT execution_elapsed_ms,execution_started_at FROM tasks WHERE id=${f.taskId}`;assert.ok(Number(first.execution_elapsed_ms)>=1801000);assert.equal(first.execution_started_at,null);
 await db`UPDATE tasks SET status='running',worker_token=${randomUUID()} WHERE id=${f.taskId}`;
 const [next]=await db`SELECT execution_elapsed_ms,execution_started_at FROM tasks WHERE id=${f.taskId}`;assert.equal(next.execution_elapsed_ms,first.execution_elapsed_ms);assert.ok(next.execution_started_at);await cancelPointTask(owner,f.taskId);
});
test('an exhausted shared execution allowance fails before reading model configuration or calling any API',async()=>{
 const f=await fixture();await db`UPDATE tasks SET execution_elapsed_ms=1800000 WHERE id=${f.taskId}`;
 await executeTask(f.taskId);const [task]=await db`SELECT t.status,t.error,h.status AS hold_status FROM tasks t JOIN point_holds h ON h.id=t.point_hold_id WHERE t.id=${f.taskId}`;assert.equal(task.status,'failed');assert.match(task.error,/30分钟/);assert.equal(task.hold_status,'released');
});
test('unknown usage is isolated to its delivered task; explicit reconciliation keeps original charges and evidence',async()=>{
 const f=await fixture();await recordUsage(f.taskId,1,{requestId:randomUUID(),responseId:null,input:0,output:0,cached:0,costNano:'0',verified:false,billable:false});await recordUsage(f.taskId,1,{requestId:randomUUID(),responseId:'synthetic-response',input:100,output:100,cached:0,costNano:'1000000',verified:true,billable:true});
 await db.begin(async tx=>{await lockCase(tx,f.caseId,owner.id);const [t]=await tx`SELECT * FROM tasks WHERE id=${f.taskId} FOR UPDATE`;await settleAi(tx,t);await settleAi(tx,t);await tx`UPDATE tasks SET status='succeeded' WHERE id=${f.taskId}`;});
 const [h]=await db`SELECT h.* FROM point_holds h JOIN tasks t ON t.point_hold_id=h.id WHERE t.id=${f.taskId}`;assert.equal(h.charged_units,aiExpected(h.snapshot));assert.equal(h.snapshot.unknownUsage,1);
 const notice=await adminNotices(admin);assert.ok(notice.modules.tasks?.items.some(i=>i.key==='usage-review:'+f.taskId));
 await assert.rejects(()=>resolveUsageReview(owner,f.taskId,'synthetic verified note'));
 await resolveUsageReview(admin,f.taskId,'核对供应商记录，保留已验证结算且不推定缺失部分费用');await resolveUsageReview(admin,f.taskId,'duplicate acknowledgement');
 const [after]=await db`SELECT h.charged_units,t.billing_review_status FROM tasks t JOIN point_holds h ON h.id=t.point_hold_id WHERE t.id=${f.taskId}`;assert.equal(after.charged_units,h.charged_units);assert.equal(after.billing_review_status,'resolved');const [e]=await db`SELECT count(*)::int AS n FROM point_usage_events WHERE task_id=${f.taskId}`;assert.equal(e.n,2);
});
function aiExpected(snapshot:any){return Number((BigInt(snapshot.baseUnits)*1000000000n+1000000n*BigInt(snapshot.markup)*100n+999999999n)/1000000000n);}
test('fair outbox dispatch fills only available slots, includes another account before a second backlog item, and is atomic',async()=>{
 const a1=await fixture(),a2=await fixture(),b1=await fixture(other);await db`UPDATE tasks SET created_at=now()-interval '2 minutes' WHERE id=${a1.taskId}`;await db`UPDATE tasks SET created_at=now()-interval '1 minute' WHERE id=${a2.taskId}`;
 const results=await Promise.all([dispatchTasks(boss,2),dispatchTasks(boss,2)]),sent=results.flat();assert.equal(sent.length,2);assert.ok(sent.includes(a1.taskId));assert.ok(sent.includes(b1.taskId));assert.equal(sent.includes(a2.taskId),false);assert.ok(QUEUE_REDISPATCH_SECONDS>QUEUE_EXPIRE_SECONDS);assert.equal(await boss.send(QUEUE,{taskId:a1.taskId},{singletonKey:a1.taskId}),null);
 await Promise.all([cancelPointTask(owner,a1.taskId),cancelPointTask(owner,a2.taskId),cancelPointTask(other,b1.taskId)]);
});
