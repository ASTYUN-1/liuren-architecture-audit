import test from "node:test";
import assert from "node:assert/strict";
import vm from "node:vm";
import { calculateSelfChart } from "../src/engine/self-chart";
import { createEngineContext, calculateChart } from "../src/engine/liuren";
import type { SelfChartInput } from "../src/lib/professional-chart";
const base:SelfChartInput={method:"time",date:"2026-10-15",time:"13:04",calendar:"solar",leapMonth:false,pillars:{year:"丙午",month:"戌",day:"壬戌",hour:"未",monthGeneral:"辰"},rules:{guiren:"甲戊庚牛羊",zhouye:"自动选择",shehai:"孟仲季",yuejiang:"中气换将"},participants:[{role:"本人",gender:"male",birthYear:1990}]};
test("自助正时的十二宫、四课三传与现有核心一致，古籍完整且不返回原始盘",()=>{
  const {chart:c}=calculateSelfChart(base),native=calculateChart({question:"自助排盘",locale:"zh",mode:"time",time:"2026-10-15T13:04:00+08:00",timeZone:"Asia/Shanghai",participants:base.participants,rules:base.rules});
  assert.deepEqual(c.lessons,native.facts.sike);assert.deepEqual(c.transmissions,native.facts.sanchuan);assert.equal(c.palaces.length,12);
  for(const p of c.palaces){assert.equal(p.heaven,native.facts.tianpan[p.key]);assert.equal(p.general,native.facts.shenpan[p.key]);assert.deepEqual(p.spirits,native.facts.shensha_py_to_name[p.key]);}
  assert(c.classics.zhizhi.length>30);assert(c.classics.jiying.length>30);assert(c.classics.bifa.length>30);assert(c.classics.licheng.length>30);assert(c.classics.kejing.length>0);assert.equal(c.people[0].annual,"壬寅");
  assert.deepEqual(c.spirits[0].entries.find(([name])=>name==="太岁")?.[1],["午"]);
  for(const group of c.spirits)for(const [,branches] of group.entries)assert(Array.isArray(branches));
  for(const k of ["_D","AI_list","facts","LiCheng","liuxun_list"])assert.equal(k in c,false);
});
test("指定月将及深度涉害沿用原引擎结果",()=>{
  const input={...base,rules:{...base.rules,yuejiang:"登明亥",shehai:"深度"}},c=calculateSelfChart(input).chart,ctx=createEngineContext();
  const p=calculateSelfChart(base).chart.pillars;
  ctx.inputJson=JSON.stringify({Date:base.date,Time:base.time,zhenghuoshi:"四柱",...input.rules,sizhu:{yg:p[0][0],yz:p[0][1],mz:p[1][1],dg:p[2][0],dz:p[2][1],hz:p[3][1],yuejiang:"亥"},user:[],cundang:{ws:""}});
  const native=JSON.parse(vm.runInContext("JSON.stringify(LiuRenPaiPan(JSON.parse(inputJson)))",ctx,{timeout:10000}));
  assert.equal(c.monthGeneral,"亥");assert.deepEqual(c.transmissions,native.sanchuan);assert.deepEqual(c.lessons,native.sike);
});
test("真太阳时使用原引擎校正，并保留原北京时间；农历公历等价",()=>{
  const c=calculateSelfChart({...base,method:"solar",longitude:116.4}).chart,ctx=createEngineContext();
  const expected=JSON.parse(vm.runInContext("JSON.stringify(getTrueSolarTimeFromBeijing(2026,10,15,13,4,0,116.4))",ctx));
  assert.equal(c.time,`${String(expected.h).padStart(2,"0")}:${String(expected.i).padStart(2,"0")}`);assert.equal(c.originalTime,"2026-10-15 13:04");
  const a=calculateSelfChart(base).chart,b=calculateSelfChart({...base,calendar:"lunar",date:"2026-09-06"}).chart;assert.equal(b.date,a.date);assert.deepEqual(a.transmissions,b.transmissions);
});
test("四柱无虚构日期、节气或行年；报数循环；必填与异常输入在服务端拒绝",()=>{
  const c=calculateSelfChart({...base,method:"pillars"}).chart;assert.equal(c.date,null);assert.equal(c.lunar,null);assert.equal(c.solarTerm,null);assert.equal(c.people[0].annual,"—");
  const a=calculateSelfChart({...base,method:"number",number:1}).chart,b=calculateSelfChart({...base,method:"number",number:13}).chart;assert.deepEqual(a.transmissions,b.transmissions);assert.equal(a.pillars[3][1],"子");
  for(const bad of [{...base,date:"2026-02-30"},{...base,method:"number",number:0},{...base,method:"solar",longitude:181},{...base,pillars:{...base.pillars,year:"甲丑"},method:"pillars"}])assert.throws(()=>calculateSelfChart(bad));
});
