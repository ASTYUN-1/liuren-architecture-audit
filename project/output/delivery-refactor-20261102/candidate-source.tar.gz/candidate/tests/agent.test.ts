import test from "node:test";
import assert from "node:assert/strict";
import { KnowledgeRelease } from "../src/agent/knowledge";
import { ModelUsageTracker } from "../src/agent/gateway";
import { ToolAudit,verifyChartFacts } from "../src/agent/tools";
import { runInterpretation, productionConfig } from "../src/agent/runtime";
import { calculateChart } from "../src/engine/liuren";
import type { CaseInput } from "../src/server/contracts";
const input:CaseInput={question:"能复合吗",locale:"zh",mode:"time",time:"2026-10-15T05:00:00Z",timeZone:"Asia/Shanghai",participants:[{role:"本人",gender:"female",birthYear:1995}]};
test("历史案例按确切占类隔离，无自动高分采信",()=>{const k=new KnowledgeRelease();const a=k.search({category:"感情占",patterns:["重审"]});assert(a.length>0);for(const r of a){assert.equal(r.meta["占类"],"感情占");assert.equal(r.automaticAcceptance,false);assert(!r.source.includes("胎产占"));}assert.throws(()=>k.read("../../opencode.json"));assert.throws(()=>k.evidence(a[0].id,"胡乱编造的完全不存在文献引用"));});
test("付款任务无 API 配置明确失败，不能交付模板",async()=>{const before=process.env.DEEPSEEK_API_KEY;delete process.env.DEEPSEEK_API_KEY;try{await assert.rejects(runInterpretation({taskId:"test",caseId:"case",kind:"initial",input,history:[]}),/service_unavailable/);}finally{if(before)process.env.DEEPSEEK_API_KEY=before;}});
test("追问必须载入固定盘，不重新起盘；工作流欠缺不得交付",()=>{const k=new KnowledgeRelease(),c=calculateChart(input);assert.throws(()=>new ToolAudit({taskId:"t",caseId:"c",kind:"followup",input,history:[]},k),/fixed_chart_required/);const a=new ToolAudit({taskId:"t",caseId:"c",kind:"followup",input,history:[],previousChart:c},k);assert.equal(a.chart.hash,c.hash);a.candidate={answer:"未经完整流程的报告"};assert.throws(()=>a.assertComplete(),/workflow_incomplete/);});
test("工具反馈指出真实缺项和正确事实；对象键序不影响相等，值与类型仍严格校验",()=>{
 const k=new KnowledgeRelease(),chart=calculateChart(input),a=new ToolAudit({taskId:"t",caseId:"c",kind:"initial",input,history:[]},k);
 a.candidate={answer:"不完整"};assert.throws(()=>a.assertComplete(),e=>e instanceof Error&&e.message.includes('"missingStages":["sanbu-duanke"')&&e.message.includes('"rootSkillRead":false'));
 assert.throws(()=>verifyChartFacts(chart,[{path:"facts.sizhu.d",value:chart.facts.sizhu.d}]),/omit the facts/);
 assert.throws(()=>verifyChartFacts(chart,[{path:"sizhu.d",value:"不存在"}]),e=>e instanceof Error&&e.message.includes('"expected":'+JSON.stringify(chart.facts.sizhu.d)));
 assert.doesNotThrow(()=>verifyChartFacts(chart,[{path:"sizhu",value:Object.fromEntries(Object.entries(chart.facts.sizhu).reverse())}]));
 assert.throws(()=>verifyChartFacts(chart,[{path:"__proto__.constructor",value:""}]),/invalid_fact_path/);
 const counts={...chart,facts:{n:1}};assert.throws(()=>verifyChartFacts(counts,[{path:"n",value:"1"}]),/chart_fact_mismatch/);
 assert(k.caseCategories().includes("感情占"));assert(!k.caseCategories().includes("不明占类"));
});
test("仅记真实费用，不做金额预估拦截；未知用量不伪造成本",()=>{const b=new ModelUsageTracker(3);b.beginRequest();b.settle({prompt_tokens:1000000,completion_tokens:32768,prompt_cache_hit_tokens:100});b.beginRequest();b.settle();b.beginRequest();assert.throws(()=>b.beginRequest(),/model_request_limit/);assert.equal(b.usage.requests,3);assert.equal(b.usage.failures,1);assert.equal(b.usage.reservedCny,0);assert(b.usage.costCny>2);});
test("主模型亲自执行，task与全部子智能体禁用，默认禁止 Shell 与任意读写/联网",()=>{const c=productionConfig("http://127.0.0.1:1","fixture");assert.equal(c.agent["liuren-main"].model,"wenheng/deepseek-flash");assert.equal(c.agent["liuren-main"].reasoningEffort,"high");assert.equal(c.permission["*"],"deny");assert.deepEqual(c.agent["liuren-main"].permission.task,{"*":"deny"});assert.equal(c.agent["liuren-cases"].disable,true);assert.equal(c.agent.general.disable,true);assert.equal(c.share,"disabled");});

test("单任务调用超过200次仍计数，OpenCode不设置固定steps",()=>{const b=new ModelUsageTracker();for(let i=0;i<250;i++)assert.doesNotThrow(()=>b.beginRequest());assert.equal(b.usage.requests,250);const c=productionConfig("http://127.0.0.1:1","fixture");assert(!("steps" in c.agent["liuren-main"]));assert(c.agent["liuren-main"].prompt.includes("不设固定次数上限"));});

test("生产进程禁止 fixture 标记",async()=>{const env=process.env.NODE_ENV,flag=process.env.WENHENG_RUNTIME_FIXTURE;Object.assign(process.env,{NODE_ENV:"production"});process.env.WENHENG_RUNTIME_FIXTURE="1";try{await assert.rejects(runInterpretation({taskId:"t",caseId:"c",kind:"initial",input,history:[],apiKey:"fixture"}),/production_fixture_forbidden/);}finally{if(env===undefined)delete (process.env as Record<string,string|undefined>).NODE_ENV;else Object.assign(process.env,{NODE_ENV:env});if(flag===undefined)delete process.env.WENHENG_RUNTIME_FIXTURE;else process.env.WENHENG_RUNTIME_FIXTURE=flag;}});

