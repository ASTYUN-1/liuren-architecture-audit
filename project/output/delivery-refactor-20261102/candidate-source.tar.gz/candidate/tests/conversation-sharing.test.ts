import {test,after,before} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {sqlClient} from '../src/server/db';
import type {Actor} from '../src/server/http';
import {readConversationShare,revokeConversationShare,renewConversationShare,ownerShares,managePractitioners} from '../src/server/conversation-sharing';
import {creditPoints,reservePoints,finishHold,walletView} from '../src/server/points';
import {defaultPointsConfig,savePointsConfig} from '../src/server/points-config';
import {requestHuman,humanAction,maintainPoints} from '../src/server/human-assist';
if(!process.env.DATABASE_URL||!/wenheng_test|wenheng-test|test_wenheng/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error('Refusing non-test database');
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:randomUUID(),WENHENG_ENCRYPTION_KEY:'ab'.repeat(32)});
const createConversationShare=async(a:Actor,id:string,advisorId:string)=>(await requestHuman(a,{caseId:id,advisorId,question:'Review this synthetic report',idempotencyKey:randomUUID()})).share;
const db=sqlClient(),make=():Actor=>{const id='share-test-'+randomUUID();return {id,email:id+'@example.invalid',name:'Share test',emailVerified:true,isAdmin:false};};
const owner=make(),reader=make(),other=make(),admin={...make(),isAdmin:true},actors=[owner,reader,other,admin],ids=actors.map(a=>a.id),caseId=randomUUID(),unshared=randomUUID();
before(async()=>{
 for(const a of actors)await db`INSERT INTO "user"(id,email,name,email_verified) VALUES(${a.id},${a.email},${a.name},true)`;
 for(const id of [caseId,unshared]){
  await db`INSERT INTO cases(id,user_id,title,status,report) VALUES(${id},${owner.id},'Shared fixture','ready',${db.json({title:'Report',content:'Synthetic shared report',chart:{privateMarker:'not-in-share'}})})`;
  await db`INSERT INTO case_inputs(case_id,version,input) VALUES(${id},1,${db.json({question:'Synthetic question',participants:[{role:'本人'}]})})`;
 }
 await db`INSERT INTO tasks(id,case_id,user_id,kind,input_version,question,answer,status,idempotency_key,usage) VALUES(${randomUUID()},${caseId},${owner.id},'followup',1,'Follow-up question','Follow-up answer','succeeded',${randomUUID()},${db.json({costCny:0.9})})`;
 await managePractitioners(admin,{action:'grant',advisorId:'congkui',email:reader.email});
 await managePractitioners(admin,{action:'grant',advisorId:'qing',email:other.email});
 await creditPoints(admin,{userId:owner.id,kind:'bonus',units:100000,reason:'Isolated test gift',idempotencyKey:randomUUID()});
 const cfg={...defaultPointsConfig(),mode:'points' as const,humanEnabled:true};cfg.advisors=cfg.advisors.map(a=>({...a,wechatId:'test_contact',accepting:true}));await savePointsConfig(admin,cfg);
});
after(async()=>{
 await db`DELETE FROM human_assists WHERE user_id IN ${db(ids)}`;
 await db`DELETE FROM point_ledger WHERE user_id IN ${db(ids)}`;
 await db`DELETE FROM point_holds WHERE user_id IN ${db(ids)}`;
 await db`DELETE FROM point_lots WHERE user_id IN ${db(ids)}`;
 await db`DELETE FROM point_profiles WHERE user_id IN ${db(ids)}`;
 await db`DELETE FROM tasks WHERE user_id IN ${db(ids)}`;
 await db`DELETE FROM case_inputs WHERE case_id IN (${caseId},${unshared})`;
 await db`DELETE FROM cases WHERE user_id IN ${db(ids)}`;
 await db`DELETE FROM audit_log WHERE actor_id IN ${db(ids)}`;
 await db`DELETE FROM "user" WHERE id IN ${db(ids)}`;
 await db`DELETE FROM service_settings WHERE key=${'test:'+process.env.SETTINGS_RECORD_KEY+':points'}`;
 await db.end();
});
test('code is scoped to an assigned practitioner; ordinary user and unrelated admin denied',async()=>{
 const s=await createConversationShare(owner,caseId,'congkui');
 assert.match(s.code!,/^WHC-[A-F0-9]{36}$/);
 const r=await readConversationShare(reader,s.code!);assert.equal(r.question,'Synthetic question');assert.equal(r.turns[0].answer,'Follow-up answer');
 assert.doesNotMatch(JSON.stringify(r),/costCny|privateMarker|token_hash|user_id/);
 for(const a of [owner,other,admin])await assert.rejects(()=>readConversationShare(a,s.code!),{code:'SHARE_UNAVAILABLE'});
 await assert.rejects(()=>readConversationShare(reader,unshared),{code:'SHARE_UNAVAILABLE'});
 const [row]=await db`SELECT token_hash FROM conversation_shares WHERE id=${s.id}`;assert.notEqual(row.token_hash,s.code!);assert.equal(row.token_hash.length,64);
});
test('only owner can generate, list and revoke; email verification required',async()=>{
 await assert.rejects(()=>createConversationShare(other,caseId,'congkui'),{code:'NOT_FOUND'});
 await assert.rejects(()=>ownerShares(other,caseId),{code:'NOT_FOUND'});
 await assert.rejects(()=>createConversationShare({...owner,emailVerified:false},caseId,'congkui'),{code:'FORBIDDEN'});
 await assert.rejects(()=>managePractitioners(other,{action:'grant',advisorId:'congkui',email:other.email}),{code:'FORBIDDEN'});
 const heldBefore=(await db`SELECT coalesce(sum(units),0)::int AS units FROM point_holds WHERE user_id=${owner.id}`)[0].units;
 await assert.rejects(()=>createConversationShare(owner,caseId,'ming'),{code:'UNAVAILABLE'});
 assert.equal((await db`SELECT coalesce(sum(units),0)::int AS units FROM point_holds WHERE user_id=${owner.id}`)[0].units,heldBefore);
 const s=await createConversationShare(owner,caseId,'congkui');
 await assert.rejects(()=>revokeConversationShare(other,caseId,s.id),{code:'NOT_FOUND'});
 assert.ok((await ownerShares(owner,caseId)).some(r=>r.id===s.id));
 await revokeConversationShare(owner,caseId,s.id);await assert.rejects(()=>readConversationShare(reader,s.code!),{code:'SHARE_UNAVAILABLE'});
});
test('revocation, expiry, role revocation and deleted case immediately block further reads',async()=>{
 const first=await createConversationShare(owner,caseId,'congkui'),second=await createConversationShare(owner,caseId,'congkui');
 await revokeConversationShare(owner,caseId,first.id);await assert.rejects(()=>readConversationShare(reader,first.code!),{code:'SHARE_UNAVAILABLE'});
 await db`UPDATE conversation_shares SET expires_at=now()-interval '1 second' WHERE id=${second.id}`;
 await assert.rejects(()=>readConversationShare(reader,second.code!),{code:'SHARE_UNAVAILABLE'});
 const third=await createConversationShare(owner,caseId,'congkui');
 await managePractitioners(admin,{action:'revoke',advisorId:'congkui',email:reader.email});
 await assert.rejects(()=>readConversationShare(reader,third.code!),{code:'SHARE_UNAVAILABLE'});
 await managePractitioners(admin,{action:'grant',advisorId:'congkui',email:reader.email});
 await db`UPDATE cases SET deleted_at=now() WHERE id=${caseId}`;
 await assert.rejects(()=>readConversationShare(reader,third.code!),{code:'SHARE_UNAVAILABLE'});
 await db`UPDATE cases SET deleted_at=NULL,permanently_deleted=true WHERE id=${caseId}`;
 await assert.rejects(()=>readConversationShare(reader,third.code!),{code:'SHARE_UNAVAILABLE'});
 await db`UPDATE cases SET permanently_deleted=false WHERE id=${caseId}`;
});
test('customer wallet preserves charges but excludes all private cost snapshots',async()=>{
 await creditPoints(admin,{userId:owner.id,kind:'bonus',units:5000,reason:'Isolated test gift',idempotencyKey:randomUUID()});
 await db.begin(async tx=>{const h=await reservePoints(tx,owner.id,'initial',1000,randomUUID(),{markup:5,costNanoCny:'123456',baseUnits:300,priceVersion:'private-rate'},caseId);await finishHold(tx,h.id,500,'Delivered');});
 const w=await walletView(owner);assert.equal(w.holds.find(h=>h.kind==='initial')?.charged_units,500);
 assert.doesNotMatch(JSON.stringify(w),/snapshot|markup|costNanoCny|baseUnits|priceVersion|private-rate/);
 const [stored]=await db`SELECT snapshot FROM point_holds WHERE user_id=${owner.id} AND kind='initial'`;assert.equal(stored.snapshot.markup,5);
});

test('only explicit owner renewal creates a fresh token; cancelled bookings and deleted cases stay blocked',async()=>{
 const h=await requestHuman(owner,{caseId,advisorId:'congkui',question:'Synthetic share renewal',idempotencyKey:randomUUID()}),old=h.share;
 await db`UPDATE conversation_shares SET expires_at=now()-interval '1 second' WHERE id=${old.id}`;
 await assert.rejects(()=>renewConversationShare(other,caseId,old.id),{code:'NOT_FOUND'});
 await assert.rejects(()=>readConversationShare(reader,old.code!),{code:'SHARE_UNAVAILABLE'});
 const renewed=await renewConversationShare(owner,caseId,old.id);assert.notEqual(renewed.code,old.code);
 await readConversationShare(reader,renewed.code);await assert.rejects(()=>readConversationShare(reader,old.code!),{code:'SHARE_UNAVAILABLE'});
 await revokeConversationShare(owner,caseId,old.id);
 assert.equal((await ownerShares(owner,caseId)).find(s=>s.id===old.id)?.code,null);
 const explicit=await renewConversationShare(owner,caseId,old.id);assert.notEqual(explicit.code,renewed.code);
 await assert.rejects(()=>readConversationShare(reader,renewed.code),{code:'SHARE_UNAVAILABLE'});
 await db`UPDATE cases SET deleted_at=now() WHERE id=${caseId}`;
 await assert.rejects(()=>renewConversationShare(owner,caseId,old.id),{code:'NOT_FOUND'});
 await db`UPDATE cases SET deleted_at=NULL WHERE id=${caseId}`;
 await humanAction(owner,h.id,{action:'cancel'});
 await assert.rejects(()=>renewConversationShare(owner,caseId,old.id),{code:'SHARE_UNAVAILABLE'});
 assert.equal((await ownerShares(owner,caseId)).find(s=>s.id===old.id)?.canRenew,false);
});
test('enabled human assistance reserves 150 credits and settles only after user confirms',async()=>{
 const cfg={...defaultPointsConfig(),mode:'points' as const,humanEnabled:true};cfg.advisors=cfg.advisors.map(a=>({...a,wechatId:'test_contact',accepting:true}));await savePointsConfig(admin,cfg);
 const request={caseId,advisorId:'congkui',question:'Review this synthetic report',idempotencyKey:randomUUID()};const h=await requestHuman(owner,request),retry=await requestHuman(owner,request);assert.equal(retry.id,h.id);assert.equal(retry.share.code,h.share.code);assert.equal((await db`SELECT count(*)::int AS n FROM conversation_shares WHERE booking_id=${h.id}`)[0].n,1);assert.ok(h.share.code);await readConversationShare(reader,h.share.code!);
 await humanAction(admin,h.id,{action:'accept'});await humanAction(admin,h.id,{action:'deliver',summary:'Synthetic service summary for isolated test only.'});
 let [r]=await db`SELECT status,charged_units FROM point_holds WHERE id=${h.id}`;assert.equal(r.status,'held');assert.equal(r.charged_units,0);
 await humanAction(owner,h.id,{action:'confirm'});[r]=await db`SELECT status,charged_units FROM point_holds WHERE id=${h.id}`;assert.equal(r.charged_units,1500);
});
test('cancelled or automatically refunded bookings cannot read even with the original code',async()=>{
 const request={caseId,advisorId:'congkui',question:'Synthetic cancellation check',idempotencyKey:randomUUID()};
 const h=await requestHuman(owner,request);await readConversationShare(reader,h.share.code!);
 await humanAction(owner,h.id,{action:'cancel'});
 await assert.rejects(()=>readConversationShare(reader,h.share.code!),{code:'SHARE_UNAVAILABLE'});
 assert.equal((await ownerShares(owner,caseId)).find(s=>s.id===h.share.id)?.code,null);
 const expired=await requestHuman(owner,{...request,idempotencyKey:randomUUID()});
 await db`UPDATE human_assists SET deadline=now()-interval '1 minute' WHERE id=${expired.id}`;
 await maintainPoints();
 await assert.rejects(()=>readConversationShare(reader,expired.share.code!),{code:'SHARE_UNAVAILABLE'});
});
