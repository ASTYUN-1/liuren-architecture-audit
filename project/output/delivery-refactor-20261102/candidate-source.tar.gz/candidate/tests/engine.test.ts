import test from "node:test";
import assert from "node:assert/strict";
import { calculateChart, normalizeChartInput, publicChart, PROJECT_ROOT } from "../src/engine/liuren";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import type { CaseInput } from "../src/server/contracts";
const base:CaseInput={question:"这次分手之后能复合吗",locale:"zh",mode:"time",time:"2026-10-15T14:00:00Z",timeZone:"America/New_York",participants:[{role:"本人",gender:"female",birthYear:1995}]};
test("北京时区固定，23:00 子时但日柱至 00:00 换日",()=>{
  const a=calculateChart({...base,time:"2026-10-15T14:59:00Z"}),b=calculateChart({...base,time:"2026-10-15T15:00:00Z"}),c=calculateChart({...base,time:"2026-10-15T16:00:00Z"});
  assert.equal(a.normalized.time,"22:59");assert.equal(b.normalized.time,"23:00");assert.equal(b.facts.sizhu.h[1],"子");assert.equal(a.facts.sizhu.d,b.facts.sizhu.d);assert.notEqual(b.facts.sizhu.d,c.facts.sizhu.d);assert.equal(c.normalized.date,"2026-10-16");
});
test("报数边界拒绝并循环，正确代表时刻等价正时",()=>{
  for(const n of [0,-1,1.5,1e9,NaN])assert.throws(()=>normalizeChartInput({...base,mode:"number",number:n}));
  for(const [n,branch,time] of [[1,"子","00:00"],[12,"亥","22:00"],[13,"子","00:00"],[8,"未","14:00"],[999999999,"寅","04:00"]] as const){const c=calculateChart({...base,mode:"number",number:n});assert.equal(c.normalized.branch,branch);assert.equal(c.normalized.time,time);assert.equal(c.facts.sizhu.h[1],branch);}
  const n=calculateChart({...base,mode:"number",number:8}),t=calculateChart({...base,time:"2026-10-15T06:00:00Z"});assert.deepEqual(n.facts.sike,t.facts.sike);assert.deepEqual(n.facts.sanchuan,t.facts.sanchuan);
});
test("四柱不泄露占位日期派生，输入人物和引擎规则不被变异",()=>{
  const i:CaseInput={...base,mode:"pillars",time:undefined,pillars:{year:"丙午",month:"戌",day:"壬戌",hour:"午",monthGeneral:"辰"},participants:[{role:"本人",gender:"female",lifeBranch:"酉"}]},before=structuredClone(i),c=calculateChart(i);
  assert.deepEqual(i,before);assert.deepEqual(c.participants,i.participants);assert.equal(c.normalized.date,null);assert.equal(c.facts.Date,undefined);assert.equal(c.facts.jieqi,undefined);assert.equal(c.facts.nongli,undefined);assert.equal(c.facts.liuxun_list,undefined);assert.equal(c.facts.sike.length,4);assert.equal(c.facts.sanchuan.length,3);assert.equal(c.facts.sizhu.d,"壬戌");assert.equal(c.facts.userinfo[0].lifeBranch,"酉");
  assert.throws(()=>calculateChart({...i,pillars:{...i.pillars!,year:"甲丑"}}));assert.throws(()=>calculateChart({...i,pillars:{...i.pillars!,actualDate:"2026-10-16"}}));
  const actual=calculateChart({...i,pillars:{...i.pillars!,actualDate:"2026-10-15"}});assert.equal(actual.normalized.date,"2026-10-15");assert.equal(actual.facts.Time,undefined);assert(actual.facts.nongli);assert.equal(actual.facts.sizhu.d,c.facts.sizhu.d);
});
test("VM 多次调用不串盘，课式哈希确定且公开数据不带断语/原始输入",()=>{
  const a=calculateChart(base),b=calculateChart({...base,time:"2026-10-19T03:21:00Z",participants:[{role:"对方",birthYear:1990}]}),c=calculateChart(base);assert.equal(a.hash,c.hash);assert.notEqual(a.hash,b.hash);assert.deepEqual(a.facts,c.facts);const visible=publicChart(a);assert.equal("_D" in visible,false);assert.equal("BiFa" in visible,false);assert.equal("participants" in visible,false);
});
test("确认时间缺失或无偏移不能排队时默默重新起盘",()=>{assert.throws(()=>calculateChart({...base,time:undefined}));assert.throws(()=>calculateChart({...base,time:"2026-10-15T23:00"}));});
test("VM 北京日期与原库在真实 Asia/Shanghai 时区直接运行对照",()=>{
  for(const time of ["2026-10-15T15:00:00Z","2026-10-15T16:00:00Z","2026-02-04T04:00:00Z"]){const c=calculateChart({...base,time}),env={Date:c.normalized.date,Time:c.normalized.time,zhenghuoshi:"正时",...c.normalized.rules,user:[],cundang:{ws:base.question}};const r=spawnSync(process.execPath,[fileURLToPath(new URL("./engine-native-reference.cjs",import.meta.url)),PROJECT_ROOT,JSON.stringify(env)],{env:{...process.env,TZ:"Asia/Shanghai"},encoding:"utf8",timeout:30000});assert.equal(r.status,0,r.stderr);const native=JSON.parse(r.stdout);for(const key of Object.keys(native))assert.deepEqual(c.facts[key],native[key],`${time} ${key}`);}
});
test("已知出生年及性别使用原算法行年，已知本命有来源；缺真实日期不计算行年",()=>{
  const c=calculateChart({...base,participants:[{role:"本人",gender:"male",birthYear:1990,lifeBranch:"午"},{role:"对方",gender:"female",birthDate:"1992-06-01"},{role:"旁人",gender:"unknown",lifeBranch:"酉"}]});assert.equal(c.facts.userinfo[0].benming.branch,"午");assert.equal(c.facts.userinfo[0].benming.source,"user.lifeBranch");assert.equal(c.facts.userinfo[0].xingnian.stemBranch,"壬寅");assert.equal(c.facts.userinfo[0].xingnian.yearOffset,36);assert(c.facts.userinfo[1].benming.confirmed);assert(c.facts.userinfo[1].xingnian);assert.equal(c.facts.userinfo[2].xingnian,undefined);
  const p=calculateChart({...base,mode:"pillars",pillars:{year:"丙午",month:"戌",day:"壬戌",hour:"午",monthGeneral:"辰"},participants:[{role:"本人",gender:"male",birthYear:1990,lifeBranch:"午"}]});assert.equal(p.facts.userinfo[0].xingnian,undefined);assert.equal(p.facts.userinfo[0].benming.branch,"午");
});
