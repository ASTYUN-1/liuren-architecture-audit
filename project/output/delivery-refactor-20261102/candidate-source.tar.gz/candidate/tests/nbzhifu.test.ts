import {before,after,test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {sqlClient} from '../src/server/db';
import {type Actor} from '../src/server/http';
import {encryptSecret} from '../src/server/settings';
import {createCase,createOrder,createTurn,caseDetail,submitPayment,confirmPayment,totals} from '../src/server/service';
import {cancelUnpaidOrder} from '../src/server/admin';
import {startNbPayment,handleNbNotification,applyNbQuery,checkNbPayment,publishNbPayments} from '../src/server/nbzhifu';
import {nbSign,nbVerify,nbCents,nbPayUrl} from '../src/server/nbzhifu-api';
import {POST as notify} from '../src/app/api/payments/nbzhifu/notify/route';
if(!process.env.DATABASE_URL||!/wenheng_test|wenheng-test|test_wenheng/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error('Refusing gateway tests outside isolated database');
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:randomUUID(),WENHENG_ENCRYPTION_KEY:'cd'.repeat(32),SMTP_HOST:'test.invalid',SMTP_FROM:'test@example.invalid',DEEPSEEK_API_KEY:'test-only',AI_ENABLED:'true',MANUAL_PAYMENT_ENABLED:'true',PAYMENT_QR_URL:'https://example.invalid/qr.png',APP_URL:'https://example.invalid'});
const db=sqlClient(),key='test:'+process.env.SETTINGS_RECORD_KEY;
const owner:Actor={id:'nb-test-'+randomUUID(),email:'nb-'+randomUUID()+'@example.invalid',name:'Test',emailVerified:true,isAdmin:false};
const config={pid:'2088000000000000',secret:'test-secret-only',enabled:true};
const input={question:'测试收款后的权益流程',locale:'zh',mode:'time',time:'2026-10-16T00:00:00+08:00',timeZone:'Asia/Shanghai',participants:[{role:'本人',gender:'male',birthYear:1995}]};
let originalFetch:typeof fetch;let queryStatus='TRADE_SUCCESS';let queryAmount:string|undefined;let calls=0;
before(async()=>{
 await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${owner.id},'Test',${owner.email},true)`;
 await db`INSERT INTO service_settings(key,value) VALUES(${key},${db.json({nbzhifuEnabled:true,nbzhifuPublicEnabled:true,nbzhifuPid:config.pid,nbzhifuKeyEncrypted:encryptSecret(config.secret)})}),(${key+':workerHeartbeat'},${db.json({at:new Date().toISOString()})})`;
 originalFetch=globalThis.fetch;
 globalThis.fetch=async(url,options)=>{
  calls++;const p=Object.fromEntries(new URLSearchParams(options?.body as string));assert.equal(nbVerify(p,config.secret),true);
  if(String(url).endsWith('/create'))return Response.json({code:1,data:{out_trade_no:p.out_trade_no,trade_no:'TEST-'+p.out_trade_no,pay_url:'https://pay.nbzhifu.com/process/next?trade_no=TEST-'+p.out_trade_no}});
  const [payment]=await db`SELECT amount_cents FROM gateway_payments WHERE id=${p.out_trade_no}`;
  return Response.json({code:1,data:{out_trade_no:p.out_trade_no,trade_no:'TEST-'+p.out_trade_no,total_amount:queryAmount||(payment.amount_cents/100).toFixed(2),trade_status:queryStatus}});
 };
});
after(async()=>{
 globalThis.fetch=originalFetch;
 await db`DELETE FROM audit_log WHERE target_id IN (SELECT id::text FROM gateway_payments WHERE user_id=${owner.id}) OR target_id IN (SELECT id::text FROM orders WHERE user_id=${owner.id}) OR target_id IN (SELECT id::text FROM cases WHERE user_id=${owner.id})`;
 await db`DELETE FROM gateway_payments WHERE user_id=${owner.id}`;
 for(const table of ['entitlement_ledger','tasks','entitlements','orders','case_inputs','deletion_tombstones'])await db.unsafe(`DELETE FROM ${table} WHERE case_id IN (SELECT id FROM cases WHERE user_id=$1)`,[owner.id]);
 await db`DELETE FROM referral_profiles WHERE user_id=${owner.id}`;await db`DELETE FROM cases WHERE user_id=${owner.id}`;await db`DELETE FROM "user" WHERE id=${owner.id}`;
 await db`DELETE FROM service_settings WHERE key IN (${key},${key+':workerHeartbeat'})`;await db`DELETE FROM audit_log WHERE target_id IN (SELECT id::text FROM gateway_payments WHERE user_id=${owner.id})`;
 await db.end();
});
async function checkout(){const c=await createCase(owner,{input});const order=await createOrder(owner,c.id,{kind:'base',idempotencyKey:randomUUID()});const payment=await startNbPayment(owner,{orderId:order.id,paytype:'alipay'},'127.0.0.1');return {c,order,payment}}
function state(payment:any,status='TRADE_SUCCESS',amount?:string){return {out_trade_no:payment.id,trade_no:payment.tradeNo,total_amount:amount||(payment.amountCents/100).toFixed(2),trade_status:status}}
function signed(payment:any){const p={pid:config.pid,...state(payment),sign_type:'MD5'};return {...p,sign:nbSign(p,config.secret)}}
test('签名处理中文、空值、参数排序；金额与外部收银台地址严格校验',()=>{
 const a={subject:'问衡 A+B & C',z:'',a:'1',nil:null};const signature=nbSign(a,'secret');assert.equal(nbSign({a:'1',subject:'问衡 A+B & C'},'secret'),signature);
 assert.equal(nbVerify({...a,sign_type:'MD5',sign:signature} as any,'wrong'),false);
 assert.equal(nbCents('0.10'),10);assert.equal(nbCents(29.9),2990);for(const value of ['1e2','-1','0.001','NaN'])assert.throws(()=>nbCents(value));
 assert.throws(()=>nbPayUrl('https://attacker.invalid/pay'));assert.throws(()=>nbPayUrl('https://user@pay.nbzhifu.com/pay'));assert.throws(()=>nbPayUrl('javascript:alert(1)'));
});
test('并发创建收银台只生成一笔交易；金额取服务器订单，人工核验不可串用',async()=>{
 const c=await createCase(owner,{input});const order=await createOrder(owner,c.id,{kind:'base',idempotencyKey:randomUUID()});
 const payments=await Promise.all([1,2].map(()=>startNbPayment(owner,{orderId:order.id,paytype:'alipay'},'127.0.0.1')));assert.equal(payments[0].id,payments[1].id);assert.equal(payments[0].amountCents,2990);
 await assert.rejects(()=>submitPayment(owner,order.id,{paymentReference:'fake reference'}));await assert.rejects(()=>confirmPayment({...owner,isAdmin:true},order.id,{reference:'fake reference'}),/对应的支付渠道/);
 await assert.rejects(()=>startNbPayment(owner,{orderId:order.id,paytype:'wxpay'},'127.0.0.1'),/另一通道/);
 await assert.rejects(()=>checkNbPayment({...owner,id:'another-user'},payments[0].id),/不存在/);
 await cancelUnpaidOrder(owner,order.id);
});
test('伪造通知、金额不符与重复参数不能开通；已签名通知仍须主动查单',async()=>{
 const {c,payment}=await checkout();const p=signed(payment);const beforeCalls=calls;
 await assert.rejects(()=>handleNbNotification({...p,sign:'0'.repeat(32)}),/signature/);assert.equal(calls,beforeCalls);
 await assert.rejects(()=>handleNbNotification({...p,total_amount:'0.10',sign:nbSign({...p,total_amount:'0.10'},config.secret)}),/match/);
 queryAmount='0.10';try{await assert.rejects(()=>handleNbNotification(p),/不匹配/)}finally{queryAmount=undefined}
 const response=await notify(new Request('https://example.invalid/api/payments/nbzhifu/notify',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(p).toString()+'&pid='+config.pid}));assert.equal(response.status,400);
 assert.equal((await totals(db,c.id)).granted,0);
 queryStatus='WAIT_BUYER_PAY';try{await handleNbNotification(p);assert.equal((await totals(db,c.id)).granted,0)}finally{queryStatus='TRADE_SUCCESS'}
});
test('真实查单成功后自动排队报告和2次追问，重复回调不双发；交付后可实际追问',async()=>{
 const {c,payment}=await checkout();const p=signed(payment);await Promise.all([handleNbNotification(p),handleNbNotification(p)]);
 const response=await notify(new Request('https://example.invalid/api/payments/nbzhifu/notify',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(p)}));assert.equal(response.status,200);assert.equal(await response.text(),'success');
 assert.equal((await totals(db,c.id)).granted,2);const tasks=await db`SELECT id FROM tasks WHERE case_id=${c.id}`;assert.equal(tasks.length,1);
 await db`UPDATE tasks SET status='succeeded' WHERE case_id=${c.id}`;await db`UPDATE cases SET status='ready',report=${db.json({content:'已交付测试报告'})} WHERE id=${c.id}`;
 const followup=await createTurn(owner,c.id,{question:'付款后是否可以继续追问？',idempotencyKey:randomUUID()});assert.equal(followup.status,'queued');assert.equal((await totals(db,c.id)).remaining,1);
 await db`UPDATE entitlements SET reserved=0 WHERE case_id=${c.id}`;await db`UPDATE tasks SET status='succeeded' WHERE case_id=${c.id}`;
 const addon=await createOrder(owner,c.id,{kind:'addon',idempotencyKey:randomUUID()});const extra=await startNbPayment(owner,{orderId:addon.id,paytype:'wxpay'},'127.0.0.1');await handleNbNotification(signed(extra));assert.equal((await totals(db,c.id)).granted,5);
});
test('取消后迟到付款进入退款处理，不能错误启动报告',async()=>{
 const {c,order,payment}=await checkout();await cancelUnpaidOrder(owner,order.id);await handleNbNotification(signed(payment));
 const result=await caseDetail(owner,c.id);assert.equal(result.orders[0].status,'refundPending');assert.equal(result.remainingTurns,0);assert.equal(result.tasks.length,0);
 const view=await checkNbPayment(owner,payment.id);assert.equal(view.orderStatus,'refundPending');assert.equal(view.caseId,c.id);
});

test('渠道退款后重复成功和解冻不能重新开放已冻结权益',async()=>{
 const {c,payment}=await checkout();await handleNbNotification(signed(payment));await applyNbQuery(payment.id,state(payment,'TRADE_REFUND'));
 for(const status of ['TRADE_SUCCESS','TRADE_SUCCESS','TRADE_UNFREEZE']){const view=await applyNbQuery(payment.id,state(payment,status));assert.equal(view.status,'TRADE_REFUND');assert.equal(view.orderStatus,'paymentFrozen')}
 assert.equal((await caseDetail(owner,c.id)).remainingTurns,0);
});
test('支付冻结阻止后续使用，解冻保留次数；过期成功通知不能绕过主动查单',async()=>{
 const {c,payment}=await checkout();await handleNbNotification(signed(payment));
 await applyNbQuery(payment.id,state(payment,'TRADE_FREEZE'));
 let detail=await caseDetail(owner,c.id);assert.equal(detail.orders[0].status,'paymentFrozen');assert.equal(detail.remainingTurns,0);assert.equal(detail.tasks[0].status,'failed');
 await assert.rejects(()=>createTurn(owner,c.id,{question:'冻结时不能追问',idempotencyKey:randomUUID()}),/正在核查/);
 queryStatus='TRADE_FREEZE';try{await handleNbNotification(signed(payment));assert.equal((await caseDetail(owner,c.id)).orders[0].status,'paymentFrozen')}finally{queryStatus='TRADE_SUCCESS'}
 await applyNbQuery(payment.id,state(payment,'TRADE_UNFREEZE'));detail=await caseDetail(owner,c.id);assert.equal(detail.orders[0].status,'paid');assert.equal(detail.remainingTurns,2);assert.equal(detail.tasks[0].status,'queued');
});
test('0.10元测试限管理员、不改正式价格、不发报告和次数',async()=>{
 await assert.rejects(()=>startNbPayment(owner,{test:true,paytype:'alipay'},'127.0.0.1'),/管理员/);
 const p=await startNbPayment({...owner,isAdmin:true},{test:true,paytype:'alipay'},'127.0.0.1');assert.equal(p.amountCents,10);assert.equal(p.isTest,true);assert.equal(p.orderId,null);
 const [before]=await db`SELECT count(*)::int AS count FROM tasks WHERE user_id=${owner.id}`;await handleNbNotification(signed(p));const [after]=await db`SELECT count(*)::int AS count FROM tasks WHERE user_id=${owner.id}`;assert.equal(after.count,before.count);
});

test('公开入口可由管理员独立暂停，普通用户不能绕过测试阶段发起新付款',async()=>{
 await assert.rejects(()=>publishNbPayments(owner,false),/Administrator/);
 await publishNbPayments({...owner,isAdmin:true},false);
 try{const c=await createCase(owner,{input});const order=await createOrder(owner,c.id,{kind:'base',idempotencyKey:randomUUID()});await assert.rejects(()=>startNbPayment(owner,{orderId:order.id,paytype:'alipay'},'127.0.0.1'),/仍在验证/)}finally{await publishNbPayments({...owner,isAdmin:true},true)}
});
