import {test} from "node:test";
import assert from "node:assert/strict";
import {waitForSessionCompletion} from "../src/agent/session-completion";
test("长任务用短轮询跨过五分钟，不把排队空窗或未完成消息当成功",async()=>{
  let reads=0,elapsed=0;
  await waitForSessionCompletion(async()=>{reads++;if(reads===1)return{busy:false};if(reads===2)return{busy:false,assistant:{}};if(elapsed<360000)return{busy:true};return{busy:false,assistant:{completed:elapsed}};},new AbortController().signal,async()=>{elapsed+=1500;});
  assert(elapsed>=360000);assert(reads>200);
});
test("轮询可取消并拒绝模型错误，即使已有部分工具输出也不能交付",async()=>{
  await assert.rejects(waitForSessionCompletion(async()=>({busy:false,assistant:{completed:1,error:{name:"ProviderError"}}}),new AbortController().signal),/model_execution_failed/);
  const abort=new AbortController();let reads=0;
  await assert.rejects(waitForSessionCompletion(async()=>{reads++;return{busy:true};},abort.signal,async()=>{abort.abort(new Error("cancelled"));}),/cancelled/);assert.equal(reads,1);
});


test('保留终止原因，不记录上游私有正文或凭据',async()=>{
 for(const code of ['tool_limit_exceeded','model_request_limit','model_output_incomplete','request_too_large'])await assert.rejects(waitForSessionCompletion(async()=>({busy:false,assistant:{error:{name:'APIError',data:{responseBody:JSON.stringify({error:{message:code},private:'never log this'})}}}}),new AbortController().signal),new RegExp('^Error: '+code+'$'));
 await assert.rejects(waitForSessionCompletion(async()=>({busy:false,assistant:{error:{data:{responseBody:'credential secret'}}}}),new AbortController().signal),/^Error: model_execution_failed$/);
});
