import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {sqlClient} from '../src/server/db';
import type {Actor} from '../src/server/http';
import {completePartnerHuman} from '../src/server/partner-human-redemption';
import {readConversationShare,revokeConversationShare,renewConversationShare,managePractitioners} from '../src/server/conversation-sharing';
import {creditPoints,finishHold,walletTotals} from '../src/server/points';
import {requestHuman,humanAction,maintainPoints} from '../src/server/human-assist';
import {defaultPointsConfig,savePointsConfig} from '../src/server/points-config';
if(!process.env.DATABASE_URL||!new URL(process.env.DATABASE_URL).pathname.includes('wenheng_test'))throw Error('isolated test database required');
const key='partner-'+randomUUID();Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:key,WENHENG_ENCRYPTION_KEY:'ab'.repeat(32)});
const db=sqlClient(),make=():Actor=>{const id='partner-test-'+randomUUID();return{id,email:id+'@example.invalid',name:'Synthetic partner test',emailVerified:true,isAdmin:false};};
const owner=make(),reader=make(),other=make(),admin={...make(),isAdmin:true},ids=[owner,reader,other,admin].map(a=>a.id),caseId=randomUUID();
before(async()=>{
 for(const a of [owner,reader,other,admin])await db`INSERT INTO "user"(id,email,name,email_verified) VALUES(${a.id},${a.email},${a.name},true)`;
 await db`INSERT INTO cases(id,user_id,title,status,report) VALUES(${caseId},${owner.id},'Synthetic partner settlement','ready',${db.json({content:'Synthetic report'})})`;
 await db`INSERT INTO case_inputs(case_id,version,input) VALUES(${caseId},1,${db.json({question:'Synthetic initial question',participants:[]})})`;
 await managePractitioners(admin,{action:'grant',advisorId:'congkui',email:reader.email});await managePractitioners(admin,{action:'grant',advisorId:'qing',email:other.email});
 const cfg={...defaultPointsConfig(),mode:'points' as const,humanEnabled:true};cfg.advisors=cfg.advisors.map(a=>({...a,wechatId:'synthetic_contact',accepting:true}));await savePointsConfig(admin,cfg);
 await creditPoints(admin,{userId:owner.id,kind:'bonus',units:200000,reason:'Isolated test balance only',idempotencyKey:randomUUID()});
});
after(async()=>{
 for(const table of ['human_assists','point_ledger','point_holds','point_lots','point_profiles'])await db.unsafe(`DELETE FROM ${table} WHERE user_id IN ($1,$2,$3,$4)`,ids);
 await db`DELETE FROM case_inputs WHERE case_id=${caseId}`;await db`DELETE FROM cases WHERE id=${caseId}`;await db`DELETE FROM audit_log WHERE actor_id IN ${db(ids)}`;await db`DELETE FROM "user" WHERE id IN ${db(ids)}`;await db`DELETE FROM service_settings WHERE key=${'test:'+key+':points'}`;await db.end();
});
const book=()=>requestHuman(owner,{caseId,advisorId:'congkui',question:'Synthetic service review',idempotencyKey:randomUUID()});
const finish=(code:unknown,actor:Actor=reader,extra:any={})=>completePartnerHuman(actor,{code,serviceCompleted:true,...extra});
const hold=async(id:string)=>(await db`SELECT * FROM point_holds WHERE id=${id}`)[0];
test('viewing only exposes booking state and never settles; assigned partner completes pending/accepted/review',async()=>{
 for(const state of ['pending','accepted','review']){
  const h=await book();if(state!=='pending')await humanAction(admin,h.id,{action:'accept'});if(state==='review')await humanAction(admin,h.id,{action:'deliver',summary:'Synthetic service was provided for review.'});
  const before=await walletTotals(db,owner.id),shared=await readConversationShare(reader,h.share.code);assert.equal(shared.booking.canComplete,true);assert.equal((await hold(h.id)).charged_units,0);
  const result=await finish(h.share.code!.toLowerCase(),reader,{units:1,chargedUnits:1,bookingId:randomUUID()});assert.equal(result.chargedUnits,1500);assert.equal(result.alreadyCompleted,false);
  const after=await walletTotals(db,owner.id);assert.equal(after.available,before.available);assert.equal(after.frozen,before.frozen-1500);
  const settled=await hold(h.id);assert.equal(settled.snapshot.humanRedemption.operatorId,reader.id);assert.equal(settled.snapshot.humanRedemption.source,'partner');assert.equal(settled.status,'settled');
  const reread=await readConversationShare(reader,h.share.code);assert.equal(reread.booking.status,'completed');assert.equal(reread.booking.canComplete,false);assert.equal(reread.booking.chargedUnits,1500);
 }
});
test('owner, another partner, unrelated admin, unverified account and unknown code cannot settle',async()=>{
 const h=await book(),before=await hold(h.id);
 for(const a of [owner,other,admin,{...reader,emailVerified:false}])await assert.rejects(()=>finish(h.share.code,a));await assert.rejects(()=>finish('WHC-UNKNOWN'));
 for(const value of [false,'true',undefined])await assert.rejects(()=>finish(h.share.code,reader,{serviceCompleted:value}),{code:'INVALID_INPUT'});assert.deepEqual(await hold(h.id),before);
});
test('parallel retries write one settlement and one partner audit record',async()=>{
 const h=await book(),results=await Promise.all(Array.from({length:8},()=>finish(h.share.code)));assert.equal(results.filter(r=>!r.alreadyCompleted).length,1);
 assert.equal((await db`SELECT count(*)::int AS n FROM point_ledger WHERE hold_id=${h.id} AND action='settled'`)[0].n,1);assert.equal((await db`SELECT count(*)::int AS n FROM audit_log WHERE target_id=${h.id} AND action='human:partner-redeem'`)[0].n,1);
 const before=await hold(h.id);await finish(h.share.code);assert.deepEqual(await hold(h.id),before);
});
test('revoked or rotated code and removed partner membership are rechecked',async()=>{
 const revoked=await book();await revokeConversationShare(owner,caseId,revoked.share.id);await assert.rejects(()=>finish(revoked.share.code));assert.equal((await hold(revoked.id)).charged_units,0);
 const rotated=await book(),next=await renewConversationShare(owner,caseId,rotated.share.id);await assert.rejects(()=>finish(rotated.share.code));await finish(next.code);
 const removed=await book();await readConversationShare(reader,removed.share.code);await managePractitioners(admin,{action:'revoke',advisorId:'congkui',email:reader.email});await assert.rejects(()=>finish(removed.share.code));await managePractitioners(admin,{action:'grant',advisorId:'congkui',email:reader.email});assert.equal((await hold(removed.id)).charged_units,0);
});
test('cancelled, refunded, disputed, expired booking/share and released or mismatched holds are rejected',async()=>{
 const cancelled=await book();await humanAction(owner,cancelled.id,{action:'cancel'});
 const refunded=await book();await humanAction(admin,refunded.id,{action:'refund',reason:'Synthetic service was not provided'});
 const disputed=await book();await humanAction(admin,disputed.id,{action:'accept'});await humanAction(owner,disputed.id,{action:'dispute',reason:'Synthetic service dispute'});
 const expired=await book();await db`UPDATE human_assists SET deadline=now()-interval '1 minute' WHERE id=${expired.id}`;
 const expiredShare=await book();await db`UPDATE conversation_shares SET expires_at=now()-interval '1 minute' WHERE id=${expiredShare.share.id}`;
 const released=await book();await db.begin(tx=>finishHold(tx,released.id,0,'Synthetic release'));
 const mismatched=await book();await db`UPDATE point_holds SET case_id=${randomUUID()} WHERE id=${mismatched.id}`;
 for(const h of [cancelled,refunded,disputed,expired,expiredShare,released,mismatched]){const before=await hold(h.id);await assert.rejects(()=>finish(h.share.code));assert.deepEqual(await hold(h.id),before);}
});
test('deleted case is inaccessible and cannot be settled',async()=>{
 const h=await book();try{await db`UPDATE cases SET deleted_at=now() WHERE id=${caseId}`;await assert.rejects(()=>finish(h.share.code));assert.equal((await hold(h.id)).charged_units,0);}finally{await db`UPDATE cases SET deleted_at=NULL WHERE id=${caseId}`;}
});
test('partner completion racing cancellation or operator redemption has one terminal ledger entry',async()=>{
 for(const operator of [false,true])for(let i=0;i<3;i++){
  const h=await book();await Promise.allSettled([finish(h.share.code),operator?humanAction(admin,h.id,{action:'redeem',serviceCompleted:true,summary:'Operator provided this synthetic service.'}):humanAction(owner,h.id,{action:'cancel'})]);
  const final=await hold(h.id),[booking]=await db`SELECT status FROM human_assists WHERE id=${h.id}`;assert.equal(booking.status,final.status==='settled'?'completed':'cancelled');assert.equal((await db`SELECT count(*)::int AS n FROM point_ledger WHERE hold_id=${h.id} AND action IN ('settled','released')`)[0].n,1);
 }
});
test('operator or automatic completed bookings remain idempotent; maintenance never charges completed twice',async()=>{
 for(const automatic of [false,true]){
  const h=await book();if(automatic){await humanAction(admin,h.id,{action:'accept'});await humanAction(admin,h.id,{action:'deliver',summary:'Synthetic completed service delivery.'});await db`UPDATE human_assists SET deadline=now()-interval '1 second' WHERE id=${h.id}`;await maintainPoints();}else await humanAction(admin,h.id,{action:'redeem',serviceCompleted:true,summary:'Synthetic operator completed service.'});
  const before=await hold(h.id);assert.equal((await finish(h.share.code)).alreadyCompleted,true);assert.deepEqual(await hold(h.id),before);await maintainPoints();assert.deepEqual(await hold(h.id),before);
 }
});
