import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {SMTPServer} from 'smtp-server';
import {sqlClient} from '../src/server/db';

if(!process.env.DATABASE_URL||new URL(process.env.DATABASE_URL).pathname!=='/wenheng_test_account')throw Error('Exact isolated test DB required');
const key='auth-recovery-'+randomUUID(),origin='http://127.0.0.1:3199',email=key+'@example.invalid',password='synthetic-old-password-20261017',newPassword='synthetic-new-password-20261017';
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:key,APP_URL:origin,BETTER_AUTH_SECRET:'isolated-auth-recovery-secret-20261017'});
let mail='',cookie='',userId='';
const db=sqlClient(),smtp=new SMTPServer({authOptional:true,disabledCommands:['STARTTLS'],onData(stream,_session,done){let raw='';stream.on('data',s=>raw+=s);stream.on('end',()=>{mail=raw.replace(/=\r?\n/g,'').replace(/=([0-9A-F]{2})/g,(_,h)=>String.fromCharCode(parseInt(h,16)));done();});}});
async function send(path:string,data:unknown,cookies='',source=origin){const {getAuth}=await import('../src/server/auth');return getAuth().handler(new Request(origin+'/api/auth/'+path,{method:'POST',headers:{Origin:source,'Content-Type':'application/json',...(cookies?{Cookie:cookies}:{})},body:JSON.stringify(data)}));}
before(async()=>{
 await new Promise<void>((resolve,reject)=>{smtp.once('error',reject);smtp.listen(12528,'127.0.0.1',resolve);});
 await db`INSERT INTO service_settings(key,value) VALUES(${'test:'+key},${db.json({emailProvider:'smtp',smtpHost:'127.0.0.1',smtpPort:12528,smtpSecure:false,smtpFrom:'test@example.invalid'})})`;
 const signup=await send('sign-up/email',{username:'recover_'+randomUUID().replaceAll('-','').slice(0,12),email,password,name:'Synthetic recovery account'});assert.equal(signup.status,200);userId=(await signup.json()).user.id;cookie=signup.headers.getSetCookie().map(c=>c.split(';')[0]).join('; ');
 const verification=mail.match(/http:\/\/127\.0\.0\.1:3199\/api\/auth\/verify-email[^\s<>]+/)?.[0];assert.ok(verification);const {getAuth}=await import('../src/server/auth');assert.equal((await getAuth().handler(new Request(verification))).status,302);
});
after(async()=>{if(userId)await db`DELETE FROM "user" WHERE id=${userId}`;await db`DELETE FROM service_settings WHERE key=${'test:'+key}`;await db`DELETE FROM rate_limits WHERE key LIKE ${'mail:test:'+key+'%'}`;await db.end();await new Promise<void>(resolve=>smtp.close(()=>resolve()));});

test('password recovery revokes all old sessions; reset token is single-use and old password fails',async()=>{
 const {getAuth}=await import('../src/server/auth');
 assert.equal((await send('request-password-reset',{email,redirectTo:'https://untrusted.invalid/steal'})).status,403);
 assert.equal((await send('change-email',{newEmail:'untrusted@example.invalid'},cookie,'https://untrusted.invalid')).status,403);
 assert.equal((await send('request-password-reset',{email,redirectTo:origin+'/reset-password'})).status,200);
 const link=mail.match(/http:\/\/127\.0\.0\.1:3199\/api\/auth\/reset-password\/[^\s<>]+/)?.[0];assert.ok(link);
 const token=new URL(link).pathname.split('/').pop()!;
 assert.equal((await send('reset-password',{token,newPassword})).status,200);
 assert.equal(await getAuth().api.getSession({headers:new Headers({Cookie:cookie})}),null,'compromised old sessions must stop working after recovery');
 assert.equal((await send('reset-password',{token,newPassword:password})).status,400,'a consumed token must not reset the password twice');
 assert.equal((await send('sign-in/email',{email,password})).status,401);
 assert.equal((await send('sign-in/email',{email,password:newPassword})).status,200);
});
