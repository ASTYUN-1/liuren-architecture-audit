import {test,before,after} from 'node:test';
import {SMTPServer} from 'smtp-server';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {renderMail,mailUrl,MAIL_KINDS} from '../src/server/mail-content';
import {sesPayload,mailErrorCode} from '../src/server/mail';
import {getRuntimeSettings,updateSettings,getSettings} from '../src/server/settings';
import {sqlClient} from '../src/server/db';
import {drainMailOutbox} from '../src/server/mail-outbox';
if(!process.env.DATABASE_URL||!new URL(process.env.DATABASE_URL).pathname.includes('wenheng_test'))throw Error('isolated test DB required');
Object.assign(process.env,{NODE_ENV:'test'});
const smtp=new SMTPServer({authOptional:true,disabledCommands:['STARTTLS'],onData(stream,_session,done){stream.resume();stream.on('end',done);}});
before(async()=>{await new Promise<void>((resolve,reject)=>{smtp.once('error',reject);smtp.listen(12525,'127.0.0.1',resolve);});});
after(async()=>{await sqlClient().end();await new Promise<void>(resolve=>smtp.close(()=>resolve()));});

test('邮件链接固定同源，SES变量仅含路径，内容无问题或出生资料',async()=>{
 const previous=process.env.APP_URL;process.env.APP_URL='https://wen.qiluhub.com';
 try {
  assert.throws(()=>mailUrl('https://external.invalid/'),/REJECTED/);
  assert.throws(()=>mailUrl('https://name:pass@wen.qiluhub.com/'),/REJECTED/);
  for(const kind of MAIL_KINDS){const content=renderMail(kind,'https://wen.qiluhub.com/account');assert.ok(content.subject&&content.text.includes('https://wen.qiluhub.com/account'));}
  const s={...await getRuntimeSettings(),smtpFrom:'notifications@mail.qiluhub.com',sesTemplates:{verification:225066,passwordReset:225067,resultReady:225068,serviceUpdate:225069,referralReward:225070}};
  const payload=sesPayload(s,'test@example.invalid','verification','https://wen.qiluhub.com/api/auth/verify-email?token=fixture');
  assert.deepEqual(payload.Destination,['test@example.invalid']);
  assert.deepEqual(JSON.parse(payload.Template.TemplateData),{path:'api/auth/verify-email?token=fixture'});
  assert.equal(payload.TriggerType,1);assert.equal(payload.Template.TemplateID,225066);
 }finally{process.env.APP_URL=previous;}
});

test('邮件错误不保留原始响应、邮箱或验证令牌',()=>{
 assert.equal(mailErrorCode({code:'AuthFailure.SignatureFailure',message:'secret payload'}),'AuthFailure.SignatureFailure');
 assert.equal(mailErrorCode({code:'secret@example.com?token=private'}),'MAIL_DELIVERY_FAILED');
 assert.equal(mailErrorCode(new Error('token=private')),'MAIL_DELIVERY_FAILED');
});

test('SES两项凭据均加密保存且读取不回显，改动模板使就绪状态失效',async()=>{
 if(!process.env.DATABASE_URL||!new URL(process.env.DATABASE_URL).pathname.includes('wenheng_test'))throw Error('isolated test DB required');
 const previous=process.env.SETTINGS_RECORD_KEY;process.env.SETTINGS_RECORD_KEY='ses-'+randomUUID();
 const db=sqlClient(),actor={id:'test-mail-admin',email:'mail@example.invalid',name:'Test',emailVerified:true,isAdmin:true};
 try{
  const result=await updateSettings(actor,{emailProvider:'tencentSes',sesSecretId:'fixture-secret-id',sesSecretKey:'fixture-secret-key'});
  assert.equal(result.hasSesSecretKey,true);assert.equal(JSON.stringify(result).includes('fixture-secret'),false);
  const [row]=await db`SELECT value FROM service_settings WHERE key=${'test:'+process.env.SETTINGS_RECORD_KEY}`;
  assert.equal(JSON.stringify(row.value).includes('fixture-secret'),false);
  await db`UPDATE service_settings SET value=jsonb_set(value,'{sesAuthReady}','true') WHERE key=${'test:'+process.env.SETTINGS_RECORD_KEY}`;
  assert.equal((await getSettings()).sesAuthReady,true);
  await updateSettings(actor,{sesTemplates:{verification:1,passwordReset:2,resultReady:3,serviceUpdate:4,referralReward:5}});
  assert.equal((await getSettings()).sesAuthReady,false);
  await updateSettings(actor,{clearSesCredentials:true});assert.equal((await getSettings()).hasSesSecretKey,false);
 }finally{await db`DELETE FROM service_settings WHERE key=${'test:'+process.env.SETTINGS_RECORD_KEY}`;if(previous===undefined)delete process.env.SETTINGS_RECORD_KEY;else process.env.SETTINGS_RECORD_KEY=previous;}
});

test('业务触发器与事务一起提交，去重，邮件失败不回滚业务；删除档案不再通知',async()=>{
 const db=sqlClient(),previous=process.env.SETTINGS_RECORD_KEY;process.env.SETTINGS_RECORD_KEY='outbox-'+randomUUID();
 const id=randomUUID(),caseId=randomUUID(),taskId=randomUUID(),key='test:'+process.env.SETTINGS_RECORD_KEY;
 try{
  await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${id},'仅测试 · 邮件队列',${id+'@example.invalid'},true)`;
  await db`INSERT INTO cases(id,user_id,title) VALUES(${caseId},${id},'仅测试 · 隐私内容不得写进邮件队列')`;
  await db`INSERT INTO tasks(id,case_id,user_id,kind,input_version,idempotency_key) VALUES(${taskId},${caseId},${id},'initial',1,${taskId})`;
  await assert.rejects(db.begin(async tx=>{await tx`UPDATE tasks SET status='succeeded' WHERE id=${taskId}`;throw Error('rollback');}));
  assert.equal((await db`SELECT id FROM mail_outbox WHERE user_id=${id}`).length,0);
  await db`UPDATE tasks SET status='succeeded' WHERE id=${taskId}`;
  await db`UPDATE tasks SET status='succeeded' WHERE id=${taskId}`;
  const rows=await db`SELECT * FROM mail_outbox WHERE user_id=${id}`;assert.equal(rows.length,1);
  assert.equal(rows[0].kind,'resultReady');assert.equal(JSON.stringify(rows).includes('隐私内容'),false);
  await db`INSERT INTO service_settings(key,value) VALUES(${key},${db.json({emailProvider:'smtp',smtpHost:'127.0.0.1',smtpPort:12525,smtpSecure:false,smtpFrom:'test@example.invalid',serviceNotificationsEnabled:true})})`;
  // Test fixtures are selected first without changing production query paths.
  await db`UPDATE mail_outbox SET created_at=now()-interval '6 days' WHERE user_id=${id}`;
  await drainMailOutbox();
  const [accepted]=await db`SELECT * FROM mail_outbox WHERE user_id=${id}`;assert.equal(accepted.status,'accepted');assert.ok(accepted.provider_message_id);
  // Completion, clarification and failure updates for a follow-up stay in-app.
  const followupId=randomUUID();
  await db`INSERT INTO tasks(id,case_id,user_id,kind,input_version,idempotency_key) VALUES(${followupId},${caseId},${id},'followup',1,${followupId})`;
  for(const status of ['succeeded','failed']){
   await db`UPDATE tasks SET status=${status} WHERE id=${followupId}`;
   await db`UPDATE mail_outbox SET created_at=now()-interval '6 days' WHERE user_id=${id} AND status='pending'`;
   await drainMailOutbox();
  }
  const followupMail=await db`SELECT status,error_code FROM mail_outbox WHERE user_id=${id} AND event_key LIKE ${'task:'+followupId+':%'}`;
  assert.equal(followupMail.length,2);assert.ok(followupMail.every(m=>m.status==='suppressed'&&m.error_code==='FOLLOWUP_IN_APP_ONLY'));
  assert.equal((await db`SELECT id FROM mail_outbox WHERE user_id=${id} AND status='accepted'`).length,1);
  await db`INSERT INTO mail_outbox(event_key,user_id,case_id,kind,created_at) VALUES(${randomUUID()},${id},${caseId},'serviceUpdate',now()-interval '6 days')`;
  await db`UPDATE service_settings SET value=jsonb_set(value,'{smtpPort}','1') WHERE key=${key}`;
  await drainMailOutbox();assert.equal((await db`SELECT id FROM mail_outbox WHERE user_id=${id} AND status='failed'`).length,1);
  await db`INSERT INTO mail_outbox(event_key,user_id,case_id,kind,created_at) VALUES(${randomUUID()},${id},${caseId},'serviceUpdate',now()-interval '6 days')`;
  await db`UPDATE cases SET deleted_at=now() WHERE id=${caseId}`;
  await drainMailOutbox();assert.equal((await db`SELECT id FROM mail_outbox WHERE user_id=${id} AND status='suppressed' AND error_code='NO_LONGER_APPLICABLE'`).length,1);
  await db`UPDATE service_settings SET value=value || ${db.json({emailProvider:'tencentSes',sesAuthReady:true,sesTemplates:{verification:1,passwordReset:2,resultReady:3,serviceUpdate:4,referralReward:0}})} WHERE key=${key}`;
  await db`INSERT INTO mail_outbox(event_key,user_id,kind,created_at) VALUES(${randomUUID()},${id},'referralReward',now()-interval '6 days')`;
  await drainMailOutbox();assert.equal((await db`SELECT id FROM mail_outbox WHERE user_id=${id} AND status='suppressed' AND error_code='MAIL_KIND_DISABLED'`).length,1);
  assert.equal((await db`SELECT status FROM tasks WHERE id=${taskId}`)[0].status,'succeeded');
 }finally{
  await db`DELETE FROM mail_outbox WHERE user_id=${id}`;await db`DELETE FROM tasks WHERE user_id=${id}`;await db`DELETE FROM cases WHERE user_id=${id}`;await db`DELETE FROM "user" WHERE id=${id}`;await db`DELETE FROM service_settings WHERE key=${key}`;if(previous===undefined)delete process.env.SETTINGS_RECORD_KEY;else process.env.SETTINGS_RECORD_KEY=previous;
 }
});
