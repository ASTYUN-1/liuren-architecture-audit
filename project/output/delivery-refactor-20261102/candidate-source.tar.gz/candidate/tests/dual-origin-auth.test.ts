import {test} from 'node:test';
import assert from 'node:assert/strict';
import {betterAuth} from 'better-auth';
import {memoryAdapter} from 'better-auth/adapters/memory';

test('canonical auth URL accepts secondary-origin signup, login and host-only session cookie',async()=>{
  const origin='https://cn-wen.qiluhub.com';
  const auth=betterAuth({
    baseURL:'https://wen.qiluhub.com',
    trustedOrigins:['https://wen.qiluhub.com',origin],
    secret:'synthetic-test-only-secret-not-a-production-credential',
    database:memoryAdapter({user:[],session:[],account:[],verification:[]}),
    emailAndPassword:{enabled:true,minPasswordLength:10},
    rateLimit:{enabled:false},
    advanced:{disableOriginCheck:false,disableCSRFCheck:false},
  });
  const send=(path:string,body:unknown,source=origin)=>auth.handler(new Request(origin+'/api/auth/'+path,{
    method:'POST',headers:{'content-type':'application/json',origin:source,host:'cn-wen.qiluhub.com'},body:JSON.stringify(body),
  }));
  const email='dual-origin@example.invalid',password='synthetic-test-password-only';
  const signup=await send('sign-up/email',{email,password,name:'Synthetic dual origin',callbackURL:'/account'});
  assert.equal(signup.status,200);
  const login=await send('sign-in/email',{email,password});
  assert.equal(login.status,200);
  const cookies=login.headers.getSetCookie();
  assert.ok(cookies.some(c=>c.includes('session_token=')&&c.includes('Secure')));
  assert.ok(cookies.every(c=>!/(?:^|;)\s*domain=/i.test(c)));
  const cookie=cookies.map(c=>c.split(';')[0]).join('; ');
  const session=await auth.handler(new Request(origin+'/api/auth/get-session',{headers:{cookie,host:'cn-wen.qiluhub.com'}}));
  assert.equal(session.status,200);
  assert.equal((await session.json()).user.email,email);
  const rejected=await send('sign-in/email',{email,password},'https://untrusted.invalid');
  assert.equal(rejected.status,403);
});
