import test from "node:test";
import assert from "node:assert/strict";
import {spawn} from "node:child_process";
import {runInterpretation} from "../src/agent/runtime";
import {stopRuntimeChild} from "../src/agent/runtime-lifecycle";
const endpoint='https://api.deepseek.com/v1/chat/completions';
test('隔离OpenCode并发2/4：上下文不混、仅模拟费用、所有运行正常回收',{skip:process.env.WENHENG_RUNTIME_FIXTURE!=='1',timeout:120000},async()=>{
 const original=globalThis.fetch;const results:any[]=[];
 const level=process.env.WENHENG_CAPACITY_LEVEL;assert(!level||["2","4"].includes(level));
 try{for(const concurrency of (level?[Number(level)]:[2,4])){
  console.log("LOCAL_CONCURRENCY_BEGIN",JSON.stringify({concurrency,nodeRssBytes:process.memoryUsage().rss}));
  let requests=0,initial=0,active=0,maxActive=0,release!:()=>void;const gate=new Promise<void>(ok=>release=ok),seen=new Set<string>(),started=Date.now();
  globalThis.fetch=(async(url:any,init:any)=>{if(String(url)!==endpoint)return original(url,init);requests++;active++;maxActive=Math.max(maxActive,active);const body=JSON.parse(init.body),labels=new Set<string>(JSON.stringify(body.messages).match(/isolation-[24]-[0-3]/g)??[]);let actions:any[]=[];if(!labels.size){initial++;if(initial===concurrency)release();await gate;actions=[{id:`context-${requests}`,type:'function',function:{name:'wenheng_read_case',arguments:'{}'}}];}else{assert.equal(labels.size,1,'No cross-task case context');for(const label of labels)seen.add(label);}active--;return new Response(JSON.stringify({id:`concurrent-${requests}`,created:1,model:'deepseek-flash',choices:[{index:0,message:{role:'assistant',content:actions.length?null:'Synthetic done',reasoning_content:'synthetic',...(actions.length?{tool_calls:actions}:{})},finish_reason:actions.length?'tool_calls':'stop'}],usage:{prompt_tokens:1,completion_tokens:1}}));}) as typeof fetch;
  await Promise.all(Array.from({length:concurrency},(_,i)=>assert.rejects(runInterpretation({taskId:`isolation-${concurrency}-${i}`,caseId:`isolation-${concurrency}-${i}`,kind:'initial',audience:'practitioner',input:{question:`isolation-${concurrency}-${i}`,locale:'en',mode:'time',time:'2026-10-15T05:00:00Z',timeZone:'Asia/Shanghai',participants:[]},history:[],apiKey:'not-a-real-key',signal:AbortSignal.timeout(90000)},{protocol:'liuren-v3'}),e=>{const error=e as Error&{usage:any};assert.equal(error.message,'report_not_submitted');assert.equal(error.usage.requests,2);assert.equal(error.usage.toolCalls,1);return true;})));
  assert.equal(requests,concurrency*2);assert.equal(seen.size,concurrency);assert.equal(maxActive,concurrency);const result={concurrency,durationMs:Date.now()-started,requests,maxActive,isolatedContexts:seen.size,nodeRssBytes:process.memoryUsage().rss};results.push(result);console.log("LOCAL_CONCURRENCY_PHASE_RESULT",JSON.stringify(result));
 }console.log('LOCAL_CONCURRENCY_EVIDENCE',JSON.stringify({paidApiRequests:0,results}));}finally{globalThis.fetch=original;}
});
test('运行子进程停止后等待exit，不遗留清理定时器',async()=>{const child=spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{stdio:'ignore',windowsHide:true});await new Promise<void>((ok,bad)=>{child.once('spawn',ok);child.once('error',bad);});await stopRuntimeChild(child);assert(child.exitCode!==null||child.signalCode!==null);});
