import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {sqlClient} from '../src/server/db';
import type {Actor} from '../src/server/http';
import {creditPoints,walletTotals} from '../src/server/points';
import {createCase,deleteCase,patchCase} from '../src/server/service';
import {createPointsTask,cancelPointTask} from '../src/server/points-ai';
import {requestHuman,humanAction} from '../src/server/human-assist';
import {defaultPointsConfig,savePointsConfig} from '../src/server/points-config';
if(!process.env.DATABASE_URL||!new URL(process.env.DATABASE_URL).pathname.includes('wenheng_test'))throw Error('isolated test database required');
const key='deletion-security-'+randomUUID();
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:key,WENHENG_ENCRYPTION_KEY:'ab'.repeat(32),AI_ENABLED:'true',DEEPSEEK_API_KEY:'not-a-real-key'});
const db=sqlClient(),users:string[]=[],cases:string[]=[];
async function user(admin=false):Promise<Actor>{const id='deletion-security-'+randomUUID();users.push(id);const a={id,email:id+'@example.invalid',name:'Synthetic deletion security',emailVerified:true,isAdmin:admin};await db`INSERT INTO "user"(id,email,name,email_verified) VALUES(${id},${a.email},${a.name},true)`;return a;}
let admin:Actor;
before(async()=>{admin=await user(true);await db`INSERT INTO advisor_accounts(advisor_id,user_id) VALUES('congkui',${admin.id})`;await db`INSERT INTO service_settings(key,value) VALUES(${'test:'+key+':workerHeartbeat'},${db.json({at:new Date().toISOString()})})`;const cfg={...defaultPointsConfig(),mode:'points' as const,humanEnabled:true,aiEnabled:true};cfg.advisors=cfg.advisors.map(a=>({...a,wechatId:'synthetic_contact',accepting:true}));await savePointsConfig(admin,cfg);});
after(async()=>{
 await db`DELETE FROM tasks WHERE user_id IN ${db(users)}`;
 for(const table of ['human_assists','point_ledger','point_holds','point_lots','point_profiles'])await db.unsafe(`DELETE FROM ${table} WHERE user_id = ANY($1)`,[users]);
 await db`DELETE FROM case_inputs WHERE case_id IN ${db(cases)}`;await db`DELETE FROM cases WHERE user_id IN ${db(users)}`;
 await db`DELETE FROM audit_log WHERE actor_id IN ${db(users)}`;await db`DELETE FROM "user" WHERE id IN ${db(users)}`;await db`DELETE FROM service_settings WHERE key LIKE ${'test:'+key+'%'}`;await db.end();
});
async function fixture(owner?:Actor){const a=owner??await user();if(!owner)await creditPoints(admin,{userId:a.id,kind:'bonus',units:100000,reason:'Isolated synthetic security balance',idempotencyKey:randomUUID()});const c=await createCase(a,{input:{question:'隔离测试：这次合作如何推进？',locale:'zh',mode:'time',timeZone:'Asia/Shanghai',time:'2026-10-15T00:00:00+08:00',participants:[]}});cases.push(c.id);return {a,c};}
async function booking(state:string){const f=await fixture();await db`UPDATE cases SET report=${db.json({content:'Synthetic report'})},status='ready' WHERE id=${f.c.id}`;const h=await requestHuman(f.a,{caseId:f.c.id,advisorId:'congkui',question:'Synthetic review request',idempotencyKey:randomUUID()});if(state!=='pending')await humanAction(admin,h.id,{action:'accept'});if(['review','completed'].includes(state))await humanAction(admin,h.id,{action:'deliver',summary:'Synthetic delivered service, not real customer data.'});if(state==='completed')await humanAction(f.a,h.id,{action:'confirm'});if(state==='disputed')await humanAction(f.a,h.id,{action:'dispute',reason:'Synthetic dispute reason'});return {...f,h};}
const hold=async(id:string)=>(await db`SELECT * FROM point_holds WHERE id=${id}`)[0];
for(const state of ['accepted','review','disputed'])for(const permanent of [false,true])test(`${state}: ${permanent?'permanent':'soft'} deletion cannot refund active human service`,async()=>{
 const {a,c,h}=await booking(state),balance=await walletTotals(db,a.id),before=await hold(h.id);
 await assert.rejects(()=>deleteCase(a,c.id,permanent),{code:'HUMAN_ACTIVE'});assert.deepEqual(await hold(h.id),before);assert.deepEqual(await walletTotals(db,a.id),balance);
 const [saved]=await db`SELECT deleted_at,permanently_deleted,report FROM cases WHERE id=${c.id}`;assert.equal(saved.deleted_at,null);assert.equal(saved.permanently_deleted,false);assert(saved.report);
 await humanAction(admin,h.id,{action:'refund',reason:'Synthetic legitimate refund'});await deleteCase(a,c.id,permanent);
});
test('pending service deletion releases once and revokes its share even after restore',async()=>{
 const {a,c,h}=await booking('pending');await deleteCase(a,c.id);const released=await hold(h.id);assert.equal(released.status,'released');assert.equal(released.charged_units,0);assert((await db`SELECT revoked_at FROM conversation_shares WHERE id=${h.share.id}`)[0].revoked_at);
 await patchCase(a,c.id,{restore:true});await deleteCase(a,c.id,true);const purged=await hold(h.id);for(const key of ['status','units','charged_units','refunded_units','allocations'])assert.deepEqual(purged[key],released[key]);assert.equal(purged.snapshot.question,undefined);
});
test('completed human charge survives permanent deletion',async()=>{
 const {a,c,h}=await booking('completed'),before=await hold(h.id);await deleteCase(a,c.id,true);const after=await hold(h.id);assert.equal(after.status,'settled');assert.equal(after.charged_units,1500);assert.equal(after.refunded_units,before.refunded_units);
});
async function running(a:Actor,c:any){const t=await createPointsTask(a,c.id,{kind:'initial',idempotencyKey:randomUUID()});await db`UPDATE tasks SET status='running',worker_token=${randomUUID()},lease_expires_at=now()+interval '1 minute' WHERE id=${t.id}`;return t;}
test('delete/restore and explicit cancellation remain available beyond three stops and release once',async()=>{
 const {a,c}=await fixture();
 for(let i=0;i<5;i++){const t=await running(a,c);if(i%2){await cancelPointTask(a,t.id);await cancelPointTask(a,t.id);}else{await deleteCase(a,c.id);await patchCase(a,c.id,{restore:true});}const [saved]=await db`SELECT * FROM tasks WHERE id=${t.id}`;assert.equal(saved.status,'cancelled');assert.equal((await hold(saved.point_hold_id)).status,'released');}
 assert.equal((await db`SELECT count(*)::int AS n FROM audit_log WHERE actor_id=${a.id} AND action='pointTaskCancel'`)[0].n,5);
});
test('queued deletion remains allowed, clears token and retains cancellation audit',async()=>{
 const {a,c}=await fixture();await db`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'pointTaskCancel','synthetic-1','{}'),(${randomUUID()},${a.id},'pointTaskCancel','synthetic-2','{}'),(${randomUUID()},${a.id},'pointTaskCancel','synthetic-3','{}')`;
 const t=await createPointsTask(a,c.id,{kind:'initial',idempotencyKey:randomUUID()});await deleteCase(a,c.id,true);const [saved]=await db`SELECT * FROM tasks WHERE id=${t.id}`;assert.equal(saved.status,'cancelled');assert.equal(saved.worker_token,null);assert.equal(saved.lease_expires_at,null);assert.equal((await hold(saved.point_hold_id)).status,'released');assert.equal((await db`SELECT count(*)::int AS n FROM audit_log WHERE actor_id=${a.id} AND action='pointTaskCancel'`)[0].n,4);
});
test('concurrent deletions on different cases both release their own reservations',async()=>{
 const {a,c}=await fixture(),second=await fixture(a);await db`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'pointTaskCancel','synthetic-1','{}'),(${randomUUID()},${a.id},'pointTaskCancel','synthetic-2','{}')`;
 await running(a,c);await running(a,second.c);const results=await Promise.allSettled([deleteCase(a,c.id),deleteCase(a,second.c.id,true)]);assert.equal(results.filter(r=>r.status==='fulfilled').length,2);assert.equal((await db`SELECT count(*)::int AS n FROM audit_log WHERE actor_id=${a.id} AND action='pointTaskCancel'`)[0].n,4);
});
test('acceptance racing deletion cannot release an accepted booking',async()=>{
 const {a,c,h}=await booking('pending');await Promise.allSettled([humanAction(admin,h.id,{action:'accept'}),deleteCase(a,c.id)]);const [r]=await db`SELECT status FROM human_assists WHERE id=${h.id}`,saved=await hold(h.id);if(r.status==='accepted'){assert.equal(saved.status,'held');assert.equal((await db`SELECT deleted_at FROM cases WHERE id=${c.id}`)[0].deleted_at,null);}else{assert.equal(r.status,'cancelled');assert.equal(saved.status,'released');}
});
