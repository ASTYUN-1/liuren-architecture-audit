import {test} from "node:test";
import assert from "node:assert/strict";
import {createServer} from "node:http";
import {proxyModel,ModelUsageTracker,MODEL_MAX_OUTPUT_TOKENS} from "../src/agent/gateway";
test("推理输出额度涵盖思考；截断和请求上限返回不可重试错误，不重复花费",async()=>{
 const original=globalThis.fetch,upstream="https://api.deepseek.com/v1/chat/completions";let calls=0,finish="stop";
 globalThis.fetch=(async(url:any,init:any)=>{
  if(String(url)!==upstream)return original(url,init);
  calls++;const body=JSON.parse(init.body);assert.equal(body.max_tokens,32768);assert.equal(body.stream,true);assert.equal(body.reasoning_effort,"high");
  return new Response(JSON.stringify({id:"test",model:"deepseek-flash",created:1,choices:[{message:{role:"assistant",content:"OK",reasoning_content:"x".repeat(130000)},finish_reason:finish}],usage:{prompt_tokens:100,completion_tokens:16000,prompt_cache_hit_tokens:0}}),{status:200});
 }) as typeof fetch;
 const budget=new ModelUsageTracker(3),server=createServer((req,res)=>{void proxyModel(req,res,"fixture-only",budget,new AbortController().signal);});
 await new Promise<void>(resolve=>server.listen(0,"127.0.0.1",resolve));const addr=server.address();assert(addr&&typeof addr==="object");const url=`http://127.0.0.1:${addr.port}`;
 const send=()=>original(url,{method:"POST",body:JSON.stringify({model:"deepseek-flash",messages:[{role:"user",content:"x".repeat(130000)}],max_tokens:12000})});
 try{
  assert.equal(MODEL_MAX_OUTPUT_TOKENS,32768);const first=await send();assert.equal(first.status,200);assert((await first.text()).includes('[DONE]'));assert.equal(budget.usage.outputTokens,16000);
  finish="length";const truncated=await send();assert.equal(truncated.status,400);assert.equal((await truncated.json()).error.message,"model_output_incomplete");assert.equal(budget.usage.requests,2);assert.equal(budget.usage.reservedCny,0);assert.equal(budget.usage.outputTokens,32000);
  finish="stop";budget.resumeIncompleteOutput();budget.usage.costCny=100;const large=await send();assert.equal(large.status,200);await large.text();assert.equal(calls,3);const exhausted=await send();assert.equal(exhausted.status,400);assert.equal((await exhausted.json()).error.message,"model_request_limit");assert.equal(calls,3);
 }finally{globalThis.fetch=original;await new Promise<void>(resolve=>server.close(()=>resolve()));}
});
