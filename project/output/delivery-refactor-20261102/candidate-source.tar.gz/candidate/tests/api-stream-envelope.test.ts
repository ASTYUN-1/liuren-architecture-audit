import {test,afterEach} from 'node:test';
import assert from 'node:assert/strict';
import {api,ApiException} from '../src/lib/api';
const original=globalThis.fetch;
afterEach(()=>{globalThis.fetch=original;});
test('JSON whitespace heartbeat retains the final result',async()=>{
 globalThis.fetch=async()=>new Response(' \n \n'+JSON.stringify({data:{ok:true}}),{status:200});
 assert.deepEqual(await api('/synthetic'),{ok:true});
});
test('HTTP 200 streaming error retains its application status and code',async()=>{
 globalThis.fetch=async()=>new Response(' \n'+JSON.stringify({error:{status:504,code:'INPUT_REVIEW_TIMEOUT',message:'整理超时'}}),{status:200});
 await assert.rejects(api('/synthetic'),(e:unknown)=>e instanceof ApiException&&e.status===504&&e.code==='INPUT_REVIEW_TIMEOUT'&&e.message==='整理超时');
});
test('truncated JSON is not delivered as success',async()=>{
 globalThis.fetch=async()=>new Response(' \n{"data":',{status:200});
 await assert.rejects(api('/synthetic'),{code:'INVALID_RESPONSE'});
});
