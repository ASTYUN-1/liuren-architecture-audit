import {calculateChart,publicChart} from "../src/engine/liuren";
import {test} from "node:test";
import assert from "node:assert/strict";
import {randomBytes,createHmac,randomUUID} from "node:crypto";
import {mkdir,readdir,readFile,writeFile} from "node:fs/promises";
import {resolve} from "node:path";
import {sqlClient} from "../src/server/db";
if(!process.env.DATABASE_URL||!/wenheng_test/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error("HTTP tests require isolated wenheng_test database");
const origin=process.env.APP_URL||"http://127.0.0.1:3100";
type Jar=Map<string,string>;
const jar:Jar=new Map(),adminJar:Jar=new Map();
async function request(path:string,method="GET",value?:unknown,cookies:Jar=jar){const response=await fetch(origin+path,{method,headers:{Origin:origin,...(value?{"Content-Type":"application/json"}:{}),Cookie:[...cookies].map(([k,v])=>`${k}=${v}`).join("; ")},body:value?JSON.stringify(value):undefined,redirect:"manual"});for(const c of response.headers.getSetCookie()){const [pair]=c.split(";");const at=pair.indexOf("=");cookies.set(pair.slice(0,at),pair.slice(at+1));}const text=await response.text();let json:any;try{json=JSON.parse(text);}catch{json={};}return {response,json,text};}
async function newEmailLink(email:string,send:()=>Promise<unknown>){const directory=resolve("test-results/mail"),before=new Set(await readdir(directory));await send();for(let i=0;i<30;i++){for(const name of (await readdir(directory)).filter(n=>!before.has(n))){const raw=(await readFile(resolve(directory,name),"utf8")).replace(/=\r?\n/g,"").replace(/=([0-9A-F]{2})/g,(_,h)=>String.fromCharCode(parseInt(h,16)));if(raw.includes(email)){const match=raw.match(/https?:\/\/[^\s<>]+/g)?.find(link=>new URL(link).origin===origin);if(match)return match;}}await new Promise(r=>setTimeout(r,100));}throw new Error("Expected local SMTP message was not delivered");}
function totp(uri:string){const secret=new URL(uri).searchParams.get("secret")!;let bits="";for(const c of secret.toUpperCase().replace(/=+$/,""))bits+="ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".indexOf(c).toString(2).padStart(5,"0");const decoded=Buffer.from(bits.match(/.{8}/g)!.map(b=>parseInt(b,2)));const counter=Buffer.alloc(8);counter.writeBigUInt64BE(BigInt(Math.floor(Date.now()/30000)));const digest=createHmac("sha1",decoded).update(counter).digest(),offset=digest[digest.length-1]&15;return ((digest.readUInt32BE(offset)&0x7fffffff)%1000000).toString().padStart(6,"0");}
test("真实HTTP注册、邮件验证、密码重置、管理员TOTP与密钥配置",async()=>{
 const email="qa-"+Date.now()+"@example.invalid",password=randomBytes(24).toString("base64url"),newPassword=randomBytes(24).toString("base64url"),adminEmail=process.env.ADMIN_EMAILS!.split(",")[0],adminPassword=randomBytes(24).toString("base64url");
 await mkdir(resolve("test-results"),{recursive:true});await writeFile(resolve("test-results/private-login.json"),JSON.stringify({origin,email,password:newPassword,adminEmail,adminPassword},null,2),{mode:0o600});const setupDb=sqlClient();await setupDb`DELETE FROM "user" WHERE email=${adminEmail} AND name='仅测试 · 管理员'`;const inviterJar:Jar=new Map();
 const inviterSignup=await request("/api/auth/sign-up/email","POST",{email:"referrer-"+Date.now()+"@example.invalid",password:randomBytes(24).toString("base64url"),name:"仅测试 · 邀请人"},inviterJar);assert.equal(inviterSignup.response.status,200);
 const inviterMe=await request("/api/me","GET",undefined,inviterJar);assert.equal(inviterMe.json.data.referral.availableCoupons,0);
 const invitation=await request(new URL(inviterMe.json.data.referral.shareUrl).pathname);assert.equal(invitation.response.status,303);assert.ok(invitation.response.headers.get("set-cookie")?.includes("HttpOnly"));assert.ok(invitation.response.headers.get("set-cookie")?.includes("SameSite=Lax"));assert.ok(invitation.response.headers.get("location")?.endsWith("/register?invited=1"));
 let signup:any; const verification=await newEmailLink(email,async()=>{signup=await request("/api/auth/sign-up/email","POST",{email,password,name:"仅测试 · 浏览器验收",callbackURL:origin+"/account"});assert.equal(signup.response.status,200);});
 const unverified=await request("/api/me");assert.equal(unverified.json.data.user.emailVerified,false);assert.equal(unverified.json.data.referral.availableCoupons,1);
 assert.equal((await request("/api/me","GET",undefined,inviterJar)).json.data.referral.invited,1);
 const missingPeople=await request("/api/cases","POST",{input:{question:"测试缺少必填出生资料",mode:"time",participants:[]}});assert.equal(missingPeople.response.status,200);
 const draft=await request("/api/cases","POST",{input:{question:"仅用于验收的测试问题：是否应该整理日程？",locale:"zh",mode:"time",timeZone:"Asia/Shanghai",participants:[{role:"本人",gender:"female",birthYear:1995}]}});assert.equal(draft.response.status,200);
 const denied=await request(`/api/cases/${draft.json.data.id}/orders`,"POST",{kind:"base",idempotencyKey:randomUUID()});assert.equal(denied.json.error.code,"EMAIL_UNVERIFIED");
 const verify=await request(new URL(verification).pathname+new URL(verification).search);assert.ok([200,302].includes(verify.response.status));assert.equal((await request("/api/me")).json.data.user.emailVerified,true);
 const reset=await newEmailLink(email,async()=>{const r=await request("/api/auth/request-password-reset","POST",{email,redirectTo:origin+"/reset-password"});assert.equal(r.response.status,200);});
 const resetToken=new URL(reset).pathname.split("/").pop()!;const resetResult=await request("/api/auth/reset-password","POST",{token:resetToken,newPassword});assert.equal(resetResult.response.status,200);
 assert.equal((await request("/api/me")).response.status,401,'password recovery must revoke the old session');
 assert.equal((await request("/api/auth/reset-password","POST",{token:resetToken,newPassword:password})).response.status,400,'reset tokens are single-use');
 jar.clear();assert.equal((await request("/api/auth/sign-in/email","POST",{email,password:newPassword})).response.status,200);
 const adminSignup=await request("/api/auth/sign-up/email","POST",{email:adminEmail,password:adminPassword,name:"仅测试 · 管理员"},adminJar);assert.equal(adminSignup.response.status,200);
 const adminVerification=await newEmailLink(adminEmail,async()=>{assert.equal((await request("/api/auth/send-verification-email","POST",{email:adminEmail,callbackURL:origin+"/admin"},adminJar)).response.status,200);});
 await request(new URL(adminVerification).pathname+new URL(adminVerification).search,"GET",undefined,adminJar);
 assert.equal((await request("/api/admin/users","GET",undefined,adminJar)).json.error.code,"ADMIN_2FA_REQUIRED");
 const no2fa=await request("/api/admin/settings","GET",undefined,adminJar);assert.equal(no2fa.json.error.code,"ADMIN_2FA_REQUIRED");
 const enable=await request("/api/auth/two-factor/enable","POST",{password:adminPassword},adminJar);assert.equal(enable.response.status,200);assert.ok(enable.json.totpURI);
 const totpUri=enable.json.totpURI;await writeFile(resolve("test-results/private-login.json"),JSON.stringify({origin,email,password:newPassword,adminEmail,adminPassword,adminTotpUri:totpUri,caseId:draft.json.data.id},null,2),{mode:0o600});const first=await request("/api/auth/two-factor/verify-totp","POST",{code:totp(totpUri)},adminJar);assert.equal(first.response.status,200);
 const get=await request("/api/admin/settings","GET",undefined,adminJar);assert.equal(get.response.status,200);assert.equal(typeof get.json.data.hasDeepseekApiKey,"boolean");
 const fakeKey="fixture-key-"+randomBytes(16).toString("hex");const patch=await request("/api/admin/settings","PATCH",{deepseekApiKey:fakeKey,aiEnabled:false,paymentsEnabled:false,paymentQrUrl:"/payment-placeholder.svg"},adminJar);assert.equal(patch.response.status,200);assert.equal(patch.json.data.hasDeepseekApiKey,true);assert.equal(patch.text.includes(fakeKey),false);
 const csrf=await fetch(origin+"/api/admin/settings",{method:"PATCH",headers:{Origin:"https://wrong.invalid","Content-Type":"application/json",Cookie:[...adminJar].map(([k,v])=>`${k}=${v}`).join("; ")},body:JSON.stringify({aiEnabled:true})});assert.equal(csrf.status,403);
 const testMail=await request("/api/admin/settings/test","POST",{kind:"smtp"},adminJar);assert.equal(testMail.response.status,200);
 const clear=await request("/api/admin/settings","PATCH",{clearDeepseekApiKey:true,aiEnabled:false,paymentsEnabled:false},adminJar);assert.equal(clear.response.status,200);assert.equal(clear.json.data.hasDeepseekApiKey,false);assert.equal((await request("/api/status")).json.data.paymentsEnabled,false);
 adminJar.clear();const signIn=await request("/api/auth/sign-in/email","POST",{email:adminEmail,password:adminPassword},adminJar);assert.equal(signIn.json.twoFactorRedirect,true);assert.equal((await request("/api/auth/two-factor/verify-totp","POST",{code:totp(totpUri)},adminJar)).response.status,200);assert.equal((await request("/api/admin/settings","GET",undefined,adminJar)).response.status,200);
 // Explicit fixture data exists only in wenheng_test and is clearly labelled.
 const db=sqlClient();await db`UPDATE cases SET status='ready',report=${db.json({title:"仅测试 · 页面验收样例",summary:"这是一份验收夹具，不代表实际AI测算结果。",content:"仅测试 · 页面验收样例\n\n此档案只用于核对页面排版、导出和用户权限，不是收费报告。\n\n可执行建议：先列出本周目标，然后按时间安排。",chart:publicChart(calculateChart(draft.json.data.input))})} WHERE id=${draft.json.data.id}`;const fixtureOrder=randomUUID(),fixtureEntitlement=randomUUID(),fixtureTurn=randomUUID();
 await db`INSERT INTO orders(id,user_id,case_id,kind,amount_cents,status,input_version,idempotency_key,confirmed_reference) VALUES(${fixtureOrder},${signup.json.user.id},${draft.json.data.id},'base',2990,'paid',1,${"test-fixture-"+fixtureOrder},${"TEST_ONLY_NO_REAL_PAYMENT_"+fixtureOrder})`;
 await db`INSERT INTO entitlements(id,case_id,order_id,granted,used) VALUES(${fixtureEntitlement},${draft.json.data.id},${fixtureOrder},2,1)`;
 await db`INSERT INTO tasks(id,case_id,user_id,kind,status,input_version,question,idempotency_key,entitlement_id,answer) VALUES(${fixtureTurn},${draft.json.data.id},${signup.json.user.id},'followup','succeeded',1,'仅测试：如何安排下一步？',${"test-fixture-"+fixtureTurn},${fixtureEntitlement},'仅测试 · 追问排版样例。这不是实际AI解读。建议先选择一件最重要的事情，再安排下一步。')`;
 await db`INSERT INTO entitlement_ledger(id,case_id,entitlement_id,order_id,action,quantity) VALUES(${randomUUID()},${draft.json.data.id},${fixtureEntitlement},${fixtureOrder},'grant',2)`;
 await db`INSERT INTO entitlement_ledger(id,case_id,entitlement_id,task_id,action,quantity) VALUES(${randomUUID()},${draft.json.data.id},${fixtureEntitlement},${fixtureTurn},'consume',1)`;
 const users=await request(`/api/admin/users?q=${encodeURIComponent(email)}`,"GET",undefined,adminJar);assert.equal(users.response.status,200);assert.equal(users.json.data.total,1);assert.equal(users.json.data.users[0].paidCents,2990);assert.equal(users.json.data.users[0].usedTurns,1);assert.equal(users.json.data.users[0].remainingTurns,1);
 const records=await request(`/api/admin/users?userId=${signup.json.user.id}`,"GET",undefined,adminJar);assert.equal(records.json.data.orders.length,1);assert(records.json.data.cases.some((c:any)=>c.id===draft.json.data.id));assert(!records.text.includes("测试问题"));
 assert.equal((await request("/api/admin/users")).response.status,403);assert.equal((await request("/api/admin/users","GET",undefined,new Map())).response.status,401);
 await mkdir(resolve("test-results"),{recursive:true});await writeFile(resolve("test-results/private-login.json"),JSON.stringify({origin,email,password:newPassword,caseId:draft.json.data.id,adminEmail,adminPassword,adminTotpUri:totpUri},null,2),{mode:0o600});await db.end();console.log("HTTP acceptance passed. Private fixture: test-results/private-login.json (secrets not printed)");
});



