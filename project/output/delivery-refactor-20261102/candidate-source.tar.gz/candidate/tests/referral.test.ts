import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { sqlClient } from "../src/server/db";
import { parseInput } from "../src/server/validation";
import { type Actor } from "../src/server/http";
import { createCase,createOrder,confirmPayment,confirmRefund,requestRefund,patchCase,deleteCase,caseDetail } from "../src/server/service";
import { cancelUnpaidOrder } from "../src/server/admin";
import { bindSignupReferral,referralSummary,rewardDeliveredReferral } from "../src/server/referrals";

if(!process.env.DATABASE_URL||!/wenheng_test/.test(new URL(process.env.DATABASE_URL).pathname))throw new Error('Refusing non-test database');
Object.assign(process.env,{NODE_ENV:'test',SETTINGS_RECORD_KEY:randomUUID(),SMTP_HOST:'test.invalid',SMTP_FROM:'test@example.invalid',DEEPSEEK_API_KEY:'fixture-only',AI_ENABLED:'true',MANUAL_PAYMENT_ENABLED:'true',PAYMENT_QR_URL:'https://example.invalid/payment.png'});
const db=sqlClient(), users:Actor[]=Array.from({length:7},(_,i)=>({id:'ref-'+randomUUID(),email:randomUUID()+'@example.invalid',name:'Referral fixture '+i,emailVerified:true,isAdmin:false}));
const [inviter,invitee,other,refundUser,refundInviter,legacy,revokedBuyer]=users,admin={...inviter,isAdmin:true};
const input={question:'仅测试：下周如何安排工作？',locale:'zh',mode:'time',timeZone:'Asia/Shanghai',time:'2026-10-15T00:00:00+08:00',participants:[{role:'本人',gender:'female',birthYear:1995}]};
const heartbeat='test:'+process.env.SETTINGS_RECORD_KEY+':workerHeartbeat';
before(async()=>{for(const u of users)await db`INSERT INTO "user"(id,name,email,email_verified) VALUES(${u.id},${u.name},${u.email},true)`;await db`INSERT INTO service_settings(key,value) VALUES(${heartbeat},${db.json({at:new Date().toISOString()})})`;});
after(async()=>{
  // Coupon/order references are intentionally retained in production; clear only this isolated fixture graph.
  const ids=users.map(u=>u.id);
  await db`UPDATE orders SET referral_coupon_id=NULL WHERE user_id IN ${db(ids)}`;
  await db`DELETE FROM referral_coupons WHERE user_id IN ${db(ids)} OR referral_id IN ${db(ids)}`;
  await db`DELETE FROM referrals WHERE inviter_id IN ${db(ids)} OR invitee_id IN ${db(ids)}`;
  for(const table of ['entitlement_ledger','tasks','entitlements','orders','case_inputs','deletion_tombstones'])await db.unsafe(`DELETE FROM ${table} WHERE case_id IN (SELECT id FROM cases WHERE user_id=ANY($1::text[]))`,[ids]);
  await db`DELETE FROM cases WHERE user_id IN ${db(ids)}`;await db`DELETE FROM audit_log WHERE actor_id IN ${db(ids)}`;
  await db`DELETE FROM "user" WHERE id IN ${db(ids)}`;await db`DELETE FROM service_settings WHERE key=${heartbeat}`;await db.end();
});
async function order(u:Actor){const c=await createCase(u,{input});return {c,o:await createOrder(u,c.id,{kind:'base',idempotencyKey:randomUUID()})};}
async function delivered(c:string){await db`UPDATE cases SET report=${db.json({content:'TEST ONLY'})},status='ready' WHERE id=${c}`;await db`UPDATE tasks SET status='succeeded' WHERE case_id=${c}`;await db.begin(tx=>rewardDeliveredReferral(tx,c));}

test('gender and year optional; supplied dates and years remain validated',()=>{
  for(const people of [undefined,[],[{role:'本人'}],[{role:'本人',gender:'unknown',birthYear:1995}],[{role:'本人',gender:'male'}]])assert.doesNotThrow(()=>parseInput({...input,participants:people}));
  assert.throws(()=>parseInput({...input,participants:[{role:'本人',birthYear:new Date().getFullYear()+1}]}),/出生年份/);
  assert.throws(()=>parseInput({...input,participants:[{role:'本人',gender:'male',birthYear:1995,birthDate:'1996-01-01'}]}),/出生日期/);
  assert.equal(parseInput(input).participants[0].birthYear,1995);
});
test('signup binding is single, self-invitation and invalid codes earn nothing',async()=>{
  const r=await referralSummary(inviter.id);await bindSignupReferral(inviter.id,r.code);await bindSignupReferral(other.id,'a'.repeat(24));
  assert.equal((await referralSummary(inviter.id)).availableCoupons,0);assert.equal((await referralSummary(other.id)).availableCoupons,0);
  await Promise.all([bindSignupReferral(invitee.id,r.code),bindSignupReferral(invitee.id,r.code)]);
  await bindSignupReferral(invitee.id,(await referralSummary(other.id)).code);
  assert.equal((await referralSummary(invitee.id)).availableCoupons,1);assert.equal((await referralSummary(inviter.id)).invited,1);assert.equal((await referralSummary(other.id)).invited,0);
});
test('one coupon under concurrent checkout; idempotency, cancellation and late receipts',async()=>{
  const c1=await createCase(invitee,{input}),c2=await createCase(invitee,{input});const key=randomUUID();
  const orders=await Promise.all([createOrder(invitee,c1.id,{kind:'base',idempotencyKey:key,amountCents:1}),createOrder(invitee,c2.id,{kind:'base',idempotencyKey:randomUUID()})]);
  assert.deepEqual(orders.map(o=>o.amountCents).sort((a,b)=>a-b),[2392,2990]);const discounted=orders.find(o=>o.amountCents===2392)!;assert.equal(discounted.discountCents,598);assert.equal(discounted.listAmountCents,2990);
  assert.equal((await createOrder(invitee,c1.id,{kind:'base',idempotencyKey:key})).id,orders[0].id);
  assert.equal((await referralSummary(invitee.id)).availableCoupons,0);
  await cancelUnpaidOrder(invitee,discounted.id);assert.equal((await referralSummary(invitee.id)).availableCoupons,1);await cancelUnpaidOrder(invitee,orders.find(o=>o.id!==discounted.id)!.id);
  assert.equal((await referralSummary(invitee.id)).availableCoupons,1);
  const replacement=await createOrder(invitee,discounted.caseId,{kind:'base',idempotencyKey:randomUUID()});assert.equal(replacement.amountCents,2392);
  const late=await confirmPayment(admin,discounted.id,{reference:randomUUID()});assert.equal(late.status,'refundPending');assert.equal(late.refundRequestedCents,2392);
  await confirmRefund(admin,late.id,randomUUID());assert.equal((await caseDetail(invitee,replacement.caseId)).status,'awaitingPayment');await cancelUnpaidOrder(invitee,replacement.id);
});
test('reward only after paid report delivery, once; add-on price unchanged; inviter can use next order',async()=>{
  const {c,o}=await order(invitee);assert.equal(o.amountCents,2392);
  await db.begin(tx=>rewardDeliveredReferral(tx,c.id));assert.equal((await referralSummary(inviter.id)).availableCoupons,0);
  await confirmPayment(admin,o.id,{reference:randomUUID()});assert.equal((await referralSummary(inviter.id)).availableCoupons,0);
  await delivered(c.id);await Promise.all([db.begin(tx=>rewardDeliveredReferral(tx,c.id)),db.begin(tx=>rewardDeliveredReferral(tx,c.id))]);
  assert.equal((await referralSummary(inviter.id)).availableCoupons,1);assert.equal((await referralSummary(inviter.id)).successful,1);
  const addon=await createOrder(invitee,c.id,{kind:'addon',idempotencyKey:randomUUID()});assert.equal(addon.amountCents,990);assert.equal(addon.discountCents,0);
  const next=await order(inviter);assert.equal(next.o.amountCents,2392);await confirmPayment(admin,next.o.id,{reference:randomUUID()});assert.equal((await referralSummary(inviter.id)).availableCoupons,0);
});
test('undelivered full refund restores 20%-off use and refunds actual payment',async()=>{
  await bindSignupReferral(refundUser.id,(await referralSummary(refundInviter.id)).code);const {c,o}=await order(refundUser);
  await confirmPayment(admin,o.id,{reference:randomUUID()});const refund=await requestRefund(refundUser,o.id,'test undelivered');assert.equal(refund.refundRequestedCents,2392);
  await confirmRefund(admin,o.id,randomUUID());assert.equal((await referralSummary(refundUser.id)).availableCoupons,1);assert.equal((await referralSummary(refundInviter.id)).availableCoupons,0);
  const retry=await createOrder(refundUser,c.id,{kind:'base',idempotencyKey:randomUUID()});assert.equal(retry.amountCents,2392);
  await patchCase(refundUser,c.id,{input:{...input,question:'仅测试修改后是否释放优惠券？'}});assert.equal((await referralSummary(refundUser.id)).availableCoupons,1);
});
test('old unpaid draft can proceed without optional demographics',async()=>{
  const c=await createCase(legacy,{input});await db`UPDATE case_inputs SET input=jsonb_set(input,'{participants}','[]'::jsonb) WHERE case_id=${c.id}`;
  assert.equal((await createOrder(legacy,c.id,{kind:'base',idempotencyKey:randomUUID()})).amountCents,2990);
  await patchCase(legacy,c.id,{input});assert.equal((await createOrder(legacy,c.id,{kind:'base',idempotencyKey:randomUUID()})).amountCents,2990);
});
test('exceptional full refund revokes reserved inviter reward; invalid paid order becomes refundable',async()=>{
  await bindSignupReferral(revokedBuyer.id,(await referralSummary(other.id)).code);const {c,o}=await order(revokedBuyer);await confirmPayment(admin,o.id,{reference:randomUUID()});await delivered(c.id);
  const rewardOrder=await order(other);assert.equal(rewardOrder.o.amountCents,2392);
  await db`UPDATE orders SET status='refundPending',refund_requested_cents=amount_cents WHERE id=${o.id}`;
  await confirmRefund(admin,o.id,randomUUID());assert.equal((await referralSummary(other.id)).availableCoupons,0);
  const late=await confirmPayment(admin,rewardOrder.o.id,{reference:randomUUID()});assert.equal(late.status,'refundPending');assert.equal(late.refundRequestedCents,2392);
  await deleteCase(other,rewardOrder.c.id,true);
});
