import test from 'node:test';
import assert from 'node:assert/strict';
import {shouldRetryTask} from '../src/server/task-retry';
test('only unused known startup failures can retry; supplier and uncertain attempts never restart',()=>{
 for(const code of ['interpretation_timeout','interpretation_stalled','workflow_error_loop','model_stream_incomplete','model_connection_failed','worker_lease_expired','unknown','supplier_http_408','supplier_http_429','supplier_http_502','supplier_http_503'])assert.equal(shouldRetryTask(code,1,{requests:0,toolCalls:0}),false,code);
 for(const code of ['opencode_unavailable','opencode_start_timeout','session_creation_failed']){
  assert.equal(shouldRetryTask(code,1,{requests:0,toolCalls:0}),true);
  assert.equal(shouldRetryTask(code,2,{requests:0,toolCalls:0}),true);
  assert.equal(shouldRetryTask(code,3,{requests:0,toolCalls:0}),false);
  assert.equal(shouldRetryTask(code,1,{requests:1,toolCalls:0}),false);
  assert.equal(shouldRetryTask(code,1,{requests:0,toolCalls:1}),false);
  assert.equal(shouldRetryTask(code,1),false);
 }
});
