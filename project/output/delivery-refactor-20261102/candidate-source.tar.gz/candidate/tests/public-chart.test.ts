import test from "node:test";
import assert from "node:assert/strict";
import {chartRateIdentity} from "../src/server/public-chart";
test("匿名排盘不信任 XFF；Cloudflare IPv6 同网段共享限额且地址不明文存储",()=>{
  const before=process.env.NODE_ENV, secret=process.env.BETTER_AUTH_SECRET;
  Object.assign(process.env,{NODE_ENV:"production",BETTER_AUTH_SECRET:"test-only-secret"});
  try {
    const request=(headers:Record<string,string>)=>new Request("https://example.invalid/api/chart",{headers});
    const a=chartRateIdentity(request({"cf-connecting-ip":"2001:db8:abcd:1234::1"}));
    assert.equal(a,chartRateIdentity(request({"cf-connecting-ip":"2001:0db8:abcd:1234:0:0:0:2"})));
    assert.notEqual(a,chartRateIdentity(request({"cf-connecting-ip":"2001:db8:abcd:1235::1"})));
    assert.equal(a.length,64);
    assert.equal(chartRateIdentity(request({"x-forwarded-for":"1.2.3.4"})),chartRateIdentity(request({"x-forwarded-for":"9.8.7.6"})));
    assert.equal(chartRateIdentity(request({"cf-connecting-ip":"bad"})),chartRateIdentity(request({})));
  } finally {
    if(before===undefined)delete (process.env as Record<string,string|undefined>).NODE_ENV;else Object.assign(process.env,{NODE_ENV:before});
    if(secret===undefined)delete process.env.BETTER_AUTH_SECRET;else process.env.BETTER_AUTH_SECRET=secret;
  }
});
