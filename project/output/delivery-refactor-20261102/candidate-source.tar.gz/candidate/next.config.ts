import type { NextConfig } from "next";
const config: NextConfig = {
  output: "standalone",
  poweredByHeader: false,
  serverExternalPackages: ["pg-boss", "postgres", "nodemailer"],
  async rewrites() {
    if(process.env.WENHENG_PUBLIC_UI_ENABLED==='false')return [];
    const routes:Record<string,string>={'/':'','/cases':'cases','/wallet':'wallet','/chart':'chart','/assistance':'assistance','/help':'help','/guide':'help','/terms':'terms','/privacy':'privacy','/account':'account','/account/settings':'account','/practitioner':'practitioner','/admin':'admin','/payments':'payments','/examples':'examples','/cases/:id':'cases/:id','/examples/:slug':'examples/:slug'};
    return {beforeFiles:Object.entries(routes).map(([source,route])=>({source,destination:'/site-workspace'+(route?'/'+route:'')}))};
  },
  async headers() {
    return [{ source: "/:path*", headers: [
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
      { key: "X-Frame-Options", value: "DENY" }
    ] }, { source: "/api/:path*", headers: [{ key: "Cache-Control", value: "no-store, private" }] }];
  }
};
export default config;
