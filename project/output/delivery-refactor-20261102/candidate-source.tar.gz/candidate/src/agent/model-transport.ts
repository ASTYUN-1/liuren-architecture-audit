import {Agent} from "undici";
// A dedicated dispatcher, never a global mutation. The caller's task signal
// supplies the deadline; Undici's default five-minute headers/body limits do not.
let dispatcher:Agent|undefined;
export function modelFetch(url:string,init:RequestInit){
 dispatcher??=new Agent({headersTimeout:0,bodyTimeout:0,connect:{timeout:20_000}});
 return fetch(url,{...init,dispatcher} as RequestInit&{dispatcher:Agent});
}
export async function closeModelTransport(){const current=dispatcher;dispatcher=undefined;await current?.close();}
