import { spawnSync,spawn } from "node:child_process";
import { resolve } from "node:path";

// Only a fixed, hash-checked local program reads immutable release indexes.
// This grants no shell or filesystem capability to the analysis model.
export function frozenRetrieval(root:string, request:{operation:"cases"|"experience";query?:string;category?:string;fields?:Record<string,string>;limit?:number;excludeSources?:string[]}) {
  const limit=request.limit??8;
  if(!Number.isInteger(limit)||limit<1||limit>20||request.excludeSources&&(!Array.isArray(request.excludeSources)||request.excludeSources.length>20||request.excludeSources.some(x=>typeof x!=="string"||!x.trim()||x.length>300)))throw new Error("invalid_retrieval_options");
  const child=spawnSync(process.platform==="win32"?"python":"/usr/bin/python3",
    ["-B",resolve(root,"tools/website-retrieval.py")],{
      cwd:root,input:JSON.stringify({...request,limit}),encoding:"utf8",timeout:10000,maxBuffer:1024*1024,windowsHide:true,
      env:{NODE_ENV:process.env.NODE_ENV,PATH:process.env.PATH??"",SystemRoot:process.env.SystemRoot??"",PYTHONIOENCODING:"utf-8",PYTHONNOUSERSITE:"1",PYTHONDONTWRITEBYTECODE:"1"},
    });
  if(child.error||child.status!==0)throw new Error("frozen_retrieval_failed");
  const result=JSON.parse(child.stdout) as {results:any[];[key:string]:any};
  if(!Array.isArray(result.results)||result.results.length>limit)throw new Error("frozen_retrieval_invalid");
  return result;
}


// Production MCP uses a separate child per request. Cancelling one task kills
// only its own Python child; no synchronous filesystem/index work blocks peers.
export function frozenRetrievalAsync(root:string,request:Parameters<typeof frozenRetrieval>[1],signal?:AbortSignal):Promise<ReturnType<typeof frozenRetrieval>>{
 const limit=request.limit??8;
 if(!Number.isInteger(limit)||limit<1||limit>20||request.excludeSources&&(!Array.isArray(request.excludeSources)||request.excludeSources.length>20||request.excludeSources.some(x=>typeof x!=="string"||!x.trim()||x.length>300)))return Promise.reject(new Error("invalid_retrieval_options"));
 if(signal?.aborted)return Promise.reject(new Error("frozen_retrieval_cancelled"));
 return new Promise((resolveResult,reject)=>{
  const child=spawn(process.platform==="win32"?"python":"/usr/bin/python3",["-B",resolve(root,"tools/website-retrieval.py")],{cwd:root,windowsHide:true,stdio:["pipe","pipe","pipe"],env:{NODE_ENV:process.env.NODE_ENV,PATH:process.env.PATH??"",SystemRoot:process.env.SystemRoot??"",PYTHONIOENCODING:"utf-8",PYTHONNOUSERSITE:"1",PYTHONDONTWRITEBYTECODE:"1"}});
  let settled=false,size=0;const chunks:Buffer[]=[];
  const finish=(error?:Error,result?:ReturnType<typeof frozenRetrieval>)=>{if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener("abort",abort);if(error){child.kill();reject(error);}else resolveResult(result!);};
  const abort=()=>finish(new Error("frozen_retrieval_cancelled"));
  const timer=setTimeout(()=>finish(new Error("frozen_retrieval_failed")),10000);
  signal?.addEventListener("abort",abort,{once:true});if(signal?.aborted){abort();return;}
  child.stdout.on("data",(chunk:Buffer)=>{size+=chunk.length;if(size>1024*1024){finish(new Error("frozen_retrieval_invalid"));return;}chunks.push(chunk);});
  child.stderr.resume();child.on("error",()=>finish(new Error("frozen_retrieval_failed")));
  child.on("close",code=>{if(settled)return;if(code!==0){finish(new Error("frozen_retrieval_failed"));return;}try{const result=JSON.parse(Buffer.concat(chunks).toString("utf8"));if(!Array.isArray(result.results)||result.results.length>limit)throw new Error();finish(undefined,result);}catch{finish(new Error("frozen_retrieval_invalid"));}});
  child.stdin.on("error",()=>finish(new Error("frozen_retrieval_failed")));child.stdin.end(JSON.stringify({...request,limit}));
 });
}
