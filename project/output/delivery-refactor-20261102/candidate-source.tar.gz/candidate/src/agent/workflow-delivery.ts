// OpenCode MCP truncates output above 50 KiB / 2,000 lines. Responses use
// single-line JSON, with 10 KiB of headroom for MCP envelopes and metadata.
export const TOOL_RESPONSE_MAX_BYTES=40*1024;
export function assertReportIntegrity(text:string){
  if(Buffer.byteLength(text)>256*1024||/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(text))throw new Error("report_encoding_incomplete");
  if(/<\/?(?:truncated|tool_output_truncated)\b|\[(?:output|response|content) truncated\]|\[正文[已被]*截断\]/i.test(text))throw new Error("report_content_truncated");
}
