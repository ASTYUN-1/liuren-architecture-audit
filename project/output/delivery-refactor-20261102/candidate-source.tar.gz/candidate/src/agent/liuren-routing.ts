import {existsSync, readFileSync,lstatSync} from "node:fs";
import {resolve, relative, isAbsolute, sep} from "node:path";
import {createHash} from "node:crypto";
import {isDeepStrictEqual} from "node:util";

export interface LiurenRuntimeManifest {
  schemaVersion:2|3;mode:"structural"|"enhanced";version:string;
  files:Record<string,string>;modules:Record<string,{file:string;id:string;requires:string[];when:string}>;
  required:string[];routes:Record<string,string[]>;legacyAliases:Record<string,string[]>;entryId:string;
  release?:string;localMethodVersion?:string;readingRoute?:{domainStage:number;domains:string[];stages:{id:number;title:string;required:string[]}[];conditional:Record<string,{stage:number;trigger:string;selectWith:string}>};
}
const digest=(raw:Buffer)=>createHash("sha256").update(raw).digest("hex");
export function loadLiurenRuntime(root:string,boundFiles?:Record<string,string>):LiurenRuntimeManifest {
  const path=resolve(root,"liuren-runtime.json");
  if(!existsSync(path))throw new Error("liuren_runtime_missing");
  const raw=readFileSync(path),m=JSON.parse(raw.toString("utf8")) as LiurenRuntimeManifest;
  if(boundFiles&&boundFiles["liuren-runtime.json"]!==digest(raw))throw new Error("liuren_runtime_not_manifest_bound");
  if(![2,3].includes(m.schemaVersion)||!m.version||!m.files||!m.modules||!Array.isArray(m.required)||!m.routes||!m.legacyAliases||m.entryId!=="skill:daliuren/SKILL.md")throw new Error("liuren_runtime_invalid");
  const canonical=JSON.stringify({files:Object.fromEntries(Object.entries(m.files).sort(([a],[b])=>a<b?-1:a>b?1:0)),mode:m.mode});
  if(digest(Buffer.from(canonical))!==m.version)throw new Error("liuren_runtime_version_mismatch");
  for(const [name,hash] of Object.entries(m.files)){
    const p=resolve(root,name),rel=relative(resolve(root),p);
    if(name.includes("\\")||name.includes(":")||name.split("/").some(x=>!x||x===".."||x===".")||isAbsolute(rel)||rel.startsWith(".."+sep))throw new Error("liuren_runtime_path_invalid");
    let current=resolve(root);for(const part of name.split("/")){current=resolve(current,part);if(lstatSync(current).isSymbolicLink())throw new Error("liuren_runtime_symlink_forbidden");}
    if(!/^[a-f0-9]{64}$/.test(hash)||digest(readFileSync(p))!==hash||boundFiles&&boundFiles[name]!==hash)throw new Error("liuren_runtime_hash_mismatch:"+name);
  }
  for(const [key,v] of Object.entries(m.modules)){
    if(v.id!==`skill:daliuren/refs/runtime/${v.file}`||!m.files[`.opencode/skills/daliuren/refs/runtime/${v.file}`])throw new Error("liuren_module_binding:"+key);
  }
  const source=JSON.parse(readFileSync(resolve(root,".opencode/skills/daliuren/refs/runtime/manifest.json"),"utf8"));
  if(m.schemaVersion===3){
    const route=JSON.parse(readFileSync(resolve(root,".opencode/skills/daliuren/refs/runtime/reading-route.json"),"utf8"));
    const modules=Object.fromEntries(Object.entries(source.modules).map(([key,v])=>{const x=v as {file:string;requires:string[];trigger:string};return [key,{file:x.file,id:`skill:daliuren/refs/runtime/${x.file}`,requires:x.requires,when:x.trigger}];}));
    const routes=Object.fromEntries(route.domains.map((key:string)=>[key,[key]]));
    if(source.schemaVersion!==4||m.release!==source.release||m.localMethodVersion!==source.version||!isDeepStrictEqual(m.modules,modules)||!isDeepStrictEqual(m.readingRoute,route)||!isDeepStrictEqual(m.required,route.stages.flatMap((s:any)=>s.required))||!isDeepStrictEqual(m.routes,routes)||!isDeepStrictEqual(source.required,m.required)||!isDeepStrictEqual(source.conditional,Object.fromEntries(Object.entries(route.conditional).map(([k,v])=>[k,(v as any).trigger]))))throw new Error("liuren_modular_metadata_binding");
    for(const [name,hash] of Object.entries(source.files))if(m.files[`.opencode/skills/daliuren/refs/runtime/${name}`]!==hash)throw new Error("liuren_local_source_binding");
    if(route.stages.map((s:any)=>s.id).join(",")!=="1,2,3,4,5,6,7,8,9,10,11"||route.conditional.nianming?.stage!==1)throw new Error("liuren_modular_stage_binding");
    requiredModules(m,Object.keys(m.modules));return m;
  }
  const expected=Object.fromEntries(Object.entries(source.modules).map(([key,v])=>[key,{...(v as object),id:`skill:daliuren/refs/runtime/${(v as {file:string}).file}`} ]));
  if(!isDeepStrictEqual(m.modules,expected)||!isDeepStrictEqual(m.routes,source.routes)||!isDeepStrictEqual(m.legacyAliases,source.legacyAliases)||!isDeepStrictEqual(m.required,["core","evidence","shensha"]))throw new Error("liuren_runtime_metadata_binding");
  requiredModules(m,Object.keys(m.modules));
  for(const keys of [...Object.values(m.routes),...Object.values(m.legacyAliases)])requiredModules(m,keys);
  return m;
}
export function moduleReadPlan(m:LiurenRuntimeManifest,domains:string[]=[],conditions:string[]=[],mechanisms:string[]=[]){
  const requested=[...domains.flatMap(key=>{if(!m.routes[key])throw new Error("unknown_liuren_domain");return m.routes[key];}),...conditions,...mechanisms];
  if(!m.readingRoute)return requiredModules(m,requested).map(key=>({key,id:m.modules[key].id,stage:null}));
  const selected=new Set([...conditions,...mechanisms]),seen=new Set<string>(),result:{key:string;id:string;stage:number}[]=[];
  const add=(key:string,stage:number)=>{if(seen.has(key))return;const mod=m.modules[key];if(!mod)throw new Error("unknown_liuren_module:"+key);for(const dep of mod.requires)add(dep,stage);seen.add(key);result.push({key,id:mod.id,stage});};
  for(const phase of m.readingRoute.stages){
    for(const [key,item] of Object.entries(m.readingRoute.conditional))if(selected.has(key)&&item.stage===phase.id)add(key,phase.id);
    for(const key of phase.required)add(key,phase.id);
    if(phase.id===m.readingRoute.domainStage)for(const key of domains)add(key,phase.id);
  }
  for(const key of requested)if(!seen.has(key))add(key,11);
  return result;
}
export function requiredModules(m:LiurenRuntimeManifest,requested:string[]=[]){
  const seen=new Set<string>(),visiting=new Set<string>();
  const visit=(key:string)=>{
    if(visiting.has(key))throw new Error("liuren_module_cycle");
    if(seen.has(key))return;
    const v=m.modules[key];if(!v)throw new Error("unknown_liuren_module:"+key);
    visiting.add(key);for(const dep of v.requires)visit(dep);visiting.delete(key);seen.add(key);
  };
  for(const key of [...m.required,...requested])visit(key);
  return [...seen];
}
