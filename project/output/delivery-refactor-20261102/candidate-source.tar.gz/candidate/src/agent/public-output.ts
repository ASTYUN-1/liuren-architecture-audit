import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { PROJECT_ROOT } from "../engine/liuren";

export interface PublicOutputPolicy { text: string; version: string; hash: string }
const policyName = "wenheng-public-output";
const supportedVersion = "1.0.0";

// Validate the independent policy before any paid call. In liuren-v3 the model
// receives it only through the gated final-output tool, never the initial prompt.
export function loadPublicOutputPolicy(root = PROJECT_ROOT): PublicOutputPolicy {
  let text: string;
  try { text = readFileSync(/* turbopackIgnore: true */ join(root, "website-skills", policyName, "SKILL.md"), "utf8").replace(/^\uFEFF/, ""); }
  catch { throw new Error("public_output_policy_not_configured"); }
  const header = text.match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);
  const name = header?.[1].match(/^name: ([a-z0-9-]+)\r?$/m)?.[1];
  const version = header?.[1].match(/^metadata:\r?\n  version: (["']?)(\d+\.\d+\.\d+)\1\r?$/m)?.[2];
  if (!header || name !== policyName || version !== supportedVersion || text.includes("\0") || !text.slice(header[0].length).trim()
    || (header[1].match(/^name:/gm)?.length ?? 0) !== 1 || (header[1].match(/^metadata:/gm)?.length ?? 0) !== 1) {
    throw new Error("public_output_policy_invalid");
  }
  return { text, version, hash: createHash("sha256").update(text).digest("hex") };
}

export function buildPublicMainPrompt(base: string, policy: PublicOutputPolicy): string {
  return `${base}\n\n以下是仅适用于网站最终公开字段的完整输出约束。它优先于旧技能中的展示、案例命名和对客引用格式要求；不得降低内部分析、查证、技能阅读、事实核对或 citations 要求。\n<website_public_output_policy>\n${policy.text}\n</website_public_output_policy>`;
}

export function publicOutputPolicyPage(policy:PublicOutputPolicy,page=1,expectedHash?:string){
  const pages:string[]=[];let chunk="",bytes=0;
  for(const char of policy.text){const count=Buffer.byteLength(char);if(bytes+count>8000){pages.push(chunk);chunk="";bytes=0;}chunk+=char;bytes+=count;}
  if(chunk)pages.push(chunk);
  if(!Number.isInteger(page)||page<1||page>pages.length)throw new Error("invalid_public_output_page");
  if((page>1&&!expectedHash)||(expectedHash!==undefined&&expectedHash!==policy.hash))throw new Error("public_output_hash_mismatch");
  const text=pages[page-1];
  return {id:"website:wenheng-public-output",version:policy.version,deliveryHash:policy.hash,page,
    pageCount:pages.length,pageHash:createHash("sha256").update(text).digest("hex"),text};
}

// Only high-confidence mechanical identifiers are rejected here. This is not a
// semantic classifier for techniques, paraphrases, personal data or prompt leaks.
// Reject the whole submission; never delete words and accidentally alter meaning.
const privateMarkers: RegExp[] = [
  /<script\b|reasoning_content|DEEPSEEK_API_KEY|-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----/i,
  /\b(?:wenheng_)?(?:read_case|calculate_chart|list_knowledge|resolve_knowledge_link|read_knowledge_batch|read_knowledge|search_cases|search_experience|search_knowledge|register_questions|record_workflow|reopen_analysis|record_judgment|record_stage|prepare_public_output|submit_report|submit_clarification|check_readiness|repair_report)\b/i,
  /\bskill:[a-z0-9][a-z0-9_./-]*|\breference:[a-f0-9]{20}(?::[1-9][0-9]*)?|\bcase:[a-z0-9_-]+|\bcase[\s_#-]*\d+\b/i,
  /(?:案例编号|案例ID)\s*[:：#]?\s*[a-z0-9_-]+/i,
  /案例项目库|(?:\.opencode|website-skills)[\\/]|\bSKILL\.md\b|\bwenheng-public-output\b/i,
  /(?:^|[\s("'`>：，、；])(?:[a-z]:[\\/]|\\\\[^\\\s]+\\)|file:\/\//i,
  /(?:^|[\s("'`>：，、；])\/(?:opt|home|srv|etc|var|tmp|Users|workspace|mnt)\//,
  /(?:案例项目库|经验日志|books)[\\/][^\s]+|(?:^|[\s("'`>：，、；])(?:web\/src|\.\/|\.\.\/)[^\s]+/i,
  /\b(?:sanbu-duanke|leishen-keti|kongwang-bianzhi|shensha-panduan|youlu-lilun|keti-qishi|jixiong-tiaozhi|yingqi-panduan|liuren-cases|liuren-v[23])\b/i,
  /["'](?:internal_evidence|completedStages|chartHash|reasoning_content)["']\s*:/,
];

export function assertPublicText(field: string, text: string): void {
  if (privateMarkers.some(pattern => pattern.test(text))) {
    // Only the controlled field name is returned to the model. Never echo the
    // matched text, internal source, path, key or submitted customer content.
    throw new Error(`public_output_rejected:${field}`);
  }
}

type Locale = "zh" | "en";
function plainEngineWarning(warning: string, locale: Locale): string {
  const english = locale === "en";
  // Participant roles are free-form user data. In these two fixed engine
  // templates only, replace a role that resembles an internal identifier with
  // a neutral label; keep the actual warning, input and chart unchanged.
  const publicRole = (role: string) => privateMarkers.some(pattern => pattern.test(role)) ? (english ? "this person" : "该人物") : role;
  if (warning === "纯四柱未提供真实日期，不生成节气、年龄、行年或公历应期。") return english
    ? "The calendar date for this chart is missing. Solar-term checks, age calculations and personal-year assessments are omitted, and no specific calendar date is predicted."
    : "本次缺少对应的真实日期，无法核对节气或据此计算年龄；与个人年份有关的判断已省略，也不提供具体公历日期的时间预测。";
  if (warning === "四柱真实日期已核对；未提供精确时刻，不推测交节时分。") return english
    ? "The supplied calendar date has been checked. Without an exact time, the precise solar-term transition time cannot be determined."
    : "提供的日期已核对；由于没有准确时刻，无法确认节气切换的具体时分，相关时间判断保留不确定性。";
  if (warning === "人物资料不足的年命、行年判断省略；已知本命保留。") return english
    ? "Some personal details are missing, so personal-year assessments that depend on them are omitted. Details already explicitly provided are still used."
    : "人物资料尚不完整，依赖缺失资料的个人年份判断已省略；已明确提供的信息仍保留使用。";
  const boundary = warning.match(/^(.+)出生日期处于立春换年日，缺出生时刻，年命及行年起算需确认。$/);
  if (boundary) return english
    ? `${publicRole(boundary[1])}'s birthday falls on the Start of Spring, but the birth time is missing. The basis for personal-year assessments still needs confirmation.`
    : `${publicRole(boundary[1])}的生日在立春当天，但缺少出生时刻；用于个人年份判断的基础信息仍需确认，相关判断不能视为已确认。`;
  const yearOnly = warning.match(/^(.+)仅提供出生年份，本命按该年立春后年柱暂取；立春前出生需补充日期确认。$/);
  if (yearOnly) return english
    ? `Only the birth year is available for ${publicRole(yearOnly[1])}. Related personal details provisionally assume birth after the Start of Spring that year; a birth date is needed to confirm a birth before that boundary.`
    : `目前只有${publicRole(yearOnly[1])}的出生年份，相关个人信息暂按当年立春之后估算；若出生在立春之前，需要补充出生日期才能确认。`;
  return warning;
}

export function preparePublicWarnings(engineWarnings: string[], submittedWarnings: string[], locale: Locale): string[] {
  const warnings = [...engineWarnings.map(warning => plainEngineWarning(warning, locale)), ...submittedWarnings];
  warnings.forEach((warning, index) => assertPublicText(`warnings[${index}]`, warning));
  return warnings;
}

export function validatePublicReport(report: { title: string; summary: string; content: string; warnings: string[] }, engineWarnings: string[], locale: Locale): string[] {
  for (const field of ["title", "summary", "content"] as const) assertPublicText(field, report[field]);
  return preparePublicWarnings(engineWarnings, report.warnings, locale);
}
