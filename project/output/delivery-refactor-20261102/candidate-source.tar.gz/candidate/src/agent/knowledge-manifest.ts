import {existsSync,readFileSync,realpathSync,lstatSync} from "node:fs";
import {resolve,relative,isAbsolute,sep} from "node:path";
import {createHash} from "node:crypto";
import {z} from "zod";

const hash=z.string().regex(/^[a-f0-9]{64}$/);
const strings=z.record(z.string(),z.string());
const entry=z.object({id:z.string().regex(/^(case|reference):[a-f0-9]{20}(:[1-9][0-9]*)?$/),file:z.string(),source:z.string(),hash,kind:z.enum(["case","experience","reference"]),title:z.string(),meta:strings,metadataOrigins:strings.optional(),metadataConflicts:z.array(z.object({field:z.string(),source:z.string(),index:z.string()})).optional(),provenance:z.object({sourceHash:hash,encoding:z.enum(["utf-8","utf-8-sig","gb18030"]),indexSource:z.string().optional(),indexHash:hash.optional(),indexed:z.boolean().optional(),feedbackRaw:z.string().optional(),indexFeedbackRaw:z.string().optional(),feedback:z.string(),decodedHash:hash.optional(),section:z.number().int().positive().optional(),sections:z.number().int().positive().optional(),decodedByteStart:z.number().int().nonnegative().optional(),decodedByteEnd:z.number().int().nonnegative().optional(),lineStart:z.number().int().positive().optional(),lineEnd:z.number().int().positive().optional()})});
export type ManifestEntry=z.infer<typeof entry>;
export function loadKnowledgeManifest(root:string){
 const path=resolve(root,"knowledge-manifest.json");if(!existsSync(path))return null;
 const data=readFileSync(path),m=z.object({schemaVersion:z.literal(1),policyVersion:z.string(),files:z.record(z.string(),hash),documents:z.array(entry),retrieval:z.object({schema:z.literal("fine-grained-20261019")}).optional()}).parse(JSON.parse(data.toString("utf8")));
 const base=realpathSync(root),checked=new Map<string,Buffer>();
 function file(name:string){
  if(isAbsolute(name)||name.includes("\\")||name.split("/").some(p=>!p||p==="."||p===".."))throw new Error("invalid_knowledge_manifest_path");
  const path=resolve(base,name),rel=relative(base,path);if(rel.startsWith(".."+sep)||isAbsolute(rel))throw new Error("invalid_knowledge_manifest_path");
  let current=base;for(const p of name.split("/")){current=resolve(current,p);if(lstatSync(current).isSymbolicLink())throw new Error("knowledge_symlink_forbidden");}
  return path;
 }
 for(const [name,expected] of Object.entries(m.files)){
  const raw=readFileSync(file(name));if(createHash("sha256").update(raw).digest("hex")!==expected)throw new Error("knowledge_manifest_hash_mismatch:"+name);checked.set(name,raw);
 }
 const ids=new Set<string>();
 const documents=m.documents.map(d=>{
  if(ids.has(d.id)||!checked.has(d.file)||m.files[d.file]!==d.hash||m.files[d.source]!==d.provenance.sourceHash||(d.provenance.indexSource&&m.files[d.provenance.indexSource]!==d.provenance.indexHash))throw new Error("knowledge_manifest_binding_mismatch");
  if((d.kind==="reference")!==d.id.startsWith("reference:"))throw new Error("knowledge_manifest_kind_mismatch");
  ids.add(d.id);const text=new TextDecoder("utf-8",{fatal:true}).decode(checked.get(d.file)!);return {...d,text};
 });
 if(m.retrieval)for(const name of ["tools/website-retrieval.py","tools/case_retrieval.py","tools/experience_retrieval.py","_retrieval/case-index.json","_retrieval/experience-index.json","_retrieval/bindings.json"]){if(!checked.has(name))throw new Error("knowledge_retrieval_binding_missing");}
 return {hash:createHash("sha256").update(data).digest("hex"),documents,retrieval:m.retrieval,files:m.files};
}
