// Limits apply to real execution, not page polling or the worker lease heartbeat.
export const TASK_MAX_MS=30*60_000;
export const TASK_IDLE_MS=6*60_000;
export const QUEUE_EXPIRE_SECONDS=35*60;
export function workerConcurrency(value=process.env.WENHENG_WORKER_CONCURRENCY){
 if(value===undefined||value==='')return 2;
 const n=Number(value);if(!Number.isInteger(n)||n<1||n>4)throw new Error('invalid_worker_concurrency');return n;
}
export class ExecutionControl {
 private started:number;private lastProgress:number;private repeatedErrors=0;private lastError='';
 terminalError?:'interpretation_timeout'|'workflow_error_loop';
 constructor(private now=()=>Date.now()){this.started=this.lastProgress=now();}
 progress(){this.lastProgress=this.now();}
 toolResult(ok:boolean,fingerprint:string){
  if(ok){this.repeatedErrors=0;this.lastError='';this.progress();return;}
  this.repeatedErrors=this.lastError===fingerprint?this.repeatedErrors+1:1;this.lastError=fingerprint;
  if(this.repeatedErrors>=5)this.terminalError='workflow_error_loop';
 }
 // Stagnation is diagnostic only: a long silent reasoning request may be valid.
 snapshot(){const now=this.now();return {elapsedMs:Math.max(0,now-this.started),idleMs:Math.max(0,now-this.lastProgress),stalled:now-this.lastProgress>=TASK_IDLE_MS};}
 check(){if(this.terminalError)return this.terminalError;if(this.now()-this.started>=TASK_MAX_MS)return this.terminalError='interpretation_timeout';}
}
