// Counts remain observable; actual execution is bounded by TASK_MAX_MS.
// Undefined means no fixed call-count cap. Never serialize Infinity as a limit.
export const TASK_TOOL_LIMIT: number | undefined = undefined;
export const TASK_MODEL_REQUEST_LIMIT: number | undefined = undefined;
