import {randomUUID} from "node:crypto";
import type {IncomingMessage,ServerResponse} from "node:http";
import {TASK_MODEL_REQUEST_LIMIT} from "./limits";
import type {RuntimeTelemetry} from "./runtime-telemetry";
import {modelFetch} from "./model-transport";
export const MODEL_MAX_OUTPUT_TOKENS=32768;
export const MODEL_REQUEST_MAX_BYTES=16*1024*1024;
export const INTERNAL_JSON_REQUEST_MAX_BYTES=2_000_000;
export interface ModelUsage {requests:number;inputTokens:number;outputTokens:number;cachedInputTokens:number;costCny:number;reservedCny:number;failures:number;model:string;supplier:string}
export interface UsageEvent {requestId:string;responseId:string|null;input:number;output:number;cached:number;costNano:string;verified:boolean;billable:boolean}
export function safeUsage(u:any){const input=u?.prompt_tokens,output=u?.completion_tokens,cached=u?.prompt_cache_hit_tokens??u?.prompt_tokens_details?.cached_tokens??0;return u&&[input,output,cached].every(v=>Number.isSafeInteger(v)&&v>=0)&&cached<=input?{input,output,cached}:undefined;}
export class ModelUsageTracker {
 usage:ModelUsage={requests:0,inputTokens:0,outputTokens:0,cachedInputTokens:0,costCny:0,reservedCny:0,failures:0,model:"deepseek-flash",supplier:"DeepSeek official"};
 terminalError?:string;
 constructor(readonly maxRequests:number|undefined=TASK_MODEL_REQUEST_LIMIT,readonly onUsage?:(event:UsageEvent)=>Promise<void>){}
 async record(requestId:string,u:any,responseId:unknown,billable:boolean){const v=safeUsage(u);await this.onUsage?.({requestId,responseId:typeof responseId==="string"?responseId.slice(0,200):null,input:v?.input??0,output:v?.output??0,cached:v?.cached??0,costNano:v?(BigInt(v.input-v.cached)*2000n+BigInt(v.cached)*40n+BigInt(v.output)*8000n).toString():"0",verified:!!v,billable:!!v&&billable});}
 beginRequest(){if(this.terminalError)throw new Error(this.terminalError);if(this.maxRequests!==undefined&&this.usage.requests>=this.maxRequests)throw new Error("model_request_limit");this.usage.requests++;}
 settle(u?:any){const v=safeUsage(u);if(!v){this.usage.failures++;return;}this.usage.inputTokens+=v.input;this.usage.outputTokens+=v.output;this.usage.cachedInputTokens+=v.cached;this.usage.costCny+=((v.input-v.cached)*2+v.cached*.04+v.output*8)/1e6;}
 // Only the runtime's explicit same-session output-length continuation may reset.
 resumeIncompleteOutput(){if(this.terminalError!=="model_output_incomplete")throw new Error("model_resume_not_allowed");this.terminalError=undefined;}
}
export async function readJson(req:IncomingMessage,limit=INTERNAL_JSON_REQUEST_MAX_BYTES,errorCode="request_too_large"){let size=0;const chunks:Buffer[]=[];for await(const chunk of req.iterator({destroyOnReturn:false})){const b=Buffer.from(chunk);size+=b.length;if(size>limit){req.resume();throw new Error(errorCode);}chunks.push(b);}return JSON.parse(Buffer.concat(chunks).toString("utf8"));}
const allowedFinish=new Set(["stop","tool_calls","function_call"]);
const safeFailure=(e:unknown,signal:AbortSignal)=>signal.aborted?"interpretation_cancelled":e instanceof Error&&/^(model_[a-z_]+|supplier_http_\d{3}|invalid_model_request|request_too_large|supplier_usage_invalid|client_disconnected)$/.test(e.message)?e.message:"model_connection_failed";
async function writeChunk(res:ServerResponse,value:string,signal:AbortSignal){signal.throwIfAborted();if(res.destroyed)throw new Error("client_disconnected");if(res.write(value))return;await new Promise<void>((ok,bad)=>{const clean=()=>{res.off("drain",drain);res.off("close",close);signal.removeEventListener("abort",abort);};const drain=()=>{clean();ok();},close=()=>{clean();bad(new Error("client_disconnected"));},abort=()=>{clean();bad(signal.reason);};res.once("drain",drain);res.once("close",close);signal.addEventListener("abort",abort,{once:true});if(signal.aborted)abort();});}
export async function proxyModel(req:IncomingMessage,res:ServerResponse,key:string,budget:ModelUsageTracker,signal:AbortSignal,onProgress?:(stage:string)=>Promise<void>|void,telemetry?:RuntimeTelemetry){
 const requestId=randomUUID(),start=Date.now(),disconnect=new AbortController(),combined=AbortSignal.any([signal,disconnect.signal]);
 let started=false,settled=false,recorded=false,usage:any,responseId:unknown,finish:string|undefined,done=false,firstDeltaMs:number|undefined,upstream:Response|undefined,reader:ReadableStreamDefaultReader<Uint8Array>|undefined,heartbeat:ReturnType<typeof setInterval>|undefined;
 const toolArguments=new Map<number,{id:string;name:string;arguments:string}>();
 const toolFrames:any[]=[];let toolFrameBytes=0;
 const onClose=()=>{if(!res.writableEnded)disconnect.abort();};res.once("close",onClose);
 const forward=async(frame:any)=>{if(!res.headersSent)res.writeHead(200,{"Content-Type":"text/event-stream","Cache-Control":"no-store","X-Accel-Buffering":"no"});await writeChunk(res,`data: ${JSON.stringify(frame)}\n\n`,combined);};
 const consume=async(frame:any)=>{
  if(frame?.error)throw new Error("model_upstream_error");
  if(!frame||!Array.isArray(frame.choices))throw new Error("model_stream_invalid");
  responseId=frame.id??responseId;
  if(frame.usage!==undefined&&frame.usage!==null){if(!safeUsage(frame.usage))throw new Error("supplier_usage_invalid");usage=frame.usage;}
  for(const choice of frame.choices){
   if(choice.index!==0)throw new Error("model_stream_invalid");
   const delta=choice.delta??{};
   if(finish!==undefined&&Object.keys(delta).length)throw new Error("model_stream_invalid");
   if(delta.tool_calls!==undefined){if(!Array.isArray(delta.tool_calls))throw new Error("model_stream_invalid");for(const t of delta.tool_calls){if(!Number.isInteger(t.index)||t.index<0)throw new Error("model_stream_invalid");const prior=toolArguments.get(t.index)??{id:"",name:"",arguments:""};for(const field of ["id","name","arguments"] as const){const fragment=field==="id"?t.id:t.function?.[field];if(fragment!==undefined){if(typeof fragment!=="string")throw new Error("model_stream_invalid");prior[field]+=fragment;}}if(prior.arguments.length>2_000_000||toolArguments.size>10000)throw new Error("model_stream_frame_too_large");toolArguments.set(t.index,prior);}}
   const content=typeof delta.content==="string"&&delta.content.length>0||typeof delta.reasoning_content==="string"&&delta.reasoning_content.length>0||Array.isArray(delta.tool_calls)&&delta.tool_calls.some((t:any)=>typeof t.function?.arguments==="string"&&t.function.arguments.length>0||typeof t.function?.name==="string"&&t.function.name.length>0);
   if(content){if(firstDeltaMs===undefined){firstDeltaMs=Date.now()-start;telemetry?.emit({type:"model_first_delta",request:budget.usage.requests,firstDeltaMs});}await onProgress?.(`model_delta:${budget.usage.requests}`);}
   if(choice.finish_reason!==null&&choice.finish_reason!==undefined){if(finish!==undefined&&finish!==choice.finish_reason)throw new Error("model_stream_invalid");finish=choice.finish_reason;}
  }
  // OpenCode executes a complete tool argument delta before finish_reason. Keep
  // all tool frames until validated upstream completion, while text/reasoning
  // continue streaming. Holding only the finish frame is insufficient.
  if(frame.choices.some((c:any)=>c.finish_reason!=null))return frame;
  if(frame.choices.length===0&&frame.usage)return;
  const tools=frame.choices.filter((c:any)=>c.delta?.tool_calls?.length).map((c:any)=>({...c,delta:{tool_calls:c.delta.tool_calls}}));
  if(tools.length){const held={...frame,choices:tools};toolFrameBytes+=Buffer.byteLength(JSON.stringify(held));if(toolFrameBytes>2_000_000)throw new Error("model_stream_frame_too_large");toolFrames.push(held);}
  const visible=frame.choices.map((c:any)=>{const delta={...c.delta};delete delta.tool_calls;return {...c,delta};}).filter((c:any)=>Object.keys(c.delta).length);
  if(visible.length)await forward({...frame,choices:visible});
 };
 try{
  const body=await readJson(req,MODEL_REQUEST_MAX_BYTES,"model_request_too_large");if(body.model!=="deepseek-flash"||!Array.isArray(body.messages))throw new Error("invalid_model_request");
  body.max_tokens=MODEL_MAX_OUTPUT_TOKENS;body.stream=true;body.stream_options={include_usage:true};body.n=1;delete body.max_completion_tokens;
  body.thinking={type:"enabled"};body.reasoning_effort="high";delete body.temperature;delete body.top_p;
  combined.throwIfAborted();budget.beginRequest();started=true;telemetry?.emit({type:"model_start",request:budget.usage.requests});await onProgress?.(`model_request:${budget.usage.requests}`);
  // Keep the localhost SDK connection alive even while the supplier has not
  // emitted a delta. These comments never count as analysis progress.
  heartbeat=setInterval(()=>{if(res.destroyed||res.writableEnded||res.writableNeedDrain)return;if(!res.headersSent)res.writeHead(200,{"Content-Type":"text/event-stream","Cache-Control":"no-store","X-Accel-Buffering":"no"});res.write(": waiting-for-model\n\n");},15_000);heartbeat.unref();
  upstream=await modelFetch("https://api.deepseek.com/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${key}`},body:JSON.stringify(body),signal:combined});
  if(!upstream.ok)throw new Error(`supplier_http_${upstream.status}`);
  let terminalFrame:any;
  if((upstream.headers.get("content-type")??"").includes("text/event-stream")){
   if(!upstream.body)throw new Error("model_stream_incomplete");reader=upstream.body.getReader();const decoder=new TextDecoder();let pending="",data:string[]=[];
   const line=async(value:string)=>{if(value===""){if(!data.length)return;const raw=data.join("\n");data=[];if(raw==="[DONE]"){done=true;return;}if(done)throw new Error("model_stream_invalid");let frame;try{frame=JSON.parse(raw);}catch{throw new Error("model_stream_invalid");}const t=await consume(frame);if(t)terminalFrame=t;return;}if(value.startsWith("data:")){data.push(value.slice(5).replace(/^ /,""));if(data.reduce((n,s)=>n+s.length,0)>2_000_000)throw new Error("model_stream_frame_too_large");}};
   while(!done){combined.throwIfAborted();const part=await reader.read();pending+=part.done?decoder.decode():decoder.decode(part.value,{stream:true});if(pending.length>2_000_000)throw new Error("model_stream_frame_too_large");let match:RegExpExecArray|null;while((match=/\r\n|\n|\r(?!$)/.exec(pending))){const value=pending.slice(0,match.index);pending=pending.slice(match.index+match[0].length);await line(value);}if(part.done)break;}
  }else{
   // Compatibility for legacy JSON-only fixtures/proxies. Production still requests SSE.
   const result:any=await upstream.json();responseId=result.id;usage=result.usage;
   if(!Array.isArray(result.choices)||result.choices.length!==1||!result.choices[0]?.message)throw new Error("model_stream_invalid");
   const c=result.choices[0],m=c.message;const envelope={id:result.id,object:"chat.completion.chunk",created:result.created,model:"deepseek-flash"};
   if(c.finish_reason==="length")throw new Error("model_output_incomplete");
   await consume({...envelope,choices:[{index:0,delta:{...m,...(m.tool_calls?{tool_calls:m.tool_calls.map((t:any,index:number)=>({...t,index}))}:{})},finish_reason:null}]});
   terminalFrame=await consume({...envelope,choices:[{index:0,delta:{},finish_reason:c.finish_reason}]});done=true;
  }
  if(!done||finish===undefined)throw new Error("model_stream_incomplete");
  if(finish==="length")throw new Error("model_output_incomplete");
  if(!allowedFinish.has(finish))throw new Error("model_finish_invalid");
  if(toolArguments.size&&finish!=="tool_calls"&&finish!=="function_call")throw new Error("model_finish_invalid");
  if(finish==="tool_calls"||finish==="function_call"){if(!toolArguments.size)throw new Error("model_tool_arguments_invalid");for(const t of toolArguments.values()){if(!t.id||!t.name)throw new Error("model_tool_arguments_invalid");try{JSON.parse(t.arguments);}catch{throw new Error("model_tool_arguments_invalid");}}}
  if(!safeUsage(usage))throw new Error("supplier_usage_invalid");
  budget.settle(usage);settled=true;recorded=true;await budget.record(requestId,usage,responseId,true);
  for(const frame of toolFrames)await forward(frame);
  if(terminalFrame)await forward(terminalFrame);
  await forward({id:responseId,object:"chat.completion.chunk",model:"deepseek-flash",choices:[],usage});
  if(!res.headersSent)throw new Error("model_stream_invalid");
  await writeChunk(res,"data: [DONE]\n\n",combined);res.end();await onProgress?.(`model_completed:${budget.usage.requests}`);
  telemetry?.emit({type:"model_end",request:budget.usage.requests,durationMs:Date.now()-start,firstDeltaMs,finishReason:finish,outcome:"completed",inputTokens:safeUsage(usage)!.input,outputTokens:safeUsage(usage)!.output,cachedInputTokens:safeUsage(usage)!.cached});
 }catch(e){
  const message=safeFailure(e,combined);
  if(started){budget.terminalError=message;if(!settled){budget.settle(usage);if(safeUsage(usage))budget.usage.failures++;}if(!recorded){recorded=true;await budget.record(requestId,usage,responseId,false).catch(()=>{});}telemetry?.emit({type:"model_end",request:budget.usage.requests,durationMs:Date.now()-start,firstDeltaMs,finishReason:finish,outcome:message,...(safeUsage(usage)?{inputTokens:safeUsage(usage)!.input,outputTokens:safeUsage(usage)!.output,cachedInputTokens:safeUsage(usage)!.cached}:{})});}
  // Sticky failures reject automatic client retries before another supplier request.
  if(!res.destroyed){if(!res.headersSent){res.writeHead(400,{"Content-Type":"application/json"});res.end(JSON.stringify({error:{type:"invalid_request_error",message}}));}else{res.end(`data: ${JSON.stringify({error:{type:"invalid_request_error",message}})}\n\n`);}}
 }finally{clearInterval(heartbeat);res.off("close",onClose);disconnect.abort();await reader?.cancel().catch(()=>{});if(!reader)await upstream?.body?.cancel().catch(()=>{});}
}
