import {setTimeout as delay} from "node:timers/promises";
export interface SessionProgress {busy:boolean;assistant?:{completed?:number;error?:unknown}}
// Retain a safe error code, never provider bodies, prompts, or credentials.
export function modelExecutionCode(error:unknown):string {
  const e=error as {name?:string;data?:{responseBody?:string;statusCode?:number}}|null;
  try{const message=JSON.parse(e?.data?.responseBody||'{}')?.error?.message;
    if(typeof message==='string'&&/^(tool_limit_exceeded|model_request_limit|model_request_too_large|model_output_incomplete|model_stream_[a-z_]+|model_connection_failed|model_upstream_error|model_finish_invalid|model_tool_arguments_invalid|client_disconnected|supplier_usage_invalid|interpretation_cancelled|invalid_model_request|request_too_large|supplier_http_\d{3})$/.test(message))return message;
  }catch{}
  const status=e?.data?.statusCode;
  if(typeof status==='number'&&Number.isInteger(status)&&status>=400&&status<=599)return `supplier_http_${status}`;
  if(e?.name==='ContextOverflowError')return 'model_context_limit';
  return 'model_execution_failed';
}
// Prompt submission returns immediately. Each status request is short-lived;
// the caller's task deadline, rather than HTTP's five-minute header timeout, applies.
export async function waitForSessionCompletion(read:()=>Promise<SessionProgress>,signal:AbortSignal,pause=()=>delay(1500,undefined,{signal})){
  for(;;){
    signal.throwIfAborted();const state=await read();signal.throwIfAborted();
    if(!state.busy&&state.assistant){
      if(state.assistant.error)throw new Error(modelExecutionCode(state.assistant.error));
      if(state.assistant.completed!==undefined)return;
    }
    await pause();
  }
}
