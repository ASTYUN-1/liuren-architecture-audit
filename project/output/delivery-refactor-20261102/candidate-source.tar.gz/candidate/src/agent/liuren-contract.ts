import {z} from "zod";
import {isDeepStrictEqual} from "node:util";
import {requiredModules,moduleReadPlan,type LiurenRuntimeManifest} from "./liuren-routing";

const id=z.string().regex(/^[A-Za-z][A-Za-z0-9_-]{0,59}$/);
const text=z.string().trim().min(2).max(2000);
export const dimension=z.enum(["result","process","degree","attribute","identity","location","quantity","timing"]);
export const fact=z.strictObject({path:z.string().min(1).max(180),value:z.json()});
export const questionSchema=z.strictObject({questionId:id,originalQuestion:text,target:text,dimension,stage:text,successCriterion:text,domains:z.array(id).max(12),mechanisms:z.array(id).max(12),conditions:z.array(id).max(12).optional()});
export const workflowStage=z.strictObject({stage:z.number().int().min(1).max(11),summary:text,status:z.enum(["checked","not-applicable"]),sourceIds:z.array(z.string()).max(60),facts:z.array(fact).max(12)});
export const sharedWorkflowSchema=z.strictObject({schemaVersion:z.literal(3),chartHash:z.string(),runtimeVersion:z.string(),workflow:z.array(workflowStage).length(11),affectedQuestions:z.array(id).max(20).optional()});
export const judgmentSchema=z.strictObject({schemaVersion:z.union([z.literal(2),z.literal(3)]),chartHash:z.string(),runtimeVersion:z.string(),questionId:id,questionRevision:z.number().int().positive(),target:text,dimension,successCriterion:text,
  roles:z.array(z.strictObject({id,entity:text,anchorFacts:z.array(fact).min(1).max(12),mappingSourceIds:z.array(z.string()).min(1).max(8),unusedReason:text.optional()})).min(1).max(20),
  relations:z.array(z.strictObject({id,fromRole:id,toRole:id,factRefs:z.array(fact).min(1).max(12),methodIds:z.array(z.string()).min(1).max(8),assessment:z.enum(["supported","limited","unknown"]),scope:dimension,reason:text,
    effect:z.enum(["ordinary","rescue"]),effectiveness:z.enum(["confirmed","candidate","not-effective"]),limitations:z.array(text).max(12)})).min(1).max(30),
  counterEvidence:z.strictObject({status:z.enum(["found","searched-none","unresolved"]),refs:z.array(z.string()).max(20),searchScope:text,disposition:text}),
  decision:z.strictObject({status:z.enum(["supported","conditional","undetermined"]),answer:text,dependsOn:z.array(id).min(1).max(30)}),
  unresolved:z.array(z.strictObject({kind:z.enum(["source","position","other"]),description:text,important:z.boolean()})).max(20),
  retrievalRefs:z.array(z.string()).max(30),
  timing:z.strictObject({event:text,scale:text,trigger:text,candidates:z.array(text).min(1).max(12)}).optional(),
  workflow:z.array(workflowStage).length(11).optional(),
  workflowRevision:z.number().int().positive().optional(),
  questionDependencies:z.array(z.strictObject({questionId:id,questionRevision:z.number().int().positive()})).max(20).optional()
});
export type Question=z.infer<typeof questionSchema>;
export type Judgment=z.infer<typeof judgmentSchema>;
const unique=(values:string[])=>new Set(values).size===values.length;
export class LiurenContract {
  readonly questions=new Map<string,{question:Question;revision:number}>();
  readonly records=new Map<string,Judgment>();
  workflowRevision=0;
  sharedWorkflow?:z.infer<typeof sharedWorkflowSchema>["workflow"];
  readonly revisions:{questionId:string;reason:string;revision:number}[]=[];
  constructor(readonly chartHash:string,readonly runtime:LiurenRuntimeManifest,readonly originalQuestion:string,private readonly facts:unknown,private readonly isRead:(id:string)=>boolean){}
  register(input:unknown[],revisionReason?:string){
    const parsed=input.map(x=>questionSchema.parse(x));if(!parsed.length||!unique(parsed.map(x=>x.questionId)))throw new Error("duplicate_or_empty_questions");
    for(const q of parsed){
      if(!this.originalQuestion.includes(q.originalQuestion))throw new Error("question_not_in_original");
      for(const domain of q.domains)if(!this.runtime.routes[domain])throw new Error("unknown_liuren_domain");
      if(this.runtime.schemaVersion===3){
        for(const key of q.conditions??[])if(!this.runtime.readingRoute?.conditional[key])throw new Error("unknown_liuren_condition");
        for(const key of q.mechanisms)if(!this.runtime.modules[key])throw new Error("unknown_liuren_module:"+key);
      }
      requiredModules(this.runtime,[...q.domains.flatMap(d=>this.runtime.routes[d]),...q.mechanisms,...(q.conditions??[]),...(["timing","quantity"].includes(q.dimension)?[q.dimension]:[])]);
      const old=this.questions.get(q.questionId);
      if(old&&!isDeepStrictEqual(old.question,q)&&!revisionReason?.trim())throw new Error("question_revision_reason_required");
    }
    for(const q of parsed){
      const old=this.questions.get(q.questionId);if(old&&isDeepStrictEqual(old.question,q))continue;
      const revision=(old?.revision??0)+1;this.questions.set(q.questionId,{question:q,revision});
      if(old){
        this.invalidateQuestions([q.questionId]);
        this.revisions.push({questionId:q.questionId,reason:revisionReason!,revision});
      }
    }
    return this.status();
  }
  private verifyFacts(values:z.infer<typeof fact>[]){
    for(const f of values){let value:any=this.facts;for(const key of f.path.split(".")){if(["__proto__","prototype","constructor"].includes(key))throw new Error("invalid_fact_path");value=value?.[key];}if(value===undefined||!isDeepStrictEqual(value,f.value))throw new Error("chart_fact_mismatch:"+f.path);}
  }
  private verifySources(ids:string[]){for(const id of ids)if(!this.isRead(id))throw new Error("judgment_source_not_read:"+id);}
  missingModules(){
    const requested=[...this.questions.values()].flatMap(({question:q})=>[...q.domains.flatMap(d=>this.runtime.routes[d]),...q.mechanisms,...(q.conditions??[]),...(["timing","quantity"].includes(q.dimension)?[q.dimension]:[])]);
    return requiredModules(this.runtime,requested).filter(key=>!this.isRead(this.runtime.modules[key].id));
  }
  record(input:unknown){
    const r=judgmentSchema.parse(input),entry=this.questions.get(r.questionId);
    if(r.chartHash!==this.chartHash||r.runtimeVersion!==this.runtime.version||!entry||r.questionRevision!==entry.revision)throw new Error("judgment_identity_mismatch");
    const q=entry.question;
    if(r.target!==q.target||r.dimension!==q.dimension||r.successCriterion!==q.successCriterion)throw new Error("judgment_question_drift");
    if(this.missingModules().length)throw new Error("judgment_modules_incomplete");
    if(this.runtime.schemaVersion===3){
      if(r.schemaVersion!==3)throw new Error("eleven_workflow_summaries_required");
      if(r.workflow)this.verifyWorkflow(r.workflow,this.questionReadingPlan(q));
      else if(!r.workflowRevision||r.workflowRevision!==this.workflowRevision||!this.sharedWorkflow)throw new Error("shared_workflow_revision_required");
      else this.verifyWorkflow(this.sharedWorkflow,this.questionReadingPlan(q));
    }
    for(const dep of r.questionDependencies??[]){const other=this.questions.get(dep.questionId);if(dep.questionId===r.questionId||!other||other.revision!==dep.questionRevision||!this.records.has(dep.questionId))throw new Error("question_dependency_not_current");}
    if(!unique(r.roles.map(x=>x.id))||!unique(r.relations.map(x=>x.id)))throw new Error("duplicate_judgment_ids");
    const roles=new Set(r.roles.map(x=>x.id)),relations=new Map(r.relations.map(x=>[x.id,x]));
    for(const role of r.roles){this.verifyFacts(role.anchorFacts);this.verifySources(role.mappingSourceIds);}
    for(const rel of r.relations){
      if(!roles.has(rel.fromRole)||!roles.has(rel.toRole))throw new Error("unknown_relation_role");
      this.verifyFacts(rel.factRefs);this.verifySources(rel.methodIds);
      if(rel.effect==="rescue"&&rel.effectiveness==="confirmed"&&(rel.assessment!=="supported"||r.unresolved.some(x=>x.important&&["source","position"].includes(x.kind))))throw new Error("unresolved_rescue");
      if(rel.effect==="rescue"&&!this.isRead(this.runtime.modules[this.runtime.schemaVersion===3?"liqi":"state-and-rescue"].id))throw new Error("rescue_module_required");
    }
    const used=new Set<string>();
    for(const dep of r.decision.dependsOn){const rel=relations.get(dep);if(!rel)throw new Error("dangling_decision_dependency");used.add(rel.fromRole);used.add(rel.toRole);if(r.decision.status==="supported"&&rel.assessment==="unknown")throw new Error("unknown_decisive_relation");}
    for(const role of r.roles)if(!used.has(role.id)&&!role.unusedReason)throw new Error("role_named_but_unused:"+role.id);
    if(r.counterEvidence.status==="found"&&!r.counterEvidence.refs.length)throw new Error("counterevidence_reference_required");
    for(const ref of r.counterEvidence.refs)if(!relations.has(ref)&&!this.isRead(ref))throw new Error("unknown_counterevidence_reference");
    this.verifySources(r.retrievalRefs);
    if(r.dimension==="timing"&&!r.timing)throw new Error("timing_event_required");
    // Relation IDs belong to one question. Coincidentally named R1 relations
    // in independent questions must not invalidate one another.
    const previous=this.records.get(r.questionId);
    const invalidated=previous&&!isDeepStrictEqual(previous,r)?this.invalidateQuestions([r.questionId]).filter(x=>x!==r.questionId):[];
    this.records.set(r.questionId,structuredClone(r));return {accepted:true,invalidated,...this.status()};
  }
  private invalidateQuestions(ids:string[]){
    const affected=new Set(ids);let changed=true;
    while(changed){changed=false;for(const [key,r] of this.records)if(!affected.has(key)&&(r.questionDependencies??[]).some(x=>affected.has(x.questionId))){affected.add(key);changed=true;}}
    for(const key of affected)this.records.delete(key);return [...affected];
  }
  private questionReadingPlan(q:Question):{key:string;id:string;stage:number|null}[]{return moduleReadPlan(this.runtime,q.domains,[...(q.conditions??[]),...(["timing","quantity"].includes(q.dimension)?[q.dimension]:[])],q.mechanisms);}
  private verifyWorkflow(workflow:z.infer<typeof workflowStage>[],planned=this.readingPlan()){
    if(workflow.map(s=>s.stage).join(",")!=="1,2,3,4,5,6,7,8,9,10,11")throw new Error("eleven_workflow_summaries_required");
    for(const stage of workflow){this.verifyFacts(stage.facts);this.verifySources(stage.sourceIds);const required=planned.filter(x=>x.stage===stage.stage);if(required.some(x=>!stage.sourceIds.includes(x.id))||required.length&&stage.status!=="checked")throw new Error("workflow_stage_sources_incomplete:"+stage.stage);}
  }
  recordWorkflow(input:unknown){
    const r=sharedWorkflowSchema.parse(input);
    if(this.runtime.schemaVersion!==3||r.chartHash!==this.chartHash||r.runtimeVersion!==this.runtime.version||!this.questions.size)throw new Error("shared_workflow_identity_mismatch");
    if(this.missingModules().length)throw new Error("judgment_modules_incomplete");
    this.verifyWorkflow(r.workflow);
    if(this.sharedWorkflow&&isDeepStrictEqual(this.sharedWorkflow,r.workflow))return {accepted:true,workflowRevision:this.workflowRevision,invalidated:[]};
    // An extension of delivered sources does not alter prior judgments. A
    // substantive shared-check correction requires an explicit impact list.
    const substantive=this.sharedWorkflow&&this.sharedWorkflow.some((old,i)=>!isDeepStrictEqual({...old,sourceIds:[]},{...r.workflow[i],sourceIds:[]}));
    if(substantive&&this.records.size>0&&!r.affectedQuestions?.length)throw new Error("workflow_correction_impact_required");
    for(const id of r.affectedQuestions??[])if(!this.questions.has(id))throw new Error("unknown_affected_question");
    const invalidated=this.invalidateQuestions(r.affectedQuestions??[]);
    this.sharedWorkflow=structuredClone(r.workflow);this.workflowRevision++;
    return {accepted:true,workflowRevision:this.workflowRevision,invalidated};
  }
  readingPlan():{key:string;id:string;stage:number|null}[]{const seen=new Set<string>();return [...this.questions.values()].flatMap(({question})=>this.questionReadingPlan(question)).filter(x=>!seen.has(x.key)&&Boolean(seen.add(x.key)));}
  status(){return {questions:[...this.questions].map(([questionId,x])=>({questionId,revision:x.revision})),missingQuestions:[...this.questions.keys()].filter(id=>!this.records.has(id)),missingModules:this.missingModules(),readingPlan:this.readingPlan(),recordCount:this.records.size,workflowRevision:this.workflowRevision,sharedWorkflowRecorded:Boolean(this.sharedWorkflow)};}
  assertComplete(){const s=this.status();if(!this.questions.size||s.missingQuestions.length||s.missingModules.length)throw new Error("liuren_contract_incomplete:"+JSON.stringify(s));if(this.sharedWorkflow)this.verifyWorkflow(this.sharedWorkflow);}
}
