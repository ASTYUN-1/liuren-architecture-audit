import {Delivery,reportSubmissionSchema,reportPatchSchema,answerPatchSchema,type DeliveryProtocol,type DeliveryDraft,type ReportSubmission} from './delivery';
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import {isDeepStrictEqual} from "node:util";
import {createHash} from "node:crypto";
import { calculateChart, publicChart, assertChartSnapshot, type ChartSnapshot } from "../engine/liuren";
import type { CaseInput, Report } from "../server/contracts";
import { KnowledgeRelease, REQUIRED_SKILLS, type EvidenceRef } from "./knowledge";
import { assertPublicText, validatePublicReport,loadPublicOutputPolicy,publicOutputPolicyPage,type PublicOutputPolicy } from "./public-output";
import {validatePractitionerReport} from "./practitioner-output";
import { TOOL_RESPONSE_MAX_BYTES, assertReportIntegrity } from "./workflow-delivery";
import {LiurenContract,questionSchema,judgmentSchema,sharedWorkflowSchema} from "./liuren-contract";

export interface RunContext {deliveryProtocol?:DeliveryProtocol;onDraft?:(draft:DeliveryDraft)=>Promise<void>;audience?:"public"|"practitioner";taskId:string;caseId:string;kind:"initial"|"followup";input:CaseInput;question?:string;report?:Report|null;history:{question:string;answer:string}[];previousChart?:ChartSnapshot;signal?:AbortSignal}
export class ToolAudit {
  terminalError?: "tool_limit_exceeded";
  calls=0; chartRead=false; caseSearched=false;experienceSearched=false; caseHits=new Set<string>(); readIds=new Set<string>(); stages=new Map<string,unknown>(); evidence:EvidenceRef[]=[];
  candidate?:{report?:Report;answer?:string;clarification?:string};
  chart:ChartSnapshot;
  readonly contract?:LiurenContract;
  readonly delivery?:Delivery;
  private contextRead=false;
  contextDelivery(){const c=this.jsonDeliveries.get("case-context");return {read:this.contextRead,complete:this.contextRead&&(!c||c.delivered.size===c.pages.length),missingPages:c?Array.from({length:c.pages.length},(_,i)=>i+1).filter(n=>!c.delivered.has(n)):[]};}
  readContext(page=1,expectedHash?:string,maxPages=3){this.contextRead=true;return this.deliverJSON("case-context",{question:this.input.input.question,followup:this.input.question,confirmedChartRequest:this.input.input.chartRequest,participants:this.chart.participants,originalReport:this.input.report,history:this.input.history,locale:this.input.input.locale,chartConfiguration:{mode:this.input.input.mode,time:this.input.input.time,timeZone:this.input.input.timeZone,number:this.input.input.number,longitude:this.input.input.longitude,pillars:this.input.input.pillars,summary:this.input.input.intent?.summary},chartHash:this.chart.hash},page,expectedHash,maxPages);}
  private outputPhase?:{kind:"report"|"clarification";analysisHash:string;policy:PublicOutputPolicy;pageCount:number;pages:Set<number>};
  private readPages=new Map<string,{hash:string;pageCount:number;pages:Set<number>}>();
  readPage(id:string,page=1,expectedHash?:string){
    const result=this.release.page(id,page,expectedHash);
    let coverage=this.readPages.get(id);
    if(!coverage||coverage.hash!==result.deliveryHash){coverage={hash:result.deliveryHash,pageCount:result.pageCount,pages:new Set()};this.readPages.set(id,coverage);this.readIds.delete(id);}
    coverage.pages.add(page);if(coverage.pages.size===coverage.pageCount)this.readIds.add(id);
    return {...result,complete:this.readIds.has(id),missingPages:Array.from({length:coverage.pageCount},(_,i)=>i+1).filter(n=>!coverage.pages.has(n))};
  }
  private jsonDeliveries=new Map<string,{hash:string;pages:string[];delivered:Set<number>;bytes:number}>();
  deliverJSON(id:string,value:object,page=1,expectedHash?:string,maxPages=3):any{
    const raw=JSON.stringify(value);
    if(Buffer.byteLength(raw)<TOOL_RESPONSE_MAX_BYTES-1024)return value;
    let c=this.jsonDeliveries.get(id);
    if(!c){const pages:string[]=[];let part="",bytes=0;for(const char of raw){const n=Buffer.byteLength(char);if(bytes+n>8000){pages.push(part);part="";bytes=0;}part+=char;bytes+=n;}if(part)pages.push(part);c={hash:createHash("sha256").update(raw).digest("hex"),pages,delivered:new Set(),bytes:Buffer.byteLength(raw)};this.jsonDeliveries.set(id,c);}
    if(!Number.isInteger(page)||page<1||page>c.pages.length)throw new Error("invalid_bound_json_page");if(page>1&&!expectedHash||expectedHash!==undefined&&expectedHash!==c.hash)throw new Error("bound_json_hash_mismatch");
    const pages=[];for(let n=page;n<=c.pages.length&&pages.length<maxPages;n++){const text=c.pages[n-1],item={page:n,text,pageHash:createHash("sha256").update(text).digest("hex")};if(Buffer.byteLength(JSON.stringify({pages:[...pages,item]}))>TOOL_RESPONSE_MAX_BYTES-4096)break;pages.push(item);c.delivered.add(n);}
    return {id,paginated:true,deliveryHash:c.hash,pageCount:c.pages.length,totalBytes:c.bytes,pages,missingPages:Array.from({length:c.pages.length},(_,i)=>i+1).filter(n=>!c!.delivered.has(n)).slice(0,500),remainingPages:c.pages.length-c.delivered.size,complete:c.delivered.size===c.pages.length,instruction:"完整绑定JSON；按页码拼接所有text再解析，按missingPages[0]和expectedHash=deliveryHash继续调用同一工具；没有省略字段、历史、事实或原断语。"};
  }
  readChart(page=1,expectedHash?:string,maxPages=3){const result=this.deliverJSON("fixed-chart",this.chart,page,expectedHash,maxPages);this.chartRead=!result.paginated||result.complete;return result.paginated?{...result,chartHash:this.chart.hash}:result;}
  coverage(){return [...this.readPages].map(([id,c])=>({id,deliveryHash:c.hash,pageCount:c.pageCount,deliveredPages:[...c.pages].sort((a,b)=>a-b),complete:this.readIds.has(id)}));}
  constructor(readonly input:RunContext,readonly release:KnowledgeRelease){
    if(input.previousChart){
      if(!input.previousChart || input.previousChart.input.question!==input.input.question)throw new Error("fixed_chart_required");
      assertChartSnapshot(input.previousChart,input.input);
      this.chart=structuredClone(input.previousChart);
    }else {if(input.kind==="followup"||input.input.random)throw new Error("fixed_chart_required");this.chart=calculateChart(input.input);}
    if(input.deliveryProtocol==="delivery-v2")this.delivery=new Delivery(this,input.onDraft);
    if(release.liurenRuntime)this.contract=new LiurenContract(this.chart.hash,release.liurenRuntime,input.question??input.input.question,this.chart.facts,id=>this.readIds.has(id));
  }
  count(){this.calls++;}
  toolBudget(){return {used:this.calls};}
  private analysisHash(){return createHash("sha256").update(JSON.stringify({chartHash:this.chart.hash,questions:[...(this.contract?.questions??[])],records:[...(this.contract?.records??[])],revisions:this.contract?.revisions,sharedWorkflow:this.contract?.sharedWorkflow,workflowRevision:this.contract?.workflowRevision})).digest("hex");}
  assertToolAllowed(name:string){
    if(this.delivery){if(this.candidate&&!["check_readiness","submit_report","repair_report"].includes(name))this.delivery.changed();return;}
    if(this.outputPhase&&name!=="reopen_analysis"&&name!=="prepare_public_output"&&name!==(this.outputPhase.kind==="report"?"submit_report":"submit_clarification"))throw new Error("analysis_frozen_for_public_output");
  }
  reopenAnalysis(reason:string){if(this.delivery){this.delivery.changed();return {accepted:true,stage:"analysis",instruction:"已使待交付确认失效，已读内容和草稿保留"};}if(!reason.trim())throw new Error("analysis_reopen_reason_required");if(!this.outputPhase)throw new Error("public_output_phase_not_started");this.outputPhase=undefined;this.candidate=undefined;return {accepted:true,stage:"analysis",instruction:"修复缺项后重新prepare_public_output，重新绑定分析哈希；已读资料与判断保留，完整性与隐私检查照常执行。"};}
  readBatch(requests:{id:string;page?:number;expectedHash?:string}[],maxPages=3){
    // Preflight all identities/hashes before recording any delivery. Pending
    // pages are explicit and never count as read until actually returned.
    const pending=requests.map(x=>({...x,page:x.page??1}));for(const q of pending)this.release.page(q.id,q.page,q.expectedHash);
    const pages:ReturnType<ToolAudit["readPage"]>[]=[],delivered=new Set<string>();
    while(pending.length&&pages.length<maxPages){
      const q=pending[0],key=q.id+":"+q.page;if(delivered.has(key)){pending.shift();continue;}
      const raw=this.release.page(q.id,q.page,q.expectedHash);
      const estimate={pages:[...pages,{...raw,complete:false,missingPages:Array.from({length:raw.pageCount},(_,i)=>i+1)}],pending,toolBudget:this.toolBudget()};
      if(Buffer.byteLength(JSON.stringify(estimate))>TOOL_RESPONSE_MAX_BYTES-2048){if(!pages.length)throw new Error("knowledge_page_response_too_large");break;}
      pending.shift();pages.push(this.readPage(q.id,q.page,q.expectedHash));delivered.add(key);
      if(q.page<raw.pageCount&&!pending.some(x=>x.id===q.id&&x.page===q.page+1))pending.push({id:q.id,page:q.page+1,expectedHash:raw.deliveryHash});
    }
    return {pages,pending,complete:pending.length===0&&requests.every(x=>this.readIds.has(x.id)),instruction:"pages中正文完整送达；pending仍须继续读取。每文档complete仅在全部hash绑定页已送达后为真。"};
  }
  prepareOutput(kind:"report"|"clarification",policy:PublicOutputPolicy,page=1,expectedHash?:string,maxPages=1){
    const result=publicOutputPolicyPage(policy,page,expectedHash);
    if(this.delivery&&this.outputPhase?.kind!==kind)this.outputPhase=undefined;
    if(this.outputPhase){if(this.outputPhase.kind!==kind||this.outputPhase.policy.hash!==policy.hash)throw new Error("public_output_phase_mismatch");}
    else{
      if(kind==="report"&&!this.delivery)this.assertAnalysisComplete();
      this.outputPhase={kind,analysisHash:this.analysisHash(),policy,pageCount:result.pageCount,pages:new Set()};
      this.candidate=undefined;
    }
    this.outputPhase.pages.add(page);
    const additionalPages=[];for(let next=page+1;next<=result.pageCount&&additionalPages.length<maxPages-1;next++){const p=publicOutputPolicyPage(policy,next,policy.hash);if(Buffer.byteLength(JSON.stringify({first:result,additionalPages:[...additionalPages,p]}))>TOOL_RESPONSE_MAX_BYTES-4096)break;additionalPages.push(p);this.outputPhase.pages.add(next);}
    return {...result,...(additionalPages.length?{additionalPages}:{}),kind,analysisHash:this.outputPhase.analysisHash,complete:this.outputPhase.pages.size===result.pageCount,
      missingPages:Array.from({length:result.pageCount},(_,i)=>i+1).filter(n=>!this.outputPhase!.pages.has(n)),
      instruction:this.delivery?"最终整理时应用完整输出规范；发现缺口可继续补查，不冻结分析。先提交已有完整正文；只按明确阻塞项局部修复，内部登记告警不阻止交付。":"最终公开交付阶段：只整理已完成的判断，保留结论、反证和不确定性；内部判断已冻结，不能在此阶段修改、重查或补造；如发现缺项，先reopen_analysis说明修复原因，再补查并重新准备输出。旧步骤/子智能体名称只作历史表述，当前以已保存的逐问记录及内部引用为准。读完全部页后只提交对应公开结果。"};
  }
  assertOutputReady(kind:"report"|"clarification"){
    if(this.input.audience==="practitioner"||this.release.protocol!=="liuren-v3")return;
    const phase=this.outputPhase;
    if(!phase||phase.kind!==kind||phase.pages.size!==phase.pageCount)throw new Error("public_output_policy_not_fully_read");
    if(!this.delivery&&phase.analysisHash!==this.analysisHash())throw new Error("frozen_analysis_changed");
  }
  outputCoverage(){const p=this.outputPhase;return p?{stage:"final-output",kind:p.kind,version:p.policy.version,hash:p.policy.hash,analysisHash:p.analysisHash,pageCount:p.pageCount,deliveredPages:[...p.pages].sort((a,b)=>a-b),complete:p.pages.size===p.pageCount}:undefined;}
  cite(id:string,quote:string){if(!this.readIds.has(id))throw new Error("citation_not_read");const e=this.release.evidence(id,quote);if(!this.evidence.some(x=>x.id===id&&x.quote===quote))this.evidence.push(e);return e;}
  status(){return {chartRead:this.chartRead,caseSearched:this.caseSearched,experienceSearched:this.experienceSearched,completedStages:[...this.stages.keys()],missingStages:this.contract?[]:REQUIRED_SKILLS.filter(s=>!this.stages.has(s)),rootSkillRead:this.readIds.has("skill:daliuren/SKILL.md"),evidenceCount:this.evidence.length,caseCitationRequired:this.caseHits.size>0&&!this.evidence.some(e=>this.caseHits.has(e.id)),...(this.contract?{contract:this.contract.status()}:{} )};}
  assertAnalysisComplete(){const context=this.jsonDeliveries.get("case-context");if(context&&context.delivered.size!==context.pages.length)throw new Error("case_context_not_fully_read");const s=this.status();if(!s.chartRead || !s.caseSearched || (this.release.fineGrainedEnabled&&!s.experienceSearched) || s.missingStages.length || !s.rootSkillRead || s.evidenceCount<3 || s.caseCitationRequired)throw new Error("workflow_incomplete:"+JSON.stringify(s));this.contract?.assertComplete();}
  assertComplete(){if(this.delivery&&this.candidate&&!this.candidate.clarification){this.delivery.assertAccepted();return;}if(this.terminalError)throw new Error(this.terminalError);if(!this.candidate)throw new Error("report_not_submitted");this.assertOutputReady(this.candidate.clarification?"clarification":"report");if(!this.candidate.clarification&&!this.delivery)this.assertAnalysisComplete();}
}
export function verifyChartFacts(chart:ChartSnapshot,facts:{path:string;value:unknown}[]){
  for(const f of facts){let value:any=chart.facts;for(const key of f.path.split(".")){if(["__proto__","constructor","prototype"].includes(key))throw new Error("invalid_fact_path");value=value?.[key];}if(value===undefined || !isDeepStrictEqual(value,f.value))throw new Error("chart_fact_mismatch:"+JSON.stringify({path:f.path,...(value===undefined?{hint:"path is relative to calculate_chart.facts; omit the facts. prefix and copy an existing field exactly"}:{expected:value}),instruction:"Copy the exact existing value and type from the fixed chart; do not recompute it."}));}
}
function deliveryErrorDetails(audit:ToolAudit,code:string,error:unknown,arg:any){
 const expected:{field:string;expected:unknown}[]=[];const c=audit.contract;
 if(c&&code.includes("identity"))for(const [field,value] of Object.entries({chartHash:audit.chart.hash,runtimeVersion:c.runtime.version,questionRevision:c.questions.get(arg?.questionId)?.revision}))if(arg?.[field]!==undefined&&arg[field]!==value)expected.push({field,expected:value});
 const suffix=error instanceof Error?error.message.slice(code.length+1):"";
 if(code==='judgment_source_not_read'){try{const p=audit.release.page(suffix),coverage=audit.coverage().find(x=>x.id===suffix);return {expected,source:{id:p.id,missingPages:Array.from({length:p.pageCount},(_,i)=>i+1).filter(n=>!coverage?.deliveredPages.includes(n))}};}catch{}}
 if(code==='workflow_stage_sources_incomplete'&&/^(?:[1-9]|1[01])$/.test(suffix))return {expected,stage:Number(suffix),requiredSources:c?.readingPlan().filter(x=>x.stage===Number(suffix)).map(x=>x.id)};
 return {expected};
}
function boundedCandidates<T extends {results:any[]}>(data:T,offset=0){
  if(!Number.isInteger(offset)||offset<0||offset>data.results.length)throw new Error("invalid_candidate_offset");
  const results:any[]=[];for(const hit of data.results.slice(offset)){if(Buffer.byteLength(JSON.stringify({...data,results:[...results,hit]}))>TOOL_RESPONSE_MAX_BYTES-2048)break;results.push(hit);}
  if(offset<data.results.length&&!results.length)throw new Error("candidate_metadata_too_large");
  return {...data,results,totalCandidates:data.results.length,nextOffset:offset+results.length<data.results.length?offset+results.length:null};
}
const citation=z.object({id:z.string(),quote:z.string().min(8).max(1000)});
export function createTaskTools(audit:ToolAudit,publicOutput?:PublicOutputPolicy,onTool?:(name:string,ok:boolean,code:string,durationMs?:number)=>void){
  const server=new McpServer({name:"wenheng-readonly-task",version:"1.0.0"});
  function register(name:string,description:string,inputSchema:any,fn:(arg:any)=>unknown){server.registerTool(name,{description,inputSchema},async (arg:any)=>{const started=performance.now();try{audit.count();audit.assertToolAllowed(name);const result=await fn(arg);const output=JSON.stringify({...result as object,toolBudget:audit.toolBudget()});if(Buffer.byteLength(output)>TOOL_RESPONSE_MAX_BYTES)throw new Error("tool_response_too_large:use_bounded_batch_or_fewer_candidates");onTool?.(name,!(result&&typeof result==="object"&&"accepted" in result&&result.accepted===false),result&&typeof result==="object"&&"accepted" in result&&result.accepted===false?"delivery_blocked":"",Math.round(performance.now()-started));return{content:[{type:"text" as const,text:output}]};}catch(e){const code=e instanceof Error?(e.message.match(/^[a-z][a-z0-9_]{0,79}(?=:|$)/)?.[0]??"tool_validation_error"):"tool_failed";onTool?.(name,false,code,Math.round(performance.now()-started));return{isError:true,content:[{type:"text" as const,text:audit.delivery?JSON.stringify({code,field:code.includes("identity")?"binding":code.includes("source")?"sourceIds":"toolInput",message:code.includes("identity")?"当前盘、资料版本或问项修订不匹配；省略自动绑定字段，或使用当前问项修订":code.includes("source")?"来源未完整读取或环节来源缺项，请核对requiredSources和missingModules":"工具输入未通过契约校验，请按当前schema局部修复",...deliveryErrorDetails(audit,code,e,arg),current:{chartHash:audit.chart.hash,runtimeVersion:audit.contract?.runtime.version,questions:audit.delivery.questions().map(({questionId,revision})=>({questionId,revision})),workflowRevision:audit.contract?.workflowRevision,missingModules:audit.contract?.missingModules(),requiredSources:audit.contract?.readingPlan().map(x=>({id:x.id,stage:x.stage}))}}):e instanceof Error?e.message:"tool_failed"}]};}});}
  register("read_case","Read this task's bound event and complete history. Continue missingPages before delivery.",{page:z.number().int().min(1).optional(),expectedHash:z.string().regex(/^[a-f0-9]{64}$/).optional(),maxPages:z.number().int().min(1).max(3).optional()},({page,expectedHash,maxPages})=>audit.readContext(page,expectedHash,maxPages));
  register("calculate_chart","Return the full deterministic frozen chart and original engine judgments. Large charts use bounded hash-bound JSON pages; if paginated=true continue missingPages with deliveryHash and assemble every text page. No fields are omitted. All pages must be read before judgments.",{page:z.number().int().min(1).optional(),expectedHash:z.string().regex(/^[a-f0-9]{64}$/).optional(),maxPages:z.number().int().min(1).max(3).optional()},({page,expectedHash,maxPages})=>audit.readChart(page,expectedHash,maxPages));
  register("list_knowledge","List approved skills, safe case categories and a paginated reference source catalog. referencesOffset advances the reference source list.",{referencesOffset:z.number().int().min(0).max(100000).optional()},({referencesOffset})=>{const runtime=audit.release.liurenRuntime;return {version:audit.release.version,documents:audit.release.list(),references:audit.release.references(referencesOffset),caseCategories:audit.release.caseCategories(),requiredStages:audit.contract?[]:REQUIRED_SKILLS,...(runtime?{runtime:runtime.schemaVersion===3?{schemaVersion:runtime.schemaVersion,release:runtime.release,version:runtime.version,localMethodVersion:runtime.localMethodVersion,entryId:runtime.entryId,modules:runtime.modules,required:runtime.required,routes:runtime.routes,readingRoute:runtime.readingRoute}:runtime}:{} )};});
  register("read_knowledge","Read one bounded UTF-8 page by approved opaque ID. Start page=1, then read ALL missingPages with expectedHash=deliveryHash. Only full coverage permits citations/stages; batch independent pages. Skill text includes server adaptation rules.",{id:z.string().max(180),page:z.number().int().min(1).optional(),expectedHash:z.string().regex(/^[a-f0-9]{64}$/).optional()},({id,page,expectedHash})=>audit.readPage(id,page,expectedHash));
  register("read_knowledge_batch","Read several full hash-bound pages in one bounded response (maximum 3 pages/40KB JSON). Start each document at page=1; the server queues next pages with the deliveryHash. Continue with returned pending until empty; a document is read only when its own complete=true. No text is shortened.",{requests:z.array(z.object({id:z.string().max(180),page:z.number().int().min(1).optional(),expectedHash:z.string().regex(/^[a-f0-9]{64}$/).optional()})).min(1).max(24),maxPages:z.number().int().min(1).max(3).optional()},({requests,maxPages})=>audit.readBatch(requests,maxPages));
  register("resolve_knowledge_link","Resolve an exact relative link shown in an approved document to hash-bound website source IDs. No local path access; paginated source sections must still be read before citation.",{sourceId:z.string().max(180),href:z.string().min(1).max(1500),offset:z.number().int().min(0).max(100000).optional()},arg=>audit.release.resolveLink(arg.sourceId,arg.href,arg.offset));
  register("search_knowledge","Bounded literal content/title search. scope=references discovers general experience, ancient extracts and book sections without category. cases/all require a listed category (safe synonyms only). No paths, regex, shell or network. Read the complete returned document/section before citation; a section is not the whole book.",{query:z.string().min(1).max(100),scope:z.enum(["skills","cases","references","all"]).default("skills"),category:z.string().max(20).optional(),offset:z.number().int().min(0).max(100000).optional()},arg=>audit.release.searchText(arg));
  register("search_cases","Search formal cases by question and fixed-chart fields. Return question units, relevance and separate six-dimension scores, evidence identity, source keys and transfer limits. Safe category synonyms only. Scores are not correctness; read full sources. Stage-1 archives are excluded.",{query:z.string().max(300).optional(),category:z.string().max(20),patterns:z.array(z.string().max(30)).max(12).optional(),firstBranch:z.string().max(2).optional(),firstGeneral:z.string().max(5).optional(),transmissions:z.string().max(3).optional(),dayStem:z.string().max(1).optional(),deity:z.string().max(8).optional(),limit:z.number().int().min(1).max(20).optional(),excludeSources:z.array(z.string().min(1).max(300)).max(20).optional(),offset:z.number().int().min(0).max(20).optional()},async arg=>{const all=await audit.release.searchAsync({...arg,query:arg.query??audit.input.question??audit.input.input.question},audit.input.signal),bounded=boundedCandidates({results:all},arg.offset);audit.assertToolAllowed("search_cases");audit.caseSearched=true;for(const r of bounded.results)audit.caseHits.add(r.id);return{...bounded,pool:audit.release.categorySummary(arg.category),...(audit.release.caseCategories().includes(arg.category)?{}:{availableCategories:audit.release.caseCategories()}),warning:"问题相关性与盘面结构分开；分数不是正确率。pool是文档数，不是独立验证数。核对优秀作答、真实反馈及同源关系，不因高分或称验采信；无候选如实说明。"};});
  register("search_experience","Search curated fine-grained experience and pending fragments, with source line ranges, validation identity, same-source groups and related conflicts. Category is a ranking hint. Read returned opaque IDs completely before citing; no automatic rule promotion.",{query:z.string().min(1).max(100),category:z.string().max(20).optional(),limit:z.number().int().min(1).max(20).optional(),excludeSources:z.array(z.string().min(1).max(300)).max(20).optional(),offset:z.number().int().min(0).max(20).optional()},async arg=>{const result=boundedCandidates(await audit.release.searchExperiencesAsync(arg,audit.input.signal),arg.offset);audit.assertToolAllowed("search_experience");audit.experienceSearched=true;return result;});
  if(audit.contract){
    register("register_questions","Register exact original question fragments, objects, stages and success criteria; select domain/mechanism modules. Revisions require a reason and invalidate dependent judgments.",{questions:z.array(questionSchema).min(1).max(20),revisionReason:z.string().min(2).max(1000).optional()},({questions,revisionReason})=>{if(!audit.chartRead)throw new Error("chart_required");const result=audit.contract!.register(questions,revisionReason);audit.candidate=undefined;audit.delivery?.changed();return result;});
    register("record_workflow","Record the 11 shared checks once for the current registered questions. Fully cover readingPlan sources. Each judgment can reference workflowRevision. On substantive corrections explicitly list affectedQuestions for reassessment; adding read source coverage preserves unrelated judgments.",(audit.delivery?sharedWorkflowSchema.extend({chartHash:z.string().optional(),runtimeVersion:z.string().optional()}).shape:sharedWorkflowSchema.shape),arg=>{if(!audit.chartRead)throw new Error("chart_required");const result=audit.contract!.recordWorkflow(audit.delivery?{...arg,chartHash:arg.chartHash??audit.chart.hash,runtimeVersion:arg.runtimeVersion??audit.contract!.runtime.version}:arg);audit.candidate=undefined;audit.delivery?.changed();return result;});
    register("record_judgment","Record an auditable question summary with fixed-chart facts, fully read sources, role relationships, counterevidence and decision dependencies. This validates structure, not interpretive correctness.",(audit.delivery?judgmentSchema.extend({chartHash:z.string().optional(),runtimeVersion:z.string().optional(),questionRevision:z.number().int().positive().optional(),workflowRevision:z.number().int().positive().optional()}).shape:judgmentSchema.shape),arg=>{if(!audit.chartRead)throw new Error("chart_required");const result=audit.contract!.record(audit.delivery?{...arg,chartHash:arg.chartHash??audit.chart.hash,runtimeVersion:arg.runtimeVersion??audit.contract!.runtime.version,questionRevision:arg.questionRevision??audit.contract!.questions.get(arg.questionId)?.revision,workflowRevision:arg.workflowRevision??audit.contract!.workflowRevision}:arg);audit.candidate=undefined;audit.delivery?.changed();return result;});
  }
  if(!audit.contract)register("record_stage","Record actual application of a required skill to this fixed chart. Cite source text plus two true chart facts, then explain the conclusion. Read skill first.",{skill:z.enum(REQUIRED_SKILLS),chartHash:z.string(),finding:z.string().min(30).max(2500),facts:z.array(z.object({path:z.string().max(100),value:z.unknown()})).min(2).max(6),citations:z.array(citation).min(1).max(4)},({skill,chartHash,finding,facts,citations})=>{
    if(chartHash!==audit.chart.hash || !audit.chartRead || !audit.readIds.has(`skill:${skill}/SKILL.md`))throw new Error("stage_prerequisite_missing");
    if(!citations.some((c:any)=>c.id===`skill:${skill}/SKILL.md`))throw new Error("stage_own_source_required");
    verifyChartFacts(audit.chart,facts);
    for(const c of citations)audit.cite(c.id,c.quote);audit.stages.set(skill,{finding,facts,citations});return{accepted:true,skill,...audit.status()};
  });
  if(audit.input.audience!=="practitioner"&&audit.release.protocol==="liuren-v3")register("prepare_public_output",audit.delivery?"Read the complete final output policy in bounded pages. Does not freeze analysis or require citation counts. Continue missingPages before delivery.":"Enter the terminal output phase. For report/followup, finish judgments and source checks first and provide >=3 internal citations; clarification is a separate terminal branch. Returns the website output skill in bounded pages. Read all missingPages with expectedHash before submitting. Analysis tools are frozen after entering; reopen_analysis explicitly exits for repairs, then prepare again.",{kind:z.enum(["report","clarification"]),citations:z.array(citation).min(audit.delivery?0:3).max(12).optional(),page:z.number().int().min(1).optional(),expectedHash:z.string().regex(/^[a-f0-9]{64}$/).optional(),maxPages:z.number().int().min(1).max(3).optional()},({kind,citations,page,expectedHash,maxPages})=>{
    if(kind==="report"&&!audit.outputCoverage()){
      if(!citations&&!audit.delivery)throw new Error("final_citations_required");
      for(const c of citations??[]){if(!audit.readIds.has(c.id))throw new Error("citation_not_read");audit.release.evidence(c.id,c.quote);}
      for(const c of citations??[])audit.cite(c.id,c.quote);
    }
    return audit.prepareOutput(kind,publicOutput??loadPublicOutputPolicy(),page,expectedHash,maxPages);
  });
  if(audit.input.audience!=="practitioner"&&audit.release.protocol==="liuren-v3")register("reopen_analysis","Leave final formatting to repair a missing source, judgment or other validation defect. Clears any pending public submission; does not bypass reading, citations, privacy or complete-analysis checks. Prepare output again after repair.",{reason:z.string().min(2).max(1000)},({reason})=>audit.reopenAnalysis(reason));
  register("submit_clarification",audit.input.audience==="practitioner"?"Ask one concrete missing-input or same-event scope question. No website formatting phase is required; privacy and permissions remain enforced.":"Ask one concrete missing-input or same-event scope question. This returns no paid report and no consumed turn. In liuren-v3 first complete prepare_public_output(kind=clarification); this ends analysis.",{question:z.string().min(5).max(600)},({question})=>{audit.assertOutputReady("clarification");assertPublicText("clarification",question);audit.candidate={clarification:question};return{accepted:true};});
  if(audit.delivery){
    register("check_readiness","Read structured delivery blockers and separate internal audit warnings. Does not freeze analysis.",{offset:z.number().int().min(0).optional()},({offset=0})=>audit.delivery!.page(audit.delivery!.check(),offset));
    register("submit_report","Submit the complete customer-facing body and one answer/undetermined entry per current question. Server binds chart/version and supplies title/summary defaults. Internal citation counts and audit forms do not block delivery. Adopted quotes must be genuine and fully read. Limited answers are explicitly labelled and free. Draft is saved before checks; returned blockers identify local repairs.",reportSubmissionSchema.shape,async arg=>{
      const result=await audit.delivery!.submit(arg);
      if(result.accepted){if(audit.candidate?.report)audit.candidate.report.chart=publicChart(audit.chart);return result;}
      return result;
    });
    register("repair_report","Patch only specified draft fields. answerPatches updates a single question without rewriting others. Untouched fields, citations and limitations remain. Version prevents overwriting another repair.",{draftVersion:z.number().int().positive(),patch:reportPatchSchema,answerPatches:z.array(answerPatchSchema).max(20).optional()},async({draftVersion,patch,answerPatches=[]})=>{const d=audit.delivery!.draft;if(!d||d.version!==draftVersion)throw new Error("draft_revision_mismatch");if(d.snapshot!==audit.delivery!.snapshot)throw new Error('draft_snapshot_changed');const next:ReportSubmission={...d.submission,...patch};for(const p of answerPatches){const n=next.answers.findIndex(x=>x.questionId===p.questionId);if(n<0)throw new Error('unknown_draft_question');next.answers=next.answers.map((x,i)=>i===n?{...x,...p.patch}:x);}const result=await audit.delivery!.submit(next);if(result.accepted&&audit.candidate?.report)audit.candidate.report.chart=publicChart(audit.chart);return result;});
  }else {
  register("submit_report",audit.input.audience==="practitioner"?"Submit a professional interpretation after all required judgments, reading and >=3 verified citations. Explain technical chart relationships, methods, contrary evidence and uncertainty. Keep credentials, backend data, paths, tool identifiers and private case identities out of all delivered fields. No website formatting skill is required.":"Submit a public report only after completing all stages and cases review. The citations field is internal audit data only: exact source quotes from documents actually read remain required. All other fields are public: use the website output policy, explain key chart evidence with a few standard terms and plain explanations; keep private source names, paths, case IDs, proprietary techniques, tools, thoughts and raw JSON internal. Follow-up content follows the same public policy.",{title:z.string().min(2).max(100),summary:z.string().min(20).max(600),content:z.string().min(200).max(65536),citations:z.array(citation).min(3).max(12),warnings:z.array(z.string().max(300)).max(10)},arg=>{
    audit.assertOutputReady("report");assertReportIntegrity(arg.content);const warnings=audit.input.audience==="practitioner"?validatePractitionerReport(arg,audit.chart.warnings):validatePublicReport(arg,audit.chart.warnings,audit.input.input.locale);
    for(const c of arg.citations)audit.cite(c.id,c.quote);
    audit.candidate=audit.input.kind==="initial"?{report:{title:arg.title,summary:arg.summary,content:arg.content,chart:publicChart(audit.chart),warnings}}:{answer:arg.content};
    try{audit.assertComplete();}catch(e){audit.candidate=undefined;throw e;}return{accepted:true,chartHash:audit.chart.hash};
  });
  }
  return server;
}
