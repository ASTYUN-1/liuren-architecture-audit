# 问衡生产 AI 与六壬适配

2026-10-18 输入机制：`input-intent.ts`使用官方Flash/high理解自然语言，先配置参数、确认，再起盘。文字中的明确要求（含汉字时间/报数/方法/规则）优先于页面辅助设置；不确定先澄清。原事件和`chartRequest`分开保存，按版本冻结计算结果以保持一次分析一致，用户更正不被旧盘阻止。更正的旧报告/盘存于case_inputs，历史追问不进入新版研判；MCP权限与算术结果不由用户文字修改。输入整理不扣用户解读积分，调用用量单独审计并限流。旧机制已交付且未有确认凭据的档案可首次自动免费纠正，资格由服务端控制，AI不授予金额或权益。语音使用浏览器识别，转写可编辑；无支持时显示降级提示。见项目docs/输入意图优先与同档案纠正发布-20261018.md。

2026-10-17 19:15工具额度修复版本：仅启用自有 `wenheng` MCP，`plugin: []`；主/案例子智能体维持官方 `deepseek-flash`、thinking enabled、high，96工具/32请求/10分钟上限。工具结果包含剩余额度；耗尽后及时停止并记录明确错误，不整轮重跑确定性流程故障；新一轮清除旧错误提示。完整分页与引用要求保留。见项目docs/解析工具额度与重试修复-20261017.md。下方初版费用预算和未有凭据描述是历史说明，计费以积分欠费结算专项为准。

`tools/build-knowledge-release.py --output <新目录>`（在项目根执行）构建只读资料副本及 `knowledge-manifest.json`。加载时核对来源、索引、片段哈希，拒绝路径越界、软链接与缺失/过期文件；清单与技能哈希共同决定 knowledgeVersion。清单缺失时仅供旧版/测试兼容；生产版本须经发布清单验收。源文和索引的历史正确性仍须校勘，哈希只保证发布绑定。初始化资料损坏以 knowledge_release_invalid 和零供应商调用/费用失败。

发布包含171案例文档、28条事件经验、18古籍注解、17通用经验/摘要及57份六壬原书/速查来源；案例与复盘未做事件去重。保留较新的主 skill，六份扩展在发布副本中合并并加适用边界，本地原 skill 不修改。八字/终身研究、金口诀、审查任务书和重复书不启用。

`list_knowledge` 返回26项技能目录及精确/安全别名占类，`referencesOffset` 翻阅每页5个参考来源。`search_knowledge({query,scope:"references"})` 无需占类，按字面检索通用经验、注解和书籍；`skills` 查询技能，`cases`/`all` 需传 category。每次最多5个有限片段，通过 offset 翻页；片段不算已读。

`read_knowledge({id,page:1})` 每次至多8000 UTF-8字节，后续页必须使用 expectedHash=deliveryHash，按 missingPages 补齐。技能/事件案例须读完整文档；参考资料每段至多6000字节，完整读段后才可引用该段，不代表读完全书。原始字节、解码方式、原书哈希、解码哈希、段号、行号及解码字节范围均可追溯；UTF-8/GB18030转码无替换字符，按段拼接须与完整解码原文相同。usage.knowledgeCoverage是送达覆盖，不是理解证明。

`search_cases` 同查案例和事件经验，消费与原文绑定的归一化索引。只回填缺失字段，metadataOrigins标记来源、metadataConflicts保留矛盾并优先正文；反馈原值不丢弃。安全同义：学业/考试、财运/交易、家宅/宅门、健康/疾病；禁止感情/胎产、疾病/灾厄、出行/行人、事业/比赛合并。六维原始分×反馈系数（验1.1、部分验1、其余0.8），60/45只分强/有限类比，低分仅背景；不验资料标counterexample。pool计文档数，smallPool提示不足；不等于独立验证样本。高分/验反馈均不能覆盖当前课象。

验收：`tests/knowledge-release.test.ts` 检查索引冲突、原书逐段还原、边界/损坏和零费用保护；`tests/knowledge-tools.test.ts` 检查真实MCP分页与引用闸门。`WENHENG_RUNTIME_FIXTURE=1` 联合运行 agent-runtime 与 skill-delivery-audit，真实OpenCode/MCP，仅官方供应商HTTP由fixture拦截；从下一轮实际模型请求重组技能和参考段并核对哈希。Python构建回归为 `python -X utf8 -m unittest discover -s tools/tests -p test_knowledge_release.py`。

业务 worker 调用 `runInterpretation`。初次返回 `report`，追问返回 `answer`，需要澄清返回 `clarification`；后者不交付付费答案、不消耗追问。始终另返内部 `chart`、`evidence`、`usage`，内部课式禁止通过 CaseDetail 直接返回。前端课面只用 `publicChart`；报告及文字导出不含原始课式。

输入包括 `taskId`、`caseId`、`kind`、已冻结的 `CaseInput`、`history`、`question?`、`report?`、`previousChart?`、`signal?`、`apiKey?`、`budgetCny?`、`onProgress?`。追问必须提供原快照，校验整个输入和快照哈希，不能自动重新排盘。初次排盘必须有含 UTC 偏移的确认时刻；默认当前时刻应由确认 HTTP 请求记录，worker 不重新取时间。

`apiKey` 由后台解密后传入，不进 OpenCode 子进程环境、配置或工具资料。未配置时抛出 `InterpretationError("service_unavailable")`。失败携带本次调用的 `usage`，业务 worker 须跨 attempt 累加费用并将余下预算传入；每次默认主报告 ¥6、追问 ¥1.5，传入较小预算不会被提高。当前高峰价格按每百万输入 ¥2、缓存 ¥0.04、输出 ¥8 记账；正式供应商报价调整时同步更新网关与模型配置。

生产环境：

- `WENHENG_PROJECT_ROOT`：原引擎与批准知识资料的只读发布根。
- 发布根须有 `排盘工具魔改/js/{lunar,data,api,guize,paipan}.js`、`.opencode/skills`、`案例项目库`、`经验日志`。
- `OPENCODE_BIN`：锁定版本的 OpenCode CLI，缺省 `opencode`；当前集成实测 CLI 1.18.29、SDK 1.19.0。
- `DEEPSEEK_API_KEY`：仅在不使用后台动态配置时由外层 worker 提供，禁止提交到仓库。
- `NODE_ENV=production`，生产禁止 `WENHENG_RUNTIME_FIXTURE=1`。

每任务创建独立临时工作区、XDG 目录、私网 OpenCode、持有随机令牌的 MCP/模型网关。MCP 工具只绑定当前事件、确定性排盘和批准来源 ID，没有任意 Shell、路径读取、写知识库、管理后台或支付权限。主与案例子智能体显式同为 `deepseek-flash`、思考 high。网关固定 DeepSeek 官方 HTTPS 地址，逐请求预留预算，供应商失败/未知用量保守计费，不暴露思考内容。最长 10 分钟，最多 32 模型请求、64 工具调用；八技能、真实案例子智能体执行和引文均通过核验才交付。

排盘在 VM 内使用北京 Date，不改宿主 TZ；复用原四课/三传代码。报数 1–999999999 循环；四柱无日期时清除技术占位日期、农历、节气、应期日期。已知日期则核对年、月、日柱，矛盾拒绝。人物原信息保留，已知本命有来源，已知真实占年及出生年/性别时调用原 `GetXingNian`。只有出生年份的本命年柱注明按立春后暂取，不冒充已确认；出生在立春当日且缺时刻则不猜年命基数。

验证（在 web 目录）：

```powershell
node node_modules/tsx/dist/cli.mjs --test tests/engine.test.ts tests/agent.test.ts
$env:WENHENG_RUNTIME_FIXTURE='1'
node node_modules/tsx/dist/cli.mjs --test tests/agent-runtime.test.ts
```

Linux fixture 命令：`WENHENG_RUNTIME_FIXTURE=1 node node_modules/tsx/dist/cli.mjs --test tests/agent-runtime.test.ts`。fixture 只在测试文件将官方 HTTP 请求拦截成明确测试内容，仍使用真实 OpenCode 主子智能体和 MCP 协议；没有生产假报告分支。2026-10-15 共 15 个测试通过，包括晚子时/零点、报数边界、四柱日期、串盘、年命行年、独立北京时区原库对照、预算和权限、真实完整工具链与 reasoning_content 回传。尚无真实供应商凭据，不能以 fixture 结果声称解读质量、成本分位数和稳定性已经通过付费验收。

协议依据：[OpenCode SDK](https://opencode.ai/docs/sdk/)、[Agents](https://opencode.ai/docs/agents/)、[配置 schema](https://opencode.ai/config.json)。
