import type {ChildProcess} from "node:child_process";
// Reap the dedicated OpenCode child before removing its workspace. Escalate a
// child that ignores graceful termination, and never leave cleanup timers alive.
export async function stopRuntimeChild(child?:ChildProcess){
 if(!child||child.exitCode!==null||child.signalCode!==null||!child.pid)return;
 await new Promise<void>((resolve,reject)=>{
  const cleanup=()=>{clearTimeout(force);clearTimeout(expiry);child.off("exit",done);child.off("error",failed);};
  const done=()=>{cleanup();resolve();};
  const failed=()=>{cleanup();reject(new Error("opencode_cleanup_failed"));};
  const force=setTimeout(()=>{try{child.kill("SIGKILL");}catch{failed();}},2000);
  const expiry=setTimeout(failed,5000);
  child.once("exit",done);child.once("error",failed);
  try{child.kill();}catch{failed();}
 });
}
