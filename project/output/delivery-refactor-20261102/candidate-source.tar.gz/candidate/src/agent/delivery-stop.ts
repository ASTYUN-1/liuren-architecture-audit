import type {ServerResponse} from 'node:http';
/** Match the SDK's streaming transport even when no supplier call is needed. */
export function localDeliveryStop(res:ServerResponse){
 const frame={id:'local_delivery_stop',object:'chat.completion.chunk',created:Math.floor(Date.now()/1000),model:'deepseek-flash'};
 res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-store'});
 for(const value of [
  {...frame,choices:[{index:0,delta:{role:'assistant',content:'本轮结束，交由服务端核对交付状态。'},finish_reason:null}]},
  {...frame,choices:[{index:0,delta:{},finish_reason:'stop'}]},
  {...frame,choices:[],usage:{prompt_tokens:0,completion_tokens:0}},
 ])res.write('data: '+JSON.stringify(value)+'\n\n');
 res.end('data: [DONE]\n\n');
}
