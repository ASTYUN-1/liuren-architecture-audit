export interface RuntimePerformanceEvent {
 atMs:number;type:"model_start"|"model_first_delta"|"model_end"|"tool_end";
 stage?:"preparing"|"reading"|"judging"|"formatting";
 request?:number;durationMs?:number;firstDeltaMs?:number;finishReason?:string;
 outcome?:string;tool?:string;ok?:boolean;code?:string;
 inputTokens?:number;outputTokens?:number;cachedInputTokens?:number;
}
export interface RuntimePerformanceSummary {
 version:1;events:RuntimePerformanceEvent[];droppedEvents:number;
 modelRequests:number;modelDurationMs:number;toolCalls:number;toolDurationMs:number;
 durationMs:number;toolGroups:Partial<Record<"knowledge"|"judgment"|"delivery"|"other",{calls:number;durationMs?:number}>>;
}
const safe=(v:unknown)=>typeof v==="string"&&/^[a-zA-Z0-9_:-]{1,80}$/.test(v)?v:undefined;
// Construct each field rather than copying arbitrary payloads. No content or IDs.
export class RuntimeTelemetry {
 private events:RuntimePerformanceEvent[]=[];private droppedEvents=0;
 private modelRequests=0;private modelDurationMs=0;private toolCalls=0;private toolDurationMs=0;
 private stage:RuntimePerformanceEvent["stage"]="preparing";
 private toolGroups:RuntimePerformanceSummary["toolGroups"]={};
 private started:number;
 constructor(private readonly callback?:(event:RuntimePerformanceEvent)=>Promise<void>|void,private readonly now=()=>Date.now(),private readonly capacity=120){this.started=now();}
 emit(value:Omit<RuntimePerformanceEvent,"atMs">){
  const e:RuntimePerformanceEvent={atMs:Math.max(0,this.now()-this.started),type:value.type};
  for(const k of ["request","durationMs","firstDeltaMs","inputTokens","outputTokens","cachedInputTokens"] as const){const n=value[k];if(typeof n==="number"&&Number.isSafeInteger(n)&&n>=0)e[k]=n;}
  for(const k of ["finishReason","outcome","tool","code"] as const){const v=safe(value[k]);if(v)e[k]=v;}
  if(typeof value.ok==="boolean")e.ok=value.ok;
  if(e.type==="model_start")this.modelRequests++;
  if(e.type==="model_end")this.modelDurationMs+=e.durationMs??0;
  if(e.type==="tool_end"){
   this.toolCalls++;this.toolDurationMs+=e.durationMs??0;
   const name=e.tool?.replace(/^wenheng_/,"")??"";
   const group=/^(list_knowledge|read_knowledge|read_knowledge_batch|resolve_knowledge_link|search_knowledge|search_cases|search_experience)$/.test(name)?"knowledge":/^(register_questions|record_judgment|record_workflow|record_stage|reopen_analysis)$/.test(name)?"judgment":/^(prepare_public_output|submit_report|submit_clarification|check_readiness|repair_report)$/.test(name)?"delivery":"other";
   const total=this.toolGroups[group]??={calls:0};total.calls++;if(e.durationMs!==undefined)total.durationMs=(total.durationMs??0)+e.durationMs;
   if(group==="knowledge")this.stage="reading";if(group==="judgment")this.stage="judging";if(group==="delivery")this.stage="formatting";
  }
  e.stage=this.stage;
  this.events.push(e);if(this.events.length>this.capacity){this.events.shift();this.droppedEvents++;}
  try{void Promise.resolve(this.callback?.({...e})).catch(()=>{});}catch{}
 }
 summary():RuntimePerformanceSummary{return {version:1,events:this.events.map(e=>({...e})),droppedEvents:this.droppedEvents,modelRequests:this.modelRequests,modelDurationMs:this.modelDurationMs,toolCalls:this.toolCalls,toolDurationMs:this.toolDurationMs,durationMs:Math.max(0,this.now()-this.started),toolGroups:structuredClone(this.toolGroups)};}
}
