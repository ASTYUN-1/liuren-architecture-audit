import {createHash,randomUUID} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {z} from 'zod';
import type {ToolAudit} from './tools';
import {assertReportIntegrity} from './workflow-delivery';
import {assertPublicText,validatePublicReport} from './public-output';
import {validatePractitionerReport} from './practitioner-output';
import type {Report} from '../server/contracts';
import {publicChart} from '../engine/liuren';

export type DeliveryProtocol='legacy'|'delivery-v2';
export const answerSchema=z.object({questionId:z.string().min(1).max(64),status:z.enum(['answered','undetermined']),answer:z.string().trim().min(5).max(2000),limitations:z.array(z.string().trim().min(2).max(500)).max(12).default([]),basis:z.object({facts:z.array(z.object({path:z.string().max(180),value:z.json()})).min(1).max(12),sourceIds:z.array(z.string().max(180)).min(1).max(8),explanation:z.string().trim().min(10).max(2000)}).optional()});
export const reportSubmissionSchema=z.strictObject({
 content:z.string().max(65536),title:z.string().max(100).optional(),summary:z.string().max(600).optional(),
 citations:z.array(z.object({id:z.string().min(1).max(180),quote:z.string().min(1).max(1000)})).max(30).default([]),
 warnings:z.array(z.string().max(300)).max(10).default([]),answers:z.array(answerSchema).min(1).max(20),
 outcome:z.enum(['complete','limited']).default('complete'),limitations:z.array(z.string().trim().min(2).max(500)).max(12).default([]),
});
// Zod 4 applies defaults inside optional fields; a generic partial() would
// silently clear citations/limitations when the model only patches a title.
export const reportPatchSchema=z.strictObject({content:reportSubmissionSchema.shape.content.optional(),title:reportSubmissionSchema.shape.title,summary:reportSubmissionSchema.shape.summary,citations:reportSubmissionSchema.shape.citations.removeDefault().optional(),warnings:reportSubmissionSchema.shape.warnings.removeDefault().optional(),answers:reportSubmissionSchema.shape.answers.optional(),outcome:reportSubmissionSchema.shape.outcome.removeDefault().optional(),limitations:reportSubmissionSchema.shape.limitations.removeDefault().optional()});
export const answerPatchSchema=z.strictObject({questionId:answerSchema.shape.questionId,patch:z.strictObject({status:answerSchema.shape.status.optional(),answer:answerSchema.shape.answer.optional(),limitations:answerSchema.shape.limitations.removeDefault().optional(),basis:answerSchema.shape.basis})});
export type ReportSubmission=z.infer<typeof reportSubmissionSchema>;
export interface DeliveryIssue {id:string;rule:string;severity:'blocker'|'warning';field:string;message:string;questionId?:string;sourceId?:string;missingPages?:number[];repair:string;}
export interface IssueRecord extends DeliveryIssue {state:'active'|'resolved';firstSeen:number;lastSeen:number;occurrences:number;}
export interface DeliveryDraft {id:string;rulesVersion?:string;version:number;snapshot:number;hash:string;submission:ReportSubmission;issues:DeliveryIssue[];at:string;}
export interface DeliveryReceipt {protocol:'delivery-v2';outcome:'complete'|'limited';limitations:string[];draftVersion:number;draftHash:string;hash:string;snapshot:number;}
const hash=(x:unknown)=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const issue=(rule:string,field:string,message:string,repair:string,extra:Partial<DeliveryIssue>={}):DeliveryIssue=>({id:hash([rule,extra.questionId||extra.sourceId?field.replace(/\.\d+/g,'.*'):field,extra.questionId??'',extra.sourceId??'']).slice(0,20),rule,field,message,repair,severity:'blocker',...extra});

/** A diagnostic tracks a particular unresolved defect, not adjacent tool calls. */
export class DeliveryIssues {
 private records=new Map<string,IssueRecord>();
 resolvedDropped=0;
 update(issues:DeliveryIssue[],now=Date.now()){
  const active=new Set(issues.map(x=>x.id));
  for(const r of this.records.values())if(!active.has(r.id)&&r.state==='active'){r.state='resolved';r.lastSeen=now;}
  for(const i of issues){const old=this.records.get(i.id);this.records.set(i.id,{...i,state:'active',firstSeen:old?.firstSeen??now,lastSeen:now,occurrences:(old?.occurrences??0)+1});}
  const resolved=[...this.records.values()].filter(x=>x.state==='resolved');for(const r of resolved.slice(0,Math.max(0,resolved.length-200))){this.records.delete(r.id);this.resolvedDropped++;}
 }
 summary(){return [...this.records.values()].map(x=>({...x}));}
}

/** Body storage is private business data; diagnostics never contain body or quotes. */
export class Delivery {
 readonly issues=new DeliveryIssues();
 snapshot=0;draft?:DeliveryDraft;receipt?:DeliveryReceipt;
 fatalError?:'delivery_storage_unavailable'|'delivery_task_stopped';
 firstDraftAt?:number;acceptedAt?:number;private started=Date.now();private version=0;
 private lastBlockers='';private repeats=0;repairStalled=false;private submissions=0;
 beginRecovery(){this.repairStalled=false;this.repeats=0;}
 constructor(private audit:ToolAudit,private persist?:(draft:DeliveryDraft)=>Promise<void>){}
 changed(){this.snapshot++;this.receipt=undefined;this.audit.candidate=undefined;}
 questions(){const q=this.audit.contract?.questions;return q?.size?[...q].map(([questionId,x])=>({questionId,question:x.question.originalQuestion,revision:x.revision})): [{questionId:'Q1',question:this.audit.input.question??this.audit.input.input.question,revision:1}];}
 private methodReadingIncomplete(){return !this.audit.readIds.has(this.audit.release.liurenRuntime?.entryId??'skill:daliuren/SKILL.md')||!!this.audit.contract?.missingModules().length;}
 private limited(s:ReportSubmission){return s.outcome==='limited'||s.answers.some(x=>x.status==='undetermined')||this.methodReadingIncomplete();}
 private limitations(s:ReportSubmission){return [...new Set([...s.limitations,...s.answers.flatMap(x=>x.limitations),...(this.methodReadingIncomplete()?[this.audit.input.input.locale==='en'?'Some required checks remain incomplete. The conclusions need further verification.':'本次部分必要依据核对尚未完成，结论仍需进一步复核。']:[])])];}
 private analysisWarnings():DeliveryIssue[]{
  const s=this.audit.status(),out:DeliveryIssue[]=[];
  const warning=(rule:string,field:string,message:string,repair:string)=>out.push(issue(rule,field,message,repair,{severity:'warning'}));
  if(!s.rootSkillRead)warning('ROOT_READING','analysis','主方法完整读取尚未登记','在分析过程中补齐主方法；不要为补登记重写报告');
  if(!s.caseSearched)warning('CASE_SEARCH','analysis','案例检索尚未登记','核对适用候选；没有适用案例可如实说明');
  if(this.audit.release.fineGrainedEnabled&&!s.experienceSearched)warning('EXPERIENCE_SEARCH','analysis','经验检索尚未登记','核对方法条件与反例');
  const c=s.contract;
  if(c){
   for(const q of c.missingQuestions)out.push(issue('JUDGMENT_RECORD','analysis','本问内部判断记录尚未完整保存','补内部记录或核对正文依据，不因登记形式缺项重写正文',{severity:'warning',questionId:q}));
   for(const m of c.missingModules)warning('MODULE_READING','module:'+m,'适用模块尚未完整登记读取','分析时补齐模块；引用未读原文仍会被单独阻断');
   if(!c.sharedWorkflowRecorded)warning('WORKFLOW_RECORD','analysis','共享核查摘要尚未登记','分析过程中补登记；不以此单项否决正文');
  }else for(const m of s.missingStages)warning('STAGE_RECORD','stage:'+m,'方法应用摘要尚未登记','分析过程中补登记');
  return out;
 }
 check(submission=this.draft?.submission){
  const out=this.analysisWarnings(),a=this.audit;
  if(!a.chartRead)out.push(issue('CHART_INCOMPLETE','chart','固定盘未完整送达','调用calculate_chart补齐missingPages'));
  const context=a.contextDelivery();
  if(!context.read||!context.complete)out.push(issue('CONTEXT_INCOMPLETE','context','本任务问题与历史未完整送达','调用read_case并补齐missingPages',{missingPages:context.missingPages}));
  try{a.assertOutputReady('report');}catch{const p=a.outputCoverage();out.push(issue('OUTPUT_POLICY_INCOMPLETE','outputPolicy','最终输出规范尚未完整送达','调用prepare_public_output(kind=report)补齐缺页',{missingPages:p?Array.from({length:p.pageCount},(_,i)=>i+1).filter(n=>!p.deliveredPages.includes(n)):undefined}));}
  if(!submission)out.push(issue('REPORT_MISSING','content','尚未收到明确报告候选','使用submit_report提交正文及逐问回答；不要重复整轮分析'));
  if(submission){
   const capture=(fn:()=>void,field:string)=>{try{fn();}catch(e){const code=e instanceof Error?e.message.split(':')[0]:'report_invalid';out.push(issue(code.toUpperCase(),field,'该字段未通过完整性或信息边界检查','只修改该字段；内部ID、路径、凭据与可执行内容不得交付'));}};
   capture(()=>assertReportIntegrity(submission.content),'content');
   if(submission.content.trim().length<80)out.push(issue('BODY_TOO_SHORT','content','正文尚不足以构成实际回答','提交完整可读回答，不能用状态说明代替结果'));
   for(const field of ['title','summary','content'] as const)capture(()=>assertPublicText(field,submission[field]??''),field);
   submission.warnings.forEach((v,i)=>capture(()=>assertPublicText('warnings',v),'warnings.'+i));
   submission.limitations.forEach((v,i)=>capture(()=>assertPublicText('limitations',v),'limitations.'+i));
   for(const q of this.questions()){
    const found=submission.answers.filter(x=>x.questionId===q.questionId);
    if(found.length!==1)out.push(issue('QUESTION_COVERAGE','answers','本问须有且只有一个回答或明确未定项','使用check_readiness给出的questionId逐项回应',{questionId:q.questionId}));
   }
   const known=new Set(this.questions().map(x=>x.questionId));
   for(const [n,x] of submission.answers.entries()){
    if(!known.has(x.questionId))out.push(issue('QUESTION_UNKNOWN','answers.'+n,'回答使用了未登记问项','使用当前questionId；新增问项先登记'));
    capture(()=>assertPublicText('answer',x.answer),'answers.'+n+'.answer');
    x.limitations.forEach((v,i)=>capture(()=>assertPublicText('limitation',v),'answers.'+n+'.limitations.'+i));
    if(x.status==='undetermined'&&!x.limitations.length)out.push(issue('LIMITATION_REQUIRED','answers.'+n,'未定项须说明实际缺口','为本问写明无法确定的原因',{questionId:x.questionId}));
    if(x.status==='answered'){
     const record=a.contract?.records.get(x.questionId);
     if(record&&(record.decision.status==='undetermined'||record.unresolved.some(u=>u.important)))out.push(issue('JUDGMENT_UNRESOLVED','answers.'+n,'已有判断仍含关键未定项','先核实关键缺口，或把本问标为undetermined并写明原因',{questionId:x.questionId}));
     if(!record&&!x.basis)out.push(issue('ANSWER_BASIS_REQUIRED','answers.'+n,'主要回答缺少可核对依据','提供basis中的盘面事实、已读方法来源和支持说明，或明确未定及原因',{questionId:x.questionId}));
     if(x.basis){
      for(const f of x.basis.facts){let actual:unknown=a.chart.facts;for(const key of f.path.split('.'))actual=['__proto__','constructor','prototype'].includes(key)?undefined:(actual as Record<string,unknown>|undefined)?.[key];if(actual===undefined||!isDeepStrictEqual(actual,f.value))out.push(issue('FACT_MISMATCH','answers.'+n+'.basis.facts','依据与固定盘不一致','从calculate_chart复制原字段和值，不自行重算',{questionId:x.questionId}));}
      for(const id of x.basis.sourceIds)if(!a.readIds.has(id))out.push(issue('SOURCE_INCOMPLETE','answers.'+n+'.basis.sourceIds','实际采用的方法来源尚未完整送达','补齐本问采用的来源，或撤回依赖它的判断',{questionId:x.questionId,sourceId:this.safeSourceId(id),missingPages:this.missingPages(id)}));
     }
    }
   }
   if(submission.outcome==='limited'&&!submission.limitations.length&&!submission.answers.some(x=>x.limitations.length))out.push(issue('LIMITATION_REQUIRED','limitations','受限回答须明确限制','说明未完成或不能确定的部分'));
   for(const [n,c] of submission.citations.entries()){
    if(!a.readIds.has(c.id))out.push(issue('SOURCE_INCOMPLETE','citations.'+n,'采用的引用来源尚未完整送达','补齐该来源缺页或撤回依赖此来源的主张及引用',{sourceId:this.safeSourceId(c.id),missingPages:this.missingPages(c.id)}));
    else try{a.release.evidence(c.id,c.quote);}catch{out.push(issue('QUOTE_MISMATCH','citations.'+n,'引文与已读来源不匹配','核对原文后只修正该引文；不得编造引文',{sourceId:c.id}));}
   }
   // Unsafe markup/links are rejected before storage can ever become delivery.
   const publicFields:[string,string][]=[...(['content','summary','title'] as const).map(field=>[field,submission[field]??''] as [string,string]),...submission.warnings.map((s,n)=>['warnings.'+n,s] as [string,string]),...submission.limitations.map((s,n)=>['limitations.'+n,s] as [string,string]),...submission.answers.flatMap((x,n)=>[['answers.'+n+'.answer',x.answer] as [string,string],...x.limitations.map((s,m)=>['answers.'+n+'.limitations.'+m,s] as [string,string])])];
   for(const [field,text] of publicFields)if(/<\/?(?:script|iframe|object|embed|form)\b|(?:javascript|vbscript|data):/i.test(text))out.push(issue('UNSAFE_MARKUP',field,'存在可执行标记或不安全链接','移除可执行内容，保留普通正文'));
   capture(()=>{const content=this.compose(submission);assertReportIntegrity(content);assertPublicText('content',content);},'assembledContent');
   capture(()=>{const display={...submission,title:submission.title??'',summary:submission.summary??''};if(a.input.audience==='practitioner')validatePractitionerReport(display,a.chart.warnings);else validatePublicReport(display,a.chart.warnings,a.input.input.locale);},'engineWarnings');
  }
  this.issues.update(out);
  return {schemaVersion:1,protocol:'delivery-v2',snapshotVersion:this.snapshot,canSubmit:!out.some(x=>x.severity==='blocker'),questions:this.questions().map(({questionId,revision})=>({questionId,revision})),issues:out,issueTotal:out.length};
 }
 private safeSourceId(id:string){try{this.audit.release.page(id);return id;}catch{return 'unpublished-'+hash(id).slice(0,16);}}
 private compose(s:ReportSubmission){const english=this.audit.input.input.locale==='en',limited=this.limited(s),heading=english?'Answers and limitations':'逐问回应与限制',limitations=this.limitations(s);const answers=s.answers.map((x,n)=>`${english?'Question':'问题'} ${n+1}\n\n${x.answer}${x.limitations.length?'\n\n'+x.limitations.join('；'):''}`).join('\n\n');return (limited?(english?'Limited answer · No credits or follow-up turn consumed':'带限制回答 · 本轮不扣积分或追问次数')+'\n\n':'')+s.content+'\n\n### '+heading+'\n\n'+answers+(limitations.length?'\n\n'+limitations.join('；'):'');}
 private missingPages(id:string){try{const p=this.audit.release.page(id),c=this.audit.coverage().find(x=>x.id===id);return Array.from({length:p.pageCount},(_,i)=>i+1).filter(n=>!c?.deliveredPages.includes(n));}catch{return undefined;}}
 page(result:ReturnType<Delivery['check']>,offset=0){const issues:DeliveryIssue[]=[];for(const i of result.issues.slice(offset)){if(issues.length>=20||Buffer.byteLength(JSON.stringify({...result,issues:[...issues,i]}))>30*1024)break;issues.push(i);}return {...result,issues,nextOffset:offset+issues.length<result.issues.length?offset+issues.length:null};}
 private async save(draft:DeliveryDraft){try{await this.persist?.(structuredClone(draft));}catch(e){this.fatalError=e instanceof Error&&e.message==='delivery_task_stopped'?'delivery_task_stopped':'delivery_storage_unavailable';throw new Error(this.fatalError);}}
 async submit(value:ReportSubmission){
  this.audit.input.signal?.throwIfAborted();
  const submission=reportSubmissionSchema.parse(value),snapshot=this.snapshot,version=++this.version;
  this.firstDraftAt??=Date.now();this.receipt=undefined;this.audit.candidate=undefined;
  const draft:DeliveryDraft={id:randomUUID(),rulesVersion:'delivery-v2-20261103-01',version,snapshot,hash:hash(submission),submission:structuredClone(submission),issues:[],at:new Date().toISOString()};
  this.draft=draft;
  await this.save(draft); // No accepted result until durable write completes.
  this.audit.input.signal?.throwIfAborted();
  if(this.snapshot!==snapshot||this.draft?.version!==version)throw new Error('delivery_snapshot_changed');
  const result=this.check(submission);
  draft.issues=result.issues;
  await this.save(draft);
  this.audit.input.signal?.throwIfAborted();
  if(this.snapshot!==snapshot||this.draft?.version!==version)throw new Error('delivery_snapshot_changed');
  this.submissions++;
  const blockers=result.issues.filter(x=>x.severity==='blocker');
  const fingerprint=hash(blockers.map(x=>[x.id,x.missingPages]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))));
  this.repeats=blockers.length&&fingerprint===this.lastBlockers?this.repeats+1:1;this.lastBlockers=fingerprint;
  this.repairStalled=blockers.length>0&&this.repeats>=3;
  if(!result.canSubmit)return {accepted:false as const,draftVersion:version,repairStalled:this.repairStalled,...this.page(result)};
  const display={...submission,title:submission.title??"",summary:submission.summary??""};
  let warnings=this.audit.input.audience==='practitioner'?validatePractitionerReport(display,this.audit.chart.warnings):validatePublicReport(display,this.audit.chart.warnings,this.audit.input.input.locale);
  const limited=this.limited(submission);
  const limitations=this.limitations(submission);
  const content=this.compose(submission);
  assertReportIntegrity(content);assertPublicText('content',content);
  for(const c of submission.citations)this.audit.cite(c.id,c.quote);
  const title=submission.title?.trim()||(this.audit.input.input.locale==='en'?'Interpretation':'问事解读');
  const summary=submission.summary?.trim()||(limited?(this.audit.input.input.locale==='en'?'An answer with stated limitations.':'本次回答含明确的未定项或限制。'):(this.audit.input.input.locale==='en'?'The interpretation is ready.':'本次解读已生成。'));
  const receipt:DeliveryReceipt={protocol:'delivery-v2',outcome:limited?'limited':'complete',limitations,draftVersion:version,draftHash:draft.hash,hash:hash({title,summary,content,warnings,chartHash:this.audit.chart.hash}),snapshot};
  const report:Report={title,summary,content,chart:publicChart(this.audit.chart),warnings,delivery:{outcome:receipt.outcome,limitations}};
  this.audit.candidate=this.audit.input.kind==='initial'?{report}:{answer:content};
  this.receipt=receipt;this.acceptedAt=Date.now();
  return {accepted:true as const,draftVersion:version,outcome:receipt.outcome,diagnosticWarnings:result.issues.filter(x=>x.severity==='warning').length};
 }
 assertAccepted(){if(!this.receipt||!this.audit.candidate||this.receipt.snapshot!==this.snapshot)throw new Error('report_not_submitted');const c=this.audit.candidate,r=c.report;if(r&&this.receipt.hash!==hash({title:r.title,summary:r.summary,content:r.content,warnings:r.warnings,chartHash:this.audit.chart.hash})||c.answer&&c.answer!==this.compose(this.draft!.submission))throw new Error('delivery_content_changed');}
 diagnostics(){return {protocol:'delivery-v2',rulesVersion:'delivery-v2-20261103-01',resolvedIssuesDropped:this.issues.resolvedDropped,snapshot:this.snapshot,draftVersion:this.draft?.version??0,submissions:this.submissions,noProgressRounds:this.repeats,repairStalled:this.repairStalled,firstDraftMs:this.firstDraftAt===undefined?null:this.firstDraftAt-this.started,deliveryMs:this.acceptedAt===undefined?null:this.acceptedAt-(this.firstDraftAt??this.started),outcome:this.receipt?.outcome??null,issues:this.issues.summary()};}
}
