import type { Metadata } from "next";
import { AppProvider } from "@/components/app-provider";
import { Header, Footer } from "@/components/shell";
import "./globals.css";
import {publicUiEnabled} from "@/server/beta-access";
export const metadata: Metadata = { title: { default: "问衡 · 大六壬", template: "%s · 问衡 · 大六壬" }, description: "把一件事，问清楚。一事一档的大六壬 AI 辅助解读与追问。" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="zh-CN"><body><AppProvider><a className="skip-link" href="#main">跳到正文 / Skip to content</a><Header newSite={publicUiEnabled()} /><main id="main">{children}</main><Footer newSite={publicUiEnabled()} /></AppProvider></body></html>; }
