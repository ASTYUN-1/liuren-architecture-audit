import {headers} from 'next/headers';
import {notFound} from 'next/navigation';
import {betaActor,publicUiEnabled} from '@/server/beta-access';
import {AppError} from '@/server/http';
import {showcaseCases} from '@/lib/case-showcase';
import {BetaWorkspace} from '@/components/beta-workspace';
export const dynamic='force-dynamic';
export async function generateMetadata(){return publicUiEnabled()?{title:'问衡 · 大六壬'}:{title:'新版内测',robots:{index:false,follow:false}};}
export default async function Page({params}:{params:Promise<{path?:string[]}>}){
 if(!publicUiEnabled())try{await betaActor(new Request('http://localhost/beta',{headers:await headers()}));}catch(e){if(e instanceof AppError&&[401,403].includes(e.status))notFound();throw e;}
 const {path=[]}=await params;
 const route=path.join('/');
 if(!['','cases','wallet','chart','assistance','help','terms','privacy','account','practitioner','admin','payments','examples'].includes(route)&&!showcaseCases.some(c=>route==='examples/'+c.slug)&&!/^cases\/[a-f0-9-]{36}$/.test(route))notFound();
 return <BetaWorkspace webDownload={!/WenhengAndroid\//i.test((await headers()).get('user-agent')||'')} publicMode={publicUiEnabled()} route={route} showcases={route==='examples'||route.startsWith('examples/')?showcaseCases:undefined}/>;
}
