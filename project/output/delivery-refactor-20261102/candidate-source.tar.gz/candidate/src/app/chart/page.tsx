"use client";
import {EngineCredit} from "@/components/engine-credit";
import { useEffect, useRef, useState } from "react";
import { useApp } from "@/components/app-provider";
import { SelfChartForm } from "@/components/self-chart-form";
import { ProfessionalChart } from "@/components/professional-chart";
import { PageHeading } from "@/components/ui";
import { post } from "@/lib/api";
import type { ProfessionalChart as Chart, SelfChartInput } from "@/lib/professional-chart";

export default function ChartPage(){
  const {t}=useApp();
  const [busy,setBusy]=useState(false),[tab,setTab]=useState("settings"),[result,setResult]=useState<{chart:Chart;warnings:string[]}|null>(null);
  const workbench=useRef<HTMLDivElement>(null);
  useEffect(()=>{if(tab==="chart"&&result)workbench.current?.scrollIntoView({block:"start",behavior:"smooth"});},[result,tab]);
  async function create(input:SelfChartInput){setBusy(true);try{setResult(await post("/api/chart/professional",{input}));setTab("chart");}finally{setBusy(false);}}
  return <div className="page-container self-chart-page"><PageHeading title={t("自助排盘","Create a chart")} subtitle={t("正时、活时、四柱与真太阳时。按你的设定，起一课。","Clock time, number, pillars or true solar time. Create a chart with your settings.")}/>
    <EngineCredit/>
    <div ref={workbench} className="self-workbench-tabs" role="tablist" aria-label={t("自助排盘工作区","Chart workspace")}><button type="button" role="tab" aria-selected={tab==="settings"} aria-controls="self-settings" id="self-settings-tab" onClick={()=>setTab("settings")}>{t("起课设置","Settings")}</button><button type="button" role="tab" aria-selected={tab==="chart"} aria-controls="self-result" id="self-result-tab" onClick={()=>setTab("chart")}>{t("专业盘面","Chart")}</button>{result?<span>{result.chart.pillars.join("　")}</span>:null}</div>
    <div id="self-settings" role="tabpanel" aria-labelledby="self-settings-tab" hidden={tab!=="settings"}><SelfChartForm onConfirm={create} busy={busy}/></div>
    <div id="self-result" role="tabpanel" aria-labelledby="self-result-tab" hidden={tab!=="chart"}>{result?<ProfessionalChart {...result}/>:<div className="self-chart-empty"><span className="self-empty-seal">壬</span><h2>{t("尚未起课","No chart yet")}</h2><p>{t("先确认起课方式、时间与年命，再查看完整盘面。","Choose your method, time and personal information to create a chart.")}</p><button className="button secondary" onClick={()=>setTab("settings")}>{t("前往起课","Open settings")}</button></div>}</div>
  </div>;
}
