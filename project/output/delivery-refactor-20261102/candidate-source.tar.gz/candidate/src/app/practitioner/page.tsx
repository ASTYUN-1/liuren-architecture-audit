import {PractitionerWorkspace} from '@/components/practitioner-workspace';
export default function Page(){return <PractitionerWorkspace/>;}
