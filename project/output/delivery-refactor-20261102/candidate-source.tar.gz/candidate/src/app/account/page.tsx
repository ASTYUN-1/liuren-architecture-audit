import {PointsDashboard} from "@/components/points-dashboard";
export default function Account(){return <PointsDashboard/>;}
