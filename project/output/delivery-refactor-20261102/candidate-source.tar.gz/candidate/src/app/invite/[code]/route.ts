import { sqlClient } from "@/server/db";
import {requestAppOrigin} from "@/server/origins";
import {pointsConfig} from "@/server/points-config";

export async function GET(request: Request, context: { params: Promise<{ code: string }> }) {
  const { code } = await context.params;
  if ((await pointsConfig()).mode==='points') {
    const target=new URL('/register',requestAppOrigin(request));
    return new Response(null,{status:303,headers:{Location:target.href,'Cache-Control':'private, no-store','Referrer-Policy':'no-referrer','X-Robots-Tag':'noindex, nofollow','Set-Cookie':`wenheng_invite=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax${target.protocol==='https:'?'; Secure':''}`}});
  }
  const valid = /^[a-f0-9]{24}$/.test(code) && (await sqlClient()`SELECT user_id FROM referral_profiles WHERE code=${code}`).length > 0;
  const target = new URL(valid ? '/register?invited=1' : '/register?inviteError=1',requestAppOrigin(request));
  const headers = new Headers({ Location:target.href, 'Cache-Control':'private, no-store', 'Referrer-Policy':'no-referrer', 'X-Robots-Tag':'noindex, nofollow' });
  if (valid) headers.set('Set-Cookie',`wenheng_invite=${code}; Path=/; Max-Age=2592000; HttpOnly; SameSite=Lax${target.protocol==='https:'?'; Secure':''}`);
  else headers.set('Set-Cookie',`wenheng_invite=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax${target.protocol==='https:'?'; Secure':''}`);
  return new Response(null,{status:303,headers});
}
