import {api,actor,body} from "@/server/http";
import {retryTask} from "@/server/admin";
export const POST=api(async(req,ctx)=>retryTask(await actor(req,true,true),(await ctx.params).id,(await body(req)).reason));
