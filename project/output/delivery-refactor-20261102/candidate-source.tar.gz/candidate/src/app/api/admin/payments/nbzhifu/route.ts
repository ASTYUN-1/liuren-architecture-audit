import {api,actor,body} from '@/server/http';
import {listNbPayments,nbBalance,startNbPayment,publishNbPayments} from '@/server/nbzhifu';
export const dynamic='force-dynamic';
export const GET=api(async req=>{const a=await actor(req,true,true);return {...await listNbPayments(a,true),...await nbBalance(a)}});
export const POST=api(async req=>{const a=await actor(req,true,true),data=await body(req);return startNbPayment(a,{test:true,paytype:data.paytype},(req.headers.get('x-forwarded-for')||'').split(',')[0].trim())});
export const PATCH=api(async req=>{const a=await actor(req,true,true),data=await body(req);return publishNbPayments(a,data.enabled)});
