import {api,actor,body,rateLimit} from '@/server/http';
import {practitionerRoles,readConversationShare} from '@/server/conversation-sharing';
export const GET=api(async req=>practitionerRoles(await actor(req)));
export const POST=api(async req=>{const a=await actor(req);await rateLimit('share-read:'+a.id,60,3600);return Response.json({data:await readConversationShare(a,(await body(req)).code)},{headers:{'Cache-Control':'private, no-store'}});});
