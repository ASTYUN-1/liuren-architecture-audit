import {api,actor,body,rateLimit,AppError} from '@/server/http';
import {walletView,requestPointRefund} from '@/server/points';
import {drawAdvisor,requestHuman,humanAction} from '@/server/human-assist';
import {createPointsTask,cancelPointTask} from '@/server/points-ai';
import {caseDetail} from '@/server/service';
import {verifyIntent} from '@/server/input-intent';
import {requireTurnIntent} from '@/server/case-intent';
export const GET=api(async req=>walletView(await actor(req,false)));
export const POST=api(async req=>{const a=await actor(req);const d=await body(req);if(d.action==='ai')await rateLimit('ai-burst:'+a.id,12,60);else if(d.action!=='cancelTask')await rateLimit('points:'+a.id,60,3600);switch(d.action){case 'draw':return drawAdvisor(a,d.idempotencyKey);case 'human':return requestHuman(a,d);case 'humanAction':return humanAction(a,d.id,{...d,action:d.humanAction});case 'refund':return requestPointRefund(a,d);case 'ai':if(d.kind==='initial')verifyIntent(a,(await caseDetail(a,d.caseId)).input,{caseId:undefined});else await requireTurnIntent(a,d.caseId,d);return createPointsTask(a,d.caseId,d);case 'cancelTask':return cancelPointTask(a,d.taskId);default:throw new AppError('ACTION','操作无效');}});
