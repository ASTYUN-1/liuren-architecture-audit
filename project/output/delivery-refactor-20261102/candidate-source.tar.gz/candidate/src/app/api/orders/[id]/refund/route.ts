import {api,actor,body} from "@/server/http";
import {requestRefund} from "@/server/service";
export const POST=api(async(req,ctx)=>requestRefund(await actor(req),(await ctx.params).id,(await body(req)).reason||"申请退还未使用权益"));
