import {api,actor} from '@/server/http';
import {betaAllowed} from '@/server/beta-access';
export const dynamic='force-dynamic';
export const GET=api(async req=>Response.json({data:{allowed:betaAllowed(await actor(req))}},{headers:{'Cache-Control':'private, no-store'}}));
