import {api,actor,body,rateLimit} from '@/server/http';
import {certificationQueue,reviewPractitioner} from '@/server/practitioner-certification';
export const GET=api(async req=>certificationQueue(await actor(req,true,true)));
export const POST=api(async req=>{const a=await actor(req,true,true);await rateLimit('practitioner-review:'+a.id,60,3600);return reviewPractitioner(a,await body(req));});
