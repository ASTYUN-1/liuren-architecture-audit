import {api,actor,body,rateLimit} from '@/server/http';
import {resolveInput} from '@/server/input-intent';
import {inputIntentResponse} from '@/server/input-intent-response';
export const POST=api(async req=>{const a=await actor(req,false),data=await body(req);await rateLimit('intent-minute:'+a.id,6,60);return inputIntentResponse(req,signal=>resolveInput(a,data.input,{signal}));});
