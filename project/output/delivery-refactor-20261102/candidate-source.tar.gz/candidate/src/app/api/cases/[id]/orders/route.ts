import {api,actor,body,rateLimit} from "@/server/http";
import {createOrder} from "@/server/service";
export const POST=api(async(req,ctx)=>{const a=await actor(req);await rateLimit("order:"+a.id,20,3600);return createOrder(a,(await ctx.params).id,await body(req));});
