import {api,body} from '@/server/http';
import {profile} from '@/server/account-security';
export const POST=api(async req=>profile(req,await body(req)));
