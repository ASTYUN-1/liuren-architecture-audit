import {api,actor,body,rateLimit} from "@/server/http";
import {testConnection} from "@/server/settings";
export const POST=api(async req=>{const a=await actor(req,true,true);await rateLimit("connection-test:"+a.id,6,600);return testConnection(a,(await body(req)).kind);});
