import {z} from "zod";
import {api,body,AppError} from "@/server/http";
import {publicChartLimit} from "@/server/public-chart";
import {startRandomChart,stopRandomChart} from "@/engine/random-chart";
const schema=z.discriminatedUnion("action",[
  z.object({action:z.literal("start"),rules:z.record(z.string(),z.string().max(50)).default({})}),
  z.object({action:z.literal("stop"),ticket:z.string().max(5000),number:z.number().int().min(1).max(12)})
]);
export const POST=api(async req=>{
  await publicChartLimit(req);
  const parsed=schema.safeParse(await body(req));
  if(!parsed.success)throw new AppError("INVALID_RANDOM_INPUT","请检查随机起课设置");
  try {const v=parsed.data;return v.action==="start"?startRandomChart(v.rules):stopRandomChart(v.ticket,v.number);}
  catch{throw new AppError("RANDOM_CHART_INVALID","随机会话已失效或设置无效，请重新开始 / Start a new random selection");}
});
