import {api,actor} from "@/server/http";
import {sqlClient} from "@/server/db";
import {orderView} from "@/server/service";
export const GET=api(async req=>{const a=await actor(req,false);const orders=await sqlClient()`SELECT * FROM orders WHERE user_id=${a.id} ORDER BY created_at DESC LIMIT 200`;return {orders:orders.map(orderView)};});
