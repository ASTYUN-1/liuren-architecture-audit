import {api,actor,body} from '@/server/http';
import {checkNbPayment,listNbPayments,startNbPayment} from '@/server/nbzhifu';
export const dynamic='force-dynamic';
export const GET=api(async req=>{const a=await actor(req);const id=new URL(req.url).searchParams.get('payment');return id?checkNbPayment(a,id):listNbPayments(a)});
export const POST=api(async req=>{const a=await actor(req);const data=await body(req);return startNbPayment(a,{orderId:data.orderId,paytype:data.paytype},(req.headers.get('x-forwarded-for')||'').split(',')[0].trim())});
