import {walletTotals,requestPointRefund} from "@/server/points";
import {randomUUID} from "node:crypto";
import {api,actor,body,AppError} from "@/server/http";
import {sqlClient} from "@/server/db";
import {deleteCase} from "@/server/service";
export const POST=api(async req=>{const a=await actor(req);if((await body(req)).confirmation!=="DELETE")throw new AppError("CONFIRMATION_REQUIRED","请填写 DELETE 确认账户删除申请");const cases=await sqlClient()`SELECT id FROM cases WHERE user_id=${a.id} AND permanently_deleted=false`;for(const c of cases)await deleteCase(a,c.id,true);const balance=await walletTotals(sqlClient(),a.id);if(balance.paid>0)await requestPointRefund(a,{units:balance.paid,reason:"账户注销，申请未用实付积分退款",idempotencyKey:"delete-refund:"+randomUUID()});await sqlClient()`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'accountDeletionRequested',${a.id},${sqlClient().json({email:a.email,status:"pendingFinancialReconciliation"})})`;await sqlClient()`DELETE FROM session WHERE user_id=${a.id}`;return {requested:true,message:"账户删除申请已提交；先核对退款和财务记录，再由运营完成账户清理。"};});
