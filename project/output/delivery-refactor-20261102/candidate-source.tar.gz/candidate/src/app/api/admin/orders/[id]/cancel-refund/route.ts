import {api,actor,body} from "@/server/http";
import {cancelRefund} from "@/server/admin";
export const POST=api(async(req,ctx)=>cancelRefund(await actor(req,true,true),(await ctx.params).id,(await body(req)).reason));
