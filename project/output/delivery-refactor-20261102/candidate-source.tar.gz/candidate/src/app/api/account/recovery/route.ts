import {api,body} from '@/server/http';
import {rotateRecovery,recover} from '@/server/account-security';
export const POST=api(async req=>{const data=await body(req);return data.action==='rotate'?rotateRecovery(req,data):recover(req,data);});
