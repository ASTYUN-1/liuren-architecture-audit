import {AppError} from '@/server/http';
import {handleNbNotification} from '@/server/nbzhifu';
import {limitedText} from '@/server/request-body';
export const dynamic='force-dynamic';
export async function POST(request:Request){
 try{
   if(Number(request.headers.get('content-length')||0)>16384)return new Response('too large',{status:413});
   if(!request.headers.get('content-type')?.startsWith('application/x-www-form-urlencoded'))return new Response('unsupported content type',{status:415});
   const raw=await limitedText(request,16384);
   const form=new URLSearchParams(raw);const params:Record<string,string>={};
   for(const [key,value] of form){if(Object.hasOwn(params,key))return new Response('duplicate field',{status:400});Object.defineProperty(params,key,{value,enumerable:true});}
   await handleNbNotification(params);return new Response('success',{headers:{'Content-Type':'text/plain; charset=utf-8'}});
 }catch(e){return new Response('retry',{status:e instanceof AppError?e.status:503});}
}
