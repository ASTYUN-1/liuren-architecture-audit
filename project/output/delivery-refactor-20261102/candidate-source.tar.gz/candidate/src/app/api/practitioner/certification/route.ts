import {api,actor,body,rateLimit} from '@/server/http';
import {applyPractitioner,practitionerProfile} from '@/server/practitioner-certification';
export const GET=api(async req=>practitionerProfile((await actor(req,false)).id));
export const POST=api(async req=>{const a=await actor(req);await rateLimit('practitioner-apply:'+a.id,5,86400);return applyPractitioner(a,await body(req));});
