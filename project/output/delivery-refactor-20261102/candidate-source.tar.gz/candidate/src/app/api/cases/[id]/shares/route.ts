import {api,actor,body,rateLimit,AppError} from '@/server/http';
import {ownerShares,revokeConversationShare,renewConversationShare} from '@/server/conversation-sharing';
export const GET=api(async(req,ctx)=>{const a=await actor(req),{id}=await ctx.params;return Response.json({data:await ownerShares(a,id)},{headers:{'Cache-Control':'private, no-store'}});});
export const POST=api(async(req,ctx)=>{const a=await actor(req),{id}=await ctx.params;await rateLimit('share-revoke:'+a.id,30,3600);const d=await body(req);if(d.action==='renew'&&d.confirmed===true)return renewConversationShare(a,id,d.id);if(d.action!=='revoke')throw new AppError('BOOKING_REQUIRED','请先预约真人辅助，重新授权需明确确认',409);return revokeConversationShare(a,id,d.id);});
