const origin = 'https://wen.qiluhub.com';
const fallback = origin + '/downloads/android/wenheng-0.3.3.apk';

export const dynamic = 'force-dynamic';

export async function GET() {
  let target = fallback;
  try {
    const response = await fetch(origin + '/downloads/android/latest.json', {
      cache: 'no-store',
      redirect: 'error',
      signal: AbortSignal.timeout(4000),
    });
    if (response.ok) {
      const manifest: unknown = await response.json();
      const apkUrl = manifest && typeof manifest === 'object' && 'apkUrl' in manifest ? manifest.apkUrl : null;
      if (typeof apkUrl === 'string' && /^https:\/\/wen\.qiluhub\.com\/downloads\/android\/wenheng-\d+\.\d+\.\d+\.apk$/.test(apkUrl)) {
        target = apkUrl;
      }
    }
  } catch {
    // The last verified public APK remains available if the announcement is temporarily unavailable.
  }
  return new Response(null, {
    status: 307,
    headers: { Location: target, 'Cache-Control': 'no-store' },
  });
}

export const HEAD = GET;
