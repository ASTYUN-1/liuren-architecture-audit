import {api,body,rateLimit} from '@/server/http';
import {betaActor} from '@/server/beta-access';
import {completePartnerHuman} from '@/server/partner-human-redemption';
export const POST=api(async req=>{
 const a=await betaActor(req);await rateLimit('partner-complete:'+a.id,30,3600);
 return completePartnerHuman(a,await body(req));
});
