import {api,actor,body,rateLimit} from '@/server/http';
import {resolveCaseIntent} from '@/server/case-intent';
import {inputIntentResponse} from '@/server/input-intent-response';
export const POST=api(async(req,ctx)=>{const a=await actor(req),data=await body(req),id=(await ctx.params).id;await rateLimit('intent-minute:'+a.id,6,60);return inputIntentResponse(req,signal=>resolveCaseIntent(a,id,data.question,signal));});
