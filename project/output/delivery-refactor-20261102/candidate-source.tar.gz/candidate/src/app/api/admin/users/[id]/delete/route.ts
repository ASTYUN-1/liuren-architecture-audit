import {api,actor,body} from "@/server/http";
import {completeAccountDeletion} from "@/server/operations";
export const POST=api(async(req,ctx)=>completeAccountDeletion(await actor(req,true,true),(await ctx.params).id,(await body(req)).reason));
