import {api,actor,body} from '@/server/http';
import {resolveUsageReview} from '@/server/points-ai';
export const POST=api(async(req,ctx)=>resolveUsageReview(await actor(req,true,true),(await ctx.params).id,(await body(req)).reason));
