import {api,AppError} from "@/server/http";
export const POST=api(async()=>{throw new AppError("PROVIDER_DISABLED","Overseas payments are not connected yet",503);});
