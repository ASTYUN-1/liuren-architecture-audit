import {api,actor,body,AppError,rateLimit} from '@/server/http';
import {uuid} from '@/server/validation';
import {humanAction} from '@/server/human-assist';
import {humanAssistAdminView,quickRedeemHuman} from '@/server/human-assist-admin';

export const GET=api(async req=>humanAssistAdminView(await actor(req,true,true),new URL(req.url).searchParams));
export const POST=api(async req=>{
 const a=await actor(req,true,true);await rateLimit('admin-human:'+a.id,120,3600);
 const d=await body(req);
 if(d.action==='quickRedeem')return quickRedeemHuman(a,d.code);
 if(!['accept','redeem','refund'].includes(d.action))throw new AppError('ACTION','操作无效');
 if(typeof d.id!=='string')throw new AppError('INVALID_INPUT','请提供预约编号');
 return humanAction(a,uuid(d.id),d);
});
