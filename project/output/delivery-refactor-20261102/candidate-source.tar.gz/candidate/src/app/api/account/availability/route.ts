import {api} from '@/server/http';
import {authRate} from '@/server/account-security';
import {sqlClient} from '@/server/db';
import {validUsername} from '@/lib/account-identity';
export const GET=api(async req=>{await authRate(req,'availability');const value=(new URL(req.url).searchParams.get('username')||'').trim().toLowerCase();return {available:validUsername(value)&&!(await sqlClient()`SELECT id FROM "user" WHERE lower(username)=${value}`).length};});
