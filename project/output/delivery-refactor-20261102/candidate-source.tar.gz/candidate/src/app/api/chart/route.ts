import {api,body} from "@/server/http";
import {publicChartLimit} from "@/server/public-chart";
import {parseInput} from "@/server/validation";
import {calculateChart,publicChart} from "@/engine/liuren";
export const POST=api(async req=>{await publicChartLimit(req);const input=parseInput((await body(req)).input);const chart=calculateChart(input);return {chart:publicChart(chart),warnings:chart.warnings};});
