import {api,actor} from "@/server/http";
import {adminUsers,adminUserRecords,adminCaseView} from "@/server/users";
export const GET=api(async req=>{
  const admin=await actor(req,true,true), params=new URL(req.url).searchParams;
  const caseId=params.get('caseId');if(caseId!==null)return adminCaseView(admin,caseId);
  const id=params.get("userId");
  if(id!==null)return adminUserRecords(admin,id);
  const page=Math.max(1,Math.min(100000,Number(params.get("page"))||1));
  return adminUsers(admin,params.get("q")||"",Math.floor(page));
});
