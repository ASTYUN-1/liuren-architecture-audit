import {api,actor,body} from "@/server/http";
import {caseDetail,patchCase,deleteCase} from "@/server/service";
import {verifyIntent} from '@/server/input-intent';
import {parseInput} from '@/server/validation';
export const GET=api(async(req,ctx)=>caseDetail(await actor(req,false),(await ctx.params).id));
export const PATCH=api(async(req,ctx)=>{const a=await actor(req,false),data=await body(req);if(data.input){data.input=parseInput(data.input);verifyIntent(a,data.input,{caseId:undefined},true);}return patchCase(a,(await ctx.params).id,data);});
export const DELETE=api(async(req,ctx)=>deleteCase(await actor(req,false),(await ctx.params).id,(await body(req)).permanent===true));
