import {api,actor,body} from "@/server/http";
import {getSettings,updateSettings} from "@/server/settings";
export const GET=api(async req=>{await actor(req,true,true);return getSettings();});
export const PATCH=api(async req=>updateSettings(await actor(req,true,true),await body(req)));
