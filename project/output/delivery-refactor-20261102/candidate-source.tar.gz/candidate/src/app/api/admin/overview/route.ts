import {api,actor} from "@/server/http";
import {adminOverview} from "@/server/service";
export const GET=api(async req=>{return adminOverview(await actor(req,true,true));});

