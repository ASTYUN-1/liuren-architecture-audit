import {api} from "@/server/http";
import {paymentConfig} from "@/server/service";
export const dynamic="force-dynamic";
export const GET=api(async()=>({...await paymentConfig(),overseasPaymentsEnabled:false}));
