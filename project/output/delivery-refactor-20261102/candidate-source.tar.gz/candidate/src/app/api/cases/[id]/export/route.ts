import {api,actor} from "@/server/http";
import {exportCase} from "@/server/service";
export const GET=api(async(req,ctx)=>exportCase(await actor(req,false),(await ctx.params).id));
