import {actor,api} from '@/server/http';
import {resourceMonitor} from '@/server/resource-monitor';
export const dynamic='force-dynamic';
export const GET=api(async req=>Response.json({data:await resourceMonitor(await actor(req,true,true),new URL(req.url).searchParams.get('range'))},{headers:{'Cache-Control':'private, no-store'}}));
