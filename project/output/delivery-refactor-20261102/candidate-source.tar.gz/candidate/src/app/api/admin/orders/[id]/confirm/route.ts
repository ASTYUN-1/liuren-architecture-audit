import {api,actor,body} from "@/server/http";
import {confirmPayment} from "@/server/service";
export const POST=api(async(req,ctx)=>confirmPayment(await actor(req,true,true),(await ctx.params).id,await body(req)));
