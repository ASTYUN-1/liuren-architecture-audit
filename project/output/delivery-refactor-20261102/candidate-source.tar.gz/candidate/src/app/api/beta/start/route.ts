import {api,body,rateLimit} from '@/server/http';
import {betaActor} from '@/server/beta-access';
import {startBetaCase} from '@/server/beta-start';
export const POST=api(async req=>{const a=await betaActor(req);await rateLimit('beta-start:'+a.id,12,60);return startBetaCase(a,await body(req));});
