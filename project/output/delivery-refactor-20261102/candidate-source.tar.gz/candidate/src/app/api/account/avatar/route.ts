import { actor, api, AppError, rateLimit } from "@/server/http";
import { compressAvatar, readAvatarUpload, setAvatar } from "@/server/avatars";
export const runtime = "nodejs";
let processing = 0;
export const PUT = api(async request => {
  const user = await actor(request, false);
  await rateLimit(`avatar:${user.id}`, 10, 3600);
  if (processing >= 2) throw new AppError("RATE_LIMITED", "图片处理中，请稍后重试 / Please try again shortly", 429);
  processing++;
  try { return await setAvatar(user, await compressAvatar(await readAvatarUpload(request))); }
  finally { processing--; }
});
export const DELETE = api(async request => {
  const user = await actor(request, false);
  await rateLimit(`avatar:${user.id}`, 10, 3600);
  return setAvatar(user, null);
});
