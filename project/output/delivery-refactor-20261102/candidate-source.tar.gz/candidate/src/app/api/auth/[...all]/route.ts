import { getAuth } from "@/server/auth";
import {authRate} from '@/server/account-security';
import {AppError} from '@/server/http';
export const runtime="nodejs";
export async function GET(request:Request){return getAuth().handler(request);}
export async function POST(request:Request){
 try{
  if(new URL(request.url).pathname.includes('/sign-in/')){let data:any;try{data=await request.clone().json();}catch{return Response.json({message:'请求格式不正确'},{status:400});}await authRate(request,'signin',String(data.username||data.email||''));}
  const response=await getAuth().handler(request);
  if(response.status===401&&new URL(request.url).pathname.includes('/sign-in/'))return Response.json({message:'账号或密码不正确。',code:'INVALID_CREDENTIALS'},{status:401,headers:{'Cache-Control':'no-store'}});
  return response;
 }catch(e){if(e instanceof AppError)return Response.json({message:e.message,code:e.code},{status:e.status});throw e;}
}
