import {api,actor,body} from "@/server/http";
import {getOrder,submitPayment} from "@/server/service";
import {cancelUnpaidOrder} from "@/server/admin";
export const GET=api(async(req,ctx)=>getOrder(await actor(req,false),(await ctx.params).id));
export const PATCH=api(async(req,ctx)=>{const a=await actor(req),id=(await ctx.params).id,data=await body(req);return data.cancel===true?cancelUnpaidOrder(a,id):submitPayment(a,id,data);});
