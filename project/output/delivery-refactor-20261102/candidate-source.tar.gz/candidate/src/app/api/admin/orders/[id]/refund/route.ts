import {api,actor,body} from "@/server/http";
import {confirmRefund} from "@/server/service";
export const POST=api(async(req,ctx)=>confirmRefund(await actor(req,true,true),(await ctx.params).id,(await body(req)).reference));
