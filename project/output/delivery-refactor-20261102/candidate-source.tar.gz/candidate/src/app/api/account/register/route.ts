import {api,body} from '@/server/http';
import {signup} from '@/server/account-security';
export const runtime='nodejs';
export const POST=api(async req=>signup(req,await body(req)));
