import { api, body } from "@/server/http";
import { publicChartLimit } from "@/server/public-chart";
import { calculateSelfChart } from "@/engine/self-chart";

export const POST=api(async req=>{
  await publicChartLimit(req);
  return calculateSelfChart((await body(req)).input);
});
