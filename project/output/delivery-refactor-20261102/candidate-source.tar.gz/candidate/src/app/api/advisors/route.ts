import {randomInt} from 'node:crypto';
import {api,rateLimit} from '@/server/http';
import {pointsConfig} from '@/server/points-config';
export const dynamic='force-dynamic';
export const GET=api(async()=>{const cfg=await pointsConfig();return {advisors:cfg.advisors,humanEnabled:cfg.humanEnabled};});
export const POST=api(async()=>{await rateLimit('public-advisor-draw',120,60);const cfg=await pointsConfig();return {advisorId:cfg.advisors[randomInt(cfg.advisors.length)].id};});
