import {api,actor,body,rateLimit} from '@/server/http';
import {correctCaseInput} from '@/server/case-intent';
export const POST=api(async(req,ctx)=>{const a=await actor(req);await rateLimit('input-correction:'+a.id,12,60);return correctCaseInput(a,(await ctx.params).id,await body(req));});
