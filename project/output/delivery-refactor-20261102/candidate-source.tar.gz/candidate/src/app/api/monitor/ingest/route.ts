import {AppError} from '@/server/http';
import {limitedText} from '@/server/request-body';
import {ingestMonitor} from '@/server/resource-monitor';
export const dynamic='force-dynamic';
// Machine-only HMAC endpoint. No cookies, browser session, or arbitrary commands.
export async function POST(req:Request){try{return Response.json({data:await ingestMonitor(await limitedText(req,24576),req.headers)},{headers:{'Cache-Control':'no-store'}});}catch(e){if(e instanceof AppError)return Response.json({error:{code:e.code,message:e.message}},{status:e.status});console.error('Resource monitor ingestion unavailable');return Response.json({error:{code:'MONITOR_UNAVAILABLE',message:'Monitoring unavailable'}},{status:503});}}
