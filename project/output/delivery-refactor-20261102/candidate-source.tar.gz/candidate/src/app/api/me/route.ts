import {api,actor} from "@/server/http";
import {me} from "@/server/service";
export const GET=api(async req=>me(await actor(req,false)));
