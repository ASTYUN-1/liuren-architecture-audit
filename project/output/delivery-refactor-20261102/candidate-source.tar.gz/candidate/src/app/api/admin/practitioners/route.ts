import {api,actor,body,rateLimit} from '@/server/http';
import {managePractitioners} from '@/server/conversation-sharing';
export const GET=api(async req=>managePractitioners(await actor(req,true,true)));
export const POST=api(async req=>{const a=await actor(req,true,true);await rateLimit('practitioner-admin:'+a.id,60,3600);return managePractitioners(a,await body(req));});
