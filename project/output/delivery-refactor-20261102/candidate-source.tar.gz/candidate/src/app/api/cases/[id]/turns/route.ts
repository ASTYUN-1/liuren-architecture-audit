import {api,actor,body,rateLimit} from "@/server/http";
import {createTurn} from "@/server/service";
import {requireTurnIntent} from '@/server/case-intent';
export const POST=api(async(req,ctx)=>{const a=await actor(req);await rateLimit("turn:"+a.id,12,60);const id=(await ctx.params).id,data=await body(req);await requireTurnIntent(a,id,data);return createTurn(a,id,data);});
