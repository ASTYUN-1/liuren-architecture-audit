import {api,actor,body} from '@/server/http';
import {adminNotices,readAdminNotices} from '@/server/admin-notices';
export const GET=api(async req=>adminNotices(await actor(req,true,true)));
export const POST=api(async req=>readAdminNotices(await actor(req,true,true),await body(req)));
