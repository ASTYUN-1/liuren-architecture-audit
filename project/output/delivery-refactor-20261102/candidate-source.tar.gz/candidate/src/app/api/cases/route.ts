import {api,actor,body,rateLimit} from "@/server/http";
import {createCase,listCases} from "@/server/service";
import {verifyIntent} from '@/server/input-intent';
import {parseInput} from '@/server/validation';
export const GET=api(async req=>listCases(await actor(req,false),new URL(req.url).searchParams.get("deleted")==="true"));
export const POST=api(async req=>{const a=await actor(req,false);await rateLimit("case:"+a.id,12,60);const data=await body(req);data.input=parseInput(data.input);verifyIntent(a,data.input,{caseId:undefined},true);return createCase(a,data);});
