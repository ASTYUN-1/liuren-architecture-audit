"use client";
import Link from 'next/link';
import {useEffect,useState} from 'react';
import {api} from '@/lib/api';
import {useApp} from '@/components/app-provider';
import {GatewayPayment,type GatewayPaymentView} from '@/components/gateway-payment';
import {Notice} from '@/components/ui';
export default function PaymentReturn(){const {me,loading,t}=useApp();const [payment,setPayment]=useState<GatewayPaymentView|null>(null),[error,setError]=useState('');useEffect(()=>{if(!me)return;const id=new URLSearchParams(window.location.search).get('payment');if(!id){setError(t('缺少支付编号','Payment ID missing'));return}api<GatewayPaymentView>('/api/payments/nbzhifu?payment='+encodeURIComponent(id)).then(setPayment).catch(e=>setError(e.message))},[me?.user.id]);return <div className="page-container"><h1>{t('付款状态','Payment status')}</h1>{loading?<p>{t('读取中…','Loading…')}</p>:!me?<Link className="button primary" href="/login">{t('登录后核对付款','Sign in to verify payment')}</Link>:null}{error?<Notice kind="error">{error}</Notice>:null}{payment?<><GatewayPayment payment={payment}/><Link className="button primary" href={payment.orderId?'/cases':'/admin/payments'}>{t('返回档案或管理后台','Return to cases or dashboard')}</Link></>:null}</div>}
