"use client";
import Link from 'next/link';
import {useEffect,useState} from 'react';
import {useApp} from '@/components/app-provider';
import {GatewayPayment,type GatewayPaymentView} from '@/components/gateway-payment';
import {Empty,Loading,Notice,PageHeading} from '@/components/ui';
import {api,money,date} from '@/lib/api';
export default function Payments(){
 const {me,loading,t,locale}=useApp();const [records,setRecords]=useState<GatewayPaymentView[]>([]),[current,setCurrent]=useState<GatewayPaymentView|null>(null),[error,setError]=useState('');
 async function load(){try{const result=await api<{payments:GatewayPaymentView[]}>('/api/payments/nbzhifu');setRecords(result.payments);setError('')}catch(e){setError(e instanceof Error?e.message:'Error')}}
 useEffect(()=>{if(me)void load()},[me?.user.id]);
 if(loading)return <Loading/>;
 if(!me)return <div className="page-container"><Empty title={t('请先登录','Please sign in')}><Link className="button primary" href="/login">{t('登录','Sign in')}</Link></Empty></div>;
 return <div className="page-container"><PageHeading title={t('我的支付流水','My payment transactions')} subtitle={t('付款以服务端查单结果为准；未完成付款不会增加权益。','Payments are verified on the server. Unpaid checkouts do not grant credits.')} action={<Link className="button secondary" href="/account">{t('账户与订单','Account and orders')}</Link>}/>{error?<Notice kind="error">{error}</Notice>:null}
 {current?<GatewayPayment key={current.id} payment={current} onUpdated={()=>void load()} onClose={()=>setCurrent(null)}/>:null}
 <section className="settings-section"><div className="panel-heading"><h2>{t('聚合支付记录','Online payment records')}</h2><button className="text-button" onClick={()=>void load()}>{t('刷新','Refresh')}</button></div>{records.length?<div className="table-scroll"><table className="admin-table"><thead><tr><th>{t('时间 / 交易号','Time / transaction')}</th><th>{t('金额','Amount')}</th><th>{t('支付状态 / 订单状态','Payment / order status')}</th><th></th></tr></thead><tbody>{records.map(p=><tr key={p.id}><td><small>{date(p.createdAt,locale)}<br/>{p.tradeNo||p.id}</small></td><td>{money(p.amountCents)}{p.isTest?<small> · {t('测试','Test')}</small>:null}</td><td>{p.status}<br/>{p.orderStatus||'—'}</td><td><button className="text-button" onClick={()=>setCurrent(p)}>{t('查看','View')}</button>{p.caseId?<Link href={'/cases/'+p.caseId}>{t('档案','Case')}</Link>:null}</td></tr>)}</tbody></table></div>:<p>{t('暂无聚合支付记录。人工收款订单请在账户页查看。','No online payments yet. Manual-payment orders appear on your account page.')}</p>}</section></div>;
}
