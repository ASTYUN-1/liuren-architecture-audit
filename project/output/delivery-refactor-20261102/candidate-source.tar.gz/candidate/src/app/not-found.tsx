import Link from "next/link";
export default function NotFound() { return <div className="empty"><h1>页面不存在 / Page not found</h1><p>此链接可能已失效。 / This link may no longer be available.</p><Link className="button primary" href="/">返回首页 / Home</Link></div>; }
