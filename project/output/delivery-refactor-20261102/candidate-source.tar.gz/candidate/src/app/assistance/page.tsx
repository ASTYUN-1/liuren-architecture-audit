import {HumanAssistance} from '@/components/human-assistance';
export default function Assistance(){return <HumanAssistance/>;}
