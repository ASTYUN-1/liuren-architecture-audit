"use client";
export default function ErrorPage({ reset }: { error: Error; reset: () => void }) { return <div className="empty"><h1>页面暂未完成加载 / Unable to load this page</h1><p>你的档案以服务器记录为准，请稍后重试。 / Your records remain on the server. Please try again.</p><button className="button primary" onClick={reset}>重试 / Try again</button></div>; }
