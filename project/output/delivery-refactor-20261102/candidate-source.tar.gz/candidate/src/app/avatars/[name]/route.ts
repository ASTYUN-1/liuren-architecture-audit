import { api } from "@/server/http";
import { avatarResponse } from "@/server/avatars";
export const runtime = "nodejs";
export const GET = api(async (request, context: { params: Promise<{ name: string }> }) => avatarResponse((await context.params).name, request));
