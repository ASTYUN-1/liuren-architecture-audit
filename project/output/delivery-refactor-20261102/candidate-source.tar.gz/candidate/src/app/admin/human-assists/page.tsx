"use client";
import Link from 'next/link';
import {useEffect,useRef,useState} from 'react';
import {useApp} from '@/components/app-provider';
import {AdminGate} from '@/components/admin-gate';
import {Notice,PageHeading,Loading} from '@/components/ui';
import {Modal} from '@/components/modal';
import {api,post,date} from '@/lib/api';
import styles from './page.module.css';

type Booking={id:string;user_id:string;user_name:string;user_email:string;recharge_code:string|null;case_title:string|null;advisor_id:string;advisor_name:string;question:string;status:string;summary:string|null;deadline:string|null;created_at:string;updated_at:string;units:number;hold_status:string;charged_units:number;refunded_units:number;settled_at:string|null;settled_by:string|null;operator_name:string|null;settlement_reason:string|null};
type View={assists:Booking[];hasMore:boolean;page:number;scope:string};
const labels:Record<string,[string,string]>={pending:['待接单','Awaiting acceptance'],accepted:['服务中','In service'],review:['待确认','Awaiting confirmation'],disputed:['有异议，待核对','Disputed — review required'],completed:['已完成扣费','Completed and charged'],cancelled:['已取消','Cancelled'],refunded:['已释放积分','Credits released']};
const credits=(n:number)=>(n/10).toFixed(1);

export default function HumanAssistAdmin(){
 const {me,t,locale}=useApp();
 const [scope,setScope]=useState('active'),[query,setQuery]=useState(''),[search,setSearch]=useState(''),[page,setPage]=useState(0),[revision,setRevision]=useState(0);
 const [view,setView]=useState<View|null>(null),[loading,setLoading]=useState(true),[error,setError]=useState(''),[message,setMessage]=useState('');
 const [selection,setSelection]=useState<{booking:Booking;action:'redeem'|'refund'}|null>(null),[summary,setSummary]=useState(''),[confirmed,setConfirmed]=useState(false),[busy,setBusy]=useState(false),[modalError,setModalError]=useState('');
 const inflight=useRef(false);
 useEffect(()=>{
  if(!me?.user.isAdmin)return;
  let live=true;setLoading(true);setError('');setView(null);
  api<View>(`/api/admin/human-assists?scope=${scope}&q=${encodeURIComponent(search)}&page=${page}`).then(v=>{if(live)setView(v);}).catch(e=>{if(live)setError(e.message);}).finally(()=>{if(live)setLoading(false);});
  return()=>{live=false;};
 },[me?.user.id,me?.user.isAdmin,scope,search,page,revision]);
 function open(booking:Booking,action:'redeem'|'refund'){setSelection({booking,action});setSummary(action==='redeem'?booking.summary||'':'');setConfirmed(false);setModalError('');}
 async function act(id:string,action:string){
  if(inflight.current)return;inflight.current=true;setBusy(true);setError('');setModalError('');setMessage('');
  try{
   const result=await post<{chargedUnits?:number;alreadyCompleted?:boolean}>('/api/admin/human-assists',{id,action,summary,reason:summary,serviceCompleted:confirmed});
   setSelection(null);setRevision(v=>v+1);
   setMessage(action==='redeem'?result.alreadyCompleted?t('该预约已完成，未重复扣费。','Already completed; no additional charge.'):t(`已核销，实际扣除 ${credits(result.chargedUnits!)} 积分。`,`Redeemed: ${credits(result.chargedUnits!)} credits charged.`):action==='refund'?t('已释放预约积分，请核对记录。','Reserved credits released. Check the record.'):t('已接单，服务完成后可核销。','Accepted. Redeem after completing the service.'));
  }catch(e){const msg=e instanceof Error?e.message:'Error';if(selection)setModalError(msg);else setError(msg);}
  finally{inflight.current=false;setBusy(false);}
 }
 const status=(s:string)=>{const l=labels[s];return l?t(l[0],l[1]):s;};
 return <div className={`page-container ${styles.page}`}><AdminGate>
  <PageHeading title={t('真人辅助核销','Human service redemption')} subtitle={t('服务完成后，将预约冻结积分结算为实际扣费。五个接待身份均可由运营者直接处理。','After delivering a service, settle its reserved credits. An operator can handle all five contact identities.')} action={<Link href="/admin">{t('返回运营后台','Dashboard')} →</Link>}/>
  <Notice>{t('只核销已实际完成的服务，摘要会展示给用户。未提供服务请释放积分；有异议的预约先核对。已核销服务的售后退积分请前往积分运营。','Redeem only delivered services; the summary is visible to the customer. Release credits for undelivered services and review disputes first. Use Credit operations for refunds after settlement.')} <Link className="text-button" href="/admin/points">{t('积分运营','Credit operations')} →</Link></Notice>
  <div className={styles.filters}><div className={styles.tabs} role="group" aria-label={t('预约筛选','Booking filters')}>{[['active','待处理','Active'],['history','核销与取消记录','Completed / cancelled']].map(([value,zh,en])=><button type="button" key={value} className={`button small ${scope===value?'primary':'secondary'}`} aria-pressed={scope===value} disabled={busy} onClick={()=>{setScope(value);setPage(0);}}>{t(zh,en)}</button>)}</div>
   <form className={styles.search} onSubmit={e=>{e.preventDefault();setPage(0);setSearch(query.trim());setRevision(v=>v+1);}}><label className="sr-only" htmlFor="booking-search">{t('查找预约','Find bookings')}</label><input id="booking-search" placeholder={t('昵称、邮箱、充值识别码或完整预约编号','Name, email, top-up code, or full booking ID')} maxLength={120} value={query} onChange={e=>setQuery(e.target.value)}/><button className="button secondary small" disabled={busy}>{t('查找','Search')}</button></form>
   <button className="text-button" disabled={busy||loading} onClick={()=>setRevision(v=>v+1)}>{t('刷新','Refresh')}</button>
  </div>
  {error?<Notice kind="error">{error}</Notice>:null}{message?<Notice>{message}</Notice>:null}
  {loading?<Loading/>:view?.assists.length?<div className={styles.list}>{view.assists.map(r=><article className={styles.card} key={r.id}>
   <div className={styles.heading}><div><strong>{r.user_name}</strong><p>{r.user_email}</p><small>{r.recharge_code||r.user_id}</small></div><span className={r.status==='disputed'?'danger':styles.status}>{status(r.status)}</span></div>
   <p className={styles.bookingId}>{t('预约编号','Booking ID')}：{r.id}</p>
   <div className={styles.facts}><span>{t('接待','Contact')}：{r.advisor_name}</span><span>{t('预约积分','Booked')}：{credits(r.units)}</span><span>{t('冻结','Reserved')}：{credits(r.hold_status==='held'?r.units:0)}</span><span>{t('已扣费','Charged')}：{credits(r.charged_units)}</span>{r.refunded_units>0?<span>{t('售后已退','Refunded after service')}：{credits(r.refunded_units)}</span>:null}</div>
   <p><strong>{r.case_title||t('原档案已移除','Original case removed')}</strong></p><p className="preserve-lines">{r.question}</p>
   {r.summary?<div className={styles.summary}><strong>{r.status==='disputed'?t('用户异议','Customer concern'):t('服务摘要','Service summary')}</strong><p className="preserve-lines">{r.summary}</p></div>:null}
   <small>{t('预约时间','Booked at')}：{date(r.created_at,locale)}{r.deadline&&scope==='active'?<> · {t('处理期限','Deadline')}：{date(r.deadline,locale)}</>:null}</small>
   {r.settled_at?<p className={styles.receipt}>{t('结算记录','Settlement')}：{date(r.settled_at,locale)} · {r.operator_name||(r.settled_by==='system'?t('系统自动处理','System'):r.settled_by)} · {r.settlement_reason}</p>:null}
   {scope==='active'?<div className="button-row">{['pending','accepted','review'].includes(r.status)&&r.hold_status==='held'?<button className="button primary" disabled={busy||!r.deadline||new Date(r.deadline).getTime()<=Date.now()} onClick={()=>open(r,'redeem')}>{t('完成服务并核销','Complete service and redeem')}</button>:null}{r.status==='pending'?<button className="button secondary" disabled={busy} onClick={()=>void act(r.id,'accept')}>{t('接单（可选）','Accept (optional)')}</button>:null}<button className="text-button" disabled={busy||r.hold_status!=='held'} onClick={()=>open(r,'refund')}>{t('取消并释放积分','Cancel and release credits')}</button></div>:null}
  </article>)}</div>:view?<p role="status">{t('当前筛选下暂无预约。','No bookings match these filters.')}</p>:null}
  {view?<div className={styles.pagination}><button className="button secondary small" disabled={page===0||loading||busy} onClick={()=>setPage(v=>v-1)}>{t('上一页','Previous')}</button><span>{t(`第 ${page+1} 页`,`Page ${page+1}`)}</span><button className="button secondary small" disabled={!view.hasMore||loading||busy} onClick={()=>setPage(v=>v+1)}>{t('下一页','Next')}</button></div>:null}
  {selection?<Modal title={selection.action==='redeem'?t('确认服务核销','Confirm service redemption'):t('取消预约并释放积分','Cancel booking and release credits')} onClose={()=>{if(!inflight.current)setSelection(null);}}>
   <form onSubmit={e=>{e.preventDefault();void act(selection.booking.id,selection.action);}}>
    <p><strong>{selection.booking.user_name}</strong> · {selection.booking.user_email}</p><p className={styles.bookingId}>{selection.booking.id}</p>
    <p>{t('接待','Contact')}：{selection.booking.advisor_name}</p>
    <Notice>{selection.action==='redeem'?t(`将已冻结的 ${credits(selection.booking.units)} 积分转为实际扣费；不会再从可用余额重复扣除。`,`Settle ${credits(selection.booking.units)} reserved credits. Available credits will not be charged again.`):t(`将 ${credits(selection.booking.units)} 积分释放回账户可用余额。`,`Release ${credits(selection.booking.units)} reserved credits to the available balance.`)}</Notice>
    <label>{selection.action==='redeem'?t('服务摘要（用户可见，10–2000字）','Service summary (visible to customer, 10–2000 characters)'):t('取消原因（用户可见）','Cancellation reason (visible to customer)')}<textarea required minLength={selection.action==='redeem'?10:2} maxLength={selection.action==='redeem'?2000:1000} rows={4} value={summary} onChange={e=>setSummary(e.target.value)} disabled={busy}/></label>
    <label className="checkbox-label"><input type="checkbox" required checked={confirmed} onChange={e=>setConfirmed(e.target.checked)} disabled={busy}/>{selection.action==='redeem'?t('我确认已实际完成本次服务，且账户和金额无误。','I confirm this service was delivered and the account and amount are correct.'):t('我确认取消该预约并退回冻结积分。','I confirm cancellation and release of the reserved credits.')}</label>
    {modalError?<Notice kind="error">{modalError}</Notice>:null}<div className="button-row"><button type="button" className="button secondary" disabled={busy} onClick={()=>setSelection(null)}>{t('返回','Back')}</button><button className="button primary" disabled={busy||!confirmed||summary.trim().length<(selection.action==='redeem'?10:2)}>{busy?t('正在处理…','Processing…'):selection.action==='redeem'?t('确认核销并扣费','Confirm redemption and charge'):t('确认释放积分','Confirm release')}</button></div>
   </form>
  </Modal>:null}
 </AdminGate></div>;
}
