"use client";
import dynamic from 'next/dynamic';
import {useAdminNotices,AdminNoticeList} from '@/components/admin-notices';
import type {AdminNoticeModule} from '@/lib/admin-notices';
import {useEffect,useState} from 'react';
import {useApp} from '@/components/app-provider';
import {AdminGate} from '@/components/admin-gate';
import {AdminUsers} from '@/components/admin-users';
import {AdminTasks} from '@/components/admin-tasks';
import {AccountDeletionRequests} from '@/components/admin-records';
import {PageHeading,Loading,Notice} from '@/components/ui';
import {api,post} from '@/lib/api';
import type {AdminOverview,DeletionRequestView} from '@/server/contracts';
import styles from './page.module.css';
const Points=dynamic(()=>import('@/components/admin-points').then(m=>m.AdminPoints),{loading:()=> <Loading/>});
const Payments=dynamic(()=>import('@/components/gateway-payment').then(m=>m.GatewayTestPanel),{loading:()=> <Loading/>});
const Settings=dynamic(()=>import('@/components/admin-settings').then(m=>m.AdminSettings),{loading:()=> <Loading/>});
const Practitioners=dynamic(()=>import('@/components/admin-practitioners').then(m=>m.AdminPractitioners),{loading:()=> <Loading/>});
const Resources=dynamic(()=>import('@/components/admin-resources').then(m=>m.AdminResources),{loading:()=> <Loading/>});
const tabs=[['users','用户管理','Users'],['practitioners','卦师认证','Practitioners'],['points','积分与核销','Credits & redemption'],['tasks','解读任务','Tasks'],['payments','支付与流水','Payments'],['resources','运行监控','Monitoring'],['settings','服务设置','Settings']] as const;
type Tab=typeof tabs[number][0];
function readTab():Tab{const value=window.location.hash.slice(1);return tabs.some(t=>t[0]===value)?value as Tab:'users';}
export default function AdminPage(){
 const {t,me}=useApp(),[tab,setTab]=useState<Tab>('users'),[visited,setVisited]=useState<Set<Tab>>(new Set(['users'])),[data,setData]=useState<AdminOverview|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[revision,setRevision]=useState(0),[creditUser,setCreditUser]=useState('');
 useEffect(()=>{function sync(){const next=readTab();setTab(next);setVisited(v=>new Set(v).add(next));}sync();window.addEventListener('hashchange',sync);window.addEventListener('popstate',sync);return()=>{window.removeEventListener('hashchange',sync);window.removeEventListener('popstate',sync);};},[]);
 useEffect(()=>{if(!me?.user.isAdmin)return;let live=true;setBusy(true);api<AdminOverview>('/api/admin/overview').then(v=>{if(live){setData(v);setError('');}}).catch(e=>{if(live)setError(e.message);}).finally(()=>{if(live)setBusy(false);});return()=>{live=false;};},[me?.user.id,me?.user.isAdmin,revision]);
 const noticeFeed=useAdminNotices(me?.user.isAdmin?me.user.id:undefined);
 function select(next:Tab){setTab(next);setVisited(v=>new Set(v).add(next));if(window.location.hash!=='#'+next)window.history.pushState(null,'','#'+next);}
 async function completeDeletion(request:DeletionRequestView){if(!window.confirm(t('请确认真实退款与档案清理均已完成，账户清理不可逆。','Confirm all actual refunds and case cleanup are complete. Account deletion is irreversible.')))return;if(window.prompt('输入 DELETE 确认删除账户')!=='DELETE')return;const reason=window.prompt('请输入核验与删除原因');if(!reason?.trim())return;setBusy(true);try{await post(`/api/admin/users/${encodeURIComponent(request.userId)}/delete`,{reason});setRevision(v=>v+1);}catch(e){setError(e instanceof Error?e.message:'Error');}finally{setBusy(false);}}
 return <div className={`page-container ${styles.workspace}`}><AdminGate><PageHeading title={t('运营后台','Operations')} subtitle={t('管理用户、积分与服务，在一个工作区完成。','Manage users, credits and services in one workspace.')} action={<button className="button secondary small" disabled={busy} onClick={()=>{setRevision(v=>v+1);void noticeFeed.refresh();}}>{busy?t('刷新中…','Refreshing…'):t('刷新数据','Refresh')}</button>}/>
 {data?<div className={styles.overview}><div><span>{t('用户总数','Users')}</span><strong>{data.counts.users}</strong></div><div><span>{t('待处理任务','Active tasks')}</span><strong>{data.metrics.queued+data.metrics.running}</strong></div><div><span>{t('未完成任务','Failed tasks')}</span><strong>{data.metrics.failed}</strong></div><div><span>{t('解读服务','AI service')}</span><strong className={styles.service}>{data.service.aiEnabled&&data.service.workerOnline?t('运行中','Online'):t('待检查','Check service')}</strong></div></div>:null}
 <nav className={styles.tabs} aria-label={t('后台栏目','Admin sections')}>{tabs.map(([value,zh,en])=><button key={value} type="button" aria-current={tab===value?'page':undefined} aria-controls={'admin-panel-'+value} onClick={()=>select(value)}>{t(zh,en)}{(noticeFeed.notices.modules[value as AdminNoticeModule]?.unread??0)>0?<span className={styles.badge} aria-label={`${noticeFeed.notices.modules[value as AdminNoticeModule]!.unread} ${t('条未读新消息','unread notifications')}`}>{noticeFeed.notices.modules[value as AdminNoticeModule]!.unread}</span>:null}</button>)}</nav>
 {noticeFeed.error?<Notice kind="error">{noticeFeed.error}</Notice>:null}
 <AdminNoticeList key={tab} module={tab} notices={noticeFeed.notices} onRead={noticeFeed.read}/>
 {error?<Notice kind="error">{error}</Notice>:null}
 <div id="admin-panel-users" hidden={tab!=='users'}><AdminUsers revision={revision} onCredit={id=>{setCreditUser(id);select('points');}}/>{data?.deletionRequests.length?<AccountDeletionRequests requests={data.deletionRequests} busy={busy} currentUserId={me!.user.id} onComplete={r=>void completeDeletion(r)}/>:null}</div>
 {visited.has('practitioners')?<div id="admin-panel-practitioners" hidden={tab!=='practitioners'}><Practitioners active={tab==='practitioners'} revision={revision}/></div>:null}
 {visited.has('points')?<div id="admin-panel-points" hidden={tab!=='points'}><Points key={creditUser} embedded initialQuery={creditUser} revision={revision}/></div>:null}
 {visited.has('tasks')?<div id="admin-panel-tasks" hidden={tab!=='tasks'}>{data?<AdminTasks tasks={data.tasks} onReviewed={()=>{setRevision(v=>v+1);void noticeFeed.refresh();}}/>:!error?<Loading/>:null}</div>:null}
 {visited.has('payments')?<div id="admin-panel-payments" hidden={tab!=='payments'}><Payments/></div>:null}
 {visited.has('resources')?<div id="admin-panel-resources" hidden={tab!=='resources'}><Resources active={tab==='resources'} revision={revision}/></div>:null}
 {visited.has('settings')?<div id="admin-panel-settings" hidden={tab!=='settings'}><Settings embedded/></div>:null}
 </AdminGate></div>;
}
