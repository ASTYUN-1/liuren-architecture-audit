"use client";
import {EngineCredit} from "@/components/engine-credit";
import {useState,useEffect} from 'react';
import {useRouter} from 'next/navigation';
import type {CaseInput,CaseDetail} from '@/server/contracts';
import {useApp} from '@/components/app-provider';
import {QuestionForm} from '@/components/question-form';
import {post} from '@/lib/api';
export default function Home(){
 const {t,me}=useApp(),router=useRouter(),[busy,setBusy]=useState(false),[savedInput,setSavedInput]=useState<CaseInput>();
 useEffect(()=>{try{const raw=sessionStorage.getItem('wenheng-pending-input-v1');if(raw)setSavedInput(JSON.parse(raw));}catch{sessionStorage.removeItem('wenheng-pending-input-v1');}},[]);
 async function create(input:CaseInput,options?:{outputStyle?:"public"|"practitioner"}){if(!me){sessionStorage.setItem('wenheng-pending-input-v1',JSON.stringify(input));router.push('/login?next=pending');return;}setBusy(true);try{const item=await post<CaseDetail>('/api/cases',{input,...options});sessionStorage.removeItem('wenheng-pending-input-v1');router.push(`/cases/${item.id}`);}finally{setBusy(false);}}
 return <div className="home"><section className="hero"><div className="hero-copy"><h1>{t('把一件事','One question')}<br/>{t('问清楚','A clearer path')}</h1><p>{t('说清问题与背景，其他交给问衡。','Tell us your question and context. Wenheng takes it from here.')}</p>{savedInput?<p role="status">{t('已恢复你之前的问题。点击「确认问题」，整理并核对起课要求后再保存。','Your question has been restored. Select “Review question” to review the chart settings before saving.')}</p>:null}</div><QuestionForm key={savedInput?'saved':'new'} initial={savedInput} busy={busy} onConfirm={create}/></section><EngineCredit/></div>;
}
