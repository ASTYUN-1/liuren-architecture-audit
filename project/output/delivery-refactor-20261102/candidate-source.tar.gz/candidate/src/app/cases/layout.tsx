import type { ReactNode } from "react";
import { ServiceScopeNotice } from "@/components/service-scope-notice";

export default function CasesLayout({ children }: { children: ReactNode }) {
  return <><div className="case-scope-notice"><ServiceScopeNotice /></div>{children}</>;
}
