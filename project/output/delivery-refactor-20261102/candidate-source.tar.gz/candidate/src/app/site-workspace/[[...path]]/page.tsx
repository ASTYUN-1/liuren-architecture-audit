export {default,generateMetadata} from '../../beta/[[...path]]/page';
export const dynamic='force-dynamic';
