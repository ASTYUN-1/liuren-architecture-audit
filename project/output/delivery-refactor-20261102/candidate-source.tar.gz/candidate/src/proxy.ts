import {NextResponse,type NextRequest} from 'next/server';
import {workspacePath} from './lib/public-routes';
export function proxy(request:NextRequest){
 if(process.env.WENHENG_PUBLIC_UI_ENABLED==='false')return NextResponse.next();
 const path=request.nextUrl.pathname;
 if(path==='/beta'||path.startsWith('/beta/')){
  const target=request.nextUrl.clone();target.pathname=workspacePath(path.slice(6));
  return NextResponse.redirect(target,307);
 }
 return NextResponse.next();
}
export const config={matcher:['/beta/:path*']};
