import {calculateChart,plateHash,type ChartSnapshot} from "./liuren";
import {readRandomTicket,signRandomTicket,type RandomAnchor} from "./random-ticket";
import type {DialChart,RandomSelection,RandomSeed} from "../lib/random-chart";
import {DIAL_BRANCHES} from "../lib/random-chart";
const keys=["zi","chou","yin","mao","chen","si","wu","wei","shen","you","xu","hai"];
export function dialChart(c:ChartSnapshot):DialChart {
  const f=c.facts;
  return {date:c.normalized.date!,time:c.normalized.time!,monthGeneral:f.yuejiang,hourBranch:f.sizhu.h[1],number:c.normalized.number||DIAL_BRANCHES.indexOf(f.sizhu.h[1])+1,pillars:[f.sizhu.y,f.sizhu.m,f.sizhu.d,f.sizhu.h],voidBranches:f.xunkong,palaces:keys.map((k,i)=>({earth:DIAL_BRANCHES[i],heaven:f.tianpan[k],general:f.shenpan[k]})),lessons:f.sike,transmissions:f.sanchuan};
}
export function startRandomChart(rules:Record<string,string>,time=new Date().toISOString()):RandomSeed {
  const chart=calculateChart({question:"随机取刻",locale:"zh",mode:"time",time,timeZone:"Asia/Shanghai",participants:[],rules});
  const f=chart.facts,anchor:RandomAnchor={version:1,kind:"seed",time,rules:chart.normalized.rules,monthGeneral:f.yuejiang,pillars:{y:f.sizhu.y,m:f.sizhu.m,d:f.sizhu.d},engineVersion:chart.engineVersion};
  return {ticket:signRandomTicket(anchor),chart:dialChart(chart)};
}
export function stopRandomChart(ticket:string,number:number):RandomSelection {
  const anchor=readRandomTicket(ticket,"seed");
  if(!Number.isInteger(number)||number<1||number>12)throw new Error("random_number_invalid");
  const chart=calculateChart({question:"随机取刻",locale:"zh",mode:"number",number,time:anchor.time,timeZone:"Asia/Shanghai",participants:[],rules:anchor.rules},{yuejiang:anchor.rules.yuejiang,shehai:anchor.rules.shehai,randomAnchor:anchor});
  if(chart.engineVersion!==anchor.engineVersion)throw new Error("random_engine_changed");
  const selected:RandomAnchor={...anchor,kind:"selection",number,plateHash:plateHash(chart.facts)};
  return {ticket:signRandomTicket(selected),time:anchor.time,number,rules:anchor.rules,chart:dialChart(chart)};
}
