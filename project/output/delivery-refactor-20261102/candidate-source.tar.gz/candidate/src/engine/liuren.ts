import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
import vm from "node:vm";
import {selectedAnchor,type RandomAnchor} from "./random-ticket";
import type { CaseInput, Participant } from "../server/contracts";

export const BRANCHES = [..."子丑寅卯辰巳午未申酉戌亥"];
const STEMS = [..."甲乙丙丁戊己庚辛壬癸"];
export const DEFAULT_RULES = { yuejiang: "中气换将", guiren: "甲戊庚牛羊", zhouye: "自动选择", shehai: "孟仲季" };
export class EngineInputError extends Error { code = "invalid_chart_input"; }
export interface ChartSnapshot { schemaVersion: 1; engineVersion: string; hash: string; input: CaseInput; normalized: { date: string | null; time: string | null; instant: string | null; timeZone: "Asia/Shanghai"; number?: number; branch?: string; rules: Record<string,string> }; participants: Participant[]; facts: Record<string, any>; warnings: string[] }
// Resources are deployed separately at WENHENG_PROJECT_ROOT as a read-only tree.
// Keep runtime path discovery out of Next standalone's source/config tracing.
export const PROJECT_ROOT = resolve(/* turbopackIgnore: true */ process.env.WENHENG_PROJECT_ROOT || resolve(/* turbopackIgnore: true */ process.cwd(), process.cwd().endsWith("web") ? ".." : "."));
const files = ["lunar.js", "data.js", "api.js", "guize.js", "paipan.js"];
let sources: { code: string; name: string }[] | undefined;
function sourceBundle() { return sources ??= files.map(name => ({ name, code: readFileSync(/* turbopackIgnore: true */ resolve(PROJECT_ROOT, "排盘工具魔改/js", name), "utf8") })); }
export function createEngineContext() {
  const ctx = vm.createContext({ console: { log(){}, error(){}, warn(){} }, window: { indexedDB: { open(){return {};} } }, vm_glob: { USER_ALL_DATA: { pages_config: { zhuti_config: { zhuti_bord_clor: "#182A28" } } } }, setInterval(){}, clearInterval(){}, setTimeout(){} }, { codeGeneration: { strings: false, wasm: false } });
  vm.runInContext(beijingDate, ctx, { timeout: 1000 });
  for (const s of sourceBundle()) vm.runInContext(s.code, ctx, { timeout: 5000, filename: s.name });
  return ctx;
}
function canonical(value:any):any {if(Array.isArray(value))return value.map(canonical);if(value&&typeof value==="object")return Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])]));return value;}
export function hashChartValue(value: unknown) { return createHash("sha256").update(JSON.stringify(canonical(value))).digest("hex"); }
const hash=hashChartValue;
export function assertChartSnapshot(chart:ChartSnapshot,input:CaseInput){if(chart.schemaVersion!==1 || hash(chart.input)!==hash(input) || chart.hash!==hash({engineVersion:chart.engineVersion,input:chart.input,normalized:chart.normalized,facts:chart.facts}))throw new Error("fixed_chart_invalid");}
function validGanzhi(s: string) { return s?.length === 2 && STEMS.includes(s[0]) && BRANCHES.includes(s[1]) && STEMS.indexOf(s[0]) % 2 === BRANCHES.indexOf(s[1]) % 2; }
function branch(s: string) { const b = s?.length === 2 ? s[1] : s; if (!BRANCHES.includes(b)) throw new EngineInputError("请输入有效地支"); return b; }
export function normalizeChartInput(input: CaseInput) {
  const rules = { ...DEFAULT_RULES, ...input.rules };
  const accepted: Record<string,string[]> = { yuejiang: ["中气换将", "交节换将", "日躔换将"], guiren: ["甲戊庚牛羊", "甲羊戊庚牛"], zhouye: ["自动选择", "昼贵", "夜贵"], shehai: ["孟仲季"] };
  for (const [k,v] of Object.entries(rules)) if (!accepted[k]?.includes(v)) throw new EngineInputError(`不支持的高级规则：${k}`);
  try { new Intl.DateTimeFormat("en", { timeZone: input.timeZone }); } catch { throw new EngineInputError("请输入有效 IANA 时区"); }
  let date: string | null = null, time: string | null = null, instant: string | null = null;
  if (input.mode !== "pillars") {
    if (!input.time || !/(Z|[+-]\d{2}:\d{2})$/.test(input.time)) throw new EngineInputError("起课时间必须已确认并包含 UTC 偏移");
    const d = new Date(input.time); if (!Number.isFinite(+d)) throw new EngineInputError("起课时间无效");
    instant = d.toISOString(); const wall = new Date(+d + 8 * 3600000).toISOString(); date = wall.slice(0,10); time = wall.slice(11,16);
    if (+date.slice(0,4) < 1900 || +date.slice(0,4) > 2100) throw new EngineInputError("首版支持 1900–2100 年");
  } else {
    const p = input.pillars;
    if (!p || !validGanzhi(p.year) || !validGanzhi(p.day)) throw new EngineInputError("四柱模式须提供合法年干支、日干支及月支、时支、月将");
    branch(p.month); branch(p.hour); branch(p.monthGeneral);
    if (p.actualDate) {
      const d=new Date(p.actualDate+"T00:00:00Z");if(!/^\d{4}-\d{2}-\d{2}$/.test(p.actualDate)||!Number.isFinite(+d)||d.toISOString().slice(0,10)!==p.actualDate || +p.actualDate.slice(0,4)<1900 || +p.actualDate.slice(0,4)>2100)throw new EngineInputError("真实日期无效，首版支持 1900–2100 年");
      date=p.actualDate;
    }
  }
  let number: number | undefined, numberBranch: string | undefined;
  if (input.mode === "number") {
    number = input.number;
    if (!Number.isInteger(number) || number! < 1 || number! > 999999999) throw new EngineInputError("报数范围为 1–999999999 的正整数");
    const i = (number! - 1) % 12; numberBranch = BRANCHES[i]; time = String(i * 2).padStart(2,"0") + ":00";
  }
  return { date, time, instant, timeZone: "Asia/Shanghai" as const, ...(number === undefined ? {} : { number, branch: numberBranch }), rules };
}

// The legacy library uses local Date constructors. This VM-local class makes those
// operations Beijing civil time without changing process.env.TZ or another job.
const beijingDate = `const NativeDate = Date; class BeijingDate extends NativeDate {
 constructor(...a){super(...(a.length>1?[NativeDate.UTC(a[0],a[1],a[2]??1,a[3]??0,a[4]??0,a[5]??0,a[6]??0)-28800000]:a));}
 getTimezoneOffset(){return -480;} }
for(const n of ['FullYear','Month','Date','Day','Hours','Minutes','Seconds','Milliseconds']){
 BeijingDate.prototype['get'+n]=function(){return new NativeDate(+this+28800000)['getUTC'+n]();};
 if(n!=='Day') BeijingDate.prototype['set'+n]=function(...a){const d=new NativeDate(+this+28800000); d['setUTC'+n](...a); return this.setTime(+d-28800000);};
} Date = BeijingDate;`;
export function calculateChart(input: CaseInput, selfOptions?: { yuejiang: string; shehai: string; longitude?: number; randomAnchor?:RandomAnchor }): ChartSnapshot {
  const safe = structuredClone(input), normalized = normalizeChartInput(safe), bundle = sourceBundle();
  const ctx = createEngineContext();
  const selection=selectedAnchor(safe), randomAnchor=selection||selfOptions?.randomAnchor;
  if(safe.mode==="solar"){if(!Number.isFinite(safe.longitude)||safe.longitude!< -180||safe.longitude!>180)throw new EngineInputError("请输入有效经度");selfOptions={...normalized.rules,...selfOptions,yuejiang:normalized.rules.yuejiang,shehai:normalized.rules.shehai,longitude:safe.longitude};}
  if (selfOptions) {
    normalized.rules.yuejiang = selfOptions.yuejiang;
    normalized.rules.shehai = selfOptions.shehai;
    if (selfOptions.longitude !== undefined && normalized.date && normalized.time) {
      ctx.solarArgs = JSON.stringify([...normalized.date.split("-").map(Number), ...normalized.time.split(":").map(Number), 0, selfOptions.longitude]);
      const solar = JSON.parse(vm.runInContext("JSON.stringify(getTrueSolarTimeFromBeijing(...JSON.parse(solarArgs)))", ctx, { timeout: 2000 }));
      normalized.date = `${solar.y}-${String(solar.m).padStart(2,"0")}-${String(solar.d).padStart(2,"0")}`;
      normalized.time = `${String(solar.h).padStart(2,"0")}:${String(solar.i).padStart(2,"0")}`;
      if (+normalized.date.slice(0,4) < 1900 || +normalized.date.slice(0,4) > 2100) throw new EngineInputError("真太阳时超出支持年份");
    }
  }
  const env = { Date: normalized.date ?? "2000-01-01", Time: normalized.time ?? "00:00", zhenghuoshi: safe.mode === "pillars" ? "四柱" : "正时", ...normalized.rules, user: [], cundang: { ws: safe.question } } as Record<string,unknown>;
  if (safe.pillars) { const p = safe.pillars; env.sizhu = { yg: p.year[0], yz: p.year[1], mz: branch(p.month), dg: p.day[0], dz: p.day[1], hz: branch(p.hour), yuejiang: branch(p.monthGeneral) }; }
  ctx.inputJson = JSON.stringify(env);
  // The native menu lists explicit generals, but its time-mode dispatcher
  // silently leaves them at 子. Use its supported pillar entry point instead.
  let datedFacts: Record<string,any> | undefined;
  if (selfOptions && safe.mode !== "pillars" && /^[神大功太天胜小传从河登]/.test(selfOptions.yuejiang) && BRANCHES.includes(selfOptions.yuejiang.slice(-1))) {
    ctx.inputJson = JSON.stringify({...env,yuejiang:"中气换将"});
    datedFacts = JSON.parse(vm.runInContext("JSON.stringify(LiuRenPaiPan(JSON.parse(inputJson)))",ctx,{timeout:10000}));
    const p=datedFacts!.sizhu;
    ctx.inputJson=JSON.stringify({...env,zhenghuoshi:"四柱",sizhu:{yg:p.y[0],yz:p.y[1],mz:p.m[1],dg:p.d[0],dz:p.d[1],hz:p.h[1],yuejiang:selfOptions.yuejiang.slice(-1)}});
  }
  if(randomAnchor){
    const actualTime=new Date(Date.parse(randomAnchor.time)+8*3600000).toISOString().slice(11,16);
    ctx.inputJson=JSON.stringify({...env,Time:actualTime,zhenghuoshi:"正时"});
    datedFacts=JSON.parse(vm.runInContext("JSON.stringify(LiuRenPaiPan(JSON.parse(inputJson)))",ctx,{timeout:10000}));
    const p=randomAnchor.pillars;
    ctx.inputJson=JSON.stringify({...env,zhenghuoshi:"四柱",sizhu:{yg:p.y[0],yz:p.y[1],mz:p.m[1],dg:p.d[0],dz:p.d[1],hz:normalized.branch,yuejiang:randomAnchor.monthGeneral}});
  }
  if(safe.mode==="pillars"&&normalized.date){
    const p=safe.pillars!,hour=BRANCHES.indexOf(branch(p.hour))*2;
    ctx.dateCheck=JSON.stringify({...env,Time:String(hour).padStart(2,"0")+":00",zhenghuoshi:"正时"});
    const check=JSON.parse(vm.runInContext("JSON.stringify(LiuRenPaiPan(JSON.parse(dateCheck)).sizhu)",ctx,{timeout:10000}));
    if(check.y!==p.year || check.m[1]!==branch(p.month) || check.d!==p.day)throw new EngineInputError("提供的真实日期与年、月、日柱不一致，请先确认，不会静默覆盖输入。");
  }
  let facts: Record<string,any>;
  try { facts = JSON.parse(vm.runInContext("JSON.stringify(LiuRenPaiPan(JSON.parse(inputJson)))", ctx, { timeout: 10000 })); }
  catch { throw new Error("chart_engine_failed"); }
  if (datedFacts) { facts.jieqi=datedFacts.jieqi; facts.yuejiang_type=randomAnchor?randomAnchor.rules.yuejiang:selfOptions!.yuejiang; }
  if (!Array.isArray(facts.sike) || facts.sike.length !== 4 || facts.sanchuan?.length !== 3) throw new Error("chart_engine_incomplete");
  delete facts._D; delete facts.AI_list; delete facts.wu; delete facts.tongdaoxian;
  if (selfOptions) facts.LiCheng = vm.runInContext("LiCheng", ctx, { timeout: 1000 });
  const warnings: string[] = [];
  if (safe.mode === "pillars") { for (const key of ["Time", "jieqi", "liuxun_list"]) delete facts[key];if(!normalized.date){delete facts.Date;delete facts.nongli;warnings.push("纯四柱未提供真实日期，不生成节气、年龄、行年或公历应期。");}else warnings.push("四柱真实日期已核对；未提供精确时刻，不推测交节时分。"); }
  facts.userinfo = structuredClone(safe.participants);
  for(const person of facts.userinfo){
    if(person.lifeBranch){person.benming={branch:branch(person.lifeBranch),source:"user.lifeBranch",confirmed:true};}
    let birthYear:number|undefined=person.birthYear;
    if(person.birthDate){
      if(!/^\d{4}-\d{2}-\d{2}$/.test(person.birthDate)||!Number.isFinite(+new Date(person.birthDate+"T00:00:00Z")))throw new EngineInputError("人物出生日期无效");
      const civilYear=+person.birthDate.slice(0,4);if(birthYear!==undefined&&birthYear!==civilYear)throw new EngineInputError("人物出生年与出生日期不一致");
      ctx.birthJson=JSON.stringify(person.birthDate.split("-").map(Number));
      const yearPillar=vm.runInContext("(() => { const a=JSON.parse(birthJson); return Solar.fromDate(new Date(a[0],a[1]-1,a[2],12)).getLunar().getBaZi()[0]; })()",ctx,{timeout:2000});
      // On the change-of-year date, missing birth time cannot identify which
      // side of Li Chun the person was born on. Keep user-supplied life branch.
      const before=vm.runInContext("(() => { const a=JSON.parse(birthJson); return Solar.fromDate(new Date(a[0],a[1]-1,a[2],0)).getLunar().getBaZi()[0]; })()",ctx,{timeout:2000});
      const after=vm.runInContext("(() => { const a=JSON.parse(birthJson); return Solar.fromDate(new Date(a[0],a[1]-1,a[2],23)).getLunar().getBaZi()[0]; })()",ctx,{timeout:2000});
      if(before!==after){warnings.push(`${person.role}出生日期处于立春换年日，缺出生时刻，年命及行年起算需确认。`);birthYear=undefined;}
      else{ctx.birthYearValue=civilYear;const midYear=vm.runInContext("Solar.fromDate(new Date(birthYearValue,6,1)).getLunar().getBaZi()[0]",ctx,{timeout:2000});birthYear=midYear===yearPillar?civilYear:civilYear-1;if(!person.lifeBranch)person.benming={branch:yearPillar[1],stemBranch:yearPillar,source:"user.birthDate + legacy Solar (立春换年)",confirmed:true};}
    }else if(birthYear!==undefined&&!person.lifeBranch){
      if(!Number.isInteger(birthYear)||birthYear<1800||birthYear>2100)throw new EngineInputError("人物出生年无效");
      ctx.birthYearValue=birthYear;const pillar=vm.runInContext("Solar.fromDate(new Date(birthYearValue,6,1)).getLunar().getBaZi()[0]",ctx,{timeout:2000});
      person.benming={branch:pillar[1],stemBranch:pillar,source:"user.birthYear + 原引擎出生年份口径（按该年立春后）",confirmed:false};warnings.push(`${person.role}仅提供出生年份，本命按该年立春后年柱暂取；立春前出生需补充日期确认。`);
    }
    if(normalized.date&&birthYear!==undefined&&(person.gender==="male"||person.gender==="female")){
      const civilYear=+normalized.date.slice(0,4);ctx.occupyingYearValue=civilYear;
      const midYear=vm.runInContext("Solar.fromDate(new Date(occupyingYearValue,6,1)).getLunar().getBaZi()[0]",ctx,{timeout:2000});const occupyingYear=midYear===facts.sizhu.y?civilYear:civilYear-1,offset=occupyingYear-birthYear;
      if(offset<0||offset>130)throw new EngineInputError("出生年不能晚于占年，且行年年龄超出首版支持范围");
      ctx.xingnianArgs=JSON.stringify([person.gender==="male"?"男":"女",offset]);const xn=vm.runInContext("GetXingNian(...JSON.parse(xingnianArgs))",ctx,{timeout:2000});
      person.xingnian={stemBranch:xn,branch:xn[1],source:person.birthDate?"user.birthDate + legacy GetXingNian":"user.birthYear + legacy GetXingNian",occupyingYear,birthYear,yearOffset:offset,rule:"男丙寅顺、女壬戌逆；原引擎以占年减出生年为偏移"};
    }
  }
  if ((!safe.participants.length || safe.participants.some(p => !p.birthYear || !p.gender || p.gender === "unknown"))) warnings.push("人物资料不足的年命、行年判断省略；已知本命保留。");
  const engineVersion = "legacy-beijing-midnight-v1-" + hash(bundle).slice(0,16);
  if(selection&&(selection.engineVersion!==engineVersion||selection.plateHash!==plateHash(facts)))throw new EngineInputError("随机盘已与当前引擎不一致，请重新确认随机盘");
  return { schemaVersion: 1, engineVersion, hash: hash({ engineVersion, input: safe, normalized, facts }), input: safe, normalized, participants: structuredClone(safe.participants), facts, warnings };
}
export function publicChart(chart: ChartSnapshot) {
  const f = chart.facts;
  return { hash: chart.hash, mode: chart.input.mode, random:!!chart.input.random, longitude:chart.input.longitude, date: chart.normalized.date, time: chart.normalized.time, timeZone: chart.normalized.timeZone, number: chart.normalized.number, branch: chart.normalized.branch, rules: chart.normalized.rules, pillars: f.sizhu, monthGeneral: f.yuejiang, voidBranches: f.xunkong, fourLessons: f.sike, transmissions: f.sanchuan, heavenPlate: f.tianpan, generals: f.shenpan, pattern: f.geju };
}

export function plateHash(f:Record<string,any>){return hash({pillars:f.sizhu,monthGeneral:f.yuejiang,heaven:f.tianpan,generals:f.shenpan,lessons:f.sike,transmissions:f.sanchuan,void:f.xunkong});}
