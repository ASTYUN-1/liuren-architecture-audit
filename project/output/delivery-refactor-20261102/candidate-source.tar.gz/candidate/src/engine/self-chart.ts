import vm from "node:vm";
import { z } from "zod";
import { AppError } from "../server/http";
import { parseInput } from "../server/validation";
import { calculateChart, createEngineContext, EngineInputError } from "./liuren";
import { BRANCHES, MONTH_GENERALS, type ProfessionalChart, type SelfChartInput } from "../lib/professional-chart";

const rules = z.object({
  guiren: z.enum(["甲戊庚牛羊", "甲羊戊庚牛"]), zhouye: z.enum(["自动选择", "昼贵", "夜贵"]),
  shehai: z.enum(["孟仲季", "深度"]), yuejiang: z.enum(["中气换将", "交节换将", "日躔换将", ...MONTH_GENERALS] as [string, ...string[]]),
});
const schema = z.object({
  method: z.enum(["time", "number", "pillars", "solar"]),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), time: z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/),
  calendar: z.enum(["solar", "lunar"]), leapMonth: z.boolean(),
  number: z.number().int().min(1).max(999999999).optional(), longitude: z.number().min(-180).max(180).optional(),
  pillars: z.object({ year: z.string().max(2), month: z.string().max(1), day: z.string().max(2), hour: z.string().max(1), monthGeneral: z.string().max(1) }),
  rules, participants: z.array(z.unknown()).max(8),
});
const keys = ["zi","chou","yin","mao","chen","si","wu","wei","shen","you","xu","hai"];
export function calculateSelfChart(value: unknown): { chart: ProfessionalChart; warnings: string[] } {
  const parsed = schema.safeParse(value);
  if (!parsed.success) throw new AppError("INVALID_CHART_INPUT", "请检查起课设置。");
  const v = parsed.data as SelfChartInput;
  try {
    let date = v.date;
    if (v.method !== "pillars") {
      const [y,m,d] = date.split("-").map(Number);
      if(y<1900||y>2100) throw new EngineInputError("支持 1900–2100 年");
      if (v.calendar === "lunar") {
        const ctx = createEngineContext(); ctx.lunarArgs = JSON.stringify([y, v.leapMonth ? -m : m, d]);
        date = vm.runInContext("Lunar.fromYmd(...JSON.parse(lunarArgs)).getSolar().toYmd()", ctx, {timeout:2000});
      } else {
        const check=new Date(date+"T00:00:00Z");
        if(!Number.isFinite(+check)||check.toISOString().slice(0,10)!==date) throw new EngineInputError("日期无效");
      }
    }
    if(v.method==="solar" && v.longitude===undefined) throw new EngineInputError("请输入经度");
    const input = parseInput({
      question:"自助排盘", locale:"zh", mode:v.method==="solar"?"time":v.method,
      time: date+"T"+v.time+":00+08:00", timeZone:"Asia/Shanghai", number:v.number,
      pillars:v.method==="pillars"?v.pillars:undefined, participants:v.participants,
      rules:{...v.rules,shehai:"孟仲季",yuejiang:"中气换将"},
    });
    const snapshot=calculateChart(input,{shehai:v.rules.shehai,yuejiang:v.rules.yuejiang,...(v.method==="solar"?{longitude:v.longitude}:{})});
    const f=snapshot.facts;
    const safeText=(a:unknown)=>typeof a==="string"?a:"";
    const chart:ProfessionalChart={
      method:v.method,date:snapshot.normalized.date,time:snapshot.normalized.time,
      originalTime:v.method==="pillars"?null:date+" "+v.time,
      ...(v.method==="solar"?{longitude:v.longitude}:{}), ...(v.method==="number"?{number:v.number}:{}),
      pillars:[f.sizhu.y,f.sizhu.m,f.sizhu.d,f.sizhu.h],monthGeneral:f.yuejiang,xun:f.xunshou,voidBranches:f.xunkong,
      lunar:f.nongli?`${f.nongli.y}年${f.nongli.m}${f.nongli.d}`:null,
      solarTerm:f.jieqi?.the_jieqi?.name??null,rules:v.rules,
      people:f.userinfo.map((p:any)=>({name:p.role,gender:p.gender==="male"?"男":p.gender==="female"?"女":"未提供",birthYear:p.birthYear,life:p.benming?.stemBranch||p.benming?.branch||"—",annual:p.xingnian?.stemBranch||"—"})),
      lessons:f.sike,transmissions:f.sanchuan,
      palaces:keys.map((key,i)=>({
        key,earth:BRANCHES[i],heaven:f.tianpan[key],general:f.shenpan[key],stem:f.xungan[key],
        heavenGrowth:safeText(f.tianpanzs?.[key]),generalGrowth:safeText(f.shenpanzs?.[key]),nayin:safeText(f.nayinpan?.[key]),
        onHeaven:f.shen_ju_tian?.[key]||{name:"",value:""},onEarth:f.shen_ju_di?.[key]||{name:"",value:""},
        spirits:f.shensha_py_to_name?.[key]||[],patterns:f.geju?.[key]||[],void:f.xunkong.includes(f.tianpan[key]),
      })),
      classics:{zhizhi:safeText(f.ZhiZhi),jiying:safeText(f.JiYingQian),bifa:safeText(f.BiFa),kejing:f.KeJing||[],licheng:`#### 旺衰\n\n| 月份 | 金 | 木 | 水 | 火 | 土 |\n| --- | --- | --- | --- | --- | --- |\n| ${(f.wangshuai||[]).join(" | ")} |\n\n${safeText(f.LiCheng)}`},
      spirits:Object.entries({sui:"岁煞",ji:"季煞",yue:"月煞",xun:"旬煞",dg:"日干",dz:"日支"}).map(([k,label])=>({label,entries:Object.entries(f.shensha_list?.[k]||{}).map(([name,value])=>[name,Array.isArray(value)?value.map(String):[safeText(value)]] as [string,string[]])})),
    };
    return {chart,warnings:snapshot.warnings};
  } catch(e) {
    if(e instanceof AppError) throw e;
    if(e instanceof EngineInputError) throw new AppError("INVALID_CHART_INPUT",e.message);
    throw new AppError("CHART_FAILED","起课失败，请检查日期、农历闰月及四柱设置。");
  }
}
