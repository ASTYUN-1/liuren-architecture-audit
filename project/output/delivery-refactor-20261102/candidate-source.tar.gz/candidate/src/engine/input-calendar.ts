import vm from 'node:vm';
import {z} from 'zod';
import type {CaseInput} from '../server/contracts';
import {BRANCHES,calculateChart,createEngineContext} from './liuren';

const ganzhi=z.string().regex(/^[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]$/);
const branch=z.string().regex(/^[子丑寅卯辰巳午未申酉戌亥]$/);
export const pillarDraftSchema=z.object({year:ganzhi.optional(),month:z.union([ganzhi,branch]).optional(),day:ganzhi.optional(),hour:z.union([ganzhi,branch]).optional(),monthGeneral:branch.optional(),actualDate:z.string().optional()}).strict();
export const calendarDateSchema=z.object({calendar:z.enum(['gregorian','lunar']),year:z.number().int().min(1900).max(2100),month:z.number().int().min(1).max(12),day:z.number().int().min(1).max(31),hour:z.number().int().min(0).max(23).optional(),minute:z.number().int().min(0).max(59).optional(),second:z.number().int().min(0).max(59).optional(),hourBranch:branch.optional(),leapMonth:z.boolean().optional()}).strict();
type Pillars=z.infer<typeof pillarDraftSchema>;
type CalendarDate=z.infer<typeof calendarDateSchema>;
export interface CalendarParameters {mode?:CaseInput['mode']|'random';time?:string;timeZone?:string;calendarDate?:CalendarDate;pillars?:Pillars;rules?:CaseInput['rules']}
export class CalendarClarification extends Error {}
const ask=(message:string):never=>{throw new CalendarClarification(message);};
const pad=(v:number)=>String(v).padStart(2,'0');
function validDate(date:string){const d=new Date(date+'T00:00:00Z');return /^\d{4}-\d{2}-\d{2}$/.test(date)&&Number.isFinite(+d)&&d.toISOString().slice(0,10)===date&&+date.slice(0,4)>=1900&&+date.slice(0,4)<=2100;}
function civilDate(c:CalendarDate){
  if(c.calendar==='gregorian'){
    const date=`${c.year}-${pad(c.month)}-${pad(c.day)}`;
    if(c.leapMonth)ask('公历没有闰月，请确认你说的是公历还是农历。');
    if(!validDate(date))ask('这个公历日期不存在，请核对年月日（支持1900至2100年）。');
    return date;
  }
  const ctx=createEngineContext();ctx.calendarArgs=JSON.stringify(c);
  const meta=JSON.parse(vm.runInContext(`(() => {const a=JSON.parse(calendarArgs),y=LunarYear.fromYear(a.year),m=y.getMonth(a.leapMonth?-a.month:a.month);return JSON.stringify({leap:y.getLeapMonth(),days:m?.getDayCount()??0});})()`,ctx,{timeout:2000}));
  if(c.leapMonth===undefined&&meta.leap===c.month)ask(`农历${c.year}年有闰${c.month}月，请说明是普通${c.month}月还是闰${c.month}月。`);
  if(!meta.days||c.day>meta.days)ask('这个农历年月日或闰月不存在，请核对；不会自动顺延日期。');
  const date=vm.runInContext('(() => {const a=JSON.parse(calendarArgs);return Lunar.fromYmd(a.year,a.leapMonth?-a.month:a.month,a.day).getSolar().toYmd();})()',ctx,{timeout:2000}) as string;
  if(!validDate(date))ask('换算后的日期超出1900至2100年的支持范围，请核对年份。');
  return date;
}
function chart(date:string,hour:number,minute:number,base:CaseInput){return calculateChart({...base,mode:'time',time:`${date}T${pad(hour)}:${pad(minute)}:00+08:00`,timeZone:'Asia/Shanghai',participants:[],pillars:undefined,number:undefined,longitude:undefined,random:undefined});}
function comparePillars(p:Pillars,f:Record<string,any>,checkGeneral:boolean){
  const names={year:'年柱',month:'月柱',day:'日柱',hour:'时柱'} as const,keys={year:'y',month:'m',day:'d',hour:'h'} as const;
  for(const k of Object.keys(names) as (keyof typeof names)[]){const v=p[k],actual=f.sizhu[keys[k]];if(v&&v!==(v.length===1?actual[1]:actual))ask(`所给${names[k]}${v}与日期、时间换算结果${actual}不一致，请说明采用哪组信息，或核对历法与时间。`);}
  if(checkGeneral&&p.monthGeneral&&p.monthGeneral!==f.yuejiang)ask(`所给月将${p.monthGeneral}与当前日期、换将规则不一致，请确认是否明确采用手工四柱和指定月将。`);
}
function completePillars(p:Pillars){
  const missing=([['year','年柱'],['month','月柱或月支'],['day','日柱'],['hour','时柱或时支']] as const).filter(([k])=>!p[k]).map(([,name])=>name);
  if(missing.length)ask(`已识别为干支四柱起课，还缺少${missing.join('、')}。`);
  const stems=[...'甲乙丙丁戊己庚辛壬癸'];
  for(const k of ['year','month','day','hour'] as const){const v=p[k]!;if(v.length===2&&stems.indexOf(v[0])%2!==BRANCHES.indexOf(v[1])%2)ask(`${v}不是有效干支，请核对${k==='year'?'年':k==='month'?'月':k==='day'?'日':'时'}柱。`);}
  if(p.month!.length===2){const expected=stems[(stems.indexOf(p.year![0])%5*2+2+(BRANCHES.indexOf(p.month![1])+10)%12)%10];if(p.month![0]!==expected)ask('年干与月干按五虎遁不一致，请核对年柱、月柱；若年份用于历史背景而非起课，请说明。');}
  if(p.hour!.length===2){const expected=stems[(stems.indexOf(p.day![0])%5*2+BRANCHES.indexOf(p.hour![1]))%10];if(p.hour![0]!==expected)ask('日干与时干按五鼠遁不一致，请核对日柱、时柱。');}
  return p;
}
function branchFacts(date:string,b:string,base:CaseInput){
  if(b==='子')ask('子时跨越23点和次日0点，请说明实际日期及是23点后的晚子时，还是0点后的早子时。');
  const middle=BRANCHES.indexOf(b)*2,ctx=createEngineContext();ctx.termArgs=JSON.stringify({date,start:middle-1,end:middle});
  const crossesTerm=vm.runInContext(`(() => {const a=JSON.parse(termArgs),d=a.date.split('-').map(Number),table=Solar.fromYmd(...d).getLunar().getJieQiTable();return Object.values(table).some(s=>s.toYmd()===a.date&&Number(s.toYmdHms().slice(11,13))>=a.start&&Number(s.toYmdHms().slice(11,13))<=a.end);})()`,ctx,{timeout:2000});
  if(crossesTerm)ask('这个时辰内有节气交接，请补充具体钟点，或明确四柱及月将，避免取错盘。');
  const first=chart(date,middle-1,0,base),last=chart(date,middle,59,base);
  if(first.facts.yuejiang!==last.facts.yuejiang||['y','m','d'].some(k=>first.facts.sizhu[k]!==last.facts.sizhu[k]))ask('这个时辰内发生交节、换将或换日，请补充具体钟点，或明确四柱及月将，避免取错盘。');
  return first.facts;
}
/** AI extracts the calendar fields; the installed calendar engine performs all conversion. */
export function resolveCalendarParameters<T extends CalendarParameters>(raw:T,base:CaseInput):{parameters:Omit<T,'calendarDate'|'pillars'>&{pillars?:CaseInput['pillars']};note?:string}{
  const {calendarDate:c,pillars:draft,...rest}=raw;
  const result={...rest} as Omit<T,'calendarDate'|'pillars'>&{pillars?:CaseInput['pillars']};
  if(draft&&!c&&!raw.time&&!raw.mode)result.mode='pillars';
  let p=draft?{...draft}:undefined,note:string|undefined;
  if(c){
    if(raw.mode==='random')ask('随机起课与指定历法时间同时出现，请说明这次采用哪种方式。');
    // Chinese lunar civil dates are defined in Beijing time. Do not reinterpret
    // another zone without an explicit conversion request being clarified.
    if((raw.timeZone??base.timeZone)!=='Asia/Shanghai')ask('历法日期转换按北京时间进行，请确认对应北京时间，或提供带时区的公历时刻。');
    const date=civilDate(c),h=c.hour;
    note=`${c.calendar==='lunar'?`农历${c.year}年${c.leapMonth?'闰':''}${c.month}月${c.day}日 → `:''}公历${date}${c.hourBranch?` ${c.hourBranch}时`:h!==undefined?` ${pad(h)}:${pad(c.minute??0)}`:''}（北京时间）`;
    if(c.hourBranch&&h!==undefined&&BRANCHES[Math.floor((h+1)%24/2)]!==c.hourBranch)ask('钟点与所给时辰不一致，请核对；不会自动丢弃其中一种表达。');
    if(c.hourBranch&&h===undefined){
      if((raw.mode??base.mode)==='solar')ask('真太阳时换算需要具体钟点，请补充小时和分钟，或改用明确四柱及月将。');
      if(raw.time)ask('同时给出具体时刻和仅时辰的历法时间，请统一为一组完整日期及钟点后再确认。');
      const f=branchFacts(date,c.hourBranch,base);comparePillars(p??{},f,true);
      p={year:f.sizhu.y,month:f.sizhu.m,day:f.sizhu.d,hour:f.sizhu.h,monthGeneral:f.yuejiang,actualDate:date};result.mode='pillars';
    }else{
      if(h===undefined&&(raw.mode??base.mode)!=='number')ask('已识别历法日期，请补充起课钟点或时辰；不会把页面当前时间拼到历史日期上。');
      const time=`${date}T${pad(h??0)}:${pad(c.minute??0)}:${pad(c.second??0)}+08:00`;
      if(raw.time&&Date.parse(raw.time)!==Date.parse(time))ask('同时提供的公历时刻与历法日期换算结果不一致，请核对并说明采用哪一个。');
      result.time=time;result.mode=raw.mode==='pillars'?'pillars':raw.mode??'time';
      if(p||raw.mode==='pillars'){
        p??={};
        if((raw.mode??base.mode)==='solar'||(raw.mode??base.mode)==='number')ask('报数或真太阳时会改变时柱，请明确是按计算结果起课，还是直接采用给定四柱。');
        const f=chart(date,h??0,c.minute??0,base).facts;comparePillars(p,f,raw.mode!=='pillars');
        if(raw.mode==='pillars')p={year:f.sizhu.y,month:f.sizhu.m,day:f.sizhu.d,hour:f.sizhu.h,monthGeneral:f.yuejiang,...p,actualDate:date};
      }
    }
  }else if(p&&raw.time){
    const instant=new Date(raw.time);if(!Number.isFinite(+instant))ask('起课公历时刻无效，请核对日期与时区。');
    const wall=new Date(+instant+28800000).toISOString(),f=chart(wall.slice(0,10),+wall.slice(11,13),+wall.slice(14,16),base).facts;
    comparePillars(p,f,raw.mode!=='pillars');
    if(raw.mode==='pillars')p={year:f.sizhu.y,month:f.sizhu.m,day:f.sizhu.d,hour:f.sizhu.h,monthGeneral:f.yuejiang,...p,actualDate:wall.slice(0,10)};
  }
  if(p&&(result.mode??base.mode)==='pillars'){
    if(p.actualDate){
      if(!validDate(p.actualDate))ask('四柱所附实际公历日期无效，请核对。');
      if(p.hour){
        const b=p.hour.slice(-1),f=p.monthGeneral?chart(p.actualDate,BRANCHES.indexOf(b)*2,0,base).facts:branchFacts(p.actualDate,b,base);
        comparePillars({...p,hour:undefined},f,false);
        p={year:f.sizhu.y,month:f.sizhu.m,day:f.sizhu.d,hour:p.hour,monthGeneral:f.yuejiang,...p};
      }
    }
    p=completePillars(p);
    if(!p.monthGeneral){
      if(raw.rules?.yuejiang)ask(`四柱已齐，可以按原软件的四柱默认规则起课；但你另外指定了${raw.rules.yuejiang}，需补充实际日期或明确月将，才能核对交节规则。`);
      // The original index.js sizhu_sel_fun sets the month general to the
      // month branch's 六合 partner when selecting the month. This is a
      // manual-four-pillars default, not a civil-date/solar-term inference.
      p.monthGeneral=BRANCHES[(13-BRANCHES.indexOf(p.month!.slice(-1)))%12];
      note=`按原软件四柱规则：${p.month!.slice(-1)}月默认取${p.monthGeneral}将；未指定实际公历日期`;
    }
    result.pillars=p as NonNullable<CaseInput['pillars']>;
  }
  return {parameters:result,note};
}
