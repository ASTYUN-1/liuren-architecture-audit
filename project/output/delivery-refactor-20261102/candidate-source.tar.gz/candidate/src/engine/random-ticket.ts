import {createHmac,timingSafeEqual} from "node:crypto";
import type {CaseInput} from "../server/contracts";
export interface RandomAnchor {
  version:1; kind:"seed"|"selection"; time:string; rules:Record<string,string>;
  monthGeneral:string; pillars:{y:string;m:string;d:string}; engineVersion:string;
  number?:number; plateHash?:string;
}
function key(){const secret=process.env.BETTER_AUTH_SECRET;if(!secret||secret.length<32)throw new Error("random_signing_unavailable");return secret;}
export function signRandomTicket(anchor:RandomAnchor){const body=Buffer.from(JSON.stringify(anchor)).toString("base64url");return body+"."+createHmac("sha256",key()).update("wenheng-random-v1:"+body).digest("base64url");}
export function readRandomTicket(ticket:string,kind:RandomAnchor["kind"]):RandomAnchor {
  if(typeof ticket!=="string"||ticket.length>5000)throw new Error("random_ticket_invalid");
  const [body,sig,...rest]=ticket.split(".");
  const expected=createHmac("sha256",key()).update("wenheng-random-v1:"+body).digest();
  const actual=Buffer.from(sig||"","base64url");
  if(rest.length||actual.length!==expected.length||!timingSafeEqual(actual,expected))throw new Error("random_ticket_invalid");
  const a=JSON.parse(Buffer.from(body,"base64url").toString("utf8")) as RandomAnchor;
  if(a.version!==1||a.kind!==kind||!Number.isFinite(Date.parse(a.time))||!a.pillars||!a.rules||!/^.$/u.test(a.monthGeneral))throw new Error("random_ticket_invalid");
  if(kind==="seed"&&(Date.now()-Date.parse(a.time)>15*60000||Date.parse(a.time)>Date.now()+60000))throw new Error("random_session_expired");
  return a;
}
export function selectedAnchor(input:CaseInput){
  if(!input.random)return undefined;
  const a=readRandomTicket(input.random.ticket,"selection");
  if(input.mode!=="number"||input.number!==a.number||input.time!==a.time||input.longitude!==undefined||!a.plateHash||!Number.isInteger(a.number)||a.number!<1||a.number!>12||JSON.stringify(Object.entries(input.rules||{}).sort())!==JSON.stringify(Object.entries(a.rules).sort()))throw new Error("random_selection_changed");
  return a;
}
