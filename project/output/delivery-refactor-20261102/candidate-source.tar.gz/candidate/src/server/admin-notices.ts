import {sqlClient} from './db';
import {requireAdmin} from './points-config';
import {AppError,type Actor} from './http';
import type {AdminNotices,AdminNoticeModule} from '../lib/admin-notices';

// Only current actionable states generate notices. The key changes on reapplication,
// renewed refund requests or another failure, so a previous read cannot hide new work.
function candidates(){return sqlClient().unsafe(`
 WITH notices AS (
  SELECT 'practitioners'::text AS module,'cert:'||user_id||':'||revision AS item_key,applied_at AS at,'新的卦师认证申请'::text AS label FROM practitioner_certifications WHERE status='pending'
  UNION ALL SELECT 'payments','order:'||id||':'||status||':'||updated_at::text,updated_at,CASE WHEN status='refundPending' THEN '订单退款待核实' ELSE '支付状态待核实' END FROM orders WHERE status IN ('refundPending','paymentFrozen','submitted')
  UNION ALL SELECT 'tasks','usage-review:'||id,updated_at,'AI用量记录不完整，账务待核' FROM tasks WHERE billing_review_status='pending'
  UNION ALL SELECT 'points','refund:'||id||':'||updated_at::text,updated_at,'积分退款待处理' FROM point_refunds WHERE status='pending'
  UNION ALL SELECT 'points','human:'||id||':'||status||':'||updated_at::text,updated_at,CASE WHEN status='disputed' THEN '真人服务争议待处理' WHEN status='accepted' THEN '已接单服务待完成' ELSE '新的真人服务预约' END FROM human_assists WHERE status IN ('pending','accepted','disputed')
  UNION ALL SELECT 'tasks','task:'||id||':'||updated_at::text,updated_at,'解读未完成，需要检查' FROM tasks WHERE status='failed'
  UNION ALL SELECT 'users','delete:'||target_id||':'||max(created_at)::text,max(created_at),'账户注销申请待处理' FROM audit_log a WHERE action='accountDeletionRequested' AND NOT EXISTS(SELECT 1 FROM audit_log done WHERE done.target_id=a.target_id AND done.action='accountDeletionCompleted' AND done.created_at>=a.created_at) GROUP BY target_id
 ) SELECT * FROM notices`);}

export async function adminNotices(a:Actor):Promise<AdminNotices>{
 requireAdmin(a);const db=sqlClient();
 const [rows,reads]=await Promise.all([candidates(),db`SELECT item_key FROM admin_notice_reads WHERE operator_id=${a.id}`]);
 const read=new Set(reads.map(r=>r.item_key));
 const modules:AdminNotices['modules']={};
 for(const r of rows){const key=r.module as AdminNoticeModule;const v=modules[key]??={pending:0,unread:0,items:[]};v.pending++;if(!read.has(r.item_key)){v.unread++;v.items.push({key:r.item_key,label:r.label,at:new Date(r.at).toISOString()});}}
 for(const v of Object.values(modules))v.items=v.items.sort((a,b)=>b.at.localeCompare(a.at)).slice(0,100);
 return {modules};
}
export async function readAdminNotices(a:Actor,data:unknown){
 requireAdmin(a);const keys=(data as {keys?:unknown})?.keys;
 if(!Array.isArray(keys)||!keys.length||keys.length>100||keys.some(k=>typeof k!=='string'||k.length>300))throw new AppError('INVALID_INPUT','请选择已显示的新消息');
 const current=await candidates(),allowed=new Set(current.map(r=>r.item_key)),accepted=[...new Set(keys as string[])].filter(k=>allowed.has(k));
 if(accepted.length)await sqlClient()`INSERT INTO admin_notice_reads ${sqlClient()(accepted.map(item_key=>({operator_id:a.id,item_key})), 'operator_id','item_key')} ON CONFLICT DO NOTHING`;
 return adminNotices(a);
}
