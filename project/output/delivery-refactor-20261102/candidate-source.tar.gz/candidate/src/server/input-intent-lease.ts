import {randomUUID} from 'node:crypto';
import {sqlClient} from './db';
import {AppError} from './http';
/** Short user lock coordinates all web processes. Never hold it during a model
 * call, and never let one request abort another account's or waiter's call. */
export async function acquireInputLease(userId:string,requestHash:string){
 const token=randomUUID();
 await sqlClient().begin(async tx=>{
  await tx`SELECT id FROM "user" WHERE id=${userId} FOR UPDATE`;
  await tx`DELETE FROM input_intent_leases WHERE user_id=${userId} AND expires_at<now()`;
  const leases=await tx`SELECT request_hash FROM input_intent_leases WHERE user_id=${userId}`;
  if(leases.some(l=>l.request_hash===requestHash))throw new AppError('INPUT_REVIEW_ACTIVE','相同输入正在整理，请等待完成或停止原请求后再试',409);
  if(leases.length>=2)throw new AppError('INPUT_REVIEW_BUSY','已有两个输入正在整理，请完成或停止其中一个后再试',429);
  await tx`INSERT INTO input_intent_leases(token,user_id,request_hash) VALUES(${token},${userId},${requestHash})`;
 });
 return async()=>{await sqlClient()`DELETE FROM input_intent_leases WHERE token=${token} AND user_id=${userId}`;};
}
