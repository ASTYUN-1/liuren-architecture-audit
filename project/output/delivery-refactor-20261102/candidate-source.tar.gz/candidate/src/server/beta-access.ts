import {AppError,actor,type Actor} from './http';
export const publicUiEnabled=()=>process.env.WENHENG_PUBLIC_UI_ENABLED!=='false';
export function betaAllowed(a:Pick<Actor,'id'|'emailVerified'>){
 if(publicUiEnabled())return true;
 const id=process.env.WENHENG_BETA_USER_ID?.trim();
 return process.env.WENHENG_BETA_ENABLED==='true'&&!!id&&a.emailVerified&&a.id===id;
}
export async function betaActor(req:Request){const a=await actor(req);if(!betaAllowed(a))throw new AppError('BETA_FORBIDDEN','内测尚未向此账号开放',403);return a;}
