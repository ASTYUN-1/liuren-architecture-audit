import {readFile} from 'node:fs/promises';
import {createHmac,timingSafeEqual} from 'node:crypto';
import {z} from 'zod';
import {sqlClient} from './db';
import {AppError,type Actor} from './http';
import {requireAdmin} from './points-config';
import {MONITOR_NODES,monitorPoint,monitorAlerts,type ResourceSnapshot,type MonitorNode,type ResourceMonitorView} from '../lib/resource-monitor';

const bytes=z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),percent=z.number().min(0).max(100),iso=z.string().datetime({offset:true});
const sampleSchema=z.object({
 node:z.enum(['hk','cn','windows','ubuntu']),at:iso,bootId:z.string().min(1).max(80).regex(/^[a-zA-Z0-9:._-]+$/),uptimeSeconds:bytes,
 cpu:z.object({percent:percent.nullable(),cores:z.number().int().min(1).max(1024),load1:z.number().nonnegative().max(100000).nullable(),iowaitPercent:percent.nullable()}).strict(),
 memory:z.object({total:bytes.positive(),available:bytes,swapTotal:bytes,swapUsed:bytes}).strict().refine(v=>v.available<=v.total&&v.swapUsed<=v.swapTotal),
 disks:z.array(z.object({id:z.string().regex(/^(system|[C-Z])$/),total:bytes.positive(),available:bytes}).strict().refine(v=>v.available<=v.total)).min(1).max(12),
 network:z.object({rxBps:bytes.nullable(),txBps:bytes.nullable(),dayRx:bytes,dayTx:bytes,monthRx:bytes,monthTx:bytes,trackingSince:iso,interfaceCount:z.number().int().min(0).max(64)}).strict(),
 services:z.array(z.object({id:z.enum(['web','worker','database','relay','nginx','frps','derper','otherWeb','legacyRelay']),state:z.enum(['active','inactive','failed','activating','unknown'])}).strict()).max(12),
 backup:z.object({status:z.enum(['success','failed','unknown']),lastSuccessAt:iso.nullable()}).strict().optional(),
 storage:z.array(z.object({id:z.enum(['releases','resources','backups','database','avatars','virtualDisk']),bytes}).strict()).max(8).optional(),
 processes:z.array(z.object({id:z.enum(['web','worker','database']),bytes}).strict()).max(3).optional(),
 vm:z.object({state:z.enum(['running','off','other']),assignedBytes:bytes,startupBytes:bytes,dynamic:z.boolean()}).strict().optional(),
}).strict();
export function verifyMonitorSample(raw:string,headers:Headers,keys:Record<string,string>,now=Date.now()):ResourceSnapshot{
 const node=headers.get('x-wenheng-node')||'',stamp=headers.get('x-wenheng-time')||'',signature=headers.get('x-wenheng-signature')||'';
 const key=Object.prototype.hasOwnProperty.call(keys,node)?keys[node]:'';
 if(!/^[a-f0-9]{64}$/.test(key)||!/^\d{13}$/.test(stamp)||Math.abs(now-Number(stamp))>120000||! /^[a-f0-9]{64}$/.test(signature))throw new AppError('MONITOR_UNAUTHORIZED','Invalid collector signature',401);
 const expected=createHmac('sha256',Buffer.from(key,'hex')).update(node+'\n'+stamp+'\n'+raw).digest();
 if(!timingSafeEqual(expected,Buffer.from(signature,'hex')))throw new AppError('MONITOR_UNAUTHORIZED','Invalid collector signature',401);
 let parsed:unknown;try{parsed=JSON.parse(raw);}catch{throw new AppError('MONITOR_INVALID','Invalid metrics',400);}
 const result=sampleSchema.safeParse(parsed);
 if(!result.success||result.data.node!==node||Math.abs(Date.parse(result.data.at)-Number(stamp))>2000)throw new AppError('MONITOR_INVALID','Invalid metrics',400);
 return result.data;
}
let keyCache:{at:number;keys:Record<string,string>}|null=null;
async function collectorKeys(){if(keyCache&&Date.now()-keyCache.at<60000)return keyCache.keys;try{const keys=JSON.parse(await readFile(process.env.WENHENG_MONITOR_KEYS_FILE||'/etc/wenheng/monitor-keys.json','utf8'));if(!keys||typeof keys!=='object')throw Error();keyCache={at:Date.now(),keys};return keys;}catch{throw new AppError('MONITOR_UNAVAILABLE','Monitoring is not configured',503);}}
export async function ingestMonitor(raw:string,headers:Headers){return storeMonitorSample(verifyMonitorSample(raw,headers,await collectorKeys()));}
let lastPrune=0;
export async function storeMonitorSample(s:ResourceSnapshot){
 const db=sqlClient(),bucket=new Date(Math.floor(Date.parse(s.at)/60000)*60000).toISOString();
 const rows=await db`INSERT INTO resource_monitor_samples(node_id,bucket,sampled_at,received_at,payload) VALUES(${s.node},${bucket},${s.at},now(),${db.json(s as any)}) ON CONFLICT(node_id,bucket) DO UPDATE SET sampled_at=excluded.sampled_at,received_at=excluded.received_at,payload=excluded.payload WHERE excluded.sampled_at>resource_monitor_samples.sampled_at RETURNING node_id`;
 if(Date.now()-lastPrune>3600000){await db`DELETE FROM resource_monitor_samples WHERE bucket<now()-interval '7 days'`;lastPrune=Date.now();}
 return {accepted:rows.length>0};
}
export async function resourceMonitor(a:Actor,rangeValue:string|null):Promise<ResourceMonitorView>{
 requireAdmin(a);if(rangeValue!==null&&!['1h','24h'].includes(rangeValue))throw new AppError('MONITOR_RANGE','请选择最近1小时或24小时',400);
 const range=rangeValue==='24h'?'24h':'1h',db=sqlClient(),started=performance.now();
 const [latest,history,business,heartbeat]=await Promise.all([
  db`SELECT DISTINCT ON (node_id) node_id,payload,received_at FROM resource_monitor_samples ORDER BY node_id,bucket DESC`,
  db`SELECT node_id,payload FROM resource_monitor_samples WHERE bucket>=now()-${range==='24h'?24:1}*interval '1 hour' ORDER BY bucket`,
  db`SELECT count(*) FILTER(WHERE status='queued')::int AS queued,count(*) FILTER(WHERE status='running')::int AS running,count(*) FILTER(WHERE status='failed' AND updated_at>now()-interval '24 hours')::int AS failed,count(*) FILTER(WHERE status='succeeded' AND updated_at>now()-interval '24 hours' AND clarification IS NULL)::int AS completed,min(created_at) FILTER(WHERE status='queued') AS oldest FROM tasks`,
  db`SELECT value->>'at' AS at FROM service_settings WHERE key='workerHeartbeat'`,
 ]);
 const now=Date.now(),nodes:MonitorNode[]=MONITOR_NODES.map(n=>{const row=latest.find(r=>r.node_id===n.id),sample=row?.payload as ResourceSnapshot|undefined;return {id:n.id,sample:sample||null,receivedAt:row?new Date(row.received_at).toISOString():null,stale:!row||now-new Date(row.received_at).getTime()>75000||!sample||now-Date.parse(sample.at)>90000,history:history.filter(r=>r.node_id===n.id).map(r=>monitorPoint(r.payload as ResourceSnapshot))};});
 const workerAt=heartbeat[0]?.at||null,workerOnline=!!workerAt&&now-Date.parse(workerAt)<90000;
 return {at:new Date(now).toISOString(),range,nodes,alerts:monitorAlerts(nodes,workerOnline),business:{queued:business[0].queued,running:business[0].running,failed24h:business[0].failed,completed24h:business[0].completed,oldestQueuedAt:business[0].oldest?new Date(business[0].oldest).toISOString():null,workerAt,workerOnline,databaseMs:Math.round(performance.now()-started)},retentionDays:7,sampleSeconds:15};
}
