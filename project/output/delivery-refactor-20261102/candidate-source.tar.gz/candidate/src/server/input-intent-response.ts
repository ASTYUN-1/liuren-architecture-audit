import {AppError} from './http';
import {TASK_MAX_MS} from '../agent/execution-control';

/** JSON whitespace keeps the ordinary proxy read timer alive without changing
 * the final envelope. Errors after headers must be checked by the client. */
export function inputIntentResponse(request:Request,resolve:(signal:AbortSignal)=>Promise<unknown>,options:{heartbeatMs?:number;maxMs?:number}={}){
 const abort=new AbortController(),signal=AbortSignal.any([abort.signal,request.signal,AbortSignal.timeout(options.maxMs??TASK_MAX_MS)]);
 let stop:()=>void=()=>{};
 const stream=new ReadableStream<Uint8Array>({
  start(controller){
   const encoder=new TextEncoder();let closed=false;
   const send=(value:string)=>{if(!closed)controller.enqueue(encoder.encode(value));};
   const timer=setInterval(()=>send('\n'),options.heartbeatMs??15000);
   const close=()=>{if(closed)return;closed=true;clearInterval(timer);signal.removeEventListener('abort',onAbort);controller.close();};
   const fail=(e:unknown)=>{if(closed)return;const error=e instanceof AppError?{code:e.code,message:e.message,status:e.status}:{code:'INTENT_UNAVAILABLE',status:503,message:'暂时未能完整整理起课要求，请重试；尚未开始解读或扣分'};send(JSON.stringify({error}));close();};
   const onAbort=()=>fail(new AppError('INTENT_TIMEOUT','输入整理已停止；尚未开始解读或扣分',504));
   stop=()=>{closed=true;clearInterval(timer);signal.removeEventListener('abort',onAbort);abort.abort();};
   signal.addEventListener('abort',onAbort,{once:true});
   send('\n');
   if(signal.aborted){onAbort();return;}
   Promise.resolve().then(()=>resolve(signal)).then(data=>{send(JSON.stringify({data}));close();},fail);
  },
  cancel(){stop();}
 });
 return new Response(stream,{headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'private, no-store','X-Accel-Buffering':'no'}});
}
