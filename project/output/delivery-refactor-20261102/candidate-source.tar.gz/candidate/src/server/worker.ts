import {saveDeliveryDraft} from './delivery-store';
import {settleDelivery} from './delivery-settlement';
import {RuntimeTelemetry,type RuntimePerformanceEvent} from '../agent/runtime-telemetry';
import {watchTaskCancellation} from './task-cancellation-signal';
import {dispatchTasks} from './task-dispatch';
import {workerConcurrency,TASK_MAX_MS} from '../agent/execution-control';
import {expireUnfinishedTasks} from './task-expiry';
import {taskOutputAudience} from './practitioner-certification';
import {shouldRetryTask} from "./task-retry";
import {safeFailure} from "./operations";
import {finishHold,assertAiTaskBalance} from "./points";
import {recordUsage} from "./points-ai";
import {maintainPoints} from "./human-assist";
import {drainMailOutbox} from "./mail-outbox";
import {rewardDeliveredReferral} from "./referrals";
import {randomUUID} from "node:crypto";
import {pathToFileURL} from "node:url";
import {sqlClient,type Tx} from "./db";
import {getQueue,QUEUE} from "./queue";
import {runInterpretation} from "../agent/runtime";
import {getRuntimeSettings} from "./settings";
import {lockCase,purgeLocked,requestRefund} from "./service";
const db=sqlClient();
function mergeUsage(previous:any,current:any){const merged={...previous,...current};for(const key of ["requests","inputTokens","outputTokens","cachedInputTokens","costCny","failures","toolCalls"])merged[key]=Number(previous?.[key]||0)+Number(current?.[key]||0);merged.reservedCny=0;return merged;}
async function ledger(tx:Tx,t:any,action:string,quantity:number){await tx`INSERT INTO entitlement_ledger(id,case_id,entitlement_id,task_id,action,quantity) VALUES(${randomUUID()},${t.case_id},${t.entitlement_id},${t.id},${action},${quantity}) ON CONFLICT DO NOTHING`;}
export async function executeTask(taskId:string){
  const token=randomUUID();
  const acquired=await db.begin(async tx=>{const [look]=await tx`SELECT case_id FROM tasks WHERE id=${taskId}`;if(!look)return null;const c=await lockCase(tx,look.case_id,undefined,true);const [t]=await tx`SELECT * FROM tasks WHERE id=${taskId} FOR UPDATE`;if(c.deleted_at||c.permanently_deleted||t.status!=="queued"||new Date(t.created_at).getTime()<Date.now()-7*86400000)return null;const [input]=await tx`SELECT input FROM case_inputs WHERE case_id=${c.id} AND version=${t.input_version}`;if(!input)throw new Error("missing_input_version");await tx`UPDATE tasks SET status='running',error=NULL,worker_token=${token},lease_expires_at=now()+interval '2 minutes',attempts=attempts+1,runtime_progress=${tx.json({state:'starting',startedAt:new Date().toISOString(),at:new Date().toISOString()})},updated_at=now() WHERE id=${taskId}`;await tx`UPDATE cases SET status='running',updated_at=now() WHERE id=${c.id}`;const history=await tx`SELECT question,answer FROM tasks WHERE case_id=${c.id} AND input_version=${t.input_version} AND kind='followup' AND status='succeeded' AND answer IS NOT NULL ORDER BY created_at`;return {c,t,audience:await taskOutputAudience(tx,{id:t.id,user_id:t.user_id,output_audience:t.output_audience}),input:input.input,history:history.map(h=>({question:h.question,answer:h.answer}))};});
  if(!acquired)return;
  const {c,t,input,history,audience}=acquired,abort=new AbortController(),telemetry=new RuntimeTelemetry();
  if(Number(t.execution_elapsed_ms||0)>=TASK_MAX_MS){await failTask(taskId,token,'interpretation_timeout',{requests:0,toolCalls:0});return;}
  let taskDeadlineExpired=false;const deadline=setTimeout(()=>{taskDeadlineExpired=true;abort.abort();},Math.max(0,TASK_MAX_MS-Number(t.execution_elapsed_ms||0)));
  let unwatch=()=>{};let heartbeat:ReturnType<typeof setInterval>|undefined;
  try{
  try{unwatch=await watchTaskCancellation(taskId,abort);}catch{ /* lease heartbeat remains a fail-safe */ }
  const [currentState]=await db`SELECT status,worker_token FROM tasks WHERE id=${taskId}`;if(currentState?.status!=='running'||currentState.worker_token!==token)abort.abort();
  heartbeat=setInterval(async()=>{try{const rows=await db`UPDATE tasks SET lease_expires_at=now()+interval '2 minutes' WHERE id=${taskId} AND worker_token=${token} AND status='running' RETURNING id`;if(!rows.length)abort.abort();}catch{abort.abort();}},20000);
  let lastSaved=0;const startedAt=new Date().toISOString();
  let lastTelemetrySaved=0;const onPerformance=async(event:RuntimePerformanceEvent)=>{telemetry.emit(event);const now=Date.now();if(now-lastTelemetrySaved<3000)return;lastTelemetrySaved=now;await db`UPDATE tasks SET usage=jsonb_set(coalesce(usage,'{}'::jsonb),'{performanceSummary}',${db.json(telemetry.summary() as any)}) WHERE id=${taskId} AND status='running' AND worker_token=${token}`;};
  const onProgress=async(stage:string)=>{
    const now=Date.now(),state=(stage.startsWith('model_request:')||stage.startsWith('model_delta:'))?'model_working':stage.startsWith('model_completed:')?'model_responded':stage.startsWith('tool_ok:')?'tools_progressing':stage.startsWith('tool_error:')?'tool_correction':(stage==='output_retry'||stage==='delivery_recovery')?'output_recovery':stage;
    if(now-lastSaved<3000&&state!=='tool_correction'&&state!=='output_recovery'&&state!=='checking')return;lastSaved=now;
    await db`UPDATE tasks SET runtime_progress=${db.json({state,startedAt,at:new Date(now).toISOString(),longRunning:now-Date.parse(startedAt)>10*60000})} WHERE id=${taskId} AND status='running' AND worker_token=${token}`;
  };
    abort.signal.throwIfAborted();const settings=await getRuntimeSettings();if(!settings.aiEnabled||!settings.deepseekApiKey)throw new Error("model_not_configured");
    await assertAiTaskBalance(db,{point_hold_id:t.point_hold_id,user_id:t.user_id});
    const result=await runInterpretation({executionElapsedMs:Number(t.execution_elapsed_ms||0),deliveryProtocol:t.delivery_protocol??"legacy",onDraft:draft=>saveDeliveryDraft(taskId,c.id,token,t.input_version,draft),audience,taskId,caseId:c.id,kind:t.kind,input,question:t.question||undefined,report:c.report,previousChart:c.internal_chart||undefined,history,signal:abort.signal,apiKey:settings.deepseekApiKey,onUsage:event=>recordUsage(taskId,t.attempts+1,event),onProgress,onPerformance});
    const totalUsage=mergeUsage(t.usage,result.usage);
    await db.begin(async tx=>{const current=await lockCase(tx,c.id,undefined,true);const [live]=await tx`SELECT * FROM tasks WHERE id=${taskId} FOR UPDATE`;if(current.deleted_at||current.permanently_deleted||live.status!=="running"||live.worker_token!==token)return;if(current.input_version!==t.input_version||live.input_version!==t.input_version)throw new Error('delivery_input_version_changed');
      if(result.clarification){if(live.point_hold_id)await finishHold(tx,live.point_hold_id,0,"免费补充资料");if(live.entitlement_id){await tx`UPDATE entitlements SET reserved=reserved-1 WHERE id=${live.entitlement_id} AND reserved>0`;await ledger(tx,live,"clarificationRelease:"+live.clarification_count,1);}await tx`UPDATE tasks SET status='succeeded',clarification=${result.clarification},usage=${tx.json(totalUsage)},internal_evidence=${tx.json(result.evidence as any)},worker_token=NULL,lease_expires_at=NULL,updated_at=now() WHERE id=${taskId}`;await tx`UPDATE cases SET status='needsClarification',updated_at=now() WHERE id=${c.id}`;return;}
      if(t.kind==="initial"){if(!result.report?.content)throw new Error("empty_report");await tx`UPDATE cases SET report=${tx.json(result.report as any)},internal_chart=${tx.json(result.chart as any)},status='ready',updated_at=now() WHERE id=${c.id}`;
      if(!live.system_correction&&result.delivery?.outcome!=="limited")await rewardDeliveredReferral(tx,c.id);
      }else{if(!result.answer)throw new Error("empty_followup");await tx`UPDATE cases SET status='ready',updated_at=now() WHERE id=${c.id}`;}
      await settleDelivery(tx,live,current,result.delivery?.outcome??'complete');
      await tx`UPDATE tasks SET status='succeeded',delivery_result=${tx.json(result.delivery as any??null)},answer=${result.answer||null},clarification=NULL,error=NULL,usage=${tx.json(totalUsage)},internal_evidence=${tx.json(result.evidence as any)},worker_token=NULL,lease_expires_at=NULL,updated_at=now() WHERE id=${taskId}`;
    });
  }catch(error){await failTask(taskId,token,taskDeadlineExpired?'interpretation_timeout':error instanceof Error?error.message:"interpretation_failed",(error as {usage?:Record<string,unknown>})?.usage??{performanceSummary:telemetry.summary()});}
  finally{clearInterval(heartbeat);clearTimeout(deadline);unwatch();}
}
async function failTask(taskId:string,token:string,error:string,usage?:Record<string,unknown>){await db.begin(async tx=>{const [look]=await tx`SELECT case_id FROM tasks WHERE id=${taskId}`;if(!look)return;const c=await lockCase(tx,look.case_id,undefined,true);const [t]=await tx`SELECT * FROM tasks WHERE id=${taskId} FOR UPDATE`;if(t.status!=="running"||t.worker_token!==token)return;if(usage&&('requests' in usage||'costCny' in usage))await tx`UPDATE tasks SET usage=${tx.json(mergeUsage(t.usage,usage))} WHERE id=${taskId}`;else{const [actual]=await tx`SELECT coalesce(sum(cost_nano_cny) FILTER(WHERE verified),0)::text AS cost,count(*)::int AS requests,count(*) FILTER(WHERE NOT verified)::int AS unknown FROM point_usage_events WHERE task_id=${taskId}`;await tx`UPDATE tasks SET usage=${tx.json({...t.usage,...usage,requests:actual.requests,costCny:Number(actual.cost)/1e9,reservedCny:0,unknownUsage:actual.unknown,usageIncompleteAfterWorkerLoss:true})} WHERE id=${taskId}`;usage={...usage,requests:Math.max(actual.requests,Number((usage?.performanceSummary as any)?.modelRequests??t.usage?.performanceSummary?.modelRequests??0)),toolCalls:(usage?.performanceSummary as any)?.toolCalls??t.usage?.performanceSummary?.toolCalls??0};}const retry=shouldRetryTask(error,t.attempts,usage)&&!c.deleted_at&&!c.permanently_deleted;await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},'system','taskAttemptFailed',${taskId},${tx.json({code:safeFailure(error.split(":")[0]),attempt:t.attempts,retrying:retry})})`;if(retry){await tx`UPDATE tasks SET status='queued',queued_at=NULL,error='暂时故障，正在重试',worker_token=NULL,lease_expires_at=NULL,updated_at=now() WHERE id=${taskId}`;await tx`UPDATE cases SET status='queued',updated_at=now() WHERE id=${c.id}`;return;}if(t.point_hold_id)await finishHold(tx,t.point_hold_id,0,"AI未交付，释放积分");if(t.entitlement_id){await tx`UPDATE entitlements SET reserved=reserved-1 WHERE id=${t.entitlement_id} AND reserved>0`;await ledger(tx,t,"failureRelease",1);}await tx`UPDATE tasks SET status='failed',error=${error==='points_balance_due'?'账户有欠费，任务未开始且未扣费；请充值后重试':error==='points_balance_insufficient'?'可用积分不足，追问未开始且未扣费；请充值后重试':error==='interpretation_timeout'?'分析超过30分钟仍未完成，已停止；未交付不扣费，请联系支持':error==='interpretation_stalled'?'分析长时间没有有效进展，已停止；未交付不扣费，请联系支持':error==='workflow_error_loop'?'分析流程反复校验失败，已停止；未交付不扣费，请联系支持':'解读未完成，未交付不扣费；请联系支持'},worker_token=NULL,lease_expires_at=NULL,updated_at=now() WHERE id=${taskId}`;await tx`UPDATE cases SET status=${c.report?"ready":"failed"},updated_at=now() WHERE id=${c.id}`;await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},'system','taskFailed',${taskId},${tx.json({code:safeFailure(error.split(":")[0])})})`;});await requestInitialRefund(taskId);}
async function requestInitialRefund(taskId:string){const [t]=await db`SELECT t.*,u.email,u.name,u.email_verified FROM tasks t JOIN "user" u ON u.id=t.user_id WHERE t.id=${taskId} AND t.kind='initial' AND t.status='failed'`;if(!t)return;const [o]=await db`SELECT id FROM orders WHERE case_id=${t.case_id} AND kind='base' AND status='paid'`;if(o)await requestRefund({id:t.user_id,email:t.email,name:t.name,emailVerified:t.email_verified,isAdmin:false},o.id,"系统未成功交付主报告，申请全额退款").catch(e=>console.error("Refund request failure",e.message));}
async function maintenance(){
  // Durable task rows are an outbox. Dispatch may be repeated; acquisition+worker tokens fence stale delivery.
  const queue=await getQueue();await expireUnfinishedTasks();
  const abandoned=await db`SELECT case_id FROM orders WHERE kind='base' AND status='pending' AND expires_at<now() LIMIT 100`;
  for(const o of abandoned)await db.begin(async tx=>{const c=await lockCase(tx,o.case_id,undefined,true);await tx`UPDATE orders SET status='cancelled',updated_at=now() WHERE case_id=${c.id} AND status='pending' AND expires_at<now()`;if(c.status==='awaitingPayment'&&!(await tx`SELECT id FROM orders WHERE case_id=${c.id} AND kind='base' AND status NOT IN ('cancelled','refunded')`).length)await tx`UPDATE cases SET status='draft',updated_at=now() WHERE id=${c.id}`;});
  const expired=await db`SELECT id,worker_token FROM tasks WHERE status='running' AND lease_expires_at<now()`;for(const t of expired)await failTask(t.id,t.worker_token,"worker_lease_expired");
  await dispatchTasks(queue);
  const deleted=await db`SELECT id FROM cases WHERE deleted_at IS NOT NULL AND permanently_deleted=false AND purge_after<now() LIMIT 20`;for(const c of deleted)await db.begin(async tx=>{await lockCase(tx,c.id,undefined,true);await purgeLocked(tx,c.id);});
  const overdue=await db`SELECT id FROM tasks WHERE kind='initial' AND status IN ('queued','running') AND created_at<now()-interval '24 hours'`;for(const t of overdue){const [o]=await db`SELECT o.*,u.email,u.name,u.email_verified FROM orders o JOIN "user" u ON u.id=o.user_id JOIN tasks t ON t.case_id=o.case_id WHERE t.id=${t.id} AND o.kind='base' AND o.status='paid'`;if(o)await requestRefund({id:o.user_id,email:o.email,name:o.name,emailVerified:o.email_verified,isAdmin:false},o.id,"付款24小时后仍未交付，申请全额退款").catch(e=>console.error("Overdue refund",e.message));}
  await maintainPoints();
  await drainMailOutbox();
  await db`DELETE FROM input_intent_leases WHERE expires_at<now()`;
  await db`DELETE FROM rate_limits WHERE window_start<now()-interval '2 days'`;
}
async function main(){const boss=await getQueue();await boss.work<{taskId:string}>(QUEUE,{batchSize:1,localConcurrency:workerConcurrency()},async jobs=>{for(const job of jobs){await executeTask(job.data.taskId);await dispatchTasks(boss).catch(()=>console.error('Task dispatch deferred until maintenance'));}});await maintenance();let busy=false;const timer=setInterval(async()=>{if(busy)return;busy=true;try{await maintenance();}catch(e){console.error("Worker maintenance failed",e instanceof Error?e.message:"unknown");}finally{busy=false;}},10000);await db`INSERT INTO service_settings(key,value) VALUES('workerHeartbeat',${db.json({at:new Date().toISOString()})}) ON CONFLICT(key) DO UPDATE SET value=excluded.value`;const heartbeat=setInterval(async()=>{await db`INSERT INTO service_settings(key,value) VALUES('workerHeartbeat',${db.json({at:new Date().toISOString()})}) ON CONFLICT(key) DO UPDATE SET value=excluded.value`.catch(()=>{});},30000);for(const signal of ["SIGTERM","SIGINT"] as const)process.on(signal,async()=>{clearInterval(timer);clearInterval(heartbeat);await boss.stop({graceful:true,timeout:31*60_000});await db.end();process.exit(0);});console.log("Wenheng worker ready");}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)main().catch(()=>{console.error("Worker startup failed; inspect private service diagnostics");process.exit(1);});


