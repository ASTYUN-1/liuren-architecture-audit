import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";
import * as schema from "./schema";
let connection: ReturnType<typeof postgres> | undefined;
let authConnection:ReturnType<typeof postgres>|undefined;
export function sqlClient(){
  if(!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required; no in-memory database fallback is available");
  return connection ??= postgres(process.env.DATABASE_URL,{max:10,idle_timeout:20,connect_timeout:10});
}
export function authDb(){
  if(!process.env.DATABASE_URL)throw new Error("DATABASE_URL required");
  // Drizzle replaces postgres-js JSON serializers with identity functions because
  // Drizzle itself stringifies values. Do not share this client with raw SQL JSON.
  authConnection??=postgres(process.env.DATABASE_URL,{max:5,idle_timeout:20,connect_timeout:10});
  return drizzle(authConnection,{schema});
}
export type Sql = ReturnType<typeof postgres>;
export type Tx = postgres.TransactionSql;
