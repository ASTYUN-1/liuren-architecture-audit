import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { twoFactor,username } from "better-auth/plugins";
import { APIError } from "better-auth/api";
import {sendTransactionalMail} from "./mail";
import { authDb } from "./db";
import * as schema from "./schema";
import {bindSignupReferral} from "./referrals";
import {signupProtection} from "./signup-protection";
import {hasRealEmail,validUsername} from "../lib/account-identity";
import {trustedAppOrigins} from "./origins";
async function mail(to:string,kind:'verification'|'passwordReset',url:string){
 try{await sendTransactionalMail(to,kind,url);}catch(error){throw new APIError("SERVICE_UNAVAILABLE",{code:"MAIL_UNAVAILABLE",message:"邮件暂未发送成功，请稍后重试 / Email unavailable"});}
}
function createAuth(){
  if(!process.env.BETTER_AUTH_SECRET || process.env.BETTER_AUTH_SECRET.length<32) throw new Error("BETTER_AUTH_SECRET must contain at least 32 characters");
  return betterAuth({
    database:drizzleAdapter(authDb(),{provider:"pg",schema}),
    secret:process.env.BETTER_AUTH_SECRET,baseURL:process.env.APP_URL||"http://localhost:3000",
    trustedOrigins:trustedAppOrigins(),
    // Keep the production security boundary enabled in isolated tests too.
    advanced:{disableOriginCheck:false,disableCSRFCheck:false},
    databaseHooks:{user:{update:{before:async(user)=>{if((user as {username?:unknown;displayUsername?:unknown}).username!==undefined||(user as {displayUsername?:unknown}).displayUsername!==undefined)throw new APIError("BAD_REQUEST",{message:"请在账户设置管理登录账号"});if(user.image!==undefined)throw new APIError("BAD_REQUEST",{code:"AVATAR_ENDPOINT_REQUIRED",message:"请在账户设置上传头像 / Upload your avatar in account settings"});}},create:{before:async(user,ctx)=>{const value=(user as {username?:string}).username?.trim().toLowerCase();if((value&&!validUsername(value))||(!value&&!hasRealEmail(user.email)))throw new APIError("BAD_REQUEST",{message:"账号需为4～24位字母、数字或下划线，且不能使用系统保留名"});await signupProtection(ctx?.headers||new Headers(),ctx?.body);return {data:{...user,username:value||null,image:null}};},after:async(user,ctx)=>{
      const cookies=ctx?.headers?.get('cookie')||ctx?.request?.headers.get('cookie')||'';
      const code=cookies.match(/(?:^|;\s*)wenheng_invite=([a-f0-9]{24})(?:;|$)/)?.[1];
      await bindSignupReferral(user.id,code);
    }}}},
    emailAndPassword:{enabled:true,minPasswordLength:10,requireEmailVerification:false,revokeSessionsOnPasswordReset:true,sendResetPassword:async({user,url})=>{if(hasRealEmail(user.email)&&user.emailVerified)await mail(user.email,"passwordReset",url);}},
    emailVerification:{sendOnSignUp:true,expiresIn:3600,autoSignInAfterVerification:true,sendVerificationEmail:async({user,url})=>{if(hasRealEmail(user.email))try{await mail(user.email,"verification",url);}catch{console.warn("AUTH_VERIFICATION_DELIVERY_FAILED");}}},
    user:{changeEmail:{enabled:true},deleteUser:{enabled:false}},
    session:{expiresIn:60*60*24*7,updateAge:60*60*24},
    rateLimit:{enabled:true},
    plugins:[username({minUsernameLength:4,maxUsernameLength:24,usernameValidator:value=>validUsername(value.toLowerCase()),usernameNormalization:value=>value.trim().toLowerCase()}),twoFactor({issuer:"Wenheng"})],
  });
}
let instance:ReturnType<typeof createAuth>|undefined;
export function getAuth(){return instance??=createAuth();}

