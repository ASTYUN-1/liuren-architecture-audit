import type {PgBoss} from 'pg-boss';
import {QUEUE_EXPIRE_SECONDS,workerConcurrency} from '../agent/execution-control';
import {sqlClient} from './db';
import {QUEUE} from './queue';

// Recovery cannot precede the queue's own active execution expiry. The explicit
// exclusive policy and worker token remain necessary: a timestamp is not a lock.
export const QUEUE_REDISPATCH_SECONDS=QUEUE_EXPIRE_SECONDS+5*60;
export async function dispatchTasks(queue:PgBoss,capacity=workerConcurrency()){
 return sqlClient().begin(async tx=>{
  const [guard]=await tx`SELECT pg_try_advisory_xact_lock(187921,22002) AS locked`;if(!guard.locked)return [];
  const [busy]=await tx`SELECT count(*)::int AS n FROM tasks WHERE status='running' OR (status='queued' AND queued_at>now()-${QUEUE_REDISPATCH_SECONDS}*interval '1 second')`;
  let slots=Math.max(0,capacity-busy.n);if(!slots)return [];
  // Do not prefill pg-boss with a large account's backlog. Select a round from
  // every account before a second round; running/sent work counts toward load.
  const rows=await tx`
   WITH loads AS (
    SELECT user_id,count(*)::int AS n FROM tasks WHERE status='running' OR (status='queued' AND queued_at>now()-${QUEUE_REDISPATCH_SECONDS}*interval '1 second') GROUP BY user_id
   ), ranked AS (
    SELECT t.id,t.created_at,coalesce(l.n,0)+row_number() OVER(PARTITION BY t.user_id ORDER BY t.created_at,t.id) AS turn
    FROM tasks t LEFT JOIN loads l ON l.user_id=t.user_id
    WHERE t.status='queued' AND t.created_at>now()-interval '7 days' AND (t.queued_at IS NULL OR t.queued_at<now()-${QUEUE_REDISPATCH_SECONDS}*interval '1 second')
   ) SELECT id FROM ranked ORDER BY turn,created_at,id LIMIT 100`;
  const sentIds:string[]=[];
  for(const row of rows){
   if(!slots)break;
   const sent=await queue.send(QUEUE,{taskId:row.id},{singletonKey:row.id,retryLimit:0,expireInSeconds:QUEUE_EXPIRE_SECONDS,db:{executeSql:async(query:string,values?:unknown[])=>({rows:await tx.unsafe(query,(values??[]) as any[])})}});
   if(sent){await tx`UPDATE tasks SET queued_at=now() WHERE id=${row.id} AND status='queued'`;sentIds.push(row.id);slots--;}
  }
  return sentIds;
 });
}
