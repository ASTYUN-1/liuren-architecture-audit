import {randomUUID} from 'node:crypto';
import type {Tx} from './db';
import {finishHold} from './points';
import {settleAi} from './points-ai';
import {refundLocked} from './service';

/** Call under the case+task locks, in the same transaction as final delivery. */
export async function settleDelivery(tx:Tx,t:any,c:any,outcome:'complete'|'limited'){
 const action=outcome==='limited'?'limitedRelease':'consume';
 const [prior]=await tx`SELECT id FROM entitlement_ledger WHERE task_id=${t.id} AND action=${action}`;
 if(t.entitlement_id&&!prior){
  const changed=outcome==='limited'
   ?await tx`UPDATE entitlements SET reserved=reserved-1 WHERE id=${t.entitlement_id} AND reserved>0 RETURNING id`
   :await tx`UPDATE entitlements SET reserved=reserved-1,used=used+1 WHERE id=${t.entitlement_id} AND reserved>0 RETURNING id`;
  if(!changed.length)throw new Error('lost_reservation');
  await tx`INSERT INTO entitlement_ledger(id,case_id,entitlement_id,task_id,action,quantity) VALUES(${randomUUID()},${t.case_id},${t.entitlement_id},${t.id},${action},1) ON CONFLICT DO NOTHING`;
 }
 if(outcome==='complete'){await settleAi(tx,t);return;}
 if(t.point_hold_id)await finishHold(tx,t.point_hold_id,0,'带限制回答，本次免费');
 // A cash-paid legacy initial report needs an actual refund workflow, not a
 // fictitious "zero charge". Money is refunded only by the existing operator flow.
 if(t.kind==='initial'&&!t.point_hold_id&&!t.system_correction&&(!c.report||c.report.delivery?.outcome==='limited')){
  const orders=await tx`SELECT id FROM orders WHERE case_id=${t.case_id} AND kind='base' AND status='paid'`;
  for(const o of orders)await refundLocked(tx,{...c,report:{delivery:{outcome:'limited'}}},o.id,'本次仅交付受限回答，不按完整主报告收费，申请全额退款');
 }
}
