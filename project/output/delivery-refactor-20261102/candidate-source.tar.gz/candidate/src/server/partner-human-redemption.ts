import {createHash,randomUUID} from 'node:crypto';
import {sqlClient} from './db';
import {AppError,type Actor} from './http';
import {text} from './validation';
import {lockPointUser,finishHold} from './points';

/** Only the current assigned reader may settle this booking's existing hold. */
export async function completePartnerHuman(a:Actor,data:any){
 if(!a.emailVerified)throw new AppError('FORBIDDEN','请先验证邮箱',403);
 if(data.serviceCompleted!==true)throw new AppError('INVALID_INPUT','请确认本次真人辅助服务已完成');
 const code=text(data.code,80,1).trim().toUpperCase();
 const tokenHash=createHash('sha256').update(code).digest('hex');
 return sqlClient().begin(async tx=>{
  const [lookup]=await tx`SELECT s.user_id,s.booking_id FROM conversation_shares s JOIN advisor_accounts aa ON aa.advisor_id=s.advisor_id AND aa.user_id=${a.id} WHERE s.token_hash=${tokenHash}`;
  if(!lookup)throw new AppError('SHARE_UNAVAILABLE','分享码无效或未授权给你的卦师身份',404);
  // Same user -> booking -> hold order as cancellation, operator and maintenance.
  await lockPointUser(tx,lookup.user_id);
  const [r]=await tx`SELECT * FROM human_assists WHERE id=${lookup.booking_id} FOR UPDATE`;
  const [h]=await tx`SELECT * FROM point_holds WHERE id=${lookup.booking_id} FOR UPDATE`;
  // Recheck and lock both authorizations after waiting for any financial locks.
  const [share]=await tx`SELECT s.id FROM conversation_shares s JOIN advisor_accounts aa ON aa.advisor_id=s.advisor_id AND aa.user_id=${a.id} JOIN cases c ON c.id=s.case_id AND c.user_id=s.user_id
   WHERE s.token_hash=${tokenHash} AND s.booking_id=${lookup.booking_id} AND s.user_id=${lookup.user_id}
   AND s.advisor_id=${r?.advisor_id||''} AND s.case_id=${r?.case_id||null}
   AND s.revoked_at IS NULL AND s.expires_at>clock_timestamp() AND c.deleted_at IS NULL AND c.permanently_deleted=false FOR UPDATE OF s,aa`;
  if(!share)throw new AppError('SHARE_UNAVAILABLE','分享授权已撤销、到期或不可用，请重新验证',404);
  if(!r||!h||r.user_id!==lookup.user_id||h.kind!=='human'||h.user_id!==r.user_id||h.case_id!==r.case_id||!Number.isSafeInteger(h.units)||h.units<=0)throw new AppError('STATE','预约与积分记录不一致，请联系运营者',409);
  if(r.status==='completed'&&h.status==='settled'&&h.charged_units===h.units)return {id:r.id,status:'completed' as const,chargedUnits:h.charged_units,alreadyCompleted:true};
  if(!['pending','accepted','review'].includes(r.status)||h.status!=='held')throw new AppError('STATE','该预约不能核销；已取消、已退回或有争议的预约请联系运营者',409);
  if(new Date(r.deadline).getTime()<=Date.now())throw new AppError('EXPIRED','预约已超时，请联系运营者核对积分退回情况',409);
  const completedAt=new Date().toISOString(),summary='合作卦师确认本次真人辅助服务已实际完成。';
  await finishHold(tx,r.id,h.units,'合作卦师完成真人辅助并核销',a.id,{humanRedemption:{operatorId:a.id,advisorId:r.advisor_id,completedAt,summary,source:'partner'}});
  await tx`UPDATE human_assists SET status='completed',summary=${summary},updated_at=now() WHERE id=${r.id}`;
  await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'human:partner-redeem',${r.id},${tx.json({fromStatus:r.status,advisorId:r.advisor_id,chargedUnits:h.units,completedAt})})`;
  return {id:r.id,status:'completed' as const,chargedUnits:h.units,alreadyCompleted:false};
 });
}
