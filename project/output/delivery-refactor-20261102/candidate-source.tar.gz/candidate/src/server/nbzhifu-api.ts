import {createHash,timingSafeEqual} from 'node:crypto';
import {AppError} from './http';
export const NB_GATEWAY='https://pay.nbzhifu.com';
export type NbPaytype='alipay'|'wxpay';
export interface NbConfig {pid:string;secret:string;enabled:boolean;publicEnabled?:boolean}
export function nbSign(params:Record<string,unknown>,secret:string){
 const source=Object.keys(params).filter(k=>!['sign','sign_type'].includes(k)&&params[k]!==''&&params[k]!==null&&params[k]!==undefined).sort().map(k=>`${k}=${String(params[k])}`).join('&');
 return createHash('md5').update(source+'&key='+secret,'utf8').digest('hex').toUpperCase();
}
export function nbVerify(params:Record<string,string>,secret:string){
 if(params.sign_type!=='MD5'||!/^\w{32}$/.test(params.sign||''))return false;
 const expected=Buffer.from(nbSign(params,secret));const received=Buffer.from(params.sign.toUpperCase());
 return expected.length===received.length&&timingSafeEqual(expected,received);
}
export function nbCents(amount:unknown){
 const value=String(amount);if(!/^(0|[1-9]\d{0,7})(\.\d{1,2})?$/.test(value))throw new AppError('PAYMENT_AMOUNT','支付金额格式不正确',400);
 const [whole,fraction='']=value.split('.');return Number(whole)*100+Number(fraction.padEnd(2,'0'));
}
export function nbPayUrl(value:unknown){
 if(typeof value!=='string')throw new AppError('GATEWAY_RESPONSE','支付平台未返回收银台地址',502);
 let url:URL;try{url=new URL(value)}catch{throw new AppError('GATEWAY_RESPONSE','支付平台返回的地址无效',502)}
 if(url.origin!==NB_GATEWAY||url.username||url.password)throw new AppError('GATEWAY_RESPONSE','支付平台收银台地址不受信任',502);
 return url.href;
}
export async function nbRequest(config:NbConfig,path:'/openapi/pay/create'|'/openapi/pay/query'|'/openapi/merchant/balance_query',params:Record<string,string>={}){
 const fields={...params,pid:config.pid,timestamp:String(Math.floor(Date.now()/1000)),sign_type:'MD5'};
 let response:Response;
 try{response=await fetch(NB_GATEWAY+path,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({...fields,sign:nbSign(fields,config.secret)}),signal:AbortSignal.timeout(15000),redirect:'error',cache:'no-store'});}catch{throw new AppError('GATEWAY_UNAVAILABLE','聚合支付连接暂不可用，请稍后查询订单，勿重复付款',502)}
 if(!response.ok)throw new AppError('GATEWAY_UNAVAILABLE','聚合支付暂不可用',502);
 let result:any;try{result=await response.json()}catch{throw new AppError('GATEWAY_RESPONSE','支付平台响应格式不正确',502)}
 if(result.code!==1||!result.data)throw new AppError('GATEWAY_REJECTED',`聚合支付：${String(result.msg||'请求未完成').slice(0,160)}`,502);
 return result.data as Record<string,unknown>;
}
