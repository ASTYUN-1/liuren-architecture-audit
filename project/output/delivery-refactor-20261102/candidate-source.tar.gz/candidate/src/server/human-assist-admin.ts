import {sqlClient} from './db';
import {AppError,type Actor} from './http';
import {ADVISORS,requireAdmin} from './points-config';
import {createHash} from 'node:crypto';
import {text} from './validation';
import {redeemHuman} from './human-assist';

export async function quickRedeemHuman(a:Actor,value:unknown){
 requireAdmin(a);const code=text(value,80,2).trim().toUpperCase(),db=sqlClient();
 const isId=/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/.test(code);
 const rows=isId?await db`SELECT id FROM human_assists WHERE id=${code.toLowerCase()}`:await db`SELECT DISTINCT h.id FROM conversation_shares s JOIN human_assists h ON h.id=s.booking_id WHERE s.token_hash=${createHash('sha256').update(code).digest('hex')} AND s.revoked_at IS NULL AND s.expires_at>now()`;
 if(rows.length!==1)throw new AppError('NOT_FOUND','未找到有效预约，请输入完整预约编号或有效分享码',404);
 return redeemHuman(a,rows[0].id,{serviceCompleted:true,summary:'真人辅助服务已实际完成，运营者通过快捷核销确认。'});
}

type BookingRow={id:string;status:string;advisor_id:string;operator_name:string|null;charged_units:number;settled_at:Date|null}&Record<string,unknown>;

export async function humanAssistAdminView(a:Actor,params:URLSearchParams){
 requireAdmin(a);
 const scope=params.get('scope')||'active',q=(params.get('q')||'').trim(),page=Number(params.get('page')||0);
 if(!['active','history'].includes(scope)||q.length>120||!Number.isSafeInteger(page)||page<0||page>10000)throw new AppError('INVALID_INPUT','筛选条件无效');
 const pattern='%'+q.replace(/[\\%_]/g,'\\$&')+'%',db=sqlClient();
 const rows=await db<BookingRow[]>`SELECT r.id,r.user_id,r.case_id,r.advisor_id,r.question,r.status,r.summary,r.deadline,r.created_at,r.updated_at,
  u.name AS user_name,u.email AS user_email,p.code AS recharge_code,c.title AS case_title,
  h.units,h.status AS hold_status,h.charged_units,h.refunded_units,
  l.created_at AS settled_at,l.actor_id AS settled_by,op.name AS operator_name,l.reason AS settlement_reason
  FROM human_assists r JOIN "user" u ON u.id=r.user_id JOIN point_holds h ON h.id=r.id
  LEFT JOIN point_profiles p ON p.user_id=r.user_id LEFT JOIN cases c ON c.id=r.case_id
  LEFT JOIN LATERAL (SELECT created_at,actor_id,reason FROM point_ledger WHERE hold_id=r.id AND action IN ('settled','released') ORDER BY created_at DESC LIMIT 1) l ON true
  LEFT JOIN "user" op ON op.id=l.actor_id
  WHERE (${scope}='active' AND r.status IN ('pending','accepted','review','disputed') OR ${scope}='history' AND r.status IN ('completed','cancelled','refunded'))
  AND (${q}='' OR u.name ILIKE ${pattern} OR u.email ILIKE ${pattern} OR p.code ILIKE ${pattern} OR r.id::text=${q} OR r.user_id=${q})
  ORDER BY CASE WHEN ${scope}='active' AND r.status='disputed' THEN 0 ELSE 1 END,
  CASE WHEN ${scope}='active' THEN r.created_at END ASC,r.updated_at DESC,r.id
  LIMIT 51 OFFSET ${page*50}`;
 return {assists:rows.slice(0,50).map(r=>({...r,advisor_name:ADVISORS.find(a=>a.id===r.advisor_id)?.name||r.advisor_id})),hasMore:rows.length>50,page,scope};
}
