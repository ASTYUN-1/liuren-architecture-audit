import { createHmac } from "node:crypto";
import { isIP } from "node:net";
import { rateLimit } from "./http";

// Production ingress is Cloudflare Tunnel -> loopback-only HK nginx -> SSH.
// Cloudflare overwrites this header. Never use client-supplied X-Forwarded-For.
// Without that trusted ingress, callers share a conservative fallback bucket.
export function chartRateIdentity(request: Request) {
  const supplied = process.env.NODE_ENV === "production" ? request.headers.get("cf-connecting-ip")?.trim() : undefined;
  let address = supplied && isIP(supplied) ? supplied : "shared-local";
  if (isIP(address) === 6) {
    const canonical = new URL(`http://[${address}]`).hostname.slice(1,-1);
    const [left,right=""] = canonical.split("::");
    const a=left?left.split(":"):[], b=right?right.split(":"):[];
    const groups=canonical.includes("::")?[...a,...Array(8-a.length-b.length).fill("0"),...b]:a;
    address=groups.slice(0,4).map(v=>parseInt(v,16).toString(16)).join(":")+"::/64";
  }
  return createHmac("sha256", process.env.BETTER_AUTH_SECRET!).update(address).digest("hex");
}

export async function publicChartLimit(request: Request) {
  const identity=chartRateIdentity(request);
  await rateLimit(`public-chart:minute:${identity}`,10,60);
  await rateLimit(`public-chart:day:${identity}`,100,86400);
}
