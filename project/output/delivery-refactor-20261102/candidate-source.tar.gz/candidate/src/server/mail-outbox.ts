import { randomUUID } from 'node:crypto';
import { sqlClient } from './db';
import { getRuntimeSettings } from './settings';
import { mailErrorCode, sendTransactionalMail } from './mail';

/** Only current, verified account emails are used. Retries never roll back business results. */
export async function drainMailOutbox() {
  const settings = await getRuntimeSettings();
  if (!settings.serviceNotificationsEnabled || settings.emailProvider === 'tencentSes' && !settings.sesAuthReady) return;
  if (settings.emailProvider === 'smtp' && (!settings.smtpHost || !settings.smtpFrom)) return;
  const db = sqlClient();
  // An interrupted send has an uncertain outcome: do not automatically send it
  // again. An operator can investigate using provider logs and the event key.
  await db`UPDATE mail_outbox SET status='failed',error_code='DELIVERY_UNKNOWN',lease_token=NULL,lease_until=NULL WHERE status='sending' AND lease_until<now()`;
  const token = randomUUID();
  const [message] = await db`UPDATE mail_outbox SET status='sending',lease_token=${token},lease_until=now()+interval '2 minutes',attempts=attempts+1
    WHERE id=(SELECT id FROM mail_outbox WHERE status='pending' AND available_at<=now() ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1) RETURNING *`;
  if (!message) return;
  // Follow-up results and task updates stay in the case, without another email.
  const taskEvent = /^task:([a-f0-9-]{36}):/.exec(message.event_key);
  if (taskEvent) {
    const [task] = await db`SELECT kind FROM tasks WHERE id=${taskEvent[1]}`;
    if (task?.kind === "followup") {
      await db`UPDATE mail_outbox SET status='suppressed',error_code='FOLLOWUP_IN_APP_ONLY',lease_token=NULL,lease_until=NULL WHERE id=${message.id} AND lease_token=${token}`;
      return;
    }
  }
  // A zero template explicitly disables this notification kind for SES.
  // In particular, referral rewards remain visible in the account when the
  // provider does not permit referral mail; do not disguise them as service mail.
  if (settings.emailProvider === 'tencentSes' && !settings.sesTemplates[message.kind as keyof typeof settings.sesTemplates]) {
    await db`UPDATE mail_outbox SET status='suppressed',error_code='MAIL_KIND_DISABLED',lease_token=NULL,lease_until=NULL WHERE id=${message.id} AND lease_token=${token}`;
    return;
  }
  const [user] = await db`SELECT email,email_verified FROM "user" WHERE id=${message.user_id}`;
  const [c] = message.case_id ? await db`SELECT deleted_at,permanently_deleted,status FROM cases WHERE id=${message.case_id}` : [];
  if (!user?.email_verified || Date.now() - new Date(message.created_at).getTime() > 7*86400000 || message.case_id && (!c || c.deleted_at || c.permanently_deleted)) {
    await db`UPDATE mail_outbox SET status='suppressed',error_code='NO_LONGER_APPLICABLE',lease_token=NULL,lease_until=NULL WHERE id=${message.id} AND lease_token=${token}`;
    return;
  }
  try {
    const path = message.case_id ? '/cases/' + message.case_id : '/account';
    const result = await sendTransactionalMail(user.email, message.kind, new URL(path, process.env.APP_URL || 'http://localhost:3000').href);
    await db`UPDATE mail_outbox SET status='accepted',provider_message_id=${result.messageId},sent_at=now(),lease_token=NULL,lease_until=NULL,error_code=NULL WHERE id=${message.id} AND lease_token=${token}`;
  } catch (error) {
    const code = mailErrorCode(error);
    // Only explicit rejection/rate-limit responses are safe to retry. Network
    // timeouts could have been accepted by the provider and must not spam users.
    const retryable = /^(RATE_LIMITED|LimitExceeded|RequestLimitExceeded|MAIL_NOT_CONFIGURED|MAIL_TEMPLATE_MISSING)/.test(code);
    const retry = retryable && message.attempts < 5;
    await db`UPDATE mail_outbox SET status=${retry ? 'pending' : 'failed'},error_code=${code},available_at=now()+interval '30 minutes',lease_token=NULL,lease_until=NULL WHERE id=${message.id} AND lease_token=${token}`;
  }
}
