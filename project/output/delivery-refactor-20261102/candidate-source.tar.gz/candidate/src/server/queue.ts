import {QUEUE_EXPIRE_SECONDS} from "../agent/execution-control";
import { PgBoss } from "pg-boss";
let boss:PgBoss|undefined;
export const QUEUE="wenheng-interpretation-v2";
export async function getQueue(){if(!process.env.DATABASE_URL)throw new Error("DATABASE_URL required");if(boss)return boss;boss=new PgBoss({connectionString:process.env.DATABASE_URL});boss.on("error",e=>console.error("Queue failure",e.message));await boss.start();await boss.createQueue(QUEUE,{policy:"exclusive",retryLimit:0,expireInSeconds:QUEUE_EXPIRE_SECONDS});return boss;}
