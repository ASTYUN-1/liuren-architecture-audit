interface DiagnosticIssue {id:string;rule:string;state:'active'|'resolved';severity:'blocker'|'warning';field:string;questionId:string|null;occurrences:number|null}
/** Allowlist only machine metadata for operational UI. Never forward draft text. */
export function safeDeliveryDiagnostics(value:any){
 if(value?.protocol!=='delivery-v2'||!Array.isArray(value.issues))return null;
 const number=(v:unknown)=>typeof v==='number'&&Number.isFinite(v)&&v>=0?v:null;
 const issues:DiagnosticIssue[]=value.issues.filter((i:any)=>i&&/^[a-f0-9]{20}$/.test(i.id)&&/^[A-Z][A-Z0-9_]{0,80}$/.test(i.rule)&&['active','resolved'].includes(i.state)&&['blocker','warning'].includes(i.severity)).map((i:any)=>({id:i.id,rule:i.rule,state:i.state,severity:i.severity,field:typeof i.field==='string'&&/^[a-zA-Z0-9_.:-]{1,120}$/.test(i.field)?i.field:'field',questionId:typeof i.questionId==='string'&&/^[A-Za-z][A-Za-z0-9_-]{0,59}$/.test(i.questionId)?i.questionId:null,occurrences:number(i.occurrences)}));
 return {protocol:'delivery-v2' as const,firstDraftMs:number(value.firstDraftMs),deliveryMs:number(value.deliveryMs),submissions:number(value.submissions),noProgressRounds:number(value.noProgressRounds),repairStalled:value.repairStalled===true,outcome:['complete','limited'].includes(value.outcome)?value.outcome as 'complete'|'limited':null,issues};
}
