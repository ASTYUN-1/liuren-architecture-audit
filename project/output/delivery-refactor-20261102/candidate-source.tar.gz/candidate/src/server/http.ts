import { getAuth } from "./auth";
import { sqlClient } from "./db";
import {trustedAppOrigins} from "./origins";
import {limitedText} from './request-body';
export class AppError extends Error {constructor(public code:string,message:string,public status=400){super(message);}}
export interface Actor {id:string;email:string;name:string;username?:string|null;emailVerified:boolean;isAdmin:boolean}
export async function actor(request:Request,verified=false,admin=false):Promise<Actor>{
  const s=await getAuth().api.getSession({headers:request.headers});
  if(!s) throw new AppError("UNAUTHENTICATED","请先登录 / Please sign in",401);
  const isAdmin=(process.env.ADMIN_EMAILS||"").split(",").map(x=>x.trim().toLowerCase()).includes(s.user.email.toLowerCase());
  if(verified&&!s.user.emailVerified) throw new AppError("EMAIL_UNVERIFIED","请先验证邮箱 / Verify your email",403);
  if(admin&&!isAdmin) throw new AppError("FORBIDDEN","Administrator access required",403);
  if(admin && process.env.ADMIN_REQUIRE_2FA!=="false" && !(s.user as {twoFactorEnabled?:boolean}).twoFactorEnabled) throw new AppError("ADMIN_2FA_REQUIRED","管理员须先启用二次验证",403);
  return {...s.user,isAdmin};
}
export function mutationOrigin(request:Request){
  if(!trustedAppOrigins().includes(request.headers.get("origin")||"")) throw new AppError("ORIGIN_REJECTED","Invalid request origin",403);
}
export async function body(request:Request){
  const text=await limitedText(request,32768);
  try{return JSON.parse(text||"{}");}catch{throw new AppError("INVALID_JSON","Invalid JSON");}
}
export function api(fn:(req:Request,context:any)=>Promise<unknown>){return async(req:Request,context:any)=>{try{if(!["GET","HEAD"].includes(req.method))mutationOrigin(req);const data=await fn(req,context);return data instanceof Response?data:Response.json({data});}catch(e){if(e instanceof AppError)return Response.json({error:{code:e.code,message:e.message}},{status:e.status});console.error("API request failed",e instanceof Error?(process.env.NODE_ENV!=="production"?e.stack:e.message):"unknown");return Response.json({error:{code:"SERVICE_UNAVAILABLE",message:"服务暂不可用，请稍后重试 / Service unavailable"}},{status:503});}};}
export async function rateLimit(key:string,max:number,windowSeconds:number){const r=await sqlClient()`INSERT INTO rate_limits(key,window_start,count) VALUES(${key},now(),1) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN rate_limits.window_start < now()-${windowSeconds}*interval '1 second' THEN 1 ELSE rate_limits.count+1 END,window_start=CASE WHEN rate_limits.window_start < now()-${windowSeconds}*interval '1 second' THEN now() ELSE rate_limits.window_start END RETURNING count`;if(r[0].count>max)throw new AppError("RATE_LIMITED","请求过于频繁，请稍后重试",429);}

