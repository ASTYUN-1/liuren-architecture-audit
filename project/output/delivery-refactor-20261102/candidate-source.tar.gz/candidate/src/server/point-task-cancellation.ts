import {randomUUID} from 'node:crypto';
import type {Tx} from './db';
import {AppError,type Actor} from './http';
import {finishHold} from './points';

/** Caller holds the owner's user row, case row and task row, in that order. */
export async function cancelOwnedPointTaskLocked(tx:Tx,a:Actor,t:any,source:'task'|'case-delete'){
 if(t.user_id!==a.id||!t.point_hold_id)throw new AppError('TASK_STATE','此任务不能取消',409);
 if(t.status==='cancelled')return;
 if(!['queued','running'].includes(t.status))throw new AppError('TASK_STATE','此任务不能取消',409);
 await tx`UPDATE tasks SET status='cancelled',worker_token=NULL,lease_expires_at=NULL,updated_at=now() WHERE id=${t.id}`;
 await finishHold(tx,t.point_hold_id,0,source==='task'?'用户取消，未交付':'档案删除，未交付',a.id);
 await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'pointTaskCancel',${t.id},${tx.json({source,previousStatus:t.status})})`;
}
