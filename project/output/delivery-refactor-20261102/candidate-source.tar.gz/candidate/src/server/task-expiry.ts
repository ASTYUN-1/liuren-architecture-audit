import {randomUUID} from 'node:crypto';
import {sqlClient} from './db';
import {lockCase,requestRefund} from './service';
import {finishHold} from './points';

export const TASK_RETENTION_DAYS=7;
/** Caller maintenance may repeat; case/user/task locks fence settlement and release. */
export async function expireUnfinishedTasks(){
 const db=sqlClient(),rows=await db`SELECT id,case_id FROM tasks WHERE created_at<now()-interval '7 days' AND (status IN ('queued','running','failed') OR (status='succeeded' AND clarification IS NOT NULL)) ORDER BY created_at LIMIT 100`;
 const cancelled:string[]=[];
 for(const row of rows)await db.begin(async tx=>{
  const c=await lockCase(tx,row.case_id,undefined,true);const [t]=await tx`SELECT * FROM tasks WHERE id=${row.id} FOR UPDATE`;
  if(!t||new Date(t.created_at).getTime()>Date.now()-TASK_RETENTION_DAYS*86400000||!(['queued','running','failed'].includes(t.status)||(t.status==='succeeded'&&t.clarification)))return;
  if(t.point_hold_id)await finishHold(tx,t.point_hold_id,0,'任务超过7天未完成，自动取消并释放积分');
  if(t.entitlement_id&&['queued','running'].includes(t.status)){
   const changed=await tx`UPDATE entitlements SET reserved=reserved-1 WHERE id=${t.entitlement_id} AND reserved>0 RETURNING id`;
   if(changed.length)await tx`INSERT INTO entitlement_ledger(id,case_id,entitlement_id,task_id,action,quantity) VALUES(${randomUUID()},${t.case_id},${t.entitlement_id},${t.id},'expiredRelease',1) ON CONFLICT DO NOTHING`;
  }
  await tx`UPDATE tasks SET status='cancelled',error='任务超过7天未完成，已自动取消；未交付部分不扣费',worker_token=NULL,lease_expires_at=NULL,queued_at=NULL,runtime_progress=runtime_progress||${tx.json({state:'expired',at:new Date().toISOString()})},updated_at=now() WHERE id=${t.id}`;
  if(!c.deleted_at&&!c.permanently_deleted)await tx`UPDATE cases SET status=${c.report?'ready':'failed'},updated_at=now() WHERE id=${c.id} AND NOT EXISTS(SELECT 1 FROM tasks WHERE case_id=${c.id} AND status IN ('queued','running'))`;
  await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},'system','taskAutoCancelled',${t.id},${tx.json({days:7,previousStatus:t.status})})`;
  cancelled.push(t.id);
 });
 // Real money refunds remain a reviewed operation; this only opens the existing
 // refund workflow for legacy paid initial tasks, never fabricates a money transfer.
 for(const id of cancelled){const [r]=await db`SELECT o.id,o.user_id,u.email,u.name,u.email_verified FROM tasks t JOIN orders o ON o.case_id=t.case_id AND o.kind='base' AND o.status='paid' JOIN "user" u ON u.id=o.user_id WHERE t.id=${id} AND t.kind='initial'`;
  if(r)await requestRefund({id:r.user_id,email:r.email,name:r.name,emailVerified:r.email_verified,isAdmin:false},r.id,'超过7天未交付，任务已自动取消').catch(()=>{});
 }
 return cancelled;
}
