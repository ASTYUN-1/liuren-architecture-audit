import {createHash,randomBytes,randomUUID} from 'node:crypto';
import {sqlClient,type Tx} from './db';
import {AppError,type Actor} from './http';
import {ADVISORS,requireAdmin} from './points-config';
import {lockCase} from './service';
import {uuid,text} from './validation';
import {encryptSecret,decryptSecret} from './settings';

function verified(a:Actor){if(!a.emailVerified)throw new AppError('FORBIDDEN','请先验证邮箱',403);}
const hash=(code:string)=>createHash('sha256').update(code).digest('hex');
export async function practitionerRoles(a:Actor){verified(a);return sqlClient()`SELECT advisor_id FROM advisor_accounts WHERE user_id=${a.id}`;}
export async function managePractitioners(a:Actor,data?:any){
 requireAdmin(a);const db=sqlClient();
 if(data){
  const advisor=ADVISORS.find(v=>v.id===data.advisorId),email=text(data.email,254).trim().toLowerCase();
  if(!advisor||!['grant','revoke'].includes(data.action))throw new AppError('INVALID','请选择卦师与操作');
  await db.begin(async tx=>{
   const [user]=await tx`SELECT id FROM "user" WHERE lower(email)=${email} AND email_verified=true FOR UPDATE`;
   if(!user)throw new AppError('NOT_FOUND','找不到该已验证邮箱账户',404);
   if(data.action==='grant')await tx`INSERT INTO advisor_accounts(advisor_id,user_id) VALUES(${advisor.id},${user.id}) ON CONFLICT DO NOTHING`;
   else await tx`DELETE FROM advisor_accounts WHERE advisor_id=${advisor.id} AND user_id=${user.id}`;
   await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},${'practitioner:'+data.action},${user.id},${tx.json({advisorId:advisor.id})})`;
  });
 }
 return db`SELECT aa.advisor_id,u.email FROM advisor_accounts aa JOIN "user" u ON u.id=aa.user_id ORDER BY aa.advisor_id,u.email`;
}
export async function ownerShares(a:Actor,caseId:string){
 verified(a);uuid(caseId);const db=sqlClient();
 const [c]=await db`SELECT id FROM cases WHERE id=${caseId} AND user_id=${a.id} AND deleted_at IS NULL AND permanently_deleted=false`;
 if(!c)throw new AppError('NOT_FOUND','档案不存在',404);
 const rows=await db`SELECT s.id,s.advisor_id,s.created_at,s.expires_at,s.revoked_at,s.encrypted_code,h.status AS booking_status FROM conversation_shares s JOIN human_assists h ON h.id=s.booking_id WHERE s.user_id=${a.id} AND s.case_id=${caseId} ORDER BY s.created_at DESC LIMIT 50`;
 return rows.map(r=>({id:r.id,advisor_id:r.advisor_id,created_at:r.created_at,expires_at:r.expires_at,revoked_at:r.revoked_at,canRenew:!['cancelled','refunded'].includes(r.booking_status),code:!r.revoked_at&&!['cancelled','refunded'].includes(r.booking_status)&&new Date(r.expires_at)>new Date()?decryptSecret(r.encrypted_code):null}));
}
/** Called inside the booking transaction: reservation and code either both commit or neither does. */
export async function bookingConversationShare(tx:Tx,a:Actor,caseId:string,advisorId:string,bookingId:string){
 verified(a);
 const [old]=await tx`SELECT id,expires_at,revoked_at,encrypted_code FROM conversation_shares WHERE booking_id=${bookingId} AND user_id=${a.id} AND case_id=${caseId} AND advisor_id=${advisorId}`;
 if(old)return {id:old.id,code:!old.revoked_at&&new Date(old.expires_at)>new Date()?decryptSecret(old.encrypted_code):null,expiresAt:old.expires_at,advisorId};
 if(!(await tx`SELECT 1 FROM advisor_accounts aa JOIN "user" u ON u.id=aa.user_id WHERE aa.advisor_id=${advisorId} AND u.email_verified=true LIMIT 1`).length)throw new AppError('UNAVAILABLE','该卦师的阅读账号尚未配置',409);
 const code='WHC-'+randomBytes(18).toString('hex').toUpperCase();
 const [s]=await tx`INSERT INTO conversation_shares(id,user_id,case_id,advisor_id,token_hash,encrypted_code,booking_id) VALUES(${randomUUID()},${a.id},${caseId},${advisorId},${hash(code)},${encryptSecret(code)},${bookingId}) RETURNING id,expires_at`;
 return {id:s.id,code,expiresAt:s.expires_at,advisorId};
}
export async function revokeConversationShare(a:Actor,caseId:string,id:string){
 verified(a);uuid(id);return sqlClient().begin(async tx=>{await lockCase(tx,caseId,a.id);await tx`UPDATE conversation_shares SET revoked_at=coalesce(revoked_at,now()) WHERE id=${id} AND user_id=${a.id} AND case_id=${caseId}`;return {revoked:true};});
}
/** Explicit owner consent rotates the token; expired/revoked tokens never revive. */
export async function renewConversationShare(a:Actor,caseId:string,id:string){
 verified(a);uuid(id);
 return sqlClient().begin(async tx=>{
  await lockCase(tx,caseId,a.id);
  const [s]=await tx`SELECT s.id,s.advisor_id,h.status FROM conversation_shares s JOIN human_assists h ON h.id=s.booking_id WHERE s.id=${id} AND s.case_id=${caseId} AND s.user_id=${a.id} FOR UPDATE OF s,h`;
  if(!s||['cancelled','refunded'].includes(s.status))throw new AppError('SHARE_UNAVAILABLE','此预约不能重新授权分享',409);
  if(!(await tx`SELECT 1 FROM advisor_accounts aa JOIN "user" u ON u.id=aa.user_id WHERE aa.advisor_id=${s.advisor_id} AND u.email_verified=true LIMIT 1`).length)throw new AppError('UNAVAILABLE','该卦师的阅读账号尚未配置',409);
  const code='WHC-'+randomBytes(18).toString('hex').toUpperCase();
  const [r]=await tx`UPDATE conversation_shares SET token_hash=${hash(code)},encrypted_code=${encryptSecret(code)},revoked_at=NULL,expires_at=now()+interval '7 days' WHERE id=${s.id} RETURNING expires_at`;
  await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'share:renew',${s.id},${tx.json({caseId,advisorId:s.advisor_id})})`;
  return {id:s.id,code,expiresAt:r.expires_at,advisorId:s.advisor_id};
 });
}
export async function readConversationShare(a:Actor,value:unknown){
 verified(a);const code=text(value,80).trim().toUpperCase(),db=sqlClient();
 // Authorization and content are fetched in one statement. Neither admin status nor
 // knowledge of a case ID grants access through this endpoint.
 const [r]=await db`SELECT c.title,c.report,i.input,h.id AS booking_id,h.status AS booking_status,h.deadline,ph.units,ph.charged_units,ph.status AS hold_status,
   coalesce((SELECT jsonb_agg(jsonb_build_object('question',t.question,'answer',t.answer,'clarification',t.clarification,'createdAt',t.created_at) ORDER BY t.created_at) FROM tasks t WHERE t.case_id=c.id AND t.input_version=c.input_version AND (t.kind='followup' OR t.clarification IS NOT NULL)),'[]'::jsonb) AS turns
   FROM conversation_shares s JOIN advisor_accounts aa ON aa.advisor_id=s.advisor_id AND aa.user_id=${a.id}
   JOIN cases c ON c.id=s.case_id AND c.user_id=s.user_id
   JOIN case_inputs i ON i.case_id=c.id AND i.version=c.input_version
   JOIN human_assists h ON h.id=s.booking_id JOIN point_holds ph ON ph.id=h.id
   WHERE s.token_hash=${hash(code)} AND s.revoked_at IS NULL AND s.expires_at>now()
   AND c.deleted_at IS NULL AND c.permanently_deleted=false
   AND EXISTS(SELECT 1 FROM human_assists h WHERE h.id=s.booking_id AND h.status NOT IN ('cancelled','refunded'))`;
 if(!r)throw new AppError('SHARE_UNAVAILABLE','分享码无效、已失效或未授权给你的卦师身份',404);
 return {title:r.title,question:r.input.question+(r.input.chartRequest?'\n起课更正：'+r.input.chartRequest:''),participants:r.input.participants,report:r.report?{title:r.report.title,summary:r.report.summary,content:r.report.content}:null,turns:r.turns,booking:{id:r.booking_id,status:r.booking_status,units:r.units,chargedUnits:r.charged_units,canComplete:['pending','accepted','review'].includes(r.booking_status)&&r.hold_status==='held'&&new Date(r.deadline)>new Date()}};
}
