import {randomUUID} from 'node:crypto';
import {sqlClient} from './db';
import {AppError,type Actor} from './http';
import {caseDetail,lockCase} from './service';
import {resolveInput,verifyIntent,signIntent} from './input-intent';
import {parseInput,text} from './validation';
import {calculateChart} from '../engine/liuren';

export async function resolveCaseIntent(a:Actor,id:string,question:unknown,signal?:AbortSignal){
  const c=await caseDetail(a,id),request=text(question,4000,2);
  if(c.deletedAt)throw new AppError('CASE_DELETED','请先恢复档案',409);
  const result=await resolveInput(a,c.input,{signal,question:request,history:c.turns.map(t=>({question:t.question}))},{caseId:id,inputVersion:c.inputVersion,question:request});
  const freeEligible=!!c.report&&!c.input.intent&&!(await sqlClient()`SELECT id FROM tasks WHERE case_id=${id} AND system_correction=true`).length;
  if(result.repair&&!freeEligible&&result.input){result.repair=false;result.input.intent={summary:result.summary,receipt:signIntent(a,result.input,result.summary,{caseId:id,inputVersion:c.inputVersion,question:request,action:'configure',repair:false})};}
  return result;
}
export async function requireTurnIntent(a:Actor,id:string,data:any){
  const c=await caseDetail(a,id),input=parseInput(data.intentInput);
  const b=verifyIntent(a,input,{caseId:id,inputVersion:c.inputVersion,question:text(data.question,4000,2)},true);
  if(b.action!=='keep')throw new AppError('CHART_CORRECTION_REQUIRED','请先确认更正后的起课设定',409);
}
export async function correctCaseInput(a:Actor,id:string,data:any){
  const input=parseInput(data.input),question=text(data.question,4000,2),key=text(data.idempotencyKey,128);
  await sqlClient().begin(async tx=>{
    const c=await lockCase(tx,id,a.id);
    const [prior]=await tx`SELECT id FROM audit_log WHERE actor_id=${a.id} AND action='inputCorrection' AND target_id=${id+':'+key}`;
    if(prior)return;
    const binding=verifyIntent(a,input,{caseId:id,inputVersion:c.input_version,question},true);
    if(binding.action!=='configure')throw new AppError('INVALID_INPUT','没有需要更正的起课参数');
    if((await tx`SELECT id FROM tasks WHERE case_id=${id} AND status IN ('queued','running')`).length)throw new AppError('TASK_ACTIVE','请等待当前任务完成或先取消',409);
    if((await tx`SELECT id FROM orders WHERE case_id=${id} AND status NOT IN ('cancelled','refunded')`).length)throw new AppError('LEGACY_ORDER','旧套餐档案的起课更正请联系运营者，避免权益混用',409);
    const [old]=await tx`SELECT input FROM case_inputs WHERE case_id=${id} AND version=${c.input_version}`;
    // Financial eligibility is server-owned: only a delivered legacy input without
    // the new confirmed receipt can receive one automatic service correction.
    const corrected=await tx`SELECT id FROM tasks WHERE case_id=${id} AND system_correction=true`;
    const free=!!binding.repair&&!corrected.length&&!!c.report&&!old.input.intent;
    const version=c.input_version+1;
    // Preserve the complete original event; store corrections separately, without truncating it.
    const next={...input,question:old.input.question,chartRequest:question};
    delete next.intent; // The changed question must receive a new server-bound receipt.
    next.intent={summary:input.intent!.summary,receipt:signIntent(a,next,input.intent!.summary,{action:'keep'})};
    await tx`UPDATE case_inputs SET previous_report=${c.report?tx.json(c.report):null},previous_chart=${c.internal_chart?tx.json(c.internal_chart):null},superseded_at=now() WHERE case_id=${id} AND version=${c.input_version}`;
    await tx`INSERT INTO case_inputs(case_id,version,input) VALUES(${id},${version},${tx.json(next as any)})`;
    const fixed=next.random||next.mode==='solar'?calculateChart(next):null;
    await tx`UPDATE cases SET input_version=${version},report=NULL,internal_chart=${fixed?tx.json(fixed as any):null},status=${free?'queued':'draft'},updated_at=now() WHERE id=${id}`;
    if(free)await tx`INSERT INTO tasks(id,case_id,user_id,kind,input_version,idempotency_key,system_correction) VALUES(${randomUUID()},${id},${a.id},'initial',${version},${'correction:'+id+':'+key},true)`;
    await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'inputCorrection',${id+':'+key},${tx.json({fromVersion:c.input_version,toVersion:version,free})})`;
  });
  return caseDetail(a,id);
}
