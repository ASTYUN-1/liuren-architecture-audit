import {sqlClient} from './db';
import {AppError,type Actor} from './http';
export const ADVISORS = [
 {id:'congkui',name:'从魁'}, {id:'liurenshi',name:'六壬师'}, {id:'qing',name:'清'}, {id:'wenwen',name:'温温'}, {id:'ming',name:'明'}
] as const;
export interface PointsConfig { mode:'legacy'|'points';aiEnabled:boolean;topupEnabled:boolean;humanEnabled:boolean;wechatId:string;qrUrl:string;advisors:{id:string;name:string;avatar:string;contactType?:'wechat'|'qq';wechatId:string;qrUrl:string;accepting:boolean}[] }
const key=()=>process.env.NODE_ENV==='test'?'test:'+process.env.SETTINGS_RECORD_KEY+':points':'points';
export const defaultPointsConfig=():PointsConfig=>({mode:'legacy',aiEnabled:false,topupEnabled:false,humanEnabled:false,wechatId:'',qrUrl:'',advisors:ADVISORS.map(a=>({...a,avatar:`/advisors/${a.id}.jpg`,wechatId:'',qrUrl:'',accepting:false}))});
export async function pointsConfig():Promise<PointsConfig>{const [r]=await sqlClient()`SELECT value FROM service_settings WHERE key=${key()}`;return {...defaultPointsConfig(),...r?.value};}
export function requireAdmin(a:Actor){if(!a.isAdmin||!a.emailVerified)throw new AppError('FORBIDDEN','需要管理员权限',403);}
export async function savePointsConfig(a:Actor,data:any){requireAdmin(a);const old=await pointsConfig();const contact=(v:any)=>{if(typeof v!=='string'||v.length>100||/[\s<>]/.test(v))throw new AppError('CONTACT','联系账号格式不正确');return v;};const qr=(v:any)=>{if(typeof v!=='string'||v.length>500||(v&&!/^\/uploads\/[a-zA-Z0-9/_.-]+\.(png|jpe?g|webp)$/.test(v)))throw new AppError('QR','二维码请使用本站 uploads 图片路径');return v;};
 const next:PointsConfig={mode:data.mode==='points'?'points':'legacy',aiEnabled:data.aiEnabled===true,topupEnabled:data.topupEnabled===true,humanEnabled:data.humanEnabled===true,wechatId:contact(data.wechatId??old.wechatId),qrUrl:qr(data.qrUrl??old.qrUrl),advisors:ADVISORS.map(a=>{const previous=old.advisors.find(v=>v.id===a.id);const v=data.advisors?.find((v:any)=>v.id===a.id)||previous!;const contactType=v.contactType??previous?.contactType??'wechat';if(contactType!=='wechat'&&contactType!=='qq')throw new AppError('CONTACT','请选择微信或QQ');const wechatId=contact(v.wechatId||'');if(contactType==='qq'&&wechatId&&!/^[1-9]\d{4,11}$/.test(wechatId))throw new AppError('CONTACT','QQ号须为5至12位数字');return {...a,avatar:`/advisors/${a.id}.jpg`,contactType,wechatId,qrUrl:qr(v.qrUrl||''),accepting:v.accepting===true};})};
 if(next.topupEnabled&&!next.wechatId)throw new AppError('CONTACT_REQUIRED','请先配置官方充值微信');if(next.humanEnabled&&!next.advisors.some(a=>a.accepting&&a.wechatId))throw new AppError('CONTACT_REQUIRED','请先配置接待账号');
 await sqlClient()`INSERT INTO service_settings(key,value) VALUES(${key()},${sqlClient().json(next as any)}) ON CONFLICT(key) DO UPDATE SET value=excluded.value`;return next;
}
