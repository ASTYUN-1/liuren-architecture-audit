// Only an explicitly identified, unused runtime startup failure can start a new
// attempt. A supplier request, lost worker or unknown failure may have consumed
// work even without a final usage event; never discard that analysis and retry.
const unusedStartup=new Set(['opencode_unavailable','opencode_start_timeout','session_creation_failed']);
export function shouldRetryTask(error:string,attempts:number,usage?:{requests?:unknown;toolCalls?:unknown}){
 if(attempts>=3||!unusedStartup.has(error.split(':')[0]))return false;
 return Number(usage?.requests)===0&&Number(usage?.toolCalls??0)===0;
}
