import {acquireInputLease} from './input-intent-lease';
import {createHmac,timingSafeEqual,randomUUID} from 'node:crypto';
import {hashChartValue,EngineInputError} from '../engine/liuren';
import {applyIntent,requestIntent,type IntentContext} from '../agent/input-intent';
import type {CaseInput,IntentResolution} from './contracts';
import {parseInputDraft} from './validation';
import {AppError,type Actor} from './http';
import {getRuntimeSettings} from './settings';
import {sqlClient} from './db';

export interface IntentBinding {caseId?:string;inputVersion?:number;question?:string;repair?:boolean;action:'keep'|'configure'}
function secret(){const s=process.env.BETTER_AUTH_SECRET;if(!s||s.length<32)throw new AppError('INTENT_UNAVAILABLE','输入整理暂不可用，请稍后重试',503);return s;}
function digest(input:CaseInput){const {intent:_,...value}=input;return hashChartValue(value);}
export function signIntent(a:Pick<Actor,'id'>,input:CaseInput,summary:string,binding:IntentBinding){
  const payload={v:1,owner:a.id,hash:digest(input),summary,binding,issued:Date.now()};
  const body=Buffer.from(JSON.stringify(payload)).toString('base64url');
  return body+'.'+createHmac('sha256',secret()).update('wenheng-intent-v1:'+body).digest('base64url');
}
export function verifyIntent(a:Pick<Actor,'id'>,input:CaseInput,binding:Partial<IntentBinding>={},fresh=false):IntentBinding {
  try{
    const [body,sig,...rest]=(input.intent?.receipt??'').split('.'),expected=createHmac('sha256',secret()).update('wenheng-intent-v1:'+body).digest(),actual=Buffer.from(sig??'','base64url');
    if(rest.length||actual.length!==expected.length||!timingSafeEqual(actual,expected))throw Error();
    const p=JSON.parse(Buffer.from(body,'base64url').toString());
    if(p.v!==1||p.owner!==a.id||p.hash!==digest(input)||p.summary!==input.intent?.summary||!p.binding||!['keep','configure'].includes(p.binding.action)||p.issued>Date.now()+60000||(fresh&&Date.now()-p.issued>30*60000))throw Error();
    for(const [k,v] of Object.entries(binding))if(p.binding[k]!==v)throw Error();
    return p.binding;
  }catch{throw new AppError('INPUT_REVIEW_REQUIRED','请重新确认起课要求后再提交 / Review the chart settings again',409);}
}
export async function resolveInput(a:Actor,value:unknown,context:IntentContext={},binding:Omit<IntentBinding,'action'|'repair'>={}):Promise<IntentResolution> {
  const input=parseInputDraft(value);
  // A complete, unchanged, already-confirmed initial input is deterministic.
  // Never reuse a follow-up decision: new history can change its references.
  if(context.question===undefined&&input.intent?.receipt){try{const b=verifyIntent(a,input,{caseId:undefined,inputVersion:undefined,question:undefined},true);return {action:b.action,input,summary:input.intent.summary,repair:b.repair};}catch{ /* altered/expired confirmation must be understood again */ }}
  const settings=await getRuntimeSettings();
  if(!settings.aiEnabled||!settings.deepseekApiKey)throw new AppError('INTENT_UNAVAILABLE','输入整理暂不可用，请稍后重试 / Input review unavailable',503);
  const {intent:_,...reviewInput}=input;const release=await acquireInputLease(a.id,hashChartValue({input:reviewInput,binding,question:context.question??null,history:(context.history??[]).slice(-6).map(h=>({question:h.question}))}));
  try{
    context.signal?.throwIfAborted();const now=new Date().toISOString(),resolved=applyIntent(input,await requestIntent(input,settings.deepseekApiKey,{...context,now,onUsage:async(raw:any)=>{
      const inputTokens=Number(raw?.prompt_tokens),outputTokens=Number(raw?.completion_tokens),cachedTokens=Number(raw?.prompt_cache_hit_tokens??0);
      const verified=[inputTokens,outputTokens,cachedTokens].every(v=>Number.isSafeInteger(v)&&v>=0)&&cachedTokens<=inputTokens;
      await sqlClient()`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'inputIntentUsage',${binding.caseId??'new'},${sqlClient().json(verified?{model:'deepseek-flash',chargedToUser:false,inputTokens,outputTokens,cachedTokens,estimatedCostCny:((inputTokens-cachedTokens)*2+cachedTokens*.04+outputTokens*8)/1e6}:{model:'deepseek-flash',chargedToUser:false,usageUnverified:true})})`;
    }}),{...context,now});
    if(resolved.decision.action==='clarify'||resolved.decision.action==='new_event')return {action:resolved.decision.action,summary:resolved.decision.summary,clarification:resolved.decision.clarification};
    const b:IntentBinding={...binding,action:resolved.decision.action,repair:resolved.repair};
    resolved.input.intent={summary:resolved.decision.summary,receipt:signIntent(a,resolved.input,resolved.decision.summary,b)};
    return {action:b.action,input:resolved.input,summary:resolved.decision.summary,repair:b.repair};
  }catch(e){
    if(e instanceof EngineInputError||e instanceof Error&&['intent_invalid_date','intent_explicit_time_missing'].includes(e.message))return {action:'clarify',summary:'请核对起课信息',clarification:e instanceof EngineInputError?e.message:'请补充或核对有效的起课日期、钟点与历法；不会自动采用当前时间。'};
    if(e instanceof AppError)throw e;
    const reason=e instanceof Error&&['TimeoutError','AbortError'].includes(e.name)?'timeout':e instanceof Error&&['ZodError','SyntaxError'].includes(e.name)?'format':e instanceof Error&&/^intent_supplier_http_/.test(e.message)?'supplier':e instanceof Error&&e.message==='intent_output_incomplete'?'incomplete':'validation';
    await sqlClient()`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'inputIntentFailure',${binding.caseId??'new'},${sqlClient().json({reason,chargedToUser:false,...(e instanceof Error&&/^intent_supplier_http_[0-9]{3}$/.test(e.message)?{code:e.message}:{})})})`.catch(()=>{});
    throw new AppError(reason==='timeout'?'INTENT_TIMEOUT':'INTENT_UNAVAILABLE',reason==='timeout'?'理解起课要求用时较长，已停止本次整理，请重新确认；尚未开始解读或扣分 / Input review timed out; no interpretation charged':'暂时未能完整整理起课要求，请重新确认；不会采用默认时间，也未开始解读或扣分 / Could not confirm settings; no interpretation charged',reason==='timeout'?504:503);
  }finally{await release().catch(()=>{});}
}
