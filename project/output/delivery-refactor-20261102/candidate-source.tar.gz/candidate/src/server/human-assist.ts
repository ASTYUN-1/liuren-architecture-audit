import {bookingConversationShare} from './conversation-sharing';
import {randomInt,randomUUID} from 'node:crypto';
import {POINTS_PRICING} from '../lib/points-pricing';
import {sqlClient} from './db';
import {AppError,type Actor} from './http';
import {text,uuid} from './validation';
import {lockCase} from './service';
import {pointsConfig,requireAdmin} from './points-config';
import {finishHold,lockPointUser,reservePoints} from './points';
export async function drawAdvisor(a:Actor,key:string){key=text(key,128);return sqlClient().begin(async tx=>{await lockPointUser(tx,a.id);const [old]=await tx`SELECT * FROM advisor_draws WHERE user_id=${a.id} AND idempotency_key=${key}`;if(old)return {advisorId:old.advisor_id};const cfg=await pointsConfig();const id=cfg.advisors[randomInt(5)].id;await tx`INSERT INTO advisor_draws(id,user_id,advisor_id,idempotency_key) VALUES(${randomUUID()},${a.id},${id},${key})`;return {advisorId:id};});}
export async function requestHuman(a:Actor,data:any){const cfg=await pointsConfig(),advisor=cfg.advisors.find(v=>v.id===data.advisorId);if(!cfg.humanEnabled||!advisor?.accepting||!advisor.wechatId)throw new AppError('HUMAN_CLOSED','该接待联系方式待配置或暂未开放',409);const question=text(data.question,1000,2),key=text(data.idempotencyKey,128);return sqlClient().begin(async tx=>{const c=await lockCase(tx,data.caseId,a.id);if(!c.report)throw new AppError('REPORT_REQUIRED','请先完成AI报告；基础使用指导免费',409);const [old]=await tx`SELECT * FROM point_holds WHERE user_id=${a.id} AND idempotency_key=${key}`;if(old){if(old.kind!=='human'||old.case_id!==c.id||old.snapshot.advisorId!==advisor.id||old.snapshot.question!==question)throw new AppError('IDEMPOTENCY_CONFLICT','请求内容不一致',409);return {id:old.id,share:await bookingConversationShare(tx,a,c.id,advisor.id,old.id)};}const h=await reservePoints(tx,a.id,'human',POINTS_PRICING.human*10,key,{advisorId:advisor.id,question,minutes:10,fixedUnits:POINTS_PRICING.human*10,wechatId:advisor.wechatId,qrUrl:advisor.qrUrl},c.id);await tx`INSERT INTO human_assists(id,user_id,case_id,advisor_id,question) VALUES(${h.id},${a.id},${c.id},${advisor.id},${question})`;return {id:h.id,share:await bookingConversationShare(tx,a,c.id,advisor.id,h.id)};});}
export async function humanAction(a:Actor,id:string,data:any):Promise<{id:string;status:string;chargedUnits?:number;alreadyCompleted?:boolean}>{if(data.action==='redeem')return redeemHuman(a,id,data);return sqlClient().begin(async tx=>{const [look]=await tx`SELECT user_id FROM human_assists WHERE id=${id}`;if(!look||(!a.isAdmin&&look.user_id!==a.id))throw new AppError('NOT_FOUND','预约不存在',404);await lockPointUser(tx,look.user_id);const [r]=await tx`SELECT * FROM human_assists WHERE id=${id} FOR UPDATE`;const [hold]=await tx`SELECT units FROM point_holds WHERE id=${id}`;const own=a.id===r.user_id,action=data.action;let status=r.status,summary=r.summary,deadline=r.deadline;
 if(action==='cancel'&&own&&r.status==='pending'){status='cancelled';await finishHold(tx,id,0,'接单前取消',a.id);}
 else if(action==='confirm'&&own&&r.status==='review'){status='completed';await finishHold(tx,id,hold.units,'真人辅助已确认完成',a.id);}
 else if(action==='dispute'&&own&&['accepted','review'].includes(r.status)){status='disputed';summary=text(data.reason,1000,2);deadline=new Date(Date.now()+7*86400000);}
 else if(action==='accept'&&a.isAdmin&&r.status==='pending'){requireAdmin(a);if(new Date(r.deadline)<new Date())throw new AppError('EXPIRED','预约已超时',409);status='accepted';deadline=new Date(Date.now()+86400000);}
 else if(action==='deliver'&&a.isAdmin&&r.status==='accepted'){requireAdmin(a);if(new Date(r.deadline)<new Date())throw new AppError('EXPIRED','服务已超时，请退回积分',409);status='review';summary=text(data.summary,2000,10);deadline=new Date(Date.now()+2*86400000);}
 else if(action==='refund'&&a.isAdmin&&['pending','accepted','review','disputed'].includes(r.status)){requireAdmin(a);status='refunded';summary=text(data.reason,1000,2);await finishHold(tx,id,0,summary,a.id);}
 else throw new AppError('STATE','当前状态不支持此操作',409);
 if(['cancelled','refunded'].includes(status))await tx`UPDATE conversation_shares SET revoked_at=coalesce(revoked_at,now()) WHERE booking_id=${id}`;
 await tx`UPDATE human_assists SET status=${status},summary=${summary},deadline=${deadline},updated_at=now() WHERE id=${id}`;await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},${'human:'+action},${id},'{}')`;return {id,status};});}
/** Operator redemption shares the user -> booking -> hold lock order with cancellation and maintenance. */
export async function redeemHuman(a:Actor,id:string,data:any){
 requireAdmin(a);uuid(id);
 if(data.serviceCompleted!==true)throw new AppError('INVALID_INPUT','请确认已实际完成服务');
 const summary=text(data.summary,2000,10);
 return sqlClient().begin(async tx=>{
  const [lookup]=await tx`SELECT user_id FROM human_assists WHERE id=${id}`;
  if(!lookup)throw new AppError('NOT_FOUND','预约不存在',404);
  await lockPointUser(tx,lookup.user_id);
  const [r]=await tx`SELECT * FROM human_assists WHERE id=${id} FOR UPDATE`;
  const [h]=await tx`SELECT * FROM point_holds WHERE id=${id} FOR UPDATE`;
  if(!h||h.kind!=='human'||h.user_id!==r.user_id||h.case_id!==r.case_id)throw new AppError('STATE','预约与积分记录不一致，请先核对',409);
  // A retry after operator/customer/automatic completion must never charge again or replace its record.
  if(r.status==='completed'&&h.status==='settled'&&h.charged_units===h.units)return {id,status:'completed',chargedUnits:h.charged_units,alreadyCompleted:true};
  if(!['pending','accepted','review'].includes(r.status)||h.status!=='held')throw new AppError('STATE','该预约不可直接核销；请刷新，有异议的预约须先核对',409);
  if(new Date(r.deadline)<=new Date())throw new AppError('EXPIRED','预约已超时，请刷新并核对积分退回情况',409);
  const completedAt=new Date().toISOString();
  await finishHold(tx,id,h.units,'真人辅助服务完成，运营核销',a.id,{humanRedemption:{operatorId:a.id,completedAt,summary}});
  await tx`UPDATE human_assists SET status='completed',summary=${summary},updated_at=now() WHERE id=${id}`;
  await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'human:redeem',${id},${tx.json({fromStatus:r.status,chargedUnits:h.units,summary,completedAt})})`;
  return {id,status:'completed',chargedUnits:h.units,alreadyCompleted:false};
 });
}
export async function maintainPoints(){const db=sqlClient();const expired=await db`SELECT id,user_id FROM human_assists WHERE status IN ('pending','accepted','review','disputed') AND deadline<now() LIMIT 50`;for(const row of expired)await db.begin(async tx=>{await lockPointUser(tx,row.user_id);const [r]=await tx`SELECT * FROM human_assists WHERE id=${row.id} FOR UPDATE`;if(!['pending','accepted','review','disputed'].includes(r.status)||new Date(r.deadline)>new Date())return;const completed=r.status==='review';const [hold]=await tx`SELECT units FROM point_holds WHERE id=${r.id}`;await finishHold(tx,r.id,completed?hold.units:0,completed?'完成提醒48小时无异议':'接待或争议超时，释放积分');await tx`UPDATE human_assists SET status=${completed?'completed':'refunded'},updated_at=now() WHERE id=${r.id}`;});}
