import type {RuntimePerformanceSummary,RuntimePerformanceEvent} from '../agent/runtime-telemetry';
const number=(v:unknown)=>typeof v==='number'&&Number.isSafeInteger(v)&&v>=0?v:0;
const label=(v:unknown)=>typeof v==='string'&&/^[a-zA-Z0-9_:-]{1,80}$/.test(v)?v:undefined;
/** Only operational fields may cross into the admin response; never spread a
 * persisted object, even if an older runtime wrote additional metadata. */
export function safePerformance(value:any):RuntimePerformanceSummary|null{
 if(value?.version!==1||!Array.isArray(value.events))return null;
 const events:RuntimePerformanceEvent[]=[];
 for(const raw of value.events.slice(-120)){
  if(!['model_start','model_first_delta','model_end','tool_end'].includes(raw?.type))continue;
  const event:RuntimePerformanceEvent={type:raw.type,atMs:number(raw.atMs)};
  if(['preparing','reading','judging','formatting'].includes(raw.stage))event.stage=raw.stage;
  for(const key of ['request','durationMs','firstDeltaMs','inputTokens','outputTokens','cachedInputTokens'] as const)if(raw[key]!==undefined)event[key]=number(raw[key]);
  for(const key of ['finishReason','outcome','tool','code'] as const){const v=label(raw[key]);if(v)event[key]=v;}
  if(typeof raw.ok==='boolean')event.ok=raw.ok;events.push(event);
 }
 const toolGroups:RuntimePerformanceSummary['toolGroups']={};
 for(const key of ['knowledge','judgment','delivery','other'] as const)if(value.toolGroups?.[key]){const group=value.toolGroups[key];toolGroups[key]={calls:number(group.calls),...(group.durationMs!==undefined?{durationMs:number(group.durationMs)}:{})};}
 return {version:1,events,droppedEvents:number(value.droppedEvents)+Math.max(0,value.events.length-120),modelRequests:number(value.modelRequests),modelDurationMs:number(value.modelDurationMs),toolCalls:number(value.toolCalls),toolDurationMs:number(value.toolDurationMs),durationMs:number(value.durationMs),toolGroups};
}
