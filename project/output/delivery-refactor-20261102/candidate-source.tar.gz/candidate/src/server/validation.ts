import { z } from "zod";
import { AppError } from "./http";
import type { CaseInput } from "./contracts";
import {selectedAnchor} from "../engine/random-ticket";
const pillar=z.string().regex(/^[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]$/);
const branch=z.string().regex(/^[子丑寅卯辰巳午未申酉戌亥]$/);
const input=z.object({chartRequest:z.string().max(4000).optional(),timeSource:z.enum(['current','custom']).optional(),intent:z.object({receipt:z.string().max(5000),summary:z.string().max(500)}).optional(),question:z.string().trim().min(3).max(4000),locale:z.enum(["zh","en"]).default("zh"),mode:z.enum(["time","number","pillars","solar"]),longitude:z.number().min(-180).max(180).optional(),random:z.object({ticket:z.string().max(5000)}).optional(),time:z.string().max(100).optional(),timeZone:z.string().max(100).default("Asia/Shanghai"),number:z.number().int().min(1).max(999999999).optional(),pillars:z.object({year:pillar,month:z.union([pillar,branch]),day:pillar,hour:z.union([pillar,branch]),monthGeneral:branch,actualDate:z.string().max(100).optional()}).optional(),participants:z.array(z.object({role:z.string().trim().min(1).max(100),gender:z.enum(["male","female","unknown"]).optional(),birthYear:z.number().int().min(1900).max(2100).optional(),birthDate:z.string().max(100).optional(),lifeBranch:branch.optional()})).max(8).default([]),rules:z.record(z.string(),z.string().max(100)).optional()});
/** Structural validation before AI intent resolution; incomplete auxiliary controls are allowed. */
export function parseInputDraft(value:unknown):CaseInput{const r=input.safeParse(value);if(!r.success)throw new AppError("INVALID_INPUT",r.error.issues[0].message);return r.data;}
export function parseInput(value:unknown):CaseInput{
  const r=input.safeParse(value);if(!r.success)throw new AppError("INVALID_INPUT",r.error.issues[0].message);
  const v=r.data;if(v.participants.some(p=>p.birthYear!==undefined&&p.birthYear>new Date().getFullYear()))throw new AppError("INVALID_BIRTH_YEAR","请检查出生年份");if(v.mode==="number"&&!v.number)throw new AppError("NUMBER_REQUIRED","报数必须为正整数");
  for(const p of v.participants)if(p.birthDate && (!/^\d{4}-\d{2}-\d{2}$/.test(p.birthDate)||!Number.isFinite(new Date(p.birthDate).getTime())||Number(p.birthDate.slice(0,4))!==p.birthYear))throw new AppError("BIRTH_DATE_MISMATCH","出生日期须与出生年份一致 / Birth date must match the birth year");
  if(v.mode==="pillars"&&!v.pillars)throw new AppError("PILLARS_REQUIRED","请输入完整四柱及月将");
  try{new Intl.DateTimeFormat("en",{timeZone:v.timeZone});}catch{throw new AppError("INVALID_TIMEZONE","请选择有效时区");}
  if(v.mode!=="pillars"){
    if(v.time && !/(Z|[+-]\d{2}:\d{2})$/.test(v.time))throw new AppError("TIME_OFFSET_REQUIRED","时间须包含明确时区偏移");
    const time=v.time?new Date(v.time):new Date();if(!Number.isFinite(time.getTime()))throw new AppError("INVALID_TIME","Invalid time");v.time=time.toISOString();
  }
  if(v.mode==="solar"&&v.longitude===undefined)throw new AppError("LONGITUDE_REQUIRED","真太阳时需要所在地经度 / Longitude is required");
  if(v.mode!=="solar"&&v.longitude!==undefined)throw new AppError("INVALID_LONGITUDE_MODE","经度仅用于真太阳时");
  try{selectedAnchor(v);}catch{throw new AppError("RANDOM_CHART_CHANGED","随机盘参数已改变或凭据无效，请重新随机并应用 / Random chart changed; select again");}
  return v;
}
export function text(value:unknown,max=4000,min=1){if(typeof value!=="string"||value.trim().length<min||value.length>max)throw new AppError("INVALID_INPUT","Invalid text input");return value.trim();}
export function uuid(value:string){if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value))throw new AppError("NOT_FOUND","Not found",404);return value;}
