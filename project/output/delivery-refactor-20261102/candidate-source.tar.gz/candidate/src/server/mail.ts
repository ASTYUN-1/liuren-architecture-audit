import {hasRealEmail} from '../lib/account-identity';
import nodemailer from 'nodemailer';
import { createHash } from 'node:crypto';
import { AppError, rateLimit } from './http';
import { getRuntimeSettings, type RuntimeSettings } from './settings';
import { MAIL_KINDS, mailUrl, renderMail, type MailKind } from './mail-content';

// Never persist request payloads: authentication URLs contain bearer tokens.
export function mailErrorCode(error: unknown) {
  const code = (error as { code?: unknown })?.code;
  return typeof code === 'string' && /^[A-Za-z][A-Za-z0-9_.]{0,100}$/.test(code) ? code : 'MAIL_DELIVERY_FAILED';
}

async function sesClient(s: RuntimeSettings) {
  if (!s.sesSecretId || !s.sesSecretKey || !s.smtpFrom) throw new AppError('MAIL_NOT_CONFIGURED', '腾讯云 SES API 尚未配置', 503);
  const { ses } = await import('tencentcloud-sdk-nodejs-ses');
  return new ses.v20201002.Client({
    credential: { secretId: s.sesSecretId, secretKey: s.sesSecretKey }, region: 'ap-hongkong',
    profile: { httpProfile: { endpoint: 'ses.tencentcloudapi.com', reqTimeout: 15 } },
  });
}

export async function checkSesTemplates(s: RuntimeSettings) {
  const client = await sesClient(s);
  try {
    const values = await Promise.all(MAIL_KINDS.map(async kind => {
      const id = s.sesTemplates[kind];
      return [kind, id ? (await client.GetEmailTemplate({ TemplateID: id })).TemplateStatus : -1] as const;
    }));
    return Object.fromEntries(values) as Record<MailKind, number>;
  } catch (error) { throw new AppError(mailErrorCode(error), '无法读取腾讯云模板状态，请检查受限密钥权限和网络', 503); }
}

export function sesPayload(s: RuntimeSettings, to: string, kind: MailKind, url: string) {
  const template = s.sesTemplates[kind];
  if (!template) throw new AppError('MAIL_TEMPLATE_MISSING', '此类邮件尚未配置审核模板', 503);
  const target = new URL(mailUrl(url));
  // Tencent's reviewed templates contain this literal origin. A new public
  // domain requires updating/reviewing the templates, not substituting a URL.
  if (target.origin !== 'https://wen.qiluhub.com') throw new AppError('MAIL_TEMPLATE_ORIGIN', '模板域名与网站地址不一致', 503);
  return {
    FromEmailAddress: `问衡 Wenheng <${s.smtpFrom}>`, Destination: [to], Subject: renderMail(kind, url).subject,
    Template: { TemplateID: template, TemplateData: JSON.stringify({ path: target.pathname.slice(1) + target.search + target.hash }) },
    TriggerType: 1, Unsubscribe: '0',
  };
}

export async function sendTransactionalMail(to: string, kind: MailKind, url: string) {
  const s = await getRuntimeSettings();
  const content = renderMail(kind, url);
  if(s.emailProvider==='tencentSes'&&!s.sesAuthReady&&(kind==='verification'||kind==='passwordReset'))throw new AppError('MAIL_TEMPLATES_NOT_READY','账户邮件模板尚未就绪',503);
  const namespace = process.env.NODE_ENV === 'test' ? 'mail:test:' + (process.env.SETTINGS_RECORD_KEY || '') : 'mail:production';
  // A hard application-wide cap counts attempts, including failures. No open mail relay.
  const day = new Date().toISOString().slice(0, 10);
  await rateLimit(`${namespace}:daily:${day}`, 100, 172800);
  const addressHash = createHash('sha256').update(to.toLowerCase()).digest('hex');
  await rateLimit(`${namespace}:recipient:${kind === 'verification' || kind === 'passwordReset' ? 'auth' : 'service'}:${addressHash}`, kind === 'verification' || kind === 'passwordReset' ? 5 : 20, 3600);
  try {
    if (s.emailProvider === 'tencentSes') {
      const client = await sesClient(s);
      const response = await client.SendEmail(sesPayload(s, to, kind, url));
      return { accepted: true, messageId: response.MessageId || '' };
    }
    if (!s.smtpHost || !s.smtpFrom) throw new AppError('MAIL_NOT_CONFIGURED', '邮件服务尚未配置', 503);
    const transport = nodemailer.createTransport({
      host: s.smtpHost, port: s.smtpPort, secure: s.smtpSecure,
      requireTLS: !(process.env.NODE_ENV !== 'production' && ['127.0.0.1', 'localhost'].includes(s.smtpHost)) && !s.smtpSecure,
      connectionTimeout: 15000, greetingTimeout: 15000, socketTimeout: 20000,
      auth: s.smtpUser ? { user: s.smtpUser, pass: s.smtpPassword } : undefined,
    });
    const response = await transport.sendMail({ from: { name: '问衡 Wenheng', address: s.smtpFrom }, to, ...content });
    return { accepted: true, messageId: response.messageId || '' };
  } catch (error) {
    if (error instanceof AppError) throw error;
    throw new AppError(mailErrorCode(error), '邮件服务商未接受发送，请稍后重试；不要重复提交付款', 503);
  }
}
