import { sqlClient } from "./db";
import { AppError, type Actor } from "./http";
import {requireAdmin} from './points-config';
import {uuid} from './validation';
import {randomUUID} from 'node:crypto';
import {hasRealEmail} from '../lib/account-identity';

export interface AdminUserSummary {
  id:string; name:string; username?:string|null; email:string; emailVerified:boolean; twoFactorEnabled:boolean; createdAt:string;
  orders:number; paidCents:number; refundedCents:number; pendingRefundCents:number;
  cases:number; drafts:number; deletedCases:number; usedTurns:number; remainingTurns:number;
  availableUnits:number; frozenUnits:number; debtUnits:number; consumedUnits:number;
}
export async function adminUsers(admin:Actor, query:string, page:number) {
  if(!admin.isAdmin||!admin.emailVerified)throw new AppError("FORBIDDEN","Administrator access required",403);
  const q=query.trim().slice(0,100), db=sqlClient();
  const [count]=await db`SELECT count(*)::int AS total FROM "user" WHERE strpos(lower(email||' '||COALESCE(username,'')||' '||name||' '||id),lower(${q}))>0`;
  const rows=await db`WITH selected AS (SELECT * FROM "user" WHERE strpos(lower(email||' '||COALESCE(username,'')||' '||name||' '||id),lower(${q}))>0 ORDER BY created_at DESC,id LIMIT 50 OFFSET ${(page-1)*50})
   SELECT u.id,u.name,u.username,u.email,u.email_verified,u.two_factor_enabled,u.created_at,
   (SELECT count(*)::int FROM orders WHERE user_id=u.id) AS orders,
   (SELECT coalesce(sum(amount_cents),0)::int FROM orders WHERE user_id=u.id AND status IN ('paid','refundPending','partiallyRefunded','refunded')) AS paid,
   (SELECT coalesce(sum(refunded_cents),0)::int FROM orders WHERE user_id=u.id) AS refunded,
   (SELECT coalesce(sum(refund_requested_cents),0)::int FROM orders WHERE user_id=u.id) AS pending_refund,
   (SELECT count(*)::int FROM cases WHERE user_id=u.id AND deleted_at IS NULL AND NOT permanently_deleted AND status<>'draft') AS cases,
   (SELECT count(*)::int FROM cases WHERE user_id=u.id AND deleted_at IS NULL AND NOT permanently_deleted AND status='draft') AS drafts,
   (SELECT count(*)::int FROM cases WHERE user_id=u.id AND (deleted_at IS NOT NULL OR permanently_deleted)) AS deleted_cases,
   (SELECT coalesce(sum(e.used),0)::int FROM entitlements e JOIN cases c ON c.id=e.case_id WHERE c.user_id=u.id) AS used,
   (SELECT coalesce(sum(e.granted-e.used-e.reserved-e.revoked-e.frozen),0)::int FROM entitlements e JOIN cases c ON c.id=e.case_id WHERE c.user_id=u.id AND c.deleted_at IS NULL AND NOT c.permanently_deleted) AS remaining
   ,(SELECT coalesce(sum(available_units),0)::int FROM point_lots WHERE user_id=u.id) AS funds
   ,(SELECT coalesce(sum(frozen_units),0)::int FROM point_lots WHERE user_id=u.id) AS frozen
   ,(SELECT coalesce(sum(outstanding_units),0)::int FROM point_debts WHERE user_id=u.id) AS debt
   ,(SELECT coalesce(sum(charged_units-refunded_units),0)::int FROM point_holds WHERE user_id=u.id AND kind IN ('initial','followup','human') AND status='settled') AS consumed
   FROM selected u ORDER BY u.created_at DESC,u.id`;
  const users:AdminUserSummary[]=rows.map(r=>({id:r.id,name:r.name,username:r.username,email:hasRealEmail(r.email)?r.email:"",emailVerified:r.email_verified,twoFactorEnabled:!!r.two_factor_enabled,createdAt:new Date(r.created_at).toISOString(),orders:r.orders,paidCents:r.paid,refundedCents:r.refunded,pendingRefundCents:r.pending_refund,cases:r.cases,drafts:r.drafts,deletedCases:r.deleted_cases,usedTurns:r.used,remainingTurns:r.remaining,availableUnits:r.funds-r.debt,frozenUnits:r.frozen,debtUnits:r.debt,consumedUnits:r.consumed}));
  return {users,total:count.total,page,pageSize:50};
}

export async function adminUserRecords(admin:Actor,id:string) {
  if(!admin.isAdmin||!admin.emailVerified)throw new AppError("FORBIDDEN","Administrator access required",403);
  if(!id||id.length>100)throw new AppError("INVALID_ID","Invalid user ID");
  const db=sqlClient();
  const [orders,cases]=await Promise.all([
    db`SELECT id,case_id AS "caseId",kind,status,amount_cents AS "amountCents",refunded_cents AS "refundedCents",created_at AS "createdAt" FROM orders WHERE user_id=${id} ORDER BY created_at DESC LIMIT 100`,
    db`SELECT id,title,status,archived,permanently_deleted AS "permanentlyDeleted",deleted_at AS "deletedAt",created_at AS "createdAt" FROM cases WHERE user_id=${id} ORDER BY created_at DESC LIMIT 110`
  ]);
  // No question, birth information, report, credential or session data here.
  return {orders,cases};
}

/** Explicit operator-only reader. Return public conversation fields, never internal evidence or credentials. */
export async function adminCaseView(admin:Actor,id:string){
 requireAdmin(admin);uuid(id);const db=sqlClient();
 const [c]=await db`SELECT c.id,c.title,c.status,c.deleted_at,c.permanently_deleted,c.input_version,c.report,u.name,u.email FROM cases c JOIN "user" u ON u.id=c.user_id WHERE c.id=${id}`;
 if(!c||c.permanently_deleted)throw new AppError('NOT_FOUND','档案不存在或已永久删除',404);
 const [input]=await db`SELECT input FROM case_inputs WHERE case_id=${id} AND version=${c.input_version}`;
 const turns=await db`SELECT id,kind,question,answer,clarification,status,input_version AS "inputVersion",created_at AS "createdAt" FROM tasks WHERE case_id=${id} AND kind='followup' ORDER BY created_at,id`;
 await db`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${admin.id},'admin:readCase',${id},'{}')`;
 return {id:c.id,title:c.title,status:c.deleted_at?'deleted':c.status,userName:c.name,userEmail:c.email,question:input?.input?.question||'',report:c.report?{title:c.report.title,summary:c.report.summary,content:c.report.content}:null,turns};
}
