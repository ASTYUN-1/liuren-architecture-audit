import {randomUUID} from 'node:crypto';
import {isIP} from 'node:net';
import {sqlClient,type Tx,type Sql} from './db';
import {AppError,rateLimit,type Actor} from './http';
import {decryptSecret,publicService} from './settings';
import {lockCase,settleConfirmedPayment} from './service';
import {nbCents,nbPayUrl,nbRequest,nbVerify,type NbConfig,type NbPaytype} from './nbzhifu-api';
import {uuid} from './validation';

function settingsKey(){return process.env.NODE_ENV==='test'&&process.env.SETTINGS_RECORD_KEY?'test:'+process.env.SETTINGS_RECORD_KEY:'runtime'}
export async function nbConfig():Promise<NbConfig>{
 const [row]=await sqlClient()`SELECT value FROM service_settings WHERE key=${settingsKey()}`;const s=row?.value||{};
 if(!s.nbzhifuPid||!s.nbzhifuKeyEncrypted)throw new AppError('GATEWAY_NOT_CONFIGURED','聚合支付尚未配置',503);
 return {pid:s.nbzhifuPid,secret:decryptSecret(s.nbzhifuKeyEncrypted),enabled:!!s.nbzhifuEnabled,publicEnabled:!!s.nbzhifuPublicEnabled};
}
export function gatewayView(p:any){return {id:p.id,orderId:p.order_id,caseId:p.case_id||null,orderStatus:p.order_status||null,isTest:p.is_test,amountCents:p.amount_cents,paytype:p.paytype,payUrl:p.pay_url,status:p.provider_status,tradeNo:p.trade_no,paidAt:p.paid_at,checkedAt:p.checked_at,errorCode:p.error_code,createdAt:p.created_at};}
async function paymentView(db:Tx|Sql,p:any){const [order]=p.order_id?await db`SELECT case_id,status AS order_status FROM orders WHERE id=${p.order_id}`:[];return gatewayView({...p,...order});}
export async function startNbPayment(actor:Actor,data:{orderId?:string;paytype?:unknown;test?:boolean},clientIp:string){
 if(!actor.emailVerified)throw new AppError('EMAIL_UNVERIFIED','请先验证邮箱',403);
 const config=await nbConfig();if(!config.enabled)throw new AppError('GATEWAY_PAUSED','聚合支付暂未开放',503);
 if(data.paytype!=='alipay'&&data.paytype!=='wxpay')throw new AppError('PAYMENT_TYPE','请选择支付宝或微信',400);
 const paytype:NbPaytype=data.paytype;
 if(data.test&&!actor.isAdmin)throw new AppError('FORBIDDEN','仅管理员可创建连通性测试',403);
 if(!data.test&&!config.publicEnabled&&!actor.isAdmin)throw new AppError('GATEWAY_TESTING','自动支付仍在验证，请使用人工收款',503);
 if(!data.test&&!(await publicService()).paymentsEnabled)throw new AppError('PAYMENT_UNAVAILABLE','新付款暂不可用；已有权益保留',503);
 await rateLimit('nb-create:'+actor.id,15,60);
 const payment=await sqlClient().begin(async tx=>{
   if(data.test){
     await tx`SELECT pg_advisory_xact_lock(hashtext(${actor.id+':nb-test'}))`;
     const [old]=await tx`SELECT * FROM gateway_payments WHERE user_id=${actor.id} AND is_test=true AND paytype=${paytype} AND paid_at IS NULL AND created_at>now()-interval '15 minutes' ORDER BY created_at DESC LIMIT 1`;if(old)return old;
     const [p]=await tx`INSERT INTO gateway_payments(id,user_id,is_test,merchant_pid,amount_cents,paytype) VALUES(${randomUUID()},${actor.id},true,${config.pid},10,${paytype}) RETURNING *`;return p;
   }
   if(typeof data.orderId!=='string')throw new AppError('INVALID_ORDER','缺少订单编号',400);
   uuid(data.orderId);const [look]=await tx`SELECT * FROM orders WHERE id=${data.orderId} AND user_id=${actor.id}`;if(!look)throw new AppError('NOT_FOUND','订单不存在',404);
   await lockCase(tx,look.case_id,actor.id);const [order]=await tx`SELECT * FROM orders WHERE id=${look.id} FOR UPDATE`;
   if(order.status!=='pending'||new Date(order.expires_at).getTime()<Date.now()||order.payment_reference)throw new AppError('ORDER_STATE','订单已付款、已提交参考或已过期，请查看订单状态',409);
   const [old]=await tx`SELECT * FROM gateway_payments WHERE order_id=${order.id}`;
   if(old){if(old.paytype!==paytype)throw new AppError('PAYMENT_TYPE_LOCKED','此订单已选择另一通道。未付款时可取消订单后重新购买；已付款请勿重复支付',409);return old;}
   await tx`UPDATE orders SET provider='nbzhifu',updated_at=now() WHERE id=${order.id}`;
   const [p]=await tx`INSERT INTO gateway_payments(id,user_id,order_id,merchant_pid,amount_cents,paytype) VALUES(${randomUUID()},${actor.id},${order.id},${config.pid},${order.amount_cents},${paytype}) RETURNING *`;return p;
 });
 // A stable merchant order number and row lock serialize duplicate checkout requests.
 const result=await sqlClient().begin(async tx=>{
   const [p]=await tx`SELECT * FROM gateway_payments WHERE id=${payment.id} FOR UPDATE`;
   if(p.pay_url||p.paid_at)return {payment:p};
   if(p.merchant_pid!==config.pid)throw new AppError('GATEWAY_ACCOUNT_CHANGED','支付账户已变更，请联系运营者核对旧订单',409);
   try{
     const origin=new URL(process.env.APP_URL||'http://localhost:3100').origin;
     const response=await nbRequest(config,'/openapi/pay/create',{out_trade_no:p.id,total_amount:(p.amount_cents/100).toFixed(2),subject:p.is_test?'问衡支付连通性测试':'问衡解读服务',paytype_code:p.paytype,notify_url:origin+'/api/payments/nbzhifu/notify',return_url:origin+'/payments/return?payment='+p.id,client_ip:isIP(clientIp)?clientIp:'127.0.0.1'});
     if(response.out_trade_no!==p.id||typeof response.trade_no!=='string'||!response.trade_no||response.trade_no.length>128)throw new AppError('GATEWAY_RESPONSE','支付平台订单回执不匹配',502);
     const url=nbPayUrl(response.pay_url);
     const [saved]=await tx`UPDATE gateway_payments SET trade_no=${response.trade_no},pay_url=${url},error_code=NULL,updated_at=now() WHERE id=${p.id} RETURNING *`;
     return {payment:saved};
   }catch(e){await tx`UPDATE gateway_payments SET error_code=${e instanceof AppError?e.code:'GATEWAY_ERROR'},updated_at=now() WHERE id=${p.id}`;return {error:e};}
 });
 if(result.error)throw result.error;
 return paymentView(sqlClient(),result.payment);
}

async function holdPayment(tx:Tx,p:any,order:any,status:string){
 if(!['paid','partiallyRefunded'].includes(order.status))return;
 const tasks=await tx`SELECT * FROM tasks WHERE case_id=${order.case_id} AND status IN ('queued','running') AND (${order.kind==='base'} OR entitlement_id IN (SELECT id FROM entitlements WHERE order_id=${order.id})) FOR UPDATE`;
 for(const task of tasks){
   if(task.entitlement_id){await tx`UPDATE entitlements SET reserved=reserved-1 WHERE id=${task.entitlement_id} AND reserved>0`;await tx`INSERT INTO entitlement_ledger(id,case_id,entitlement_id,task_id,order_id,action,quantity) VALUES(${randomUUID()},${order.case_id},${task.entitlement_id},${task.id},${order.id},${'paymentHoldRelease:'+p.id},1) ON CONFLICT DO NOTHING`;}
   await tx`UPDATE tasks SET status='failed',error='支付通道正在核查，次数未扣除；请稍后查看',worker_token=NULL,lease_expires_at=NULL,updated_at=now() WHERE id=${task.id}`;
 }
 const [ent]=await tx`UPDATE entitlements SET frozen=frozen+(granted-used-reserved-revoked-frozen) WHERE order_id=${order.id} RETURNING id,frozen`;
 await tx`UPDATE gateway_payments SET held_turns=${ent?.frozen||0},status_before_hold=${order.status} WHERE id=${p.id}`;
 await tx`UPDATE orders SET status='paymentFrozen',updated_at=now() WHERE id=${order.id}`;
 await tx`UPDATE cases SET status=CASE WHEN report IS NULL THEN 'failed' ELSE 'ready' END,updated_at=now() WHERE id=${order.case_id}`;
 await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},'gateway:nbzhifu','gatewayPaymentHold',${order.id},${tx.json({status})})`;
}

/** Called only with a signed callback followed by a server query, or a server query itself. */
export async function applyNbQuery(paymentId:string,state:Record<string,unknown>){
 return sqlClient().begin(async tx=>{
   const [look]=await tx`SELECT * FROM gateway_payments WHERE id=${paymentId}`;if(!look)throw new AppError('NOT_FOUND','支付记录不存在',404);
   if(look.order_id){const [o]=await tx`SELECT case_id FROM orders WHERE id=${look.order_id}`;await lockCase(tx,o.case_id,undefined,true);}
   const [p]=await tx`SELECT * FROM gateway_payments WHERE id=${paymentId} FOR UPDATE`;
   if(state.out_trade_no!==p.id||nbCents(state.total_amount)!==p.amount_cents||typeof state.trade_no!=='string'||!state.trade_no||state.trade_no.length>128||(p.trade_no&&state.trade_no!==p.trade_no))throw new AppError('PAYMENT_MISMATCH','支付订单或金额不匹配，未开通权益',409);
   const status=String(state.trade_status);if(!['WAIT_BUYER_PAY','TRADE_SUCCESS','TRADE_CLOSED','TRADE_FREEZE','TRADE_UNFREEZE','TRADE_REFUND'].includes(status))throw new AppError('GATEWAY_STATE','支付状态尚无法确认',502);
   const [order]=p.order_id?await tx`SELECT * FROM orders WHERE id=${p.order_id} FOR UPDATE`:[];
   if(order&&order.provider!=='nbzhifu')throw new AppError('PAYMENT_PROVIDER','支付渠道不匹配',409);
   // A refund requires reconciliation by the operator; later success/unfreeze messages
   // must never silently reactivate the refunded purchase.
   if(p.provider_status==='TRADE_REFUND'&&status!=='TRADE_REFUND'){
     const [saved]=await tx`UPDATE gateway_payments SET checked_at=now(),updated_at=now() WHERE id=${p.id} RETURNING *`;
     return paymentView(tx,saved);
   }
   if((status==='TRADE_FREEZE'||status==='TRADE_REFUND')&&order)await holdPayment(tx,p,order,status);
   if((status==='TRADE_SUCCESS'||status==='TRADE_UNFREEZE')&&order?.status==='paymentFrozen'&&p.paid_at&&p.provider_status!=='TRADE_REFUND'){
     await tx`UPDATE entitlements SET frozen=GREATEST(frozen-${p.held_turns},0) WHERE order_id=${order.id}`;
     await tx`UPDATE orders SET status=${p.status_before_hold||'paid'},updated_at=now() WHERE id=${order.id}`;
     await tx`UPDATE gateway_payments SET held_turns=0,status_before_hold=NULL WHERE id=${p.id}`;
     if(order.kind==='base'){
       const [task]=await tx`UPDATE tasks SET status='queued',error=NULL,queued_at=NULL,attempts=0,updated_at=now() WHERE case_id=${order.case_id} AND kind='initial' AND status='failed' AND error='支付通道正在核查，次数未扣除；请稍后查看' RETURNING id`;
       if(task)await tx`UPDATE cases SET status='queued',updated_at=now() WHERE id=${order.case_id}`;
     }
   }
   if(status==='TRADE_SUCCESS'&&order&&!p.paid_at){
     await settleConfirmedPayment(tx,order.id,'nbzhifu:'+state.trade_no,'gateway:nbzhifu','nbzhifu');
   }
   // Only a confirmed success grants rights; an unfreeze without a prior receipt does not.
   const [saved]=await tx`UPDATE gateway_payments SET trade_no=${state.trade_no},provider_status=${p.paid_at&&status==='WAIT_BUYER_PAY'?p.provider_status:status},paid_at=CASE WHEN ${status==='TRADE_SUCCESS'} THEN COALESCE(paid_at,now()) ELSE paid_at END,checked_at=now(),error_code=NULL,updated_at=now() WHERE id=${p.id} RETURNING *`;
   return paymentView(tx,saved);
 });
}
export async function checkNbPayment(actor:Actor,id:string){
 uuid(id);const [p]=await sqlClient()`SELECT * FROM gateway_payments WHERE id=${id} AND (user_id=${actor.id} OR ${actor.isAdmin})`;if(!p)throw new AppError('NOT_FOUND','支付记录不存在',404);
 if(p.checked_at&&Date.now()-new Date(p.checked_at).getTime()<5000)return paymentView(sqlClient(),p);
 await rateLimit('nb-query:'+actor.id,40,60);return reconcileNbPayment(p);
}
export async function reconcileNbPayment(p:any){
 const config=await nbConfig();if(p.merchant_pid!==config.pid)throw new AppError('GATEWAY_ACCOUNT_CHANGED','支付账户已变更，旧订单须人工核对',409);
 const state=await nbRequest(config,'/openapi/pay/query',{out_trade_no:p.id});return applyNbQuery(p.id,state);
}
export async function listNbPayments(actor:Actor,all=false){
 if(all&&!actor.isAdmin)throw new AppError('FORBIDDEN','Administrator access required',403);
 const rows=all?await sqlClient()`SELECT p.*,o.case_id,o.status AS order_status FROM gateway_payments p LEFT JOIN orders o ON o.id=p.order_id ORDER BY p.created_at DESC LIMIT 100`:await sqlClient()`SELECT p.*,o.case_id,o.status AS order_status FROM gateway_payments p LEFT JOIN orders o ON o.id=p.order_id WHERE p.user_id=${actor.id} ORDER BY p.created_at DESC LIMIT 100`;
 return {payments:rows.map(gatewayView)};
}
export async function nbBalance(actor:Actor){if(!actor.isAdmin)throw new AppError('FORBIDDEN','Administrator access required',403);const c=await nbConfig();const balance=await nbRequest(c,'/openapi/merchant/balance_query');return {enabled:c.enabled,publicEnabled:c.publicEnabled,balance:{platform:balance.platform_money,deposit:balance.deposit_money,operate:balance.operate_money}};}
export async function publishNbPayments(actor:Actor,enabled:unknown){
 if(!actor.isAdmin)throw new AppError('FORBIDDEN','Administrator access required',403);
 if(typeof enabled!=='boolean')throw new AppError('INVALID_INPUT','Missing enabled flag',400);
 await nbConfig();
 await sqlClient().begin(async tx=>{await tx`SELECT key FROM service_settings WHERE key=${settingsKey()} FOR UPDATE`;await tx`UPDATE service_settings SET value=jsonb_set(value,'{nbzhifuPublicEnabled}',${tx.json(enabled)}) WHERE key=${settingsKey()}`;await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${actor.id},'publishNbPayments','runtime',${tx.json({enabled})})`});
 return {publicEnabled:enabled};
}
export async function handleNbNotification(params:Record<string,string>){
 const config=await nbConfig();if(params.pid!==config.pid||!nbVerify(params,config.secret))throw new AppError('INVALID_SIGNATURE','Invalid payment signature',400);
 uuid(params.out_trade_no);const [p]=await sqlClient()`SELECT * FROM gateway_payments WHERE id=${params.out_trade_no}`;
 if(!p||p.merchant_pid!==params.pid||nbCents(params.total_amount)!==p.amount_cents||(p.trade_no&&p.trade_no!==params.trade_no))throw new AppError('PAYMENT_MISMATCH','Payment does not match',400);
 // Query even after notification: return pages and callback parameters never grant rights alone.
 return reconcileNbPayment(p);
}
