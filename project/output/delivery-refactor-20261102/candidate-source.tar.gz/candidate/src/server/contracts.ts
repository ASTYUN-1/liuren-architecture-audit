/** Public HTTP contract. Amounts are integer CNY cents; chart internals are never exported. */
export type Locale = "zh" | "en";
export type CaseStatus = "draft" | "awaitingPayment" | "queued" | "running" | "needsClarification" | "ready" | "failed" | "deleted";
export type OrderStatus = "pending" | "submitted" | "paid" | "cancelled" | "refundPending" | "partiallyRefunded" | "refunded" | "paymentFrozen";
export type TaskStatus = "queued" | "running" | "succeeded" | "failed" | "cancelled";
export interface Participant { role: string; gender?: "male" | "female" | "unknown"; birthYear?: number; birthDate?: string; lifeBranch?: string }
export interface CaseInput {
  chartRequest?:string;
  timeSource?: 'current'|'custom';
  intent?: {receipt:string;summary:string};
  question: string; locale: Locale; mode: "time" | "number" | "pillars" | "solar";
  time?: string; timeZone: string; number?: number;
  longitude?: number;
  random?: { ticket: string };
  pillars?: { year: string; month: string; day: string; hour: string; monthGeneral: string; actualDate?: string };
  participants: Participant[]; rules?: Record<string, string>;
}
export interface IntentResolution {action:'keep'|'configure'|'clarify'|'new_event';input?:CaseInput;summary:string;clarification?:string;repair?:boolean}
export interface PreviousReport {inputSavedAt?:string;input?:CaseInput;inputVersion:number;report:Report|null;supersededAt:string}
export interface DeliverySummary {outcome:"complete"|"limited";limitations:string[]}
export interface Report { delivery?:DeliverySummary; title: string; summary: string; content: string; chart?: Record<string, unknown>; warnings?: string[] }
export interface CaseSummary {
  id: string; title: string; status: CaseStatus; archived: boolean; favorite: boolean;
  createdAt: string; updatedAt: string; deletedAt?: string | null;
  remainingTurns: number; usedTurns: number; grantedTurns: number; canPurchaseAddon: boolean;
}
export interface TaskBilling { status: 'settled'|'released'; chargedUnits:number; refundedUnits:number }
export interface TurnView { delivery?:DeliverySummary|null; clarificationMessages?:import("../lib/clarification-messages").DialogueMessage[]; inputVersion?:number; systemCorrection?:boolean; id: string; question: string; status: TaskStatus; answer: string | null; clarification: string | null; createdAt: string; billing?:TaskBilling|null }
export interface TaskView {delivery?:{outcome:"complete"|"limited";limitations:string[]}|null;billingReviewPending?:boolean;runtimeProgress?:{state?:string;startedAt?:string;at?:string;longRunning?:boolean}|null; clarificationMessages?:import("../lib/clarification-messages").DialogueMessage[]; question?:string|null; inputVersion?:number; systemCorrection?:boolean; billingSource?: "points"|"legacy"|"system"; billing?:TaskBilling|null; id: string; kind: "initial" | "followup"; status: TaskStatus; error: string | null; clarification: string | null; createdAt: string }
export interface OrderView {
  id: string; caseId: string; kind: "base" | "addon"; amountCents: number; currency: "CNY";
  status: OrderStatus; provider: "alipayManual" | "nbzhifu"; paymentReference: string | null;
  refundedCents: number; refundRequestedCents: number; createdAt: string;
  listAmountCents: number; discountCents: number; discountLabel: "referral80" | null;
}
export interface CaseDetail extends CaseSummary {inputSavedAt?:string; outputStyle?:"public"|"practitioner"|null; input: CaseInput; inputVersion: number; report: Report | null; previousReports?:PreviousReport[]; turns: TurnView[]; tasks: TaskView[]; orders: OrderView[] }
export interface ReferralSummary { code:string; shareUrl:string; invited:number; successful:number; availableCoupons:number; reservedCoupons:number; discountPercent:number }
export interface MeView { practitioner?: import("../lib/practitioner").PractitionerProfile; points?: import("./points-config").PointsConfig; user: { id: string; name: string; username?:string|null; recoveryReady?:boolean; email: string; emailVerified: boolean; isAdmin: boolean; image?: string | null }; limits: { cases: number; drafts: number; maxCases: 100; maxDrafts: 10 }; referral:ReferralSummary; service: import('../lib/service-availability').ServiceView }
export interface ApiError { error: { code: string; message: string } }
export interface ApiData<T> { data: T }
/**
 * All mutations require same-origin browser requests and an authenticated verified email.
 * POST /api/cases {title?,input} -> CaseDetail; GET -> {cases:CaseSummary[]}.
 * PATCH /api/cases/:id {title?,archived?,favorite?,input?,restore?} -> CaseDetail.
 * DELETE /api/cases/:id {permanent?:boolean} -> {deleted:true,refundPending:boolean}.
 * POST /api/cases/:id/orders {kind:"base"|"addon",idempotencyKey:string} -> OrderView.
 * PATCH /api/orders/:id {paymentReference:string} -> OrderView (never grants rights).
 * POST /api/cases/:id/turns {question:string,idempotencyKey:string,clarificationTaskId?:string} -> TaskView.
 * GET /api/cases/:id/export -> attachment text/plain. Report+dialogue only.
 * POST /api/orders/:id/refund {reason:string} -> OrderView.
 * POST /api/admin/orders/:id/confirm {reference:string} -> OrderView (real到账 only).
 * POST /api/admin/orders/:id/refund {reference:string} -> OrderView (real退款 only).
 */
export const PRICING = { baseCents: 2990, addonCents: 990, baseTurns: 2, addonTurns: 3, maxTurns: 8 } as const;
export interface AdminTaskView extends TaskView { caseId:string; userId:string; userName:string; userEmail:string; caseTitle:string; hasClarification:boolean; consumedUnits:number|null; providerCostCny:number|null; unknownUsage:number; attempts:number; usage:{deliveryDiagnostics?:ReturnType<typeof import("./delivery-diagnostics").safeDeliveryDiagnostics>;performanceSummary?:import("../agent/runtime-telemetry").RuntimePerformanceSummary|null;requests:number;inputTokens:number;outputTokens:number;costCny:number;estimatedAfterCrash:boolean;model:string|null;supplier:string|null;engineVersion:string|null;knowledgeVersion:string|null}|null; failureCode:string|null }
export interface DeletionRequestView { userId:string; requestedAt:string; pendingRefundCount:number; pendingRefundCents:number; remainingCases:number; canComplete:boolean }
/** Ledger delta changes immediately available credits; consume/revoke after reservation/freeze are zero. */
export interface LedgerView {id:string;caseId:string;userId:string;orderId:string|null;taskId:string|null;action:string;quantity:number;delta:number;reason:string;createdAt:string}
export interface AdminOverview {orders:OrderView[];tasks:AdminTaskView[];counts:{users:number};service:MeView["service"];deletionRequests:DeletionRequestView[];ledger:LedgerView[];metrics:{scope:"allPersistedTasks";queued:number;running:number;succeeded:number;failed:number;oldestQueuedAt:string|null;pendingRefundCount:number;pendingRefundCents:number;recordedCostCny:number;tasksWithUsage:number}}

