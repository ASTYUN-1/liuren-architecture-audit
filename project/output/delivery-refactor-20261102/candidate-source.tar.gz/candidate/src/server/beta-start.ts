import {createHash,randomUUID} from 'node:crypto';
import {AppError,type Actor} from './http';
import {betaAllowed} from './beta-access';
import {parseInput,text} from './validation';
import {sqlClient} from './db';
import {verifyIntent} from './input-intent';
import {calculateChart} from '../engine/liuren';
import {pointsConfig} from './points-config';
import {publicService} from './settings';
import {quotePoints} from '../lib/points-pricing';
import {reservePoints} from './points';
import {selectReferralCoupon} from './referrals';
import {updateOutputStyle} from './practitioner-output-style';

// One transaction creates the case and reserves credits/queues the task.
// Existing pricing, coupon, debt, output authorization and signed-intent checks remain authoritative.
export async function startBetaCase(a:Actor,data:any){
 if(!betaAllowed(a))throw new AppError('BETA_FORBIDDEN','内测尚未开放',403);
 const input=parseInput(data.input),key=text(data.idempotencyKey,128,8);
 const {intent,...stable}=input;
 const fingerprint=createHash('sha256').update(JSON.stringify({input:stable,outputStyle:data.outputStyle??null})).digest('hex');
 return sqlClient().begin(async tx=>{
  await tx`SELECT id FROM "user" WHERE id=${a.id} FOR UPDATE`;
  const [prior]=await tx`SELECT t.id,t.case_id,l.details FROM tasks t LEFT JOIN audit_log l ON l.target_id=t.id::text AND l.action='betaStart' WHERE t.user_id=${a.id} AND t.idempotency_key=${key}`;
  if(prior){if(prior.details?.requestHash!==fingerprint)throw new AppError('IDEMPOTENCY_CONFLICT','请求内容已改变，请重新提交',409);return {caseId:prior.case_id,taskId:prior.id,reused:true};}
  verifyIntent(a,input,{caseId:undefined},true);
  const [cfg,service]=await Promise.all([pointsConfig(),publicService()]);
  if(cfg.mode!=='points'||!cfg.aiEnabled||!service.aiEnabled)throw new AppError('AI_UNAVAILABLE','积分解读暂未开放',503);
  const [caps]=await tx`SELECT count(*) FILTER(WHERE status='draft')::int AS drafts,count(*) FILTER(WHERE status<>'draft')::int AS cases FROM cases WHERE user_id=${a.id} AND deleted_at IS NULL`;
  if(caps.cases>=100)throw new AppError('CASE_LIMIT','正式档案上限100个',409);
  const fixed=input.random||input.mode==='solar'?calculateChart(input):null;
  const caseId=randomUUID(),taskId=randomUUID();
  await tx`INSERT INTO cases(id,user_id,title,internal_chart) VALUES(${caseId},${a.id},${input.question.slice(0,40)},${fixed?tx.json(fixed as any):null})`;
  await tx`INSERT INTO case_inputs(case_id,version,input) VALUES(${caseId},1,${tx.json(input as any)})`;
  await updateOutputStyle(tx,a,{id:caseId},{outputStyle:data.outputStyle});
  const coupon=await selectReferralCoupon(tx,a.id),snapshot=quotePoints('initial',coupon?80:100);
  const hold=await reservePoints(tx,a.id,'initial',snapshot.reserveUnits,key,snapshot,caseId,taskId,coupon?.id||null);
  await tx`INSERT INTO tasks(id,case_id,user_id,kind,input_version,idempotency_key,point_hold_id) VALUES(${taskId},${caseId},${a.id},'initial',1,${key},${hold.id})`;
  await tx`UPDATE cases SET status='queued',updated_at=now() WHERE id=${caseId}`;
  await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'betaStart',${taskId},${tx.json({requestHash:fingerprint})})`;
  return {caseId,taskId,reused:false};
 });
}
