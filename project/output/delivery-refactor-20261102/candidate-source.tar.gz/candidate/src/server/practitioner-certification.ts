import {randomUUID} from 'node:crypto';
import {sqlClient,type Tx} from './db';
import {AppError,type Actor} from './http';
import {requireAdmin} from './points-config';
import {text} from './validation';
import type {PractitionerProfile} from '../lib/practitioner';

export async function practitionerProfile(userId:string,db:ReturnType<typeof sqlClient>|Tx=sqlClient()):Promise<PractitionerProfile>{
 const [u]=await db`SELECT email_verified FROM "user" WHERE id=${userId}`;
 const [c]=await db`SELECT * FROM practitioner_certifications WHERE user_id=${userId}`;
 const roles=await db`SELECT advisor_id FROM advisor_accounts WHERE user_id=${userId} ORDER BY advisor_id`;
 const verified=!!u?.email_verified,official=verified&&roles.length>0,professional=verified&&(official||c?.status==='approved');
 return {tier:official?'official':professional?'practitioner':'user',professionalOutput:professional,canReadShared:official,advisorIds:official?roles.map(r=>r.advisor_id):[],certification:c?{status:c.status,applicationNote:c.application_note,reviewNote:c.review_note,revision:c.revision,appliedAt:c.applied_at.toISOString(),reviewedAt:c.reviewed_at?.toISOString()??null}:null};
}
export async function applyPractitioner(a:Actor,data:any){
 if(!a.emailVerified)throw new AppError('EMAIL_UNVERIFIED','请先验证邮箱',403);
 const note=text(data.note,1200,10),db=sqlClient();
 await db.begin(async tx=>{
  await tx`SELECT id FROM "user" WHERE id=${a.id} FOR UPDATE`;
  const profile=await practitionerProfile(a.id,tx);
  if(profile.professionalOutput||profile.certification?.status==='pending')throw new AppError('CERTIFICATION_EXISTS','已认证或正在审核，请勿重复提交',409);
  await tx`INSERT INTO practitioner_certifications(user_id,status,application_note) VALUES(${a.id},'pending',${note}) ON CONFLICT(user_id) DO UPDATE SET status='pending',application_note=excluded.application_note,review_note='',revision=practitioner_certifications.revision+1,applied_at=now(),reviewed_at=NULL,reviewed_by=NULL`;
  await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'practitioner:apply',${a.id},'{}')`;
 });
 return practitionerProfile(a.id);
}
export async function certificationQueue(a:Actor){
 requireAdmin(a);
 return sqlClient()`SELECT c.user_id AS "userId",u.name,u.email,c.status,c.application_note AS "applicationNote",c.review_note AS "reviewNote",c.revision,c.applied_at AS "appliedAt",c.reviewed_at AS "reviewedAt" FROM practitioner_certifications c JOIN "user" u ON u.id=c.user_id ORDER BY (c.status='pending') DESC,c.applied_at DESC LIMIT 200`;
}
export async function reviewPractitioner(a:Actor,data:any){
 requireAdmin(a);const id=text(data.userId,128),note=text(data.note,600,2);
 if(!['approve','reject','revoke'].includes(data.action)||!Number.isSafeInteger(data.revision))throw new AppError('INVALID_INPUT','请选择审核操作');
 await sqlClient().begin(async tx=>{
  const [u]=await tx`SELECT email_verified FROM "user" WHERE id=${id} FOR UPDATE`;
  const [c]=await tx`SELECT status,revision FROM practitioner_certifications WHERE user_id=${id} FOR UPDATE`;
  if(!c||c.revision!==data.revision)throw new AppError('REVIEW_CHANGED','申请状态已更新，请刷新后操作',409);
  if(data.action==='revoke'?c.status!=='approved':c.status!=='pending')throw new AppError('REVIEW_CHANGED','当前状态不能执行此操作',409);
  if(data.action==='approve'&&!u?.email_verified)throw new AppError('EMAIL_UNVERIFIED','该账户须先验证邮箱',409);
  const status=data.action==='approve'?'approved':data.action==='reject'?'rejected':'revoked';
  await tx`UPDATE practitioner_certifications SET status=${status},review_note=${note},revision=revision+1,reviewed_at=now(),reviewed_by=${a.id} WHERE user_id=${id}`;
  await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},${'practitioner:'+data.action},${id},${tx.json({note,revision:data.revision})})`;
 });
 return certificationQueue(a);
}
/** Called with the task locked; no client field can choose the output audience. */
export async function taskOutputAudience(tx:Tx,task:{id:string;user_id:string;output_audience?:string|null}):Promise<"public"|"practitioner">{
 if(task.output_audience==='public'||task.output_audience==='practitioner')return task.output_audience;
 const [c]=await tx`SELECT c.output_style FROM cases c JOIN tasks t ON t.case_id=c.id WHERE t.id=${task.id} AND c.user_id=${task.user_id}`;
 const p=await practitionerProfile(task.user_id,tx),audience=p.professionalOutput&&c?.output_style!=='public'?'practitioner':'public';
 await tx`UPDATE tasks SET output_audience=${audience} WHERE id=${task.id}`;
 return audience;
}
