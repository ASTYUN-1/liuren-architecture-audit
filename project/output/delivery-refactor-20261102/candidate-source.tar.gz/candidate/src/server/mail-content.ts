export const MAIL_KINDS = ['verification', 'passwordReset', 'resultReady', 'serviceUpdate', 'referralReward'] as const;
export type MailKind = typeof MAIL_KINDS[number];
export type MailTemplates = Record<MailKind, number>;
export const emptyMailTemplates: MailTemplates = { verification: 0, passwordReset: 0, resultReady: 0, serviceUpdate: 0, referralReward: 0 };

export const mailContent: Record<MailKind, { subject: string; text: string }> = {
  verification: {
    subject: '问衡 · 验证邮箱 / Verify your email',
    text: '你正在为问衡账户验证或更换邮箱。请打开以下链接完成验证：\n{{url}}\n\n链接有时效，失效后请回到网站重新申请。若非本人操作，请忽略。请勿转发此链接。\n\nVerify your Wenheng email using the link above. If you did not request this, ignore this email. The link expires; request a new one if needed. Do not share this link.',
  },
  passwordReset: {
    subject: '问衡 · 重置密码 / Reset your password',
    text: '我们收到了问衡账户的密码重置请求。请打开以下链接设置新密码：\n{{url}}\n\n若非本人操作，请忽略；你的密码不会自动更改。链接有时效，失效后请重新申请。请勿转发链接或向他人提供密码。\n\nReset your Wenheng password using the link above. If you did not request this, ignore this email; your password will not change automatically. Do not share the link or your password.',
  },
  resultReady: {
    subject: '问衡 · 结果已就绪 / Your result is ready',
    text: '你的问衡解读报告或追问回复已完成，请登录查看：\n{{url}}\n\n为保护隐私，本邮件不包含提问内容、出生资料或解读正文。\n\nYour Wenheng report or follow-up response is ready. Sign in using the link above. This email contains no question, birth details or report content.',
  },
  serviceUpdate: {
    subject: '问衡 · 服务状态更新 / Service update',
    text: '你的问衡账户有新的服务状态通知，可能涉及补充资料、解读任务或订单退款进度。请登录查看：\n{{url}}\n\n退款以账户订单记录及原收款渠道实际到账为准。\n\nThere is an update about requested information, an interpretation task or refund progress. Sign in using the link above. Refund completion depends on the order record and actual payment-channel receipt.',
  },
  referralReward: {
    subject: '问衡 · 邀请优惠已到账 / Referral benefit received',
    text: '你参与的问衡邀请活动已有优惠到账，请登录查看可用优惠和使用条件：\n{{url}}\n\n优惠不兑换现金，不叠加使用，适用范围与状态以账户内展示为准。本邮件不要求你付款。\n\nA benefit from your participation in the Wenheng referral program is available. Sign in using the link above for conditions. Benefits cannot be exchanged for cash or combined. This notice does not request payment.',
  },
};

export function mailUrl(value: string) {
  const origin = new URL(process.env.APP_URL || 'http://localhost:3000').origin;
  const url = new URL(value, origin);
  if (url.origin !== origin || url.username || url.password) throw new Error('MAIL_URL_REJECTED');
  return url.href;
}

export function renderMail(kind: MailKind, url: string) {
  const content = mailContent[kind];
  return { subject: content.subject, text: content.text.replace('{{url}}', mailUrl(url)) + '\n\n此邮箱仅用于系统通知，请勿直接回复。 / This is an automated email; please do not reply.' };
}
