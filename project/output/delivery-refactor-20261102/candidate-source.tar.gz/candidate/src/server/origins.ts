/** Explicit entry-point allowlist; never trust arbitrary forwarded hosts. */
export function trustedAppOrigins(){
  const configured=[process.env.APP_URL||"http://localhost:3000",...(process.env.APP_ORIGINS||"").split(",")];
  return [...new Set(configured.map(value=>{try{return new URL(value.trim()).origin}catch{return ""}}).filter(Boolean))];
}
export function requestAppOrigin(request:Request){
  const allowed=trustedAppOrigins();
  const host=request.headers.get("host");
  const origin=allowed.find(value=>new URL(value).host===host);
  return origin||allowed[0];
}
