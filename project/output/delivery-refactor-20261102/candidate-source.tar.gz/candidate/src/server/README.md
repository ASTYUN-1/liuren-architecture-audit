# 后台交接

## 配置与启动

Node 22+、PostgreSQL 16。部署根目录为 `web/`；先 `npm run db:migrate`，然后分别启动 Next Web 与 `npm run worker`。迁移 001–004 必须全部执行。无内存数据库、假报告或自动放行付款兜底。

必需环境：`DATABASE_URL`、`APP_URL`、`BETTER_AUTH_SECRET`（至少 32 字符）、`WENHENG_ENCRYPTION_KEY`（32 字节 hex/base64）、`ADMIN_EMAILS`。`APP_URL` 须与实际 HTTPS origin 完全相同；Web 与 worker 共用同一 DB、同一加密密钥。模型与 SMTP 优先通过管理员配置页存入数据库；环境可配置 `DEEPSEEK_API_KEY`、`SMTP_HOST/PORT/SECURE/USER/PASSWORD/FROM`。`AI_ENABLED`、`MANUAL_PAYMENT_ENABLED`、`PAYMENT_QR_URL` 只是初始默认值，数据库配置可覆盖。生产部署不能继承开发机的未知 API Key。`ADMIN_REQUIRE_2FA` 默认强制开启，生产不要关闭。

`scripts/db-admin-init.ts` 是仅运维 CLI：指定 `ADMIN_INIT_EMAIL`、`ADMIN_INIT_PASSWORD`（至少 14 字符），邮箱必须在 `ADMIN_EMAILS`，拒绝覆盖已有账户。首次登录后完成 TOTP，才能使用管理 API。不存在公开初始化后门。初始化操作应由根任务完成授权后执行。

注册即自动发送邮箱验证链接（1 小时有效），未验证会话仅能保留草稿、管理账户，付费功能仍被拒绝。邮件服务故障会明确报错；账户可能已建立，用户可登录后重新发送。免费排盘不需要登录，采用两个接口共享的可信 Cloudflare IP 哈希限流（10 次/分钟、100 次/天），不保存排盘资料。收费与真实 AI 需要已验证邮箱。SMTP 生产强制 TLS，仅非生产 localhost 测试 sink 允许明文。

## 业务约束

- 人物性别、出生年份均选填，不阻止起盘或问事；已填年份、日期仍做合法性校验。缺资料不虚构年命／行年，旧已购输入不重写。
- 邀请通过 HttpOnly cookie 在新账户创建钩子绑定；新用户八折券、真实交付后的邀请人八折券各限用一次基础订单，每单最多一张。订单保存原价、实价及券关联。非取消／非全退订单的部分唯一索引避免重复用券，买方行锁串行选择；取消自动释放，迟到到账解除旧券关联并单独全退。`tests/referral.test.ts` 覆盖计价、并发、退款与奖励撤销；真实 SMTP、生产 AI 和付款仍需实际配置。

- 每账户 100 正式档案、10 草稿；同用户行锁保护并发容量。输入变更保存新版本并使旧订单失效。
- ¥29.9 主报告与 2 次追问；¥9.9 追加 3 次，最多 2 包和净授予 8 次。成功报告、扣次同事务；先预留，失败/澄清释放。
- 用户提交付款参考只把订单标记 submitted。管理员实际核对收款后才授予；实际退款后才撤回。迟到的旧订单到账记 refundPending，不丢资金事件、不授予错误版本权益。
- 追加退款按未使用次数比例、整数分结算；退款待处理冻结权益。管理员取消未实际执行的退款会解冻，审计与账本均保留。
- 删除先取消任务与释放预留，建立退款待办和 tombstone；7 天回收，永久清理删除输入、报告、内部盘面、任务正文和证据。最小交易账本保留以退款核对。归档不扣权益，恢复检查容量，不复活已退权益。
- 账户删除申请注销会话并删除档案；管理员须先完成退款，再通过 `/api/admin/users/:id/delete` 清除身份资料与登录凭据，保留去标识交易关联。
- 官方导出仅报告文字与对话，不包含 chart、内部证据或原始 JSON。浏览器展示用 `publicChart`。

## 任务恢复

Postgres tasks 是持久 outbox，worker 每 10 秒补派 pg-boss；队列 stately singletonKey 防止并发派发。业务事务锁及每次 worker token 阻止过期进程交付。运行任务每 20 秒续 2 分钟租约；失联后恢复处理。技术失败最多 3 attempt；费用跨 attempt 累加，主报告 6 元、追问 1.5 元上限。向外请求前持久化剩余预算预留；worker 丢失而费用未知时保守记为已花费，不重开预算无限重试。缺模型时不交付假报告，追问不扣次，主报告进入人工退款。

已付费主报告 24 小时未交付进入退款，关闭任务交付资格。后台可审计重试失败任务；退款状态未解决不能重试基础报告。仅 `queued` 业务任务会执行，重复/迟到 queue job 不会再次扣次。

公开状态和管理员 overview 都返回 `workerOnline`：最近心跳必须早于当前时间且不超过 90 秒。心跳缺失/过期时 AI 与新收费自动关闭；worker 每 30 秒更新心跳。测试使用显式播种的独立 `test:<UUID>:workerHeartbeat`，不伪装生产 worker 在线。模型连接验证不仅要求 `/models` 返回 HTTP 200，还必须确有 `deepseek-flash`。

## 验证

`tests/backend.test.ts`：13 个真实 Postgres 集成测试，数据库名必须包含 wenheng_test；覆盖并发确认/加购/追问、容量、迟到支付、退款删除、跨账户权限、敏感配置、Drizzle JSON serializer 回归、持久 worker 缺模型恢复。测试用独立 test:<UUID> 设置记录，不改运行配置。

`tests/backend-http.test.ts`：对本地 Next 服务做完整 HTTP 注册、邮箱验证、重置登录、管理员 TOTP 挑战、配置加密与 CSRF、真实 SMTP sink 收件；只允许隔离测试 DB。`test-results/private-login.json` 为私有浏览器 QA 凭据，不打印、不提交、不用于生产。仅测试报告明确标记样例，盘面来自真实确定性引擎。

管理员概览额外包含待删除账户的 userId、申请时间、待退款检查与剩余档案数量；最近 100 条权益账本以及最近 100 个任务的安全用量、成本、保存版本与故障码。不返回客户正文、工具证据、提示词或模型思考。聚合指标基于全部现存 tasks/orders，`recordedCostCny` 是已保存调用费用汇总，不是供应商对账单；已永久清理的任务 usage 不在总数中。没有实际观测基线的转化率、准确率、执行 P95 不编造。

验收记录：`web/test-results/backend-acceptance.md`。当前未提供真实模型 Key 与真实 SMTP/收款码，生产应保持 AI 与收费关闭；配置入口已可用。此条件下不能声称付费 AI 质量已验收。
