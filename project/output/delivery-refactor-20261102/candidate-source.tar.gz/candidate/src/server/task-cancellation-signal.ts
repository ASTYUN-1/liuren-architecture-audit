import {sqlClient} from './db';

const running=new Map<string,AbortController>();
let listening:Promise<unknown>|undefined;
/** PostgreSQL delivers NOTIFY after commit, so an abort never precedes a rolled
 * back cancellation. A heartbeat remains the fallback if LISTEN disconnects. */
export async function watchTaskCancellation(taskId:string,controller:AbortController){
 listening??=sqlClient().listen('wenheng_task_stopped',id=>running.get(id)?.abort()).catch(error=>{listening=undefined;throw error;});
 await listening;running.set(taskId,controller);
 return ()=>{if(running.get(taskId)===controller)running.delete(taskId);};
}
