import sharp from "sharp";
import { randomUUID } from "node:crypto";
import { mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { MAX_AVATAR_BYTES, safeAvatarUrl } from "../lib/avatar";
import { sqlClient } from "./db";
import { AppError, type Actor } from "./http";

const tooLarge = () => new AppError("AVATAR_TOO_LARGE", "图片不能超过 2MB / Image must be 2MB or smaller", 413);
function directory() {
  if (process.env.AVATAR_DIR) return process.env.AVATAR_DIR;
  if (process.env.NODE_ENV === "production") return "/var/lib/wenheng/avatars";
  return join(process.cwd(), ".local", "avatars");
}
export async function readAvatarUpload(request: Request) {
  if (Number(request.headers.get("content-length")) > MAX_AVATAR_BYTES) throw tooLarge();
  if (!request.body) throw new AppError("AVATAR_INVALID", "请选择图片 / Choose an image");
  const reader = request.body.getReader(), chunks: Uint8Array[] = []; let size = 0;
  try {
    for (;;) { const { done, value } = await reader.read(); if (done) break; size += value.byteLength; if (size > MAX_AVATAR_BYTES) { await reader.cancel(); throw tooLarge(); } chunks.push(value); }
  } finally { reader.releaseLock(); }
  if (!size) throw new AppError("AVATAR_INVALID", "请选择图片 / Choose an image");
  return Buffer.concat(chunks, size);
}
export async function compressAvatar(input: Buffer) {
  if (input.length > MAX_AVATAR_BYTES) throw tooLarge();
  // Reject vector/other decoders before sharp processes untrusted image data.
  const jpeg = input[0] === 0xff && input[1] === 0xd8 && input[2] === 0xff;
  const png = input.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  const webp = input.toString("ascii", 0, 4) === "RIFF" && input.toString("ascii", 8, 12) === "WEBP";
  if (!jpeg && !png && !webp) throw new AppError("AVATAR_FORMAT", "请上传 JPG、PNG 或静态 WebP 图片 / Use JPG, PNG or static WebP");
  try {
    const image = sharp(input, { limitInputPixels: 40_000_000, failOn: "warning" });
    const metadata = await image.metadata();
    if (!['jpeg','png','webp'].includes(metadata.format || '') || (metadata.pages || 1) > 1) throw Error("unsupported image");
    // rotate() applies EXIF orientation; default output strips EXIF/GPS and other metadata.
    const output = await image.rotate().resize(256, 256, { fit: "cover", position: "centre" }).webp({ quality: 78, effort: 3 }).timeout({ seconds: 8 }).toBuffer();
    if (output.length > 100 * 1024) throw Error("output too large");
    return output;
  } catch { throw new AppError("AVATAR_INVALID", "图片无法处理，请换一张清晰的静态图片（不超过4000万像素） / Use a valid static image up to 40 megapixels"); }
}
export async function removeAvatarFile(url: unknown) {
  const safe = safeAvatarUrl(url); if (!safe) return;
  try { await unlink(join(directory(), safe.slice('/avatars/'.length))); }
  catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") console.error("Old avatar cleanup failed"); }
}
export async function setAvatar(a: Actor, compressed: Buffer | null) {
  const url = compressed ? `/avatars/${randomUUID()}.webp` : null;
  let old: unknown;
  try {
    await sqlClient().begin(async tx => {
      const [user] = await tx`SELECT image,email FROM "user" WHERE id=${a.id} FOR UPDATE`;
      if (!user || user.email.endsWith('@deleted.invalid')) throw new AppError("NOT_FOUND", "账户不存在 / Account not found", 404);
      old = user.image;
      if (url && compressed) { await mkdir(directory(), { recursive: true, mode: 0o700 }); await writeFile(join(directory(), url.slice('/avatars/'.length)), compressed, { mode: 0o600, flag: "wx" }); }
      await tx`UPDATE "user" SET image=${url},updated_at=now() WHERE id=${a.id}`;
    });
  } catch (e) { await removeAvatarFile(url); throw e; }
  await removeAvatarFile(old);
  return { image: url };
}
export async function avatarResponse(name: string, request: Request) {
  const url = safeAvatarUrl('/avatars/' + name);
  if (!url) return new Response(null, { status: 404 });
  try {
    const bytes = await readFile(join(directory(), name));
    const headers = { "Content-Type": "image/webp", "Cache-Control": "public, max-age=86400, immutable", "X-Content-Type-Options": "nosniff", "ETag": '"' + name + '"' };
    if (request.headers.get('if-none-match') === headers.ETag) return new Response(null, { status: 304, headers });
    return new Response(new Uint8Array(bytes), { headers });
  } catch (e) { if ((e as NodeJS.ErrnoException).code === "ENOENT") return new Response(null, { status: 404 }); throw e; }
}
