import {pointsConfig} from "./points-config";
import { randomBytes, randomUUID } from "node:crypto";
import { sqlClient, type Tx } from "./db";

/** Only the authentication new-user hook calls this. Existing accounts cannot bind. */
export async function bindSignupReferral(userId: string, code: string | undefined) {
  if ((await pointsConfig()).mode==="points")return;
  if (!code || !/^[a-f0-9]{24}$/.test(code)) return;
  await sqlClient().begin(async tx => {
    const [inviter] = await tx`SELECT user_id FROM referral_profiles WHERE code=${code} AND user_id<>${userId}`;
    if (!inviter) return;
    const [row] = await tx`INSERT INTO referrals(invitee_id,inviter_id) VALUES(${userId},${inviter.user_id}) ON CONFLICT DO NOTHING RETURNING invitee_id`;
    if (row) await tx`INSERT INTO referral_coupons(id,user_id,referral_id,kind) VALUES(${randomUUID()},${userId},${userId},'welcome')`;
  });
}

/** Select and lock a coupon, while the caller already holds the buyer user lock. */
export async function selectReferralCoupon(tx: Tx, userId: string) {
  const [coupon] = await tx`SELECT p.* FROM referral_coupons p
    WHERE p.user_id=${userId} AND NOT p.revoked
    AND (p.kind='reward' OR NOT EXISTS(SELECT 1 FROM orders o WHERE o.user_id=${userId} AND o.kind='base' AND o.status IN ('paid','refundPending','partiallyRefunded') AND o.fulfillment_eligible))
    AND NOT EXISTS(SELECT 1 FROM point_coupon_claims pc WHERE pc.coupon_id=p.id)
    AND NOT EXISTS(SELECT 1 FROM orders o WHERE o.referral_coupon_id=p.id AND o.status NOT IN ('cancelled','refunded'))
    ORDER BY CASE WHEN p.kind='welcome' THEN 0 ELSE 1 END,p.created_at,p.id
    FOR UPDATE OF p LIMIT 1`;
  return coupon;
}

/** Called inside the same transaction that saves the first delivered report. */
export async function rewardDeliveredReferral(tx: Tx, caseId: string) {
  const [r] = await tx`SELECT r.* ,o.id AS order_id FROM referrals r
    JOIN orders o ON o.user_id=r.invitee_id AND o.case_id=${caseId} AND o.kind='base'
    JOIN cases c ON c.id=o.case_id AND c.report IS NOT NULL AND c.deleted_at IS NULL
    JOIN "user" u ON u.id=r.invitee_id
    WHERE r.qualified_order_id IS NULL AND r.qualified_point_hold_id IS NULL AND o.status='paid' AND o.fulfillment_eligible AND u.email_verified
    AND o.referral_coupon_id IN (SELECT id FROM referral_coupons WHERE referral_id=r.invitee_id AND kind='welcome')
    FOR UPDATE OF r`;
  if (!r) return;
  await tx`UPDATE referrals SET qualified_order_id=${r.order_id},qualified_at=now() WHERE invitee_id=${r.invitee_id}`;
  await tx`INSERT INTO referral_coupons(id,user_id,referral_id,kind) VALUES(${randomUUID()},${r.inviter_id},${r.invitee_id},'reward') ON CONFLICT DO NOTHING`;
}

/** Exceptional post-delivery refunds revoke unused rewards; spent discounts are never clawed back. */
export async function revokeRefundedReferral(tx: Tx, orderId: string) {
  await tx`UPDATE referral_coupons SET revoked=true WHERE kind='reward' AND referral_id IN
    (SELECT invitee_id FROM referrals WHERE qualified_order_id=${orderId})`;
}

export async function referralSummary(userId: string) {
  const db = sqlClient();
  await db`INSERT INTO referral_profiles(user_id,code) VALUES(${userId},${randomBytes(12).toString('hex')}) ON CONFLICT(user_id) DO NOTHING`;
  const [profile] = await db`SELECT code FROM referral_profiles WHERE user_id=${userId}`;
  const [stats] = await db`SELECT count(*)::int AS invited,count(*) FILTER(WHERE r.qualified_at IS NOT NULL AND (o.status IN ('paid','partiallyRefunded') OR r.qualified_point_hold_id IS NOT NULL))::int AS successful
    FROM referrals r LEFT JOIN orders o ON o.id=r.qualified_order_id WHERE r.inviter_id=${userId}`;
  const [coupons] = await db`SELECT
    count(*) FILTER(WHERE NOT EXISTS(SELECT 1 FROM point_coupon_claims pc WHERE pc.coupon_id=p.id) AND NOT EXISTS(SELECT 1 FROM orders o WHERE o.referral_coupon_id=p.id AND o.status NOT IN ('cancelled','refunded')))::int AS available,
    count(*) FILTER(WHERE EXISTS(SELECT 1 FROM orders o WHERE o.referral_coupon_id=p.id AND o.status IN ('pending','submitted')))::int AS reserved
    FROM referral_coupons p WHERE p.user_id=${userId} AND NOT p.revoked
    AND (p.kind='reward' OR NOT EXISTS(SELECT 1 FROM orders o WHERE o.user_id=${userId} AND o.kind='base' AND o.referral_coupon_id IS DISTINCT FROM p.id AND o.status IN ('paid','refundPending','partiallyRefunded') AND o.fulfillment_eligible))`;
  return { code:profile.code, shareUrl:new URL(`/invite/${profile.code}`,process.env.APP_URL||'http://localhost:3100').href,
    invited:stats.invited, successful:stats.successful, availableCoupons:coupons.available, reservedCoupons:coupons.reserved, discountPercent:20 };
}
