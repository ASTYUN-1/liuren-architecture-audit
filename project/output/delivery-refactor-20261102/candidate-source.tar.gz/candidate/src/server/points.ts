import {createHash,randomUUID} from 'node:crypto';
import {sqlClient,type Tx} from './db';
import {AppError,type Actor} from './http';
import {text} from './validation';
import {pointsConfig,requireAdmin} from './points-config';
export const rechargeCode=(id:string)=>'WH-'+createHash('sha256').update('wenheng-topup:'+id).digest('hex').slice(0,16).toUpperCase();
export async function lockPointUser(tx:Tx,userId:string){const [u]=await tx`SELECT id FROM "user" WHERE id=${userId} FOR UPDATE`;if(!u)throw new AppError('NOT_FOUND','账户不存在',404);return u;}
export async function walletTotals(tx:any,userId:string){const [r]=await tx`SELECT l.*,d.debt,(l.funds-d.debt)::int AS available FROM (SELECT coalesce(sum(available_units),0)::int AS funds,coalesce(sum(frozen_units),0)::int AS frozen,coalesce(sum(available_units) FILTER(WHERE kind='paid'),0)::int AS paid,coalesce(sum(available_units) FILTER(WHERE kind='bonus'),0)::int AS bonus FROM point_lots WHERE user_id=${userId}) l CROSS JOIN (SELECT coalesce(sum(outstanding_units),0)::int AS debt FROM point_debts WHERE user_id=${userId} AND outstanding_units>0) d`;return r;}
const units=(v:unknown)=>{if(!Number.isSafeInteger(v)||Number(v)<=0||Number(v)>1000000)throw new AppError('AMOUNT','积分数量无效，最小 0.1 分');return Number(v);};
export async function walletView(a:Actor){const db=sqlClient();await db`INSERT INTO point_profiles(user_id,code) VALUES(${a.id},${rechargeCode(a.id)}) ON CONFLICT DO NOTHING`;const [balance,config,ledger,holds,topups,assists,refunds,draw]=await Promise.all([walletTotals(db,a.id),pointsConfig(),db`SELECT id,hold_id,action,available_delta,frozen_delta,charged_units,reason,created_at FROM point_ledger WHERE user_id=${a.id} ORDER BY created_at DESC LIMIT 100`,db`SELECT id,kind,case_id,task_id,status,units,charged_units,refunded_units,created_at FROM point_holds WHERE user_id=${a.id} ORDER BY created_at DESC LIMIT 100`,db`SELECT id,kind,original_units,reason,created_at FROM point_lots WHERE user_id=${a.id} ORDER BY created_at DESC LIMIT 100`,db`SELECT * FROM human_assists WHERE user_id=${a.id} ORDER BY created_at DESC LIMIT 50`,db`SELECT id,status,reason FROM point_refunds WHERE user_id=${a.id} ORDER BY updated_at DESC LIMIT 50`,db`SELECT advisor_id FROM advisor_draws WHERE user_id=${a.id} ORDER BY created_at DESC LIMIT 1`]);return {balance,config,ledger,holds,topups,assists,refunds,draw:draw[0]?.advisor_id||null,rechargeCode:rechargeCode(a.id)};}
export async function creditPoints(a:Actor,data:any){requireAdmin(a);const userId=text(data.userId,100),amount=units(data.units),reason=text(data.reason,1000,2),key=text(data.idempotencyKey,128);const kind=data.kind==='paid'?'paid':data.kind==='bonus'?'bonus':null;if(!kind)throw new AppError('KIND','请选择实付或赠送');const reference=kind==='paid'?text(data.reference,160,2):null,channel=kind==='paid'?text(data.channel,40,2):null;if(kind==='paid'&&data.amountCents!==amount)throw new AppError('RATE','实收金额与积分必须按 1 元＝10 分一致');
 return sqlClient().begin(async tx=>{await lockPointUser(tx,userId);const [prior]=await tx`SELECT * FROM point_lots WHERE idempotency_key=${key}`;if(prior){if(prior.user_id!==userId||prior.original_units!==amount||prior.kind!==kind||prior.reference!==reference||prior.channel!==channel)throw new AppError('IDEMPOTENCY_CONFLICT','重复请求内容不一致',409);return {id:prior.id};}if(reference&&(await tx`SELECT id FROM point_lots WHERE channel=${channel} AND reference=${reference}`).length)throw new AppError('RECEIPT_EXISTS','这笔到账已充值，请勿重复登记',409);const id=randomUUID();await tx`INSERT INTO point_lots(id,user_id,kind,original_units,available_units,channel,reference,reason,actor_id,idempotency_key) VALUES(${id},${userId},${kind},${amount},${amount},${channel},${reference},${reason},${a.id},${key})`;await tx`INSERT INTO point_ledger(id,user_id,lot_id,action,available_delta,frozen_delta,reason,actor_id) VALUES(${randomUUID()},${userId},${id},'topup',${amount},0,${reason},${a.id})`;await repayPointDebts(tx,userId);return {id};});
}
type Allocation={id:string;units:number};
/** Caller holds user lock. Repayment retains paid/gift provenance for service refunds. */
export async function repayPointDebts(tx:Tx,userId:string){
 const debts=await tx`SELECT * FROM point_debts WHERE user_id=${userId} AND outstanding_units>0 ORDER BY created_at,hold_id FOR UPDATE`;
 if(!debts.length)return;
 const lots=await tx`SELECT * FROM point_lots WHERE user_id=${userId} AND available_units>0 ORDER BY CASE WHEN kind='paid' THEN 0 ELSE 1 END,created_at,id FOR UPDATE`;
 for(const d of debts){let left=d.outstanding_units;const allocations:Allocation[]=[...d.allocations];
  for(const l of lots){if(!left)break;const n=Math.min(left,l.available_units);if(!n)continue;
   await tx`UPDATE point_lots SET available_units=available_units-${n} WHERE id=${l.id}`;allocations.push({id:l.id,units:n});l.available_units-=n;left-=n;
  }
  const paid=d.outstanding_units-left;if(paid){await tx`UPDATE point_debts SET outstanding_units=${left},repaid_units=repaid_units+${paid},allocations=${tx.json(allocations)} WHERE hold_id=${d.hold_id}`;
   await tx`INSERT INTO point_ledger(id,user_id,hold_id,action,available_delta,frozen_delta,reason,actor_id) VALUES(${randomUUID()},${userId},${d.hold_id},${'debtRepay:'+randomUUID()},0,0,${'偿还欠费 '+(paid/10).toFixed(1)+' 积分'},'system')`;}
 }
}
/** Settle delivered AI even when actual usage exceeds its initial reservation.
 * Caller holds user/case/task locks. Full charge and debt commit with the answer. */
export async function settleAiHold(tx:Tx,id:string,quotedUnits:number,summary:Record<string,unknown>){
 if(!Number.isSafeInteger(quotedUnits)||quotedUnits<0)throw new Error('invalid_point_settlement');
 const [lookup]=await tx`SELECT user_id FROM point_holds WHERE id=${id}`;if(!lookup)throw new Error('missing_point_hold');
 await lockPointUser(tx,lookup.user_id);const [h]=await tx`SELECT * FROM point_holds WHERE id=${id} FOR UPDATE`;
 if(h.status!=='held')return h;
 const allocations:Allocation[]=[...h.allocations];let extra=0,left=Math.max(0,quotedUnits-h.units);
 if(left){const lots=await tx`SELECT * FROM point_lots WHERE user_id=${h.user_id} AND available_units>0 ORDER BY CASE WHEN kind='paid' THEN 0 ELSE 1 END,created_at,id FOR UPDATE`;
  for(const l of lots){if(!left)break;const n=Math.min(left,l.available_units);await tx`UPDATE point_lots SET available_units=available_units-${n},frozen_units=frozen_units+${n} WHERE id=${l.id}`;allocations.push({id:l.id,units:n});left-=n;extra+=n;}
  if(extra){await tx`UPDATE point_holds SET units=units+${extra},allocations=${tx.json(allocations)} WHERE id=${id}`;await tx`INSERT INTO point_ledger(id,user_id,hold_id,action,available_delta,frozen_delta,reason,actor_id) VALUES(${randomUUID()},${h.user_id},${id},'usageReserve',${-extra},${extra},'按实际用量补足预存','system')`;}
 }
 if(left){await tx`UPDATE point_holds SET units=units+${left} WHERE id=${id}`;
  await tx`INSERT INTO point_debts(hold_id,user_id,original_units,outstanding_units) VALUES(${id},${h.user_id},${left},${left})`;}
 const settled=await finishHold(tx,id,quotedUnits,'AI成功交付','system',{...summary,quotedUnits,debtUnits:left});
 return settled;
}
export async function reservePoints(tx:Tx,userId:string,kind:string,amount:number,key:string,snapshot:any,caseId:string|null=null,taskId:string|null=null,couponId:string|null=null){
 const deferred=kind==='followup'&&amount===0&&snapshot.settlementMode==='after_delivery'&&snapshot.pricingMode==='metered'&&Number.isSafeInteger(snapshot.baseUnits)&&snapshot.baseUnits>=50;
 await lockPointUser(tx,userId);if(!deferred)units(amount);const [old]=await tx`SELECT * FROM point_holds WHERE user_id=${userId} AND idempotency_key=${key}`;if(old)throw new AppError('IDEMPOTENCY_CONFLICT','该操作已提交',409);
 const balance=await walletTotals(tx,userId);
 if(balance.debt>0)throw new AppError('POINTS_INSUFFICIENT','账户有欠费，请先充值补足，再开始新的解读或追问',409);
 if(deferred&&balance.available<snapshot.baseUnits)throw new AppError('POINTS_INSUFFICIENT',`积分不足，追问不预存，但开始前至少需有 ${(snapshot.baseUnits/10).toFixed(1)} 分可用积分`,409);
 const lots=await tx`SELECT * FROM point_lots WHERE user_id=${userId} AND available_units>0 AND (${kind!=='refund'} OR kind='paid') ORDER BY CASE WHEN kind='paid' THEN 0 ELSE 1 END,created_at,id FOR UPDATE`;if(lots.reduce((s,l)=>s+l.available_units,0)<amount)throw new AppError('POINTS_INSUFFICIENT',`积分不足，本次需暂存 ${(amount/10).toFixed(1)} 分，请先充值`,409);
 let left=amount;const allocations:Allocation[]=[];for(const l of lots){if(!left)break;const n=Math.min(left,l.available_units);await tx`UPDATE point_lots SET available_units=available_units-${n},frozen_units=frozen_units+${n} WHERE id=${l.id}`;allocations.push({id:l.id,units:n});left-=n;}const id=randomUUID();const [hold]=await tx`INSERT INTO point_holds(id,user_id,kind,case_id,task_id,units,allocations,snapshot,coupon_id,idempotency_key) VALUES(${id},${userId},${kind},${caseId},${taskId},${amount},${tx.json(allocations)},${tx.json(snapshot)},${couponId},${key}) RETURNING *`;if(couponId)await tx`INSERT INTO point_coupon_claims(coupon_id,hold_id) VALUES(${couponId},${id})`;await tx`INSERT INTO point_ledger(id,user_id,hold_id,action,available_delta,frozen_delta,reason,actor_id) VALUES(${randomUUID()},${userId},${id},${deferred?'deferred':'reserve'},${-amount},${amount},${deferred?'追问交付后结算，不预存':kind},${userId})`;return hold;
}
/** Recheck before model use: deferred tasks have no frozen funds protecting their minimum fee. */
export async function assertAiTaskBalance(tx:any,task:{point_hold_id?:string|null;user_id:string}){
 if(!task.point_hold_id)return;
 const balance=await walletTotals(tx,task.user_id);
 if(balance.debt>0)throw new Error('points_balance_due');
 const [h]=await tx`SELECT units,snapshot,status FROM point_holds WHERE id=${task.point_hold_id}`;
 if(h?.status==='held'&&h.units===0&&h.snapshot.settlementMode==='after_delivery'&&balance.available<h.snapshot.baseUnits)throw new Error('points_balance_insufficient');
}
/** Caller holds user before case/task. Terminal transition, allocations and ledger are atomic. */
export async function finishHold(tx:Tx,id:string,charge:number,reason:string,actorId='system',summary:any={}){
 const [lookup]=await tx`SELECT user_id FROM point_holds WHERE id=${id}`;if(!lookup)return;await lockPointUser(tx,lookup.user_id);
 const [h]=await tx`SELECT * FROM point_holds WHERE id=${id} FOR UPDATE`;if(h.status!=='held')return h;
 const [d]=await tx`SELECT original_units FROM point_debts WHERE hold_id=${id}`;const debt=d?.original_units||0;
 if(!Number.isSafeInteger(charge)||charge<debt||charge>h.units)throw new Error('invalid_point_settlement');
 let left=charge-debt;const frozen=h.units-debt;
 for(const part of h.allocations as Allocation[]){const spent=Math.min(left,part.units);const rows=await tx`UPDATE point_lots SET frozen_units=frozen_units-${part.units},available_units=available_units+${part.units-spent} WHERE id=${part.id} AND frozen_units>=${part.units} RETURNING id`;if(!rows.length)throw new Error('lost_point_reservation');left-=spent;}
 if(left||h.allocations.reduce((sum:number,p:Allocation)=>sum+p.units,0)!==frozen)throw new Error('point_allocation_mismatch');
 const status=charge?'settled':'released';await tx`UPDATE point_holds SET status=${status},charged_units=${charge},debt_units=${debt},snapshot=snapshot||${tx.json(summary)},updated_at=now() WHERE id=${id}`;
 if(!charge)await tx`DELETE FROM point_coupon_claims WHERE hold_id=${id}`;
 await tx`INSERT INTO point_ledger(id,user_id,hold_id,action,available_delta,frozen_delta,charged_units,reason,actor_id) VALUES(${randomUUID()},${h.user_id},${id},${status},${h.units-charge-debt},${-frozen},${charge},${reason},${actorId})`;
 await repayPointDebts(tx,h.user_id);return {...h,status,charged_units:charge,debt_units:debt};
}
export function aiChargeUnits(snapshot:any,costNano:string|bigint){const cost=BigInt(costNano);if(cost<0n)throw new Error('invalid_usage_cost');const raw=BigInt(snapshot.baseUnits)*1000000000n+cost*BigInt(snapshot.markup??3)*100n;const percent=BigInt(snapshot.discountPercent??100);const charge=(raw*percent+99999999999n)/100000000000n;return snapshot.pricingMode==='metered'?Number(charge):Math.min(snapshot.capUnits,Number(charge));}
export async function requestPointRefund(a:Actor,data:any){const amount=units(data.units),key=text(data.idempotencyKey,128),reason=text(data.reason,1000,2);return sqlClient().begin(async tx=>{await lockPointUser(tx,a.id);const [prior]=await tx`SELECT * FROM point_holds WHERE user_id=${a.id} AND idempotency_key=${key}`;if(prior){if(prior.kind!=='refund'||prior.units!==amount)throw new AppError('IDEMPOTENCY_CONFLICT','请求不一致',409);return {id:prior.id};}const h=await reservePoints(tx,a.id,'refund',amount,key,{refundCents:amount});await tx`INSERT INTO point_refunds(id,user_id,reason) VALUES(${h.id},${a.id},${reason})`;return {id:h.id};});}
export async function resolvePointRefund(a:Actor,id:string,data:any){requireAdmin(a);return sqlClient().begin(async tx=>{const [look]=await tx`SELECT user_id FROM point_refunds WHERE id=${id}`;if(!look)throw new AppError('NOT_FOUND','退款申请不存在',404);await lockPointUser(tx,look.user_id);const [r]=await tx`SELECT * FROM point_refunds WHERE id=${id} FOR UPDATE`;if(r.status!=='pending')return {id};const [h]=await tx`SELECT * FROM point_holds WHERE id=${id}`;const reject=data.action==='reject';const reference=reject?null:text(data.reference,160,2);await finishHold(tx,id,reject?0:h.units,reject?'退款取消，释放积分':'已核实真实退款',a.id);await tx`UPDATE point_refunds SET status=${reject?'cancelled':'refunded'},reference=${reference},updated_at=now() WHERE id=${id}`;return {id};});}
export async function reverseCredit(a:Actor,id:string,reason:string){requireAdmin(a);text(reason,1000,2);return sqlClient().begin(async tx=>{const [look]=await tx`SELECT user_id FROM point_lots WHERE id=${id}`;if(!look)throw new AppError('NOT_FOUND','充值不存在',404);await lockPointUser(tx,look.user_id);const [l]=await tx`SELECT * FROM point_lots WHERE id=${id} FOR UPDATE`;if(l.available_units!==l.original_units||l.frozen_units)throw new AppError('CREDIT_USED','该充值已使用或冻结，需人工核对，不能扣为负数',409);await tx`UPDATE point_lots SET available_units=0 WHERE id=${id}`;await tx`INSERT INTO point_ledger(id,user_id,lot_id,action,available_delta,frozen_delta,reason,actor_id) VALUES(${randomUUID()},${l.user_id},${id},'reverse',${-l.available_units},0,${reason},${a.id})`;return {id};});}
export async function returnServiceCredits(a:Actor,id:string,data:any){
 requireAdmin(a);const amount=units(data.units),reason=text(data.reason,1000,2),key=text(data.idempotencyKey,128);
 return sqlClient().begin(async tx=>{
  const [look]=await tx`SELECT user_id FROM point_holds WHERE id=${id}`;if(!look)throw new AppError('NOT_FOUND','结算不存在',404);await lockPointUser(tx,look.user_id);
  if((await tx`SELECT id FROM audit_log WHERE action='pointServiceRefund' AND target_id=${key}`).length)return {id};
  const [h]=await tx`SELECT * FROM point_holds WHERE id=${id} FOR UPDATE`;
  if(h.status!=='settled'||h.kind==='refund'||h.refunded_units+amount>h.charged_units)throw new AppError('REFUND_LIMIT','不能超过本次尚未退回的消费积分',409);
  const [d]=await tx`SELECT * FROM point_debts WHERE hold_id=${id} FOR UPDATE`;
  const cancelled=Math.min(amount,d?.outstanding_units||0);
  if(cancelled)await tx`UPDATE point_debts SET outstanding_units=outstanding_units-${cancelled},cancelled_units=cancelled_units+${cancelled} WHERE hold_id=${id}`;
  // Cancel unpaid debt first; return actual funds to their original paid/gift lots.
  let charged=h.charged_units-h.debt_units;const funding:Allocation[]=[];
  for(const part of h.allocations as Allocation[]){const n=Math.min(charged,part.units);if(n)funding.push({id:part.id,units:n});charged-=n;}
  funding.push(...(d?.allocations||[]));let skip=h.refunded_units-(d?.cancelled_units||0),left=amount-cancelled;
  for(const part of funding){const ignored=Math.min(skip,part.units);skip-=ignored;const restore=Math.min(left,part.units-ignored);if(restore)await tx`UPDATE point_lots SET available_units=available_units+${restore} WHERE id=${part.id}`;left-=restore;}
  if(left||skip)throw new Error('refund_allocation_mismatch');
  await tx`UPDATE point_holds SET refunded_units=refunded_units+${amount},updated_at=now() WHERE id=${id}`;
  await tx`INSERT INTO point_ledger(id,user_id,hold_id,action,available_delta,frozen_delta,reason,actor_id) VALUES(${randomUUID()},${h.user_id},${id},${'return:'+key},${amount},0,${reason},${a.id})`;
  await tx`INSERT INTO audit_log(id,actor_id,action,target_id,details) VALUES(${randomUUID()},${a.id},'pointServiceRefund',${key},${tx.json({holdId:id,units:amount,debtCancelledUnits:cancelled,reason})})`;
  await repayPointDebts(tx,h.user_id);
  if(h.refunded_units+amount===h.charged_units)await tx`UPDATE referral_coupons SET revoked=true WHERE kind='reward' AND referral_id IN (SELECT invitee_id FROM referrals WHERE qualified_point_hold_id=${id})`;
  return {id};
 });
}
