import {sqlClient} from './db';
import {lockCase} from './service';
import type {DeliveryDraft} from '../agent/delivery';
export async function saveDeliveryDraft(taskId:string,caseId:string,workerToken:string,inputVersion:number,draft:DeliveryDraft){
 await sqlClient().begin(async tx=>{
  const c=await lockCase(tx,caseId,undefined,true);
  const [t]=await tx`SELECT * FROM tasks WHERE id=${taskId} AND case_id=${caseId} FOR UPDATE`;
  if(c.deleted_at||c.permanently_deleted||c.input_version!==inputVersion||t?.input_version!==inputVersion||t.user_id!==c.user_id||t.status!=='running'||t.worker_token!==workerToken)throw new Error('delivery_task_stopped');
  const old=Array.isArray(t.delivery_drafts)?t.delivery_drafts:[];
  const drafts=[...old.filter((x:any)=>x.id!==draft.id),draft].slice(-3);
  await tx`UPDATE tasks SET delivery_drafts=${tx.json(drafts as any)} WHERE id=${taskId}`;
 });
}
