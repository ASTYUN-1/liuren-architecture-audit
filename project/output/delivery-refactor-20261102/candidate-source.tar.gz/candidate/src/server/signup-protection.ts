import {APIError} from 'better-auth/api';
import {chartRateIdentity} from './public-chart';
import {rateLimit} from './http';
export async function signupProtection(headers:Headers,data:any){
 const source=chartRateIdentity(new Request(process.env.APP_URL||'http://localhost:3000',{headers}));
 try{await rateLimit('auth:signup:source:'+source,6,900);await rateLimit('auth:signup:hour:'+source,10,3600);}catch{throw new APIError('TOO_MANY_REQUESTS',{message:'注册较频繁，请稍后再试。'});}
 if(data?.website)throw new APIError('BAD_REQUEST',{message:'注册验证未通过，请重试。'});
 const secret=process.env.TURNSTILE_SECRET_KEY,sitekey=process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY;
 if(secret||sitekey){
  if(!secret||!sitekey||typeof data?.turnstileToken!=='string')throw new APIError('BAD_REQUEST',{message:'请完成人机验证。'});
  let result:any;try{const response=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',body:new URLSearchParams({secret,response:data.turnstileToken}),signal:AbortSignal.timeout(10000)});result=await response.json();}catch{throw new APIError('SERVICE_UNAVAILABLE',{message:'人机验证暂不可用，请重试。'});}
  if(!result.success||!['wen.qiluhub.com','localhost','127.0.0.1'].includes(result.hostname)||result.action!=='signup')throw new APIError('BAD_REQUEST',{message:'人机验证未通过，请重试。'});
 }
}
