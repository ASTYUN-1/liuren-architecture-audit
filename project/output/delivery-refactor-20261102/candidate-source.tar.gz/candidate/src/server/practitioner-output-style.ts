import type {Tx} from './db';
import {AppError,type Actor} from './http';
import {practitionerProfile} from './practitioner-certification';
/** Caller holds the owner's case lock. This endpoint has no private-note storage. */
export async function updateOutputStyle(tx:Tx,a:Actor,c:{id:string},data:any){
 if(data.privateNote!==undefined||data.noteRevision!==undefined)throw new AppError('FEATURE_UNAVAILABLE','私人研习备注暂未开放',409);
 if(data.outputStyle===undefined)return;
 if(!['public','practitioner'].includes(data.outputStyle))throw new AppError('INVALID_INPUT','请选择解读表达');
 if(data.outputStyle==='practitioner'&&!(await practitionerProfile(a.id,tx)).professionalOutput)throw new AppError('FORBIDDEN','专业表达需要卦师认证',403);
 await tx`UPDATE cases SET output_style=${data.outputStyle} WHERE id=${c.id}`;
}
