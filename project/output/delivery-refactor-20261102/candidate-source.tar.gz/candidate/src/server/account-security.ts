import {createHash,randomBytes,randomUUID} from 'node:crypto';
import {hashPassword,verifyPassword} from 'better-auth/crypto';
import {getAuth} from './auth';
import {sqlClient} from './db';
import {AppError,actor,rateLimit} from './http';
import {chartRateIdentity} from './public-chart';
import {hasRealEmail,internalEmailDomain,validUsername} from '../lib/account-identity';

export const newRecoveryKey=()=>randomBytes(16).toString('hex').toUpperCase().match(/.{4}/g)!.join('-');
export const recoveryHash=(id:string,key:string)=>createHash('sha256').update(`wenheng:account-recovery:${id}:${key.replace(/[\s-]/g,'').toUpperCase()}`).digest('hex');
const passwordValid=(v:unknown):v is string=>typeof v==='string'&&v.length>=10&&v.length<=128;
const sensitive=(email:string,twoFactor:boolean)=>twoFactor||(process.env.ADMIN_EMAILS||'').split(',').some(v=>v.trim().toLowerCase()===email.toLowerCase());
const denied=()=>new AppError('RECOVERY_INVALID','账号或恢复密钥不正确，或此账户需要使用专用安全恢复流程。',400);
export async function authRate(request:Request,kind:string,identifier='') {
 const identity=chartRateIdentity(request);
 await rateLimit(`auth:${kind}:source:${identity}`,kind==='signup'?6:kind==='availability'?60:30,kind==='availability'?60:900);
 if(identifier&&kind!=='signup')await rateLimit(`auth:${kind}:account:${createHash('sha256').update(identifier.toLowerCase()).digest('hex')}`,kind==='recover'?5:20,900);
 if(kind==='signup')await rateLimit(`auth:signup:hour:${identity}`,10,3600);
}
export async function signup(request:Request,data:any) {
 const username=typeof data.username==='string'?data.username.trim().toLowerCase():'';
 if(!validUsername(username)||!passwordValid(data.password))throw new AppError('INVALID_ACCOUNT','账号需为4～24位字母、数字或下划线，密码为10～128位。');
 const email=typeof data.email==='string'?data.email.trim().toLowerCase():'';
 if(email&&(!hasRealEmail(email)||!/^\S+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254))throw new AppError('INVALID_EMAIL','请填写正确的邮箱地址，或留空。');
 // Better Auth requires an email-shaped identity internally. This reserved .invalid
 // address is never verified, delivered to, or presented as a bound email.
 const internal=email||`${randomUUID()}@${internalEmailDomain}`;
 const headers=new Headers(request.headers);headers.set('content-type','application/json');
 const response=await getAuth().handler(new Request(new URL('/api/auth/sign-up/email',request.url),{method:'POST',headers,body:JSON.stringify({username,name:username,email:internal,password:data.password,callbackURL:'/account/settings',turnstileToken:data.turnstileToken,website:data.website})}));
 if(!response.ok)return response;
 const result=await response.json(),key=newRecoveryKey();
 await sqlClient()`INSERT INTO account_recovery(user_id,key_hash) VALUES(${result.user.id},${recoveryHash(result.user.id,key)}) ON CONFLICT(user_id) DO UPDATE SET key_hash=excluded.key_hash,updated_at=now()`;
 const outgoing=new Headers({'Content-Type':'application/json','Cache-Control':'no-store'});for(const cookie of response.headers.getSetCookie())outgoing.append('set-cookie',cookie);
 return Response.json({data:{recoveryKey:key,username,email:email||null}},{status:201,headers:outgoing});
}
export async function rotateRecovery(request:Request,data:any) {
 const a=await actor(request,false);await authRate(request,'rotate',a.id);
 const db=sqlClient(),[u]=await db`SELECT email,two_factor_enabled FROM "user" WHERE id=${a.id}`;
 if(sensitive(u.email,!!u.two_factor_enabled))throw new AppError('SPECIAL_RECOVERY','此账户请使用邮箱及现有二次验证恢复流程。',403);
 const [account]=await db`SELECT id,password FROM account WHERE user_id=${a.id} AND provider_id='credential'`;
 if(!account||!passwordValid(data.password)||!await verifyPassword({hash:account.password,password:data.password}))throw new AppError('PASSWORD_INVALID','当前密码不正确。');
 const key=newRecoveryKey();await db.begin(async tx=>{
  const [fresh]=await tx`SELECT id,email,two_factor_enabled FROM "user" WHERE id=${a.id} FOR UPDATE`;
  const [credential]=await tx`SELECT password FROM account WHERE id=${account.id} FOR UPDATE`;
  const s=await getAuth().api.getSession({headers:request.headers});
  if(!s||s.user.id!==a.id||sensitive(fresh.email,!!fresh.two_factor_enabled)||credential.password!==account.password)throw new AppError('SESSION_CHANGED','账户已发生变更，请重新登录。',401);
  await tx`INSERT INTO account_recovery(user_id,key_hash) VALUES(${a.id},${recoveryHash(a.id,key)}) ON CONFLICT(user_id) DO UPDATE SET key_hash=excluded.key_hash,updated_at=now()`;
 });return {username:a.username||a.email,recoveryKey:key};
}
export async function recover(request:Request,data:any) {
 const username=typeof data.username==='string'?data.username.trim().toLowerCase():'';await authRate(request,'recover',username);
 if(!passwordValid(data.newPassword)||typeof data.recoveryKey!=='string'||data.recoveryKey.length>80)throw denied();
 const db=sqlClient(),[u]=await db`SELECT u.id,u.email,u.two_factor_enabled,r.key_hash FROM "user" u JOIN account_recovery r ON r.user_id=u.id WHERE u.username=${username} OR (u.username IS NULL AND lower(u.email)=${username})`;
 if(!u||sensitive(u.email,!!u.two_factor_enabled)||recoveryHash(u.id,data.recoveryKey)!==u.key_hash)throw denied();
 const passwordHash=await hashPassword(data.newPassword),key=newRecoveryKey();
 await db.begin(async tx=>{
  const [fresh]=await tx`SELECT email,two_factor_enabled FROM "user" WHERE id=${u.id} FOR UPDATE`;
  const [r]=await tx`SELECT key_hash FROM account_recovery WHERE user_id=${u.id} FOR UPDATE`;
  if(!fresh||sensitive(fresh.email,!!fresh.two_factor_enabled)||r?.key_hash!==u.key_hash)throw denied();
  const rows=await tx`UPDATE account SET password=${passwordHash},updated_at=now() WHERE user_id=${u.id} AND provider_id='credential' RETURNING id`;if(rows.length!==1)throw denied();
  await tx`UPDATE account_recovery SET key_hash=${recoveryHash(u.id,key)},updated_at=now() WHERE user_id=${u.id}`;
  await tx`DELETE FROM session WHERE user_id=${u.id}`;
  await tx`DELETE FROM verification WHERE value=${u.id} AND identifier LIKE 'reset-password:%'`;
 });return {username,recoveryKey:key,requiresLogin:true};
}
export async function profile(request:Request,data:any){
 const a=await actor(request,false);await rateLimit('profile:'+a.id,20,3600);const name=typeof data.name==='string'?data.name.trim():'';if(!name||name.length>40)throw new AppError('INVALID_NAME','昵称请填写1～40个字符。');
 const username=typeof data.username==='string'?data.username.trim().toLowerCase():null;if(username&&!validUsername(username))throw new AppError('INVALID_USERNAME','账号需为4～24位字母、数字或下划线。');
 try{await sqlClient().begin(async tx=>{const [u]=await tx`SELECT username FROM "user" WHERE id=${a.id} FOR UPDATE`;if(username&&u.username&&username!==u.username)throw new AppError('USERNAME_FIXED','登录账号不可修改。');await tx`UPDATE "user" SET name=${name},username=COALESCE(username,${username}),updated_at=now() WHERE id=${a.id}`;});}catch(e){if((e as {code?:string}).code==='23505')throw new AppError('USERNAME_TAKEN','该账号已被使用，请换一个。',409);throw e;}return {ok:true};
}
