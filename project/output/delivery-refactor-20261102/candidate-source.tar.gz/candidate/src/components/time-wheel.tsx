"use client";
import {useEffect,useLayoutEffect,useMemo,useRef} from 'react';
import {useApp} from './app-provider';
const years=Array.from({length:201},(_,i)=>1900+i),months=Array.from({length:12},(_,i)=>i+1),hours=Array.from({length:24},(_,i)=>i),minutes=Array.from({length:60},(_,i)=>i);
export function beijingWallTime(instant=new Date()){return new Date(+instant+28800000).toISOString().slice(0,16);}
function Wheel({label,values,value,onChange}:{label:string;values:number[];value:number;onChange:(n:number)=>void}){
 const list=useRef<HTMLDivElement>(null),timer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined),userScroll=useRef(false),latest=useRef({values,value,onChange});
 useLayoutEffect(()=>{latest.current={values,value,onChange};});
 useLayoutEffect(()=>{const el=list.current;if(!el)return;clearTimeout(timer.current);userScroll.current=false;const top=values.indexOf(value)*36;if(Math.abs(el.scrollTop-top)>1)el.scrollTo({top,behavior:'instant'});},[value,values]);
 useEffect(()=>()=>clearTimeout(timer.current),[]);
 // A native dialog has no layout before showModal(). Reposition when it becomes visible.
 useEffect(()=>{const el=list.current;if(!el)return;const observer=new ResizeObserver(()=>{if(!el.clientHeight)return;const v=latest.current;userScroll.current=false;el.scrollTo({top:v.values.indexOf(v.value)*36,behavior:'instant'});});observer.observe(el);return()=>observer.disconnect();},[]);
 function markUserScroll(){userScroll.current=true;}
 function settle(){if(!userScroll.current)return;clearTimeout(timer.current);timer.current=setTimeout(()=>{const el=list.current;if(!el||!userScroll.current)return;userScroll.current=false;const v=latest.current,i=Math.max(0,Math.min(v.values.length-1,Math.round(el.scrollTop/36)));if(v.values[i]!==v.value)v.onChange(v.values[i]);},160);}
 return <div className="time-wheel-column"><span>{label}</span><div className="time-wheel-list" ref={list} role="spinbutton" aria-label={label} aria-valuemin={values[0]} aria-valuemax={values.at(-1)} aria-valuenow={value} tabIndex={0} onWheel={markUserScroll} onPointerDown={markUserScroll} onTouchStart={markUserScroll} onKeyDown={e=>{const i=values.indexOf(value);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();onChange(values[Math.max(0,Math.min(values.length-1,i+(e.key==='ArrowDown'?1:-1)))]);}}} onScroll={settle}>{values.map(n=><button type="button" tabIndex={-1} className={n===value?'selected':''} aria-label={`${label} ${n}`} key={n} onClick={()=>onChange(n)}>{String(n).padStart(2,'0')}</button>)}</div></div>;
}
export function TimeWheel({value,onChange}:{value:string;onChange:(v:string)=>void}){
 const {t}=useApp();const [y,m,d,h,min]=value.replace('T','-').replace(':','-').split('-').map(Number);
 const days=useMemo(()=>Array.from({length:new Date(Date.UTC(y,m,0)).getUTCDate()},(_,i)=>i+1),[y,m]);
 function change(index:number,n:number){const a=[y,m,d,h,min];a[index]=n;a[2]=Math.min(a[2],new Date(Date.UTC(a[0],a[1],0)).getUTCDate());onChange(`${a[0]}-${String(a[1]).padStart(2,'0')}-${String(a[2]).padStart(2,'0')}T${String(a[3]).padStart(2,'0')}:${String(a[4]).padStart(2,'0')}`);}
 return <div className="time-wheels" aria-label={t('选择北京时间','Select Beijing time')}>{[years,months,days,hours,minutes].map((values,i)=><Wheel key={i} label={[t('年','Year'),t('月','Month'),t('日','Day'),t('时','Hour'),t('分','Minute')][i]} values={values} value={[y,m,d,h,min][i]} onChange={n=>change(i,n)}/>)}</div>;
}
