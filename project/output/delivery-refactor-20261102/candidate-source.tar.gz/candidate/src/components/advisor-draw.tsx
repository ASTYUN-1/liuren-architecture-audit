"use client";
import {useEffect,useRef,useState} from 'react';
import {flushSync} from 'react-dom';
import type {PointsConfig} from '@/server/points-config';
import {useApp} from './app-provider';
import {post} from '@/lib/api';
type Advisor=PointsConfig['advisors'][number];
export function AdvisorDraw({advisors,onSelected}:{advisors:Advisor[];onSelected:(v:Advisor)=>void}){
 const {t}=useApp(),ring=useRef<HTMLDivElement>(null),drawButton=useRef<HTMLButtonElement>(null),angle=useRef(0),frame=useRef(0),alive=useRef(true),locked=useRef(false);
 const [busy,setBusy]=useState(false),[selected,setSelected]=useState<string|null>(null),[error,setError]=useState('');
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;cancelAnimationFrame(frame.current);};},[]);
 async function draw(){if(locked.current)return;locked.current=true;setBusy(true);setError('');setSelected(null);try{
  const {advisorId}=await post<{advisorId:string}>('/api/advisors',{});if(!alive.current)return;
  const i=advisors.findIndex(a=>a.id===advisorId);if(i<0)throw Error('抽取结果无效');
  const start=angle.current,target=start+1800+((360-i*72-start%360)%360+360)%360;
  const duration=window.matchMedia('(prefers-reduced-motion: reduce)').matches?80:4200,begin=performance.now();
  await new Promise<void>(resolve=>{function tick(now:number){if(!alive.current){resolve();return;}const f=Math.min(1,(now-begin)/duration),ease=1-Math.pow(1-f,4);angle.current=start+(target-start)*ease;ring.current?.style.setProperty('--spin',angle.current+'deg');if(f<1)frame.current=requestAnimationFrame(tick);else resolve();}frame.current=requestAnimationFrame(tick);});
  if(alive.current){flushSync(()=>{setSelected(advisorId);setBusy(false);});drawButton.current?.focus({preventScroll:true});onSelected(advisors[i]);}
 }catch(e){if(alive.current)setError(e instanceof Error?e.message:'抽取失败，请重试');}finally{locked.current=false;if(alive.current)setBusy(false);}}
 return <div className="advisor-lottery"><div className="consultation-wheel"><div className={`consultation-pointer ${busy?'drawing':''}`} aria-hidden="true"/><div className="consultation-wheel-face" ref={ring}>{advisors.map((a,i)=>{const rad=i*72*Math.PI/180;return <div className={`consultation-wheel-person ${selected===a.id?'winner':''}`} key={a.id} style={{left:`${50+33*Math.sin(rad)}%`,top:`${50-33*Math.cos(rad)}%`}}><div><img src={a.avatar} alt="" width={64} height={64}/><span>{a.name}</span></div></div>;})}</div><div className="consultation-wheel-center" aria-hidden="true">{t('问衡','问衡')}</div></div><p className="draw-status" aria-live="polite">{busy?t('正在为你抽取…','Drawing your contact…'):selected?`${t('本次抽中','Selected')}: ${advisors.find(a=>a.id===selected)?.name}`:t('五位等概率，抽取免费','Equal chances. Free to draw.')}</p><button ref={drawButton} className="button primary draw-button" type="button" disabled={busy} onClick={draw}>{busy?t('抽取中…','Drawing…'):selected?t('再抽一次','Draw again'):t('随机抽取','Draw a contact')}</button>{error?<p role="alert" className="error-text">{error}</p>:null}</div>;
}
