"use client";
import type {DeliverySummary} from '@/server/contracts';
import {useApp} from './app-provider';
export function DeliveryNotice({delivery}:{delivery?:DeliverySummary|null}){
 const {t}=useApp();
 return delivery?.outcome==='limited'?<p className="muted" role="status">{t('带限制回答 · 请留意文中的未定项。本轮不扣积分或追问次数；如有原套餐款项，请查看订单退款状态。','Limited answer · Please read the stated limitations. No credits or follow-up turn are consumed. For a legacy payment, check its refund status.')}</p>:null;
}
