"use client";
import {useState} from 'react';
import {Modal} from './modal';
import {useApp} from './app-provider';
const stems=[...'甲乙丙丁戊己庚辛壬癸'],branches=[...'子丑寅卯辰巳午未申酉戌亥'];
export const ganzhiCycle=Array.from({length:60},(_,i)=>stems[i%10]+branches[i%12]);
export function PillarPicker({value,onChange}:{value:{year:string;month:string;day:string;hour:string;monthGeneral:string};onChange:(v:typeof value)=>void}){
 const {t}=useApp(),[active,setActive]=useState<'year'|'day'|null>(null);
 return <div className="pillar-picker"><div className="pillar-fields">{(['year','month','day','hour','monthGeneral'] as const).map((f,i)=><label key={f}>{[t('年柱','Year'),t('月支','Month'),t('日柱','Day'),t('时支','Hour'),t('月将','General')][i]}{f==='year'||f==='day'?<button type="button" className="pillar-value" onClick={()=>setActive(f)}>{value[f]||t('选择','Select')} <span>⌄</span></button>:<select required value={value[f].slice(-1)} onChange={e=>onChange({...value,[f]:e.target.value})}><option value="">{t('选择','Select')}</option>{branches.map(b=><option key={b}>{b}</option>)}</select>}</label>)}</div>{active?<Modal title={t(active==='year'?'选择年柱':'选择日柱',active==='year'?'Year pillar':'Day pillar')} onClose={()=>setActive(null)}><div className="ganzhi-grid">{ganzhiCycle.map(g=><button className={g===value[active]?'selected':''} type="button" key={g} onClick={()=>{onChange({...value,[active]:g});setActive(null);}}>{g}</button>)}</div></Modal>:null}</div>;
}
