"use client";
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import type { Locale, MeView } from "@/server/contracts";
import { api, ApiException } from "@/lib/api";
type AppContext = { locale: Locale; setLocale: (locale: Locale) => void; t: (zh: string, en: string) => string; me: MeView | null; loading: boolean; authError: string; refresh: () => Promise<void> };
const Context = createContext<AppContext | null>(null);
export function AppProvider({ children }: { children: ReactNode }) {
  const [locale, updateLocale] = useState<Locale>("zh"), [me, setMe] = useState<MeView | null>(null), [loading, setLoading] = useState(true), [authError, setAuthError] = useState("");
  const refreshing = useRef<Promise<void> | null>(null);
  const refresh = useCallback(() => {
    if (refreshing.current) return refreshing.current;
    refreshing.current = (async () => {
      try { setMe(await api<MeView>("/api/me")); setAuthError(""); }
      catch (error) {
        if (error instanceof ApiException && error.status === 401) { setMe(null); setAuthError(""); }
        else setAuthError(error instanceof Error ? error.message : "服务暂不可用");
      } finally { setLoading(false); refreshing.current = null; }
    })();
    return refreshing.current;
  }, []);
  useEffect(() => { const stored = localStorage.getItem("wenheng-locale"); if (stored === "en") { updateLocale("en"); document.documentElement.lang = "en"; } void refresh(); }, [refresh]);
  useEffect(() => {
    if (!me?.user.id) return;
    const update = () => { if (document.visibilityState === "visible") void refresh(); };
    const timer = window.setInterval(update, 30000);
    window.addEventListener("focus", update);
    document.addEventListener("visibilitychange", update);
    return () => { window.clearInterval(timer); window.removeEventListener("focus", update); document.removeEventListener("visibilitychange", update); };
  }, [me?.user.id, refresh]);
  const setLocale = (value: Locale) => { updateLocale(value); localStorage.setItem("wenheng-locale", value); document.documentElement.lang = value === "zh" ? "zh-CN" : "en"; };
  return <Context.Provider value={{ locale, setLocale, t: (zh, en) => locale === "zh" ? zh : en, me, loading, authError, refresh }}>{children}</Context.Provider>;
}
export function useApp() { const value = useContext(Context); if (!value) throw new Error("AppProvider missing"); return value; }
