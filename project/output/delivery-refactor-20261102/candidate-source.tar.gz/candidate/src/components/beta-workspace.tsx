"use client";
import {useEffect,useRef,useState,type MouseEvent} from 'react';
import Link from 'next/link';
import {useRouter} from 'next/navigation';
import dynamic from 'next/dynamic';
import {SquarePen,Files,Wallet,Compass,Users,BookOpen,UserRound,ShieldCheck,Menu,X,ArrowRight,Download} from 'lucide-react';
import {useApp} from './app-provider';
import {api,post,key,ApiException} from '@/lib/api';
import type {CaseSummary,CaseInput} from '@/server/contracts';
import {BetaQuestionForm} from './beta-question-form';
import {BetaCaseWorkspace} from './beta-case-workspace';
import {BetaPointsDashboard} from './beta-points-dashboard';
import {PractitionerBadge,PractitionerProfileCard} from './practitioner-profile-card';
import {HumanAssistance} from './human-assistance';
import {PractitionerWorkspace} from './practitioner-workspace';
import {Loading,Notice} from './ui';
import CasesPage from '@/app/cases/page';
import ChartPage from '@/app/chart/page';
import AccountPage from '@/app/account/settings/page';
import TermsPage from '@/app/terms/page';
import PrivacyPage from '@/app/privacy/page';
import GuidePage from './beta-guide';
import './beta-workspace.css';
import './beta-usability.css';
import {BetaShowcase} from './beta-showcase';
import type {ShowcaseCase} from '@/lib/case-showcase-types';
const emptyShowcases:ShowcaseCase[]=[];
const Admin=dynamic(()=>import('./admin-workspace').then(m=>m.AdminWorkspace),{loading:()=> <Loading/>});
const Payments=dynamic(()=>import('@/app/payments/page'),{loading:()=> <Loading/>});
const nav=[['','新的问事',SquarePen],['cases','我的档案',Files],['wallet','充值与账单',Wallet],['chart','自助排盘',Compass],['assistance','真人辅助',Users],['examples','AI 解卦案例',BookOpen],['help','使用帮助',BookOpen]] as const;
type Submission={input:CaseInput;outputStyle?:'public'|'practitioner';idempotencyKey:string};
export function BetaWorkspace({route,showcases=emptyShowcases,publicMode=false,webDownload=false}:{route:string;showcases?:ShowcaseCase[];publicMode?:boolean;webDownload?:boolean}){
 const{me,loading,refresh}=useApp(),router=useRouter(),[menu,setMenu]=useState(false),[cases,setCases]=useState<CaseSummary[]>([]),[available,setAvailable]=useState<number|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[pending,setPending]=useState<Submission|null>(null),[savedInput,setSavedInput]=useState<CaseInput>();
 const [draftReady,setDraftReady]=useState(false),[draftOwner,setDraftOwner]=useState(''),[casesOwner,setCasesOwner]=useState('');
 const base=publicMode?'':'/beta',to=(path='')=>base+(path?'/'+path:publicMode?'/':'');
 const locked=useRef(false),main=useRef<HTMLElement>(null),storageKey='wenheng-beta-pending-'+(me?.user.id||'guest');
 useEffect(()=>{setCases([]);setAvailable(null);setError('');if(!me)return;let live=true;const load=()=>{if(document.visibilityState!=='visible')return;void Promise.all([api<{cases:CaseSummary[]}>('/api/cases'),api<{balance:{available:number}}>('/api/points')]).then(([c,w])=>{if(live){setCasesOwner(me.user.id);setCases(c.cases);setAvailable(w.balance.available/10);}}).catch(e=>{if(live)setError(e.message);});};load();const timer=setInterval(load,15000);return()=>{live=false;clearInterval(timer);};},[me?.user.id,route]);
 useEffect(()=>{if(!storageKey||route!==''){setDraftReady(false);return;}try{const raw=sessionStorage.getItem(storageKey);setPending(raw?JSON.parse(raw):null);const ownKey='wenheng-beta-draft-'+(me?.user.id||'guest');const draft=sessionStorage.getItem(ownKey)||sessionStorage.getItem('wenheng-pending-input-v1')||sessionStorage.getItem('wenheng-beta-draft-guest');setSavedInput(draft?JSON.parse(draft):undefined);if(me&&draft){sessionStorage.setItem(ownKey,draft);sessionStorage.removeItem('wenheng-pending-input-v1');sessionStorage.removeItem('wenheng-beta-draft-guest');}}catch{setPending(null);setSavedInput(undefined);}setDraftOwner(storageKey);setDraftReady(true);},[storageKey,route]);
 useEffect(()=>{setMenu(false);main.current?.scrollTo({top:0});},[route]);
 async function start(input:CaseInput,options?:{outputStyle?:'public'|'practitioner'},retry?:Submission){
  if(!me){sessionStorage.setItem('wenheng-pending-input-v1',JSON.stringify(input));router.push('/login?next=/');return;}
  if(locked.current)return;locked.current=true;setBusy(true);setError('');
  const submission=retry||{input,...options,idempotencyKey:'beta:'+key()};
  setSavedInput(input);setPending(submission);sessionStorage.setItem(storageKey,JSON.stringify(submission));
  try{const result=await post<{caseId:string}>('/api/beta/start',submission);sessionStorage.removeItem(storageKey);sessionStorage.removeItem('wenheng-beta-draft-'+me?.user.id);setSavedInput(undefined);setPending(null);await refresh();router.push(to('cases/'+result.caseId));}
  catch(e){const msg=e instanceof Error?e.message:'提交失败';setError(msg);if(e instanceof ApiException&&e.status<500){sessionStorage.removeItem(storageKey);setPending(null);}throw e;}
  finally{locked.current=false;setBusy(false);}
 }
 function intercept(e:MouseEvent){if(publicMode)return;if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;const anchor=(e.target as Element).closest('a');if(!anchor||anchor.target||anchor.hasAttribute('download'))return;const url=new URL(anchor.href);if(url.origin!==location.origin||url.pathname.startsWith('/api/')||url.pathname.startsWith('/beta'))return;const map:Record<string,string>={'/':'','/cases':'cases','/account':'wallet','/account/settings':'account','/chart':'chart','/assistance':'assistance','/guide':'help','/terms':'terms','/privacy':'privacy','/practitioner':'practitioner','/admin':'admin','/payments':'payments'};const dest=map[url.pathname]??(/^\/cases\/[a-f0-9-]{36}$/.test(url.pathname)?url.pathname.slice(1):null);if(dest===null)return;e.preventDefault();e.stopPropagation();router.push('/beta'+(dest?'/'+dest:'')+url.search+url.hash);}
 if(loading&&!publicMode)return <Loading/>;if(!me&&!publicMode)return <Notice>登录已失效，请返回旧版重新登录。<a href="/login">登录</a></Notice>;
 const visibleCases=casesOwner===me?.user.id?cases:[];
 const title=route.startsWith('cases/')?'事项对话':route.startsWith('examples')?'AI 解卦案例':route==='account'?'我的账户':route==='admin'?'运营工作台':nav.find(n=>n[0]===route)?.[1]||'问衡';
 const sidebar=<><Link href={to()} className="beta-brand"><span>衡</span><div>问衡<small>大六壬 · AI 辅助解读</small></div></Link><nav className="beta-nav">{nav.map(([path,label,Icon],i)=><Link key={path} className={(route===path||(path==='cases'&&route.startsWith('cases/'))||(path==='examples'&&route.startsWith('examples/'))?'active ':'')+(i===3?'separate':'')} href={to(path)}><Icon size={19}/>{label}</Link>)}</nav><div className="beta-recent"><small>最近的问事</small>{visibleCases.filter(c=>!c.archived).slice(0,3).map(c=><Link key={c.id} href={to('cases/'+c.id)} title={c.title} aria-current={route==='cases/'+c.id?'page':undefined}>{c.title}</Link>)}</div><div className="beta-account">{me?.practitioner?.canReadShared&&<Link href={to('practitioner')} aria-current={route==='practitioner'?'page':undefined}><Users size={18}/>合作卦师工作台</Link>}{me?.user.isAdmin&&<Link href={to('admin')}><ShieldCheck size={18}/>运营工作台</Link>}<Link href={me?to('account'):'/login'}><UserRound size={18}/>{me?.user.name||'登录 / 注册'}<small>我的账户</small></Link>{!publicMode&&<a href="/" className="beta-old" onClick={e=>e.stopPropagation()}>返回旧版 ↗</a>}</div></>;
 return <div className="beta-app"><aside className="beta-sidebar">{sidebar}</aside>{menu&&<div className="beta-drawer"><aside><button className="icon-button" aria-label="关闭导航" onClick={()=>setMenu(false)}><X/></button>{sidebar}</aside><button className="beta-backdrop" aria-label="收起导航" onClick={()=>setMenu(false)}/></div>}<div className="beta-main"><header className={"beta-topbar"+(publicMode&&webDownload&&route===''?" beta-topbar-with-download":"")}><button className="beta-menu icon-button" aria-label="打开更多导航" onClick={()=>setMenu(true)}><Menu/></button><span>{title}</span>{publicMode&&webDownload&&route===''&&<a className="beta-apk-download" href="/api/download/android" download title="下载问衡安卓版（Android 8.0 及以上）"><Download size={16} aria-hidden="true"/>下载软件</a>}<Link href={me?to('wallet'):'/login'}>{me?<>可用 <strong>{available===null||casesOwner!==me?.user.id?'…':available.toFixed(1)}</strong> 积分</>:'登录 / 注册'}</Link></header>{!publicMode&&<div className="beta-notice">账号专属内测 · 真实业务与积分 <a href="/">返回旧版</a></div>}<main className="beta-content" ref={main} onClickCapture={intercept}>
 {error&&<Notice kind="error">{error} <Link href={to('wallet')}>查看积分</Link></Notice>}
 {!me&&!['','chart','assistance','help','terms','privacy','examples'].includes(route)&&!route.startsWith('examples/')?<section className="page-container"><h1>登录后查看</h1><p>登录后即可查看自己的档案与账户。</p><Link className="button primary" href={'/login?next='+encodeURIComponent(to(route))}>登录</Link> <Link className="button secondary" href="/register">注册账户</Link></section>:route===''?<div className="beta-ask"><header><h1>问衡 · 大六壬</h1><p>以大六壬为基础，结合 AI 解读，支持持续追问与档案记录。</p></header>{pending?<section className="beta-pending"><h2>核对上次提交</h2><p>保留了上次请求。重试会沿用同一提交编号，已创建的任务不会重复建档或扣款。</p><p>{pending.input.question}</p><button className="button primary" disabled={busy} onClick={()=>void start(pending.input,undefined,pending).catch(()=>{})}>{busy?'正在核对…':'核对并继续上次提交'}</button></section>:!draftReady||draftOwner!==storageKey?<Loading/>:<BetaQuestionForm key={savedInput?.question||'new'} initial={savedInput} busy={busy} onConfirm={start}/>}<section className="beta-home-recent"><div><h2>最近的问事</h2><Link href={to('cases')}>查看全部 <ArrowRight size={14}/></Link></div>{visibleCases.filter(c=>!c.archived).slice(0,3).map(c=><Link key={c.id} href={to('cases/'+c.id)}><Files size={20}/><span>{c.title}</span><small>{({ready:'已完成',draft:'待开始',queued:'排队中',running:'分析中',needsClarification:'待补充',failed:'未完成',awaitingPayment:'待付款',deleted:'已删除'} as const)[c.status]}</small><ArrowRight size={15}/></Link>)}</section></div>:route==='examples'||route.startsWith('examples/')?<BetaShowcase key={route} cases={showcases} slug={route==='examples'?undefined:route.slice(9)}/>:route==='cases'?<CasesPage/>:route.startsWith('cases/')?<BetaCaseWorkspace key={route} id={route.slice(6)}/>:route==='wallet'?<BetaPointsDashboard/>:route==='chart'?<ChartPage/>:route==='assistance'?<HumanAssistance/>:route==='help'?<><div className="beta-guide-note"><h2>在当前页开始分析</h2><p>费用在开始按钮旁列明。默认要求明确时，点击“开始分析”即整理要求、建档并提交；AI调整了起课参数时在当前页核对，有歧义则先补充。无需进入档案再点一次启动。充值入口为“充值与账单”。</p><Link href={to()}>去问事 →</Link></div><GuidePage/></>:route==='terms'?<TermsPage/>:route==='privacy'?<PrivacyPage/>:route==='account'?<><div className="beta-profile"><h1>{me?.user.name} <PractitionerBadge/></h1><PractitionerProfileCard/>{me?.practitioner?.tier==='official'&&<Link href={to('practitioner')}>官方合作工作台 →</Link>}</div><AccountPage/></>:route==='practitioner'?<PractitionerWorkspace allowCompletion archiveStyle/>:route==='admin'?me?.user.isAdmin?<Admin quickView/>:<Notice>没有运营权限。</Notice>:route==='payments'?<Payments/>:null}
 </main><nav className="beta-bottom">{[['','问事',SquarePen],['cases','档案',Files],['wallet','充值',Wallet],['account','我的',UserRound]].map(([path,label,Icon]:any)=><Link key={path} href={to(path)} className={route===path?'active':''}><Icon size={21}/>{label}</Link>)}</nav></div></div>;
}
