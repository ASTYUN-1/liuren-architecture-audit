"use client";
import {useEffect,useRef,useState} from 'react';
import {Mic,Square} from 'lucide-react';
import {useApp} from './app-provider';
type Recognition={lang:string;continuous:boolean;interimResults:boolean;onresult:((e:any)=>void)|null;onerror:((e:any)=>void)|null;onend:(()=>void)|null;start:()=>void;stop:()=>void;abort:()=>void};
type SpeechWindow=Window&{SpeechRecognition?:new()=>Recognition;webkitSpeechRecognition?:new()=>Recognition};
export function VoiceInput({onText,disabled=false}:{onText:(text:string)=>void;disabled?:boolean}){
  const [desktop,setDesktop]=useState(false);
  useEffect(()=>{
    const mobileHint=(navigator as Navigator&{userAgentData?:{mobile?:boolean}}).userAgentData?.mobile;
    const mobileDevice=mobileHint||/Android|iPhone|iPad|iPod|Mobile|Tablet|Silk|Kindle/i.test(navigator.userAgent)
      ||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
    setDesktop(!mobileDevice);
  },[]);
  // Start hidden during hydration; mobile devices never mount microphone controls.
  return desktop?<DesktopVoiceInput onText={onText} disabled={disabled}/>:null;
}
function DesktopVoiceInput({onText,disabled}:{onText:(text:string)=>void;disabled:boolean}){
  const {t,locale}=useApp(),[available,setAvailable]=useState(false),[requesting,setRequesting]=useState(false),[listening,setListening]=useState(false),[message,setMessage]=useState(''),[interim,setInterim]=useState('');
  const recognition=useRef<Recognition|null>(null),callback=useRef(onText),attempt=useRef(0),active=useRef(false);
  useEffect(()=>{callback.current=onText;},[onText]);
  useEffect(()=>{
    const w=window as SpeechWindow;setAvailable(!!(w.SpeechRecognition||w.webkitSpeechRecognition));
    return()=>{
      // A permission prompt can outlive this component. Invalidate its continuation.
      attempt.current++;active.current=false;
      const r=recognition.current;recognition.current=null;
      if(r){r.onresult=null;r.onerror=null;r.onend=null;r.abort();}
    };
  },[]);
  useEffect(()=>{
    if(!disabled)return;
    attempt.current++;active.current=false;
    const r=recognition.current;recognition.current=null;
    if(r){r.onresult=null;r.onerror=null;r.onend=null;r.abort();}
    setRequesting(false);setListening(false);setInterim('');
  },[disabled]);
  async function start(){
    if(disabled||active.current)return;
    setMessage('');const w=window as SpeechWindow,Ctor=w.SpeechRecognition||w.webkitSpeechRecognition;if(!Ctor)return;
    if(!window.isSecureContext||!navigator.mediaDevices?.getUserMedia){
      setMessage(t('麦克风需要安全连接和浏览器支持，请用系统浏览器打开本站 HTTPS 页面。','Microphone access needs a secure connection and browser support. Open this HTTPS page in your browser.'));return;
    }
    const id=++attempt.current;active.current=true;setRequesting(true);
    try{
      // Ask from the button click, before starting the separate speech service.
      // Never keep this permission-check stream recording in the background.
      const stream=await navigator.mediaDevices.getUserMedia({audio:true});
      stream.getTracks().forEach(track=>track.stop());
    }catch(error){
      if(id!==attempt.current)return;
      active.current=false;setRequesting(false);
      const name=error instanceof Error?error.name:'';
      setMessage(name==='NotAllowedError'||name==='PermissionDeniedError'
        ?t('麦克风未获授权。若未出现弹窗，请在地址栏旁的「网站设置」中允许麦克风，并检查系统麦克风权限后重试。','Microphone access was not allowed. If no prompt appeared, allow it in the site settings beside the address bar and check system microphone permissions, then retry.')
        :name==='NotFoundError'
        ?t('未检测到麦克风，请连接麦克风后重试，或继续打字。','No microphone was found. Connect one and retry, or type.')
        :name==='NotReadableError'
        ?t('麦克风无法使用，可能被其他程序占用或被系统禁用，请检查后重试。','The microphone could not be used. Check whether another app is using it or the system has disabled it.')
        :t('暂时无法取得麦克风，请检查设备后重试，或继续打字。','Could not access the microphone. Check your device and retry, or type.'));
      return;
    }
    if(id!==attempt.current)return;
    setRequesting(false);
    let r:Recognition|null=null;
    const finish=()=>{if(id!==attempt.current)return;active.current=false;setListening(false);setInterim('');recognition.current=null;if(r){r.onresult=null;r.onerror=null;r.onend=null;}};
    try{
      r=new Ctor();recognition.current=r;r.lang=locale==='zh'?'zh-CN':'en-US';r.continuous=true;r.interimResults=true;
      r.onresult=e=>{if(id!==attempt.current)return;let final='',draft='';for(let i=e.resultIndex;i<e.results.length;i++){if(e.results[i].isFinal)final+=e.results[i][0].transcript;else draft+=e.results[i][0].transcript;}if(final)callback.current(final);setInterim(draft);};
      r.onerror=e=>{
        if(id!==attempt.current)return;
        setMessage(e.error==='not-allowed'||e.error==='service-not-allowed'
          ?t('麦克风已获授权，但浏览器未允许启动语音识别。请检查浏览器语音功能或换用支持的浏览器，也可继续打字。','Microphone access was granted, but the browser did not allow speech recognition. Check browser speech settings, try a supported browser, or type.')
          :e.error==='network'
          ?t('麦克风已获授权，但语音识别服务连接失败。请检查网络后重试，或继续打字。','Microphone access was granted, but the speech service could not connect. Check your network and retry, or type.')
          :e.error==='no-speech'
          ?t('没有识别到说话声，请重试，或继续打字。','No speech was detected. Retry or type.')
          :t('语音识别暂不可用，可重试或继续打字。','Speech recognition unavailable. Retry or type instead.'));
        finish();r?.abort();
      };
      r.onend=finish;setListening(true);r.start();
    }catch{
      finish();r?.abort();setMessage(t('麦克风已获授权，但语音识别未能启动，请重试或继续打字。','Microphone access was granted, but speech recognition could not start. Retry or type.'));
    }
  }
  function toggle(){
    if(requesting){attempt.current++;active.current=false;setRequesting(false);return;}
    if(listening){try{recognition.current?.stop();}catch{recognition.current?.abort();}return;}
    void start();
  }
  return <div className="voice-input"><button type="button" className="text-button" disabled={disabled||!available} onClick={toggle} aria-pressed={listening}>{listening||requesting?<Square size={16}/>:<Mic size={16}/>} {requesting?t('取消等待','Cancel waiting'):listening?t('停止语音','Stop voice'):t('语音输入','Voice input')}</button><small aria-live="polite">{requesting?t('请在浏览器弹窗中选择是否允许麦克风；若已阻止，请检查地址栏旁的网站设置。','Choose whether to allow the microphone in the browser prompt. If blocked, check the site settings beside the address bar.'):listening?t('正在听，请说；停止后请核对文字。','Listening. Check the text when finished.'):available?t('点击后申请麦克风权限；文字可编辑，请核对日期与数字。','Click to request microphone access. Edit the text and check dates and numbers.'):t('此浏览器不支持语音识别，可使用输入法的麦克风。','This browser has no speech recognition. You can use your keyboard’s microphone.')}</small>{interim?<p aria-live="polite">{interim}</p>:null}{message?<p role="status">{message}</p>:null}</div>;
}
