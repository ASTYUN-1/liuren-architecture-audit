"use client";
import Link from "next/link";
import type { ReactNode } from "react";
import { useApp } from "./app-provider";
import { Loading, Empty } from "./ui";
export function AdminGate({ children }: { children: ReactNode }) { const { me, loading, t } = useApp(); if (loading) return <Loading />; if (!me?.user.isAdmin) return <Empty title={t("仅运营账户可访问", "Operator account required")}><Link className="button secondary" href="/account">{t("返回账户", "Back to account")}</Link></Empty>; return <>{children}</>; }
