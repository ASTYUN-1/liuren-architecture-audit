"use client";
import type {AdminTaskView} from '@/server/contracts';
import {useApp} from './app-provider';

export function AdminTaskPerformance({task}:{task:AdminTaskView}){
 const {t}=useApp(),p=task.usage?.performanceSummary;
 const duration=(ms:number)=>ms<1000?`${Math.round(ms)} ms`:`${(ms/1000).toFixed(1)} ${t('秒','s')}`;
 return <details><summary>{t('耗时记录','Timing records')}</summary>{p?<>
  <small>{t('本次执行','This execution')}: {duration(p.durationMs)}</small>
  <small>{t('模型请求累计','Model requests total')}: {duration(p.modelDurationMs)} · {p.modelRequests} {t('次','requests')}</small>
  {([['knowledge','资料读取','Knowledge reading'],['judgment','判断记录','Judgment recording'],['delivery','报告交付','Report delivery'],['other','其他工具','Other tools']] as const).map(([key,zh,en])=>{const g=p.toolGroups?.[key];return <small key={key}>{t(zh,en)}: {g?`${g.durationMs===undefined?t("耗时无记录","Timing unrecorded"):duration(g.durationMs)} · ${g.calls} ${t('次','calls')}`:t('无记录','Unrecorded')}</small>;})}
  <small className="muted">{t('工具项只计工具自身耗时，模型推理另计；并行调用累计时间可超过实际经过时间。','Tool timings exclude model reasoning. Summed concurrent calls may exceed elapsed time.')}</small>
 </>:<small>{t('此任务未记录分阶段耗时','No timing records for this task')}</small>}</details>;
}
