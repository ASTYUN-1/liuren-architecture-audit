"use client";
import { useState } from "react";
import type { OrderView } from "@/server/contracts";
import { useApp } from "./app-provider";
import { Notice, Status } from "./ui";
import { patch, post, money } from "@/lib/api";
import {GatewayPayment,type GatewayPaymentView} from './gateway-payment';
import {paymentUnavailableMessage} from "@/lib/service-availability";

export function PaymentPanel({ order, onUpdated }: { order: OrderView; onUpdated: () => void }) {
  const { t, me, locale, refresh } = useApp();
  const [reference, setReference] = useState(order.paymentReference || "");
  const [busy, setBusy] = useState(false), [error, setError] = useState("");
  const canPay = Boolean(me?.service.paymentsEnabled && !me.service.paymentQrIsPlaceholder);
  const canSubmitReceipt = Boolean(me && !me.service.paymentQrIsPlaceholder);
  const awaiting = order.status === "submitted";
  const [gateway,setGateway]=useState<GatewayPaymentView|null>(null);
  const [manual,setManual]=useState(false);
  async function checkout(paytype:'alipay'|'wxpay') {setBusy(true);setError('');try{setManual(false);setGateway(await post<GatewayPaymentView>('/api/payments/nbzhifu',{orderId:order.id,paytype}));onUpdated()}catch(e){setError(e instanceof Error?e.message:'Error');onUpdated()}finally{setBusy(false)}}
  async function cancel() {
    setBusy(true); setError("");
    try { await patch(`/api/orders/${order.id}`, { cancel: true }); onUpdated(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
    finally { setBusy(false); }
  }
  async function submit(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError("");
    try { await patch(`/api/orders/${order.id}`, { paymentReference: reference.trim() }); onUpdated(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
    finally { setBusy(false); }
  }
  return <section className="payment-panel">
    <div className="panel-heading"><h2>{t("付款方式与到账核验", "Payment verification")}</h2><Status status={order.status} /></div>
    <p>{order.kind === "base" ? t("完整解读＋2 次追问", "Full report + 2 follow-ups") : t("此档追加 3 次追问", "3 additional follow-ups for this case")} · <strong className="payment-amount">{money(order.amountCents)}</strong></p>
    {order.discountCents > 0 ? <p className="discount-line">{t("邀请八折已抵扣", "Invitation discount applied")} · <s>{money(order.listAmountCents)}</s> → {money(order.amountCents)} · {t("优惠", "Saved")} {money(order.discountCents)}</p> : null}
    <p className="break-word"><small>{t("订单编号", "Order ID")}：{order.id}</small></p>
    {order.status === "pending" && me?.service.aggregatePaymentsEnabled ? <div className="button-row"><button className="button primary" disabled={busy||!canPay} onClick={()=>void checkout('alipay')}>{t('支付宝 · 自动核验','Alipay · automatic verification')}</button><button className="button secondary" disabled={busy||!canPay} onClick={()=>void checkout('wxpay')}>{t('微信 · 自动核验','WeChat · automatic verification')}</button></div>:null}
    {gateway?<div className="modal-backdrop"><section className="modal" role="dialog" aria-modal="true" aria-label={t("聚合支付收银台","Online checkout")}><GatewayPayment payment={gateway} onUpdated={onUpdated} onClose={()=>setGateway(null)}/></section></div>:null}
    {order.provider==='nbzhifu'&&!gateway&&order.status==='pending'?<Notice>{t('此订单已使用聚合支付。点击原支付通道可重新打开收银台，或前往账户中的聚合流水查询。已付款请勿取消或改用人工码重复支付。','This order uses online payment. Reopen the same checkout or check payment records. Do not pay again using the manual code.')}</Notice>:null}
    {order.provider==='alipayManual'&&me?.service.aggregatePaymentsEnabled&&!awaiting?<button className="text-button" onClick={()=>setManual(v=>!v)}>{t('使用支付宝人工核验收款码','Use manually verified Alipay QR')}</button>:null}
    {order.provider==='alipayManual' && (manual||!me?.service.aggregatePaymentsEnabled||awaiting) && (order.status === "pending" || awaiting) ? <>
      {awaiting ? <Notice>{t("付款参考已提交，请勿重复付款。运营者核对支付宝实际到账后，会自动开始解读或增加次数；本页会自动刷新状态。", "Your payment reference was submitted. Do not pay again. Once the operator verifies receipt, your interpretation starts or credits are added. This page updates automatically.")}</Notice> : <>
        {canPay ? <div className="payment-grid">
          <img className="payment-qr" src={me!.service.paymentQrUrl} alt={t("运营者配置的支付宝收款码", "Configured Alipay collection code")} />
          <div><p>{t("请使用支付宝扫描，支付当前订单的准确金额。手机端可保存图片，再到支付宝扫一扫中从相册选择。", "Scan with Alipay and pay the exact order amount. On mobile, save the image and select it from the album in Alipay Scan.")}</p><p>{t("请保留支付宝交易凭证。已付款后不要取消订单，也不要重复支付。", "Retain your Alipay receipt. Do not cancel the order or pay again after payment.")}</p></div>
        </div> : <Notice>{paymentUnavailableMessage(me?.service.paymentUnavailableReason, locale)} <button className="text-button" disabled={busy} onClick={() => void refresh()}>{t("刷新服务状态", "Refresh service status")}</button></Notice>}
        <p>{t("已付款？即使服务暂时维护，也可以在下面提交交易号，等待运营者核验。提交参考本身不会开通权益。", "Already paid? You can submit your transaction ID below even during maintenance. A reference alone does not activate credits.")}</p>
      </>}
      <form onSubmit={submit}>
        <label>{t("支付宝交易号或付款参考", "Alipay transaction ID or payment reference")}<input required maxLength={150} minLength={4} disabled={!canSubmitReceipt || awaiting} value={reference} onChange={e => setReference(e.target.value)} placeholder={t("输入交易号，便于核对到账", "Enter a reference for verification")} /></label>
        <button className="button primary" disabled={busy || !canSubmitReceipt || awaiting}>{awaiting ? t("已提交，等待核验", "Submitted, awaiting verification") : busy ? t("正在提交…", "Submitting…") : t("提交付款参考", "Submit payment reference")}</button>
      </form>
    </> : <p>{t("付款状态以运营者真实核验结果为准。", "Payment status reflects verification of actual funds.")}</p>}
    {order.status === "pending" ? <button className="text-button" disabled={busy} onClick={() => { if (window.confirm(t("仅在尚未付款时取消。已经付款请点取消返回并提交交易参考。确认未付款并取消订单？", "Cancel only if you have not paid. If you already paid, go back and submit the payment reference. Confirm this order is unpaid and cancel?"))) void cancel(); }}>{t("取消未付款订单", "Cancel unpaid order")}</button> : null}
    {error ? <Notice kind="error">{error}</Notice> : null}
  </section>;
}
