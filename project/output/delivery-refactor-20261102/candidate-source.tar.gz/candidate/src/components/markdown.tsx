import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
export function Markdown({ children }: { children: string }) {
  return <div className="markdown"><ReactMarkdown remarkPlugins={[remarkGfm]} skipHtml components={{
    img: () => null,
    p: ({ children }) => <p className={typeof children === "string" && children.length <= 50 && !children.includes("\n") && /^(?:[一二三四五六七八九十百]+[、．.]|[（(][一二三四五六七八九十百]+[）)])\s*\S/.test(children) ? "markdown-section-label" : undefined}>{children}</p>,
    a: ({ children, href }) => <a href={href} target="_blank" rel="noopener noreferrer">{children}</a>,
  }}>{children}</ReactMarkdown></div>;
}
