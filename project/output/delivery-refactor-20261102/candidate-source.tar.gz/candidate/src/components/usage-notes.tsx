"use client";

import { useApp } from "./app-provider";

export function UsageNotes() {
  const { t } = useApp();
  return <div className="usage-notes">
    <p className="usage-lead">{t("直接在对话框输入即可，一般无需另做设置。", "Just type your question here. Usually, no extra setup is needed.")}</p>
    <ol className="usage-rules">
      <li><h3>{t("事情与背景", "The matter and its background")}</h3><p>{t("说清你想问什么、发生了什么，以及目前的情况。", "Say what you want to know, what happened, and the current situation.")}</p></li>
      <li><h3>{t("自己与相关人物", "You and the people involved")}</h3><p>{t("说明身份或关系；性别、出生年份知道就写，例如「我：2005年女，对方：2003年男」。不知道可以不填。", "Explain who is involved and your relationship. Add gender and birth year if known, for example: “I am female, born in 2005; he was born in 2003.” Unknown details can be omitted.")}</p></li>
      <li><h3>{t("起课方法", "The chart method")}</h3><p>{t("直接描述起课要求即可，例如「用二〇〇五年一月十二日下午两点四十九」「报数一百二十八」或「随机起课」。AI先理解要求并设置参数，请在确认页核对；明确的对话要求优先于辅助控件，未指定时沿用设置或当前时间。有歧义先补充，不默默换时间。支持的浏览器可用麦克风转成文字，核对后再提交。", "Describe the chart time, number or method in your own words. AI configures the parameters first; check the review before proceeding. Explicit text requests take priority over auxiliary controls. Without a request, your settings or the current time apply. Ambiguity is clarified first. Supported browsers offer editable speech-to-text.")}</p></li>
    </ol>
  </div>;
}
