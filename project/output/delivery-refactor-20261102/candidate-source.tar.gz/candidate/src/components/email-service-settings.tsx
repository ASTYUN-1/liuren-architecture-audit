"use client";
import { useApp } from './app-provider';
import { Notice } from './ui';
import { MAIL_KINDS, type MailTemplates } from '@/server/mail-content';

export type MailAdminSettings = {
  emailProvider: 'smtp'|'tencentSes'; hasSesSecretId: boolean; hasSesSecretKey: boolean;
  sesTemplates: MailTemplates; sesAuthReady: boolean; emailTestTo: string; serviceNotificationsEnabled: boolean;
  mailDeliverySummary: Record<string,number>;
  smtpHost: string; smtpPort: number; smtpSecure: boolean; smtpUser: string; smtpFrom: string; hasSmtpPassword: boolean;
};
type Props = {
  settings: MailAdminSettings; busy: boolean;
  onField: <K extends keyof MailAdminSettings>(name: K, value: MailAdminSettings[K]) => void;
  smtpPassword: string; onSmtpPassword: (value: string) => void; clearSmtpPassword: boolean; onClearSmtpPassword: (value: boolean) => void;
  sesSecretId: string; onSesSecretId: (value: string) => void; sesSecretKey: string; onSesSecretKey: (value: string) => void;
  clearSesCredentials: boolean; onClearSesCredentials: (value: boolean) => void;
  onTest: (kind: 'email'|'emailStatus'|'smtp') => void;
};
export function EmailServiceSettings(p: Props) {
  const {t}=useApp(),s=p.settings;
  const names={verification:t('邮箱验证／更换邮箱','Email verification / change'),passwordReset:t('重置密码','Password reset'),resultReady:t('主报告完成（追问仅站内）','Main report ready (follow-ups in-app)'),serviceUpdate:t('补充资料／失败／退款状态','Service / refund update'),referralReward:t('邀请优惠到账','Referral benefit')};
  return <section className="settings-section">
    <h2>{t('邮件服务','Email service')}</h2>
    <p>{t('验证邮箱通过邮件链接完成。服务通知不包含问题、出生资料或解读正文。','Email verification uses links. Service notices contain no questions, birth details or report content.')}</p>
    <label>{t('发送渠道','Delivery provider')}<select value={s.emailProvider} onChange={e=>p.onField('emailProvider',e.target.value as MailAdminSettings['emailProvider'])}><option value="tencentSes">腾讯云 SES API · 香港</option><option value="smtp">SMTP</option></select></label>
    <label>{t('发件人邮箱','Sender email')}<input type="email" value={s.smtpFrom} onChange={e=>p.onField('smtpFrom',e.target.value)} /></label>
    {s.emailProvider==='tencentSes'?<>
      <Notice>{s.sesAuthReady?t('账户邮件模板已通过上次检查。服务商接受发送后，还需在真实邮箱查收。','Account templates passed the last check. Provider acceptance still requires an inbox receipt test.'):t('腾讯云个人账户使用 API 发信。域名、发件地址、受限密钥和模板审核均须完成；保存配置不等于已能发送。','Personal Tencent accounts use the SES API. Domain, sender, restricted key and approved templates are required. Saving settings does not confirm delivery.')}</Notice>
      <div className="fields-grid"><label>SecretId<input type="password" autoComplete="off" disabled={p.clearSesCredentials} value={p.sesSecretId} onChange={e=>p.onSesSecretId(e.target.value)} placeholder={s.hasSesSecretId?t('已保存，留空保持','Saved; leave blank to keep'):t('尚未配置','Not configured')} /></label><label>SecretKey<input type="password" autoComplete="off" disabled={p.clearSesCredentials} value={p.sesSecretKey} onChange={e=>p.onSesSecretKey(e.target.value)} placeholder={s.hasSesSecretKey?t('已保存，留空保持','Saved; leave blank to keep'):t('尚未配置','Not configured')} /></label></div>
      <label className="checkbox-label"><input type="checkbox" checked={p.clearSesCredentials} onChange={e=>p.onClearSesCredentials(e.target.checked)} />{t('保存时清除 SES 凭据','Clear SES credentials on save')}</label>
      <p className="muted">{t('只授予 ses:SendEmail 和 ses:GetEmailTemplate。模板链接固定为网站域名。','Grant only ses:SendEmail and ses:GetEmailTemplate. Template links use the fixed website domain.')}</p>
      <div className="fields-grid">{MAIL_KINDS.map(kind=><label key={kind}>{names[kind]} · ID<input type="number" min={0} value={s.sesTemplates[kind]} onChange={e=>p.onField('sesTemplates',{...s.sesTemplates,[kind]:Number(e.target.value)})} /></label>)}</div>
      <p className="muted">{t('通知模板 ID 为 0 表示不发此类邮件。腾讯云未批准邀请优惠邮件，当前仅在账户页展示优惠，请保留该项为 0。','A notification template ID of 0 disables that email. Tencent has not approved referral emails; benefits remain on the account page. Keep that ID at 0.')}</p>
      <button type="button" className="button secondary" disabled={p.busy||!s.hasSesSecretKey} onClick={()=>p.onTest('emailStatus')}>{t('检查已保存模板的审核状态','Check saved template approval')}</button>
    </>:<>
      <div className="fields-grid"><label>SMTP Host<input value={s.smtpHost} onChange={e=>p.onField('smtpHost',e.target.value)} /></label><label>{t('端口','Port')}<input type="number" min={1} max={65535} value={s.smtpPort} onChange={e=>p.onField('smtpPort',Number(e.target.value))} /></label></div>
      <label>{t('SMTP 用户名','SMTP username')}<input autoComplete="off" value={s.smtpUser} onChange={e=>p.onField('smtpUser',e.target.value)} /></label>
      <label>{t('SMTP 授权码','SMTP app password')}<input type="password" autoComplete="off" disabled={p.clearSmtpPassword} value={p.smtpPassword} onChange={e=>p.onSmtpPassword(e.target.value)} placeholder={s.hasSmtpPassword?t('已保存，留空保持','Saved; leave blank to keep'):t('尚未配置','Not configured')} /></label>
      <label className="checkbox-label"><input type="checkbox" checked={p.clearSmtpPassword} onChange={e=>p.onClearSmtpPassword(e.target.checked)} />{t('保存时清除 SMTP 授权码','Clear SMTP credentials on save')}</label>
      <label className="checkbox-label"><input type="checkbox" checked={s.smtpSecure} onChange={e=>p.onField('smtpSecure',e.target.checked)} />{t('直接 TLS（465）；587 使用 STARTTLS','Direct TLS (465); use STARTTLS on 587')}</label>
    </>}
    <label>{t('测试收件邮箱','Test recipient')}<input type="email" value={s.emailTestTo} onChange={e=>p.onField('emailTestTo',e.target.value)} placeholder={t('填写你能够查收的邮箱','An inbox you control')} /></label>
    <button type="button" className="button secondary" disabled={p.busy||!s.smtpFrom||!s.emailTestTo} onClick={()=>p.onTest('email')}>{t('发送真实测试邮件','Send real test email')}</button>
    <label className="checkbox-label"><input type="checkbox" checked={s.serviceNotificationsEnabled} onChange={e=>p.onField('serviceNotificationsEnabled',e.target.checked)} />{t('启用服务状态、结果就绪及邀请权益通知','Enable service, result and earned referral notifications')}</label>
    <p className="muted">{t('每天最多 100 次发送尝试。失败不影响报告或退款；超时导致结果不确定时停止自动重发。发送记录中的“服务商已接受”不代表收件箱已收到。','At most 100 send attempts daily. Failures do not affect reports or refunds. Uncertain sends are not retried automatically. Provider acceptance does not confirm inbox receipt.')}</p>
    <p>{t('服务通知记录：','Service notification log: ')}{t('待发送','Pending')} {s.mailDeliverySummary?.pending||0} · {t('服务商已接受','Provider accepted')} {s.mailDeliverySummary?.accepted||0} · {t('失败／待检查','Failed / inspect')} {s.mailDeliverySummary?.failed||0} · {t('不再适用','Suppressed')} {s.mailDeliverySummary?.suppressed||0}</p>
  </section>;
}
