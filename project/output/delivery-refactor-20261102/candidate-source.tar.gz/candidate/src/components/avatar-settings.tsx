"use client";
import { useRef, useState } from "react";
import { useApp } from "./app-provider";
import { UserAvatar } from "./user-avatar";
import { MAX_AVATAR_BYTES } from "@/lib/avatar";
import { Notice } from "./ui";
export function AvatarSettings() {
  const { me, t, refresh } = useApp(), input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false), [message, setMessage] = useState(''), [error, setError] = useState('');
  if (!me) return null;
  async function save(file?: File) {
    setMessage(''); setError('');
    if (file && file.size > MAX_AVATAR_BYTES) { setError(t('图片不能超过 2MB。', 'Image must be 2MB or smaller.')); return; }
    if (file && !['image/jpeg','image/png','image/webp'].includes(file.type)) { setError(t('请选择 JPG、PNG 或静态 WebP 图片。', 'Choose a JPG, PNG or static WebP image.')); return; }
    setBusy(true);
    try {
      const response = await fetch('/api/account/avatar', { method: file ? 'PUT' : 'DELETE', credentials: 'same-origin', headers: file ? { 'Content-Type': file.type } : {}, body: file });
      const result = await response.json().catch(() => null);
      if (!response.ok) throw Error(result?.error?.message || t('头像未保存，请稍后重试。', 'Avatar was not saved. Please try again.'));
      await refresh(); setMessage(file ? t('头像已更新。', 'Avatar updated.') : t('已恢复昵称首字头像。', 'Initial avatar restored.'));
    } catch (e) { setError(e instanceof Error ? e.message : t('上传失败，请重试。', 'Upload failed. Please retry.')); }
    finally { setBusy(false); if (input.current) input.current.value = ''; }
  }
  return <section className="settings-section avatar-settings"><h2>{t('我的头像', 'Your avatar')}</h2><div className="avatar-settings-row"><UserAvatar name={me.user.name} image={me.user.image} large /><div><strong>{me.user.name}</strong><p>{t('选择喜欢的图片，展示在你的账户入口。', 'Choose a picture for your account.')}</p></div></div><p className="muted">{t('支持 JPG、PNG、静态 WebP，最大 2MB。图片会自动居中裁剪为正方形并压缩；建议选择主体在中间的照片。', 'JPG, PNG or static WebP, up to 2MB. Images are automatically cropped to a square and compressed. Keep the subject in the centre.')}</p><div className="avatar-settings-actions"><button type="button" className="button secondary" disabled={busy} onClick={() => input.current?.click()}>{busy ? t('正在保存…', 'Saving…') : me.user.image ? t('更换头像', 'Change avatar') : t('上传头像', 'Upload avatar')}</button>{me.user.image ? <button type="button" className="text-button" disabled={busy} onClick={() => void save()}>{t('恢复默认头像', 'Restore default avatar')}</button> : null}</div><input ref={input} type="file" accept="image/jpeg,image/png,image/webp" aria-label={t('选择头像图片', 'Choose avatar image')} hidden disabled={busy} onChange={e => { const file = e.currentTarget.files?.[0]; e.currentTarget.value = ''; if (file) void save(file); }} /><div aria-live="polite">{message ? <Notice kind="success">{message}</Notice> : null}{error ? <Notice kind="error">{error}</Notice> : null}</div></section>;
}
