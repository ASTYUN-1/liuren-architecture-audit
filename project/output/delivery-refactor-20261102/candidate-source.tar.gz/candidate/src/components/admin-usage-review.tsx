"use client";
import {useState} from 'react';
import {post} from '@/lib/api';
import {useApp} from './app-provider';
import {Notice} from './ui';
import {Modal} from './modal';

export function AdminUsageReview({taskId,onReviewed}:{taskId:string;onReviewed:()=>void}){
 const {t}=useApp();
 const [open,setOpen]=useState(false),[reason,setReason]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function resolve(){
  setBusy(true);setError('');
  try{await post(`/api/admin/tasks/${encodeURIComponent(taskId)}/usage-review`,{reason:reason.trim()});setOpen(false);onReviewed();}
  catch(e){setError(e instanceof Error?e.message:t('操作未完成','Action failed'));}
  finally{setBusy(false);}
 }
 return <div><small className="admin-warning">{t('API用量待核对','API usage needs review')}</small><button type="button" className="text-button" onClick={()=>setOpen(true)} aria-haspopup="dialog">{t('记录核对结果','Record review')}</button>{open?<Modal title={t('核对API用量','Review API usage')} onClose={()=>{if(!busy)setOpen(false);}}><form style={{display:'grid',gap:16}} onSubmit={event=>{event.preventDefault();if(!busy&&reason.trim().length>=5)void resolve();}}><p className="muted">{t('对照供应商记录后填写说明。此操作只完成待办，不追扣积分或修改已结算金额。','Check the supplier records and add a note. This closes the review without changing settled charges.')}</p><label>{t('核对说明','Review note')}<textarea value={reason} onChange={e=>setReason(e.target.value)} required minLength={5} maxLength={1000} rows={4}/></label>{error?<Notice kind="error">{error}</Notice>:null}<button type="submit" className="button secondary" disabled={busy||reason.trim().length<5}>{busy?t('保存中…','Saving…'):t('保存核对结果','Save review')}</button></form></Modal>:null}</div>;
}
