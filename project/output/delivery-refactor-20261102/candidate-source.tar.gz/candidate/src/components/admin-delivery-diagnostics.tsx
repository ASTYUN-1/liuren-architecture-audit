"use client";
import {useApp} from './app-provider';
import type {safeDeliveryDiagnostics} from '@/server/delivery-diagnostics';
export function AdminDeliveryDiagnostics({value}:{value:ReturnType<typeof safeDeliveryDiagnostics>}){
 const {t}=useApp();if(!value)return null;
 return <details><summary>{t('交付检查记录','Delivery diagnostics')}</summary><small>{t('提交次数','Submissions')}: {value.submissions??'—'} · {t('连续无进展','No-progress rounds')}: {value.noProgressRounds??'—'}</small><small>{t('首份草稿','First draft')}: {value.firstDraftMs===null?'—':(value.firstDraftMs/1000).toFixed(1)+'s'} · {t('草稿至交付','Draft to delivery')}: {value.deliveryMs===null?'—':(value.deliveryMs/1000).toFixed(1)+'s'}</small>{value.issues.map(i=><small key={i.id}>{i.state==='active'?t('未解决','Active'):t('已解决','Resolved')} · {i.severity==='blocker'?t('阻塞','Blocker'):t('告警','Warning')} · {i.rule} · {i.questionId??i.field} · {i.occurrences??1}</small>)}</details>;
}
