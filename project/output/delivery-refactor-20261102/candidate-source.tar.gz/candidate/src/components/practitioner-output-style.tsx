"use client";
import {useState} from 'react';
import type {CaseDetail} from '@/server/contracts';
import {patch} from '@/lib/api';
import {useApp} from './app-provider';
import {Notice} from './ui';
export function PractitionerOutputStyle({item,onUpdated,pending}:{item:CaseDetail;onUpdated:()=>Promise<void>;pending:boolean}){
 const {me,t}=useApp(),[busy,setBusy]=useState(false),[error,setError]=useState('');
 if(!me?.practitioner?.professionalOutput)return null;
 return <section className="practitioner-output-style"><label className="reading-style">{t('后续解读表达','Style for future readings')}<select value={item.outputStyle??'practitioner'} disabled={busy||pending} onChange={async e=>{const outputStyle=e.target.value;setBusy(true);setError('');try{await patch(`/api/cases/${item.id}`,{outputStyle});await onUpdated();}catch(e){setError(e instanceof Error?e.message:'Error');}finally{setBusy(false);}}}><option value="practitioner">{t('专业表达','Professional')}</option><option value="public">{t('通俗表达','Standard')}</option></select></label><p className="muted">{t('仅影响后续开始处理的任务，已有报告保持原样。','Applies to future tasks. Existing reports stay as delivered.')}</p>{error?<Notice kind="error">{error}</Notice>:null}</section>;
}
