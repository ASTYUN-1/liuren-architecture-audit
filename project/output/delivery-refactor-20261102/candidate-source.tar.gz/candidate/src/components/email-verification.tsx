"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Mail, ShieldCheck } from "lucide-react";
import { useApp } from "./app-provider";
import { authClient } from "@/lib/auth-client";
import { post } from "@/lib/api";
import type { CaseDetail, CaseInput } from "@/server/contracts";
import { Notice, Loading } from "./ui";

export function EmailVerification({ email: signupEmail, justSent = false }: { email?: string; justSent?: boolean }) {
  const { me, loading, refresh, t } = useApp(); const router = useRouter();
  const [busy, setBusy] = useState(false), [error, setError] = useState(""), [message, setMessage] = useState(""), [seconds, setSeconds] = useState(justSent ? 60 : 0);
  useEffect(() => { if (seconds <= 0) return; const timer = window.setTimeout(() => setSeconds(value => Math.max(0, value - 1)), 1000); return () => window.clearTimeout(timer); }, [seconds]);
  useEffect(() => { if (new URLSearchParams(window.location.search).has("error")) setError(t("验证链接失效或已过期，请重新发送验证邮件。", "The verification link is invalid or expired. Request a new email.")); }, []);
  const email = me?.user.email || signupEmail, verified = !!me?.user.emailVerified;
  async function perform(action: () => Promise<void>) { setBusy(true); setError(""); setMessage(""); try { await action(); } catch (e) { setError(e instanceof Error ? e.message : "Error"); } finally { setBusy(false); } }
  async function continueUsing() {
    // Revalidate the session; a button or query string must never mark it verified.
    const session = await authClient.getSession(); if (!session.data?.user.emailVerified) throw new Error(t("邮箱验证尚未完成，请先打开邮件中的链接。", "Please open the verification link in your email first."));
    await refresh(); const raw = sessionStorage.getItem("wenheng-pending-input-v1");
    router.push("/");
  }
  if (loading && !signupEmail) return <Loading/>;
  return <section className="verification-page"><ol className="signup-steps" aria-label={t("注册步骤", "Signup steps")}><li className="done">{t("1 创建账户", "1 Create account")}</li><li className={verified ? "done" : "current"} aria-current={!verified ? "step" : undefined}>{t("2 验证邮箱", "2 Verify email")}</li><li className={verified ? "current" : ""}>{t("3 开始使用", "3 Get started")}</li></ol><div className="verification-card"><div className="verification-icon">{verified ? <ShieldCheck size={34}/> : <Mail size={34}/>}</div><h1>{verified ? t("邮箱已验证，可以开始了", "Email verified. You’re ready!") : t("验证邮箱，启用邮箱找回", "Verify your email for account recovery")}</h1>{verified ? <p>{t("注册步骤已完成。刚才的问题也会继续保留。", "Signup is complete. Your saved question is still here.")}</p> : <><p>{justSent ? t("验证链接已发送至", "A verification link has been sent to") : t("请查收注册验证邮件", "Check your signup verification email")}</p>{email ? <strong className="verification-address">{email}</strong> : <p><Link href="/login">{t("请登录后继续验证", "Sign in to continue verification")}</Link></p>}<ol className="verification-instructions"><li>{t("打开邮箱，找到「问衡 · 验证邮箱」。", "Open your inbox and find “Wenheng · Verify your email”.")}</li><li>{t("点击邮件中的链接，1 小时内有效。", "Open the link within one hour.")}</li><li>{t("返回这里，即可继续提问；不用去设置里寻找。", "Return here to continue. No need to search in Settings.")}</li></ol><p className="muted">{t("没找到？看看垃圾邮件；地址写错了，可退出后用正确邮箱注册。", "Not there? Check spam. If the address is wrong, change it in Account settings.")}</p></>}{error ? <Notice kind="error">{error}</Notice> : null}{message ? <Notice>{message}</Notice> : null}<div className="verification-actions">{verified ? <button className="button primary full" disabled={busy} onClick={() => void perform(continueUsing)}>{t("开始使用问衡", "Start using Wenheng")} →</button> : <><button className="button primary full" disabled={busy || !email} onClick={() => void perform(async () => { const session = await authClient.getSession(); await refresh(); if (!session.data?.user.emailVerified) setMessage(t("还没有查到验证成功，请先点击邮件链接，再回来检查。", "Verification is not complete yet. Open the email link, then check again.")); })}>{busy ? t("正在检查…", "Checking…") : t("我已点击链接，检查验证状态", "I opened the link · Check status")}</button><button className="button secondary full" disabled={busy || !email || seconds > 0 || me?.service.smtpConfigured === false} onClick={() => void perform(async () => { const result = await authClient.sendVerificationEmail({ email: email!, callbackURL: "/verify-email" }); if (result.error) throw new Error(result.error.message); setSeconds(60); setMessage(t("验证邮件已重新发送，请查收。", "Verification email sent. Please check your inbox.")); })}>{seconds > 0 ? `${t("重新发送", "Resend")} · ${seconds}s` : t("重新发送验证邮件", "Resend verification email")}</button>{me?.service.smtpConfigured === false ? <Notice>{t("邮件服务暂不可用，请稍后重试。", "Email delivery is currently unavailable. Please try later.")}</Notice> : null}</>}</div><Link className="text-button" href="/">{t("返回首页 · 问题不会丢失", "Back home · Your saved question stays")}</Link>{me && !verified ? <button type="button" className="text-button" disabled={busy} onClick={() => void perform(async () => { router.push("/account/settings"); })}>{t("邮箱填错了？到账户设置修改", "Wrong email? Change it in Settings")}</button> : null}</div></section>;
}
