"use client";

import { useApp } from "./app-provider";
import "./beta-usage-notes.css";

export function BetaUsageNotes() {
  const { t } = useApp();
  return <div className="usage-notes beta-usage-notes">
    <p className="usage-lead">{t("像平时聊天一样，把想问的事说清楚就好。", "Ask naturally, as you would in a conversation.")}</p>
    <ol className="usage-rules">
      <li><h3>{t("背景", "Background")}</h3><p>{t("简单说说", "Briefly explain ")}<strong>{t("发生了什么、现在是什么情况", "what happened and the current situation")}</strong>{t("。", ".")}</p></li>
      <li><h3>{t("起卦时间", "Chart time")}</h3><p>{t("真实求测默认用", "A new question defaults to ")}<strong>{t("当下时间", "the current time")}</strong>{t("；旧案例重测用", "; a historical case uses ")}<strong>{t("原起卦时间", "its original chart time")}</strong>{t("。", ".")}</p></li>
      <li><h3>{t("人物信息", "People")}</h3><p>{t("写相关人物的", "Add each relevant person's ")}<strong>{t("出生年、性别、在这件事中的身份", "birth year, gender and role in the matter")}</strong>{t("，不知道的可以不写。", "; omit details you do not know.")}</p></li>
      <li><h3>{t("具体问题", "Your question")}</h3><p>{t("说清", "State ")}<strong>{t("最想知道什么", "what you most want to know")}</strong>{t("，例如", ", such as ")}<strong>{t("教室有没有人上课、今年考研能否考过、会不会分手", "whether a class is in session, whether you will pass this year's entrance exam, or whether you will separate")}</strong>{t("。", ".")}</p></li>
    </ol>
    <aside className="beta-chart-note">
      <h3>{t("时间怎么设置？", "How do I set the time?")}</h3>
      <p>{t("没有指定时间，也没有手动改过设置时，默认使用", "If you do not specify a time or change the settings, the default is ")}<strong>{t("当下时间", "the current time")}</strong>{t("。旧案例或旧卦重测，请直接告诉 AI", ". For a historical case or chart, tell AI ")}<strong>{t("原起卦时间", "the original chart time")}</strong>{t("；也可以在「起课与人物设置」里自己设置。", ", or set it yourself under Chart & people settings.")}</p>
      <p><strong>{t("开始前核对背景、人物和起卦时间是否正确；出现确认页面时，核对无误再继续。", "Check the background, people and chart time before starting. If a confirmation appears, review it before continuing.")}</strong></p>
    </aside>
    <section className="beta-question-example" aria-label={t("提问示例", "Example questions")}>
      <div className="beta-example-heading"><h3>{t("可以这样问", "Ways to ask")}</h3></div>
      <div className="beta-example-item"><h4>{t("A · 旧案例重测", "A · Revisit a historical case")}</h4><blockquote>
        {t("起卦时间：", "Chart time: ")}<strong>{t("2026年10月23日 8:17", "October 23, 2026 at 08:17")}</strong><br/>
        {t("问题：", "Question: ")}<strong>{t("220教室有没有人上课？", "Is a class in session in room 220?")}</strong><br/><br/>
        {t("背景：", "Background: ")}<br/>
        {t("问卦人当时把", "The person asking had left their ")}<strong>{t("耳机忘在这个教室了", "earphones in this classroom")}</strong>{t("，想要去取。但是", " and wanted to collect them, but was ")}<strong>{t("担心有人在上课不太方便", "worried about interrupting a class")}</strong>{t("，所以起课，想看看这个教室到底有没有人在上课。", ". They wanted to find out whether a class was in session.")}
      </blockquote></div>
      <div className="beta-example-item"><h4>{t("B · 当下求测", "B · Ask about the present")}</h4><blockquote>
        {t("使用", "Use ")}<strong>{t("当下时间起卦", "the current time")}</strong>{t("，我想看一下", ". I'd like to know ")}<strong>{t("今年考研能考过吗？", "whether I will pass this year's postgraduate entrance exam.")}</strong>{t("我是", " I'm ")}<strong>{t("2004年生，女", "female, born in 2004")}</strong>{t("。", ".")}
      </blockquote></div>
      <div className="beta-example-item"><h4>{t("C · 不指定时间", "C · Leave the time unspecified")}</h4><blockquote>
        {t("我跟我", "My ")}<strong>{t("男朋友", "boyfriend")}</strong>{t("感情出了点问题，我很担心", " and I are having relationship problems. I'm worried about ")}<strong>{t("会不会分手", "whether we will separate")}</strong>{t("，帮我看一下吧。我是", ". Could you look into it? I'm ")}<strong>{t("2000年生，女", "female, born in 2000")}</strong>{t("，他是", "; he's ")}<strong>{t("1998年生，男", "male, born in 1998")}</strong>{t("。", ".")}
      </blockquote></div>
    </section>
  </div>;
}
