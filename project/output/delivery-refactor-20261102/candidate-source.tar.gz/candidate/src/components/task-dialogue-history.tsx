import type { TaskView } from "@/server/contracts";
import { useApp } from "./app-provider";
import { ConversationMessage } from "./conversation-message";
import { dialogueTime } from "@/lib/case-input-display";

export function TaskDialogueHistory({task}: {task: Pick<TaskView, "question" | "clarificationMessages"> & {createdAt?: string; kind?: string}}) {
  const {t, locale} = useApp();
  const messages = task.clarificationMessages?.length ? task.clarificationMessages
    : task.question?.trim() ? [{role: "user" as const, content: task.question, at: task.kind === "followup" ? task.createdAt : undefined}] : [];
  return <>{messages.map((message, index) => <ConversationMessage key={index} role={message.role}
    label={message.role === "user" ? t("你 · 提问或补充", "You · Question or clarification") : t("AI · 请求补充", "AI · Clarification request")}
    time={dialogueTime(message.at, locale)}
  >{message.content}</ConversationMessage>)}</>;
}
