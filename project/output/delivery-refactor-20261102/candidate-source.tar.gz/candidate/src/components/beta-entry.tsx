"use client";
import {useEffect,useState} from 'react';
import Link from 'next/link';
import {useApp} from './app-provider';
import {api} from '@/lib/api';
export function BetaEntry(){const{me}=useApp(),[owner,setOwner]=useState('');useEffect(()=>{let live=true;setOwner('');if(me)api<{allowed:boolean}>('/api/beta/access').then(v=>{if(live&&v.allowed)setOwner(me.user.id);}).catch(()=>{});return()=>{live=false;};},[me?.user.id]);return owner&&owner===me?.user.id?<Link className="text-button" href="/beta">新版内测</Link>:null;}
