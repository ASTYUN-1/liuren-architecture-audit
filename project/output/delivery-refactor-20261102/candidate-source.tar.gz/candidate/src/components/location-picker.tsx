"use client";
import {useState} from 'react';
import locations from '@/lib/china-locations.json';
import {useApp} from './app-provider';
const provinces=[...new Set(locations.map(v=>v.province))];
export function LocationPicker({value,onChange}:{value:string;onChange:(v:string)=>void}){
 const {t}=useApp(),[province,setProvince]=useState(''),[search,setSearch]=useState(''),[city,setCity]=useState('');
 const matches=locations.filter(v=>(!province||v.province===province)&&(!search||v.name.includes(search.trim())||v.province.includes(search.trim())));
 const selected=locations.find(v=>v.province+'/'+v.name===city);
 return <div className="location-picker"><div className="fields-grid"><label>{t('省份 / 地区','Province / region')}<select aria-label={t('省份 / 地区','Province / region')} value={province} onChange={e=>{setProvince(e.target.value);setCity('');}}><option value="">{t('全部地区','All regions')}</option>{provinces.map(p=><option key={p}>{p}</option>)}</select></label><label>{t('搜索城市','Search city')}<input value={search} onChange={e=>setSearch(e.target.value)} placeholder={t('输入城市名称','City name')}/></label></div><label>{t('选择所在地','Choose location')}<select aria-label={t('选择所在地','Choose location')} value={city} onChange={e=>{setCity(e.target.value);const c=locations.find(v=>v.province+'/'+v.name===e.target.value);if(c)onChange(String(c.longitude));}}><option value="">{t('选择城市，自动填写经度','Choose a city to fill longitude')}</option>{matches.map(c=><option key={c.province+'/'+c.name} value={c.province+'/'+c.name}>{c.province} · {c.name}</option>)}</select></label>{selected?<p className="muted">{selected.name} · {t('东经','E')} {selected.longitude.toFixed(4)}° · {t('北纬','N')} {selected.latitude.toFixed(4)}°</p>:null}<label>{t('经度，可手动微调','Longitude, editable')}<input required type="number" min={-180} max={180} step="any" value={value} onChange={e=>{setCity('');onChange(e.target.value);}}/></label><small>{t('内置624处地区坐标；城市中心仅作参考，可填更准确的经度。','624 locations included. City centers are approximate; enter a more precise longitude if available.')}</small></div>;
}
