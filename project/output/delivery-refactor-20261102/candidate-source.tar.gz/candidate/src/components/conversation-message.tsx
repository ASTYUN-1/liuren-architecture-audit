import type { ReactNode } from "react";
import { Markdown } from "./markdown";
import "./conversation-message.css";

export function ConversationMessage({ role, label, time, children, feedback, id }: {
  role: "user" | "assistant";
  label: string;
  time?: string;
  children: ReactNode;
  feedback?: boolean;
  id?: string;
}) {
  return <section id={id} className={`conversation-message is-${role}${feedback ? " is-feedback" : ""}`} aria-label={label}>
    <header><strong>{label}</strong>{feedback && <span className="conversation-feedback-tag">结果反馈</span>}{time && <span className="conversation-time">{time}</span>}</header>
    <div className="conversation-body">{typeof children === "string"
      ? role === "assistant" ? <Markdown>{children}</Markdown> : <div className="preserve-lines">{children}</div>
      : children}</div>
  </section>;
}
