"use client";

import Link from "next/link";
import { useApp } from "./app-provider";

export function ServiceScopeNotice({ human = false }: { human?: boolean }) {
  const { t } = useApp();
  return <aside className="service-scope-notice" aria-label={t("解读与服务说明", "Interpretation and service scope")}>
    <strong>{t("解读与服务说明", "Interpretation and service scope")}</strong>
    <p>{t("本站提供传统文化角度的 AI 分析与真人复核，科学性有待验证，结果仅供参考，不保证真实或准确。请结合现实情况理性判断，不据此作出人生重大抉择，不用于赌博、投资决策，亦不替代医疗、法律等专业意见。", "This site offers AI analysis and human review from a traditional cultural perspective. Its scientific validity is unverified; results are for reference and are not guaranteed to be true or accurate. Assess them against real circumstances. Do not rely on them for major life decisions, gambling or investment decisions, or as a substitute for medical, legal or other professional advice.")}</p>
    {human ? <p>{t("真人辅助仅针对一个已有 AI 报告的修正、纠错和解释，不包含重新起课或新事项的全面分析。", "Human assistance corrects or explains one existing AI report. It excludes a fresh chart or a full reading of a new matter.")}</p> : null}
    <Link href="/terms">{t("查看服务范围与售后", "Service scope and refunds")} →</Link>
  </aside>;
}
