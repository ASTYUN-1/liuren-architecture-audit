"use client";
import {useEffect,useState} from 'react';
import Link from 'next/link';
import {BadgeCheck,ShieldCheck} from 'lucide-react';
import {useApp} from './app-provider';
import {post} from '@/lib/api';
import type {PractitionerProfile} from '@/lib/practitioner';
import {Notice} from './ui';

export function PractitionerProfileCard(){
 const {me,t,refresh}=useApp(),[profile,setProfile]=useState<PractitionerProfile|undefined>(me?.practitioner),[note,setNote]=useState(''),[open,setOpen]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>{setProfile(me?.practitioner);setError('');setNote('');setOpen(false);},[me?.user.id,me?.practitioner]);
 if(!me||profile?.professionalOutput)return null;
 const status=profile?.certification?.status;
 const statusLabel=status==='pending'?t('申请审核中','Application pending'):status==='rejected'?t('申请未通过','Application not approved'):status==='revoked'?t('认证已撤销','Certification revoked'):'';
 return <section className="practitioner-application" aria-label={t('卦师认证申请','Practitioner application')}><details><summary>{t('卦师认证','Practitioner certification')}{statusLabel?' · '+statusLabel:''}</summary><p className="muted">{t('备注研习经历与常用方法，经人工审核后开启专业解读。','Apply with your study experience and methods to enable technical readings.')}</p><div className="button-row">{status==='pending'?<span role="status" className="certification-status">{statusLabel}</span>:<button type="button" className="button secondary" onClick={()=>setOpen(v=>!v)} disabled={!me.user.emailVerified}>{open?t('收起申请','Close application'):t(status?'重新申请认证':'申请卦师认证',status?'Reapply':'Apply for certification')}</button>}{!me.user.emailVerified?<Link href="/verify-email">{t('先验证邮箱','Verify email first')}</Link>:null}{status&&status!=='pending'?<span className="muted">{statusLabel}</span>:null}</div>{profile?.certification?.reviewNote?<p className="muted">{t('审核备注：','Review note: ')}{profile.certification.reviewNote}</p>:null}{open?<form className="certification-form" onSubmit={async e=>{e.preventDefault();if(busy)return;setBusy(true);setError('');try{setProfile(await post<PractitionerProfile>('/api/practitioner/certification',{note}));setOpen(false);setNote('');await refresh();}catch(e){setError(e instanceof Error?e.message:'Error');}finally{setBusy(false);}}}><label htmlFor="certification-note">{t('认证备注','Application note')}</label><textarea id="certification-note" required minLength={10} maxLength={1200} value={note} disabled={busy} onChange={e=>setNote(e.target.value)} placeholder={t('简述你的六壬研习经历、常用方法与使用需求（10–1200字）。无需提交身份证或密码。','Describe your study, methods and intended use (10–1200 characters). Do not send identity documents or passwords.')}/><small>{note.length} / 1200 · {t('由运营者人工审核，申请不会自动授予权限。','Manually reviewed. Applying does not grant access.')}</small><button className="button primary" disabled={busy||note.trim().length<10}>{busy?t('提交中…','Submitting…'):t('提交认证申请','Submit application')}</button></form>:null}{error?<Notice kind="error">{error}</Notice>:null}</details></section>;
}

export function PractitionerBadge(){
 const {me,t}=useApp();if(!me?.practitioner?.professionalOutput)return null;
 const official=me.practitioner.tier==='official';
 return <span className={`practitioner-badge ${official?'official':''}`} title={official?t('官方合作卦师','Official partner'):t('卦师身份已审核','Verified practitioner')}>{official?<ShieldCheck size={18}/>:<BadgeCheck size={18}/>} {official?t('官方认证卦师','Official practitioner'):t('认证卦师','Verified practitioner')}</span>;
}
