"use client";
import Link from "next/link";
import type { CaseSummary } from "@/server/contracts";
import { useApp } from "./app-provider";
import { date } from "@/lib/api";
import { Status } from "./ui";
export function CaseList({ cases, selected, compact }: { cases: CaseSummary[]; selected?: string; compact?: boolean }) { const { t, locale } = useApp(); return <div className={compact ? "case-list compact" : "case-list"}>{cases.map(item => <Link href={`/cases/${item.id}`} className={`case-row ${selected === item.id ? "selected" : ""}`} key={item.id}><div><h3>{item.favorite ? <span aria-label={t("已收藏", "Favorite")}>☆ </span> : null}{item.title}</h3><small>{date(item.updatedAt, locale)}{item.archived ? ` · ${t("已归档", "Archived")}` : ""}</small></div>{!compact ? <div className="case-row-meta"><Status status={item.status} /><span>{t("剩余", "Remaining")} {item.remainingTurns} {t("次追问", "follow-ups")}</span></div> : null}</Link>)}</div>; }
