"use client";
import Link from 'next/link';
import {useRef,useState} from 'react';
import {useApp} from './app-provider';
import {post,key} from '@/lib/api';
import {interpretationUnavailableMessage} from '@/lib/service-availability';
import {Notice} from './ui';
import type {CaseDetail} from '@/server/contracts';

export function PointsCasePanel({item,onUpdated,onEdit}:{item:CaseDetail;onUpdated:()=>Promise<void>;onEdit?:()=>void}) {
  const {me,t,locale,refresh}=useApp(),[busy,setBusy]=useState(false),[error,setError]=useState(''),attempt=useRef('');
  const active=item.tasks.find(v=>['running','queued'].includes(v.status)),unpaid=item.orders.some(v=>!['cancelled','refunded'].includes(v.status));
  const canStart=!item.report&&!active&&!unpaid&&item.status!=='needsClarification';
  const unavailable=!me?t('请先登录。','Sign in first.'):
    !me.service.aiEnabled?interpretationUnavailableMessage(me.service.aiUnavailableReason,locale):
    !me.points?.aiEnabled?t('积分解读已暂停，现有积分保留。请稍后刷新，或联系运营者核对。','Credit interpretations are paused. Your credits are preserved. Refresh later or contact support.'):null;
  async function start() {
    if(!window.confirm(t('主报告30积分起，本次预存100积分；交付后按实际用量结算，多退少补，超出余额的部分记为欠费，补足后才可继续使用。确认开始？','Reports from 30 credits. Reserve 100 credits; settle actual usage from your available balance on delivery. Any shortfall becomes a negative balance; top up before starting another task. Continue?')))return;
    setBusy(true);setError('');
    try {await post('/api/points',{action:'ai',caseId:item.id,kind:'initial',idempotencyKey:attempt.current||=(key())});attempt.current='';await Promise.all([onUpdated(),refresh()]);}
    catch(e){setError(e instanceof Error?e.message:'Error');}finally{setBusy(false);}
  }
  return <section className="points-case-panel"><div><strong>{t('积分解读','Credit-based interpretation')}</strong><p>{canStart?t('主报告30积分起，按实际用量结算；未交付不扣费。','Reports from 30 credits, settled by actual usage. Undelivered tasks are free.'):item.report?t('追问5积分起，不预存，交付后按实际用量结算。','Follow-ups from 5 credits, with no reservation; settled on delivery.'):t('任务完成后可在账户查看费用明细。','See billing details in your account after completion.')}</p></div><div className="button-row">
    {canStart&&onEdit?<button className="button secondary" disabled={busy} onClick={onEdit}>{t('核对或修改起课要求','Review or edit chart request')}</button>:null}
    {canStart?<button className="button primary" disabled={busy||!!unavailable} onClick={start}>{t('使用积分开始解读','Start with credits')}</button>:null}
    <Link className="button secondary small" href="/wallet">{t('积分与充值','Credits & top-up')}</Link>
    {item.report?<Link className="text-button" href="/assistance">{t('请真人协助','Request human assistance')}</Link>:null}
    {active?.billingSource==='points'?<button className="text-button" disabled={busy} onClick={async()=>{
      if(!window.confirm(t('取消未交付任务并释放积分？','Cancel this undelivered credit task and release credits?')))return;
      setBusy(true);setError('');try{await post('/api/points',{action:'cancelTask',taskId:active.id});await Promise.all([onUpdated(),refresh()]);}catch(e){setError(e instanceof Error?e.message:'Error');}finally{setBusy(false);}
    }}>{t('取消积分任务','Cancel credit task')}</button>:null}
  </div>{canStart&&unavailable?<Notice>{unavailable}  <button className="text-button" disabled={busy} onClick={async()=>{setBusy(true);try{await refresh();}finally{setBusy(false);}}}>{t('刷新服务状态','Refresh service status')}</button></Notice>:null}{error?<Notice kind="error">{error}</Notice>:null}</section>;
}
