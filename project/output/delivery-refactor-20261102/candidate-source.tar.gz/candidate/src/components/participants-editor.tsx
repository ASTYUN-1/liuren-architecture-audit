"use client";
import type { Participant } from "@/server/contracts";
import { useApp } from "./app-provider";
export function ParticipantsEditor({ value, onChange }: { value: Participant[]; onChange: (value: Participant[]) => void }) {
  const { t } = useApp();
  function update(index: number, patch: Partial<Participant>) { onChange(value.map((person, i) => i === index ? { ...person, ...patch } : person)); }
  return <>{value.map((person, i) => <fieldset className="participant-fields" key={i}>
    <legend>{t("人物", "Person")} {i + 1}</legend>
    <div className="fields-grid">
      <label>{t("身份 / 关系", "Role / relationship")}<input maxLength={100} value={person.role} onChange={e => update(i, { role: e.target.value })} placeholder={t("本人、对方等", "Self, partner…")} /></label>
      <label>{t("性别", "Gender")}<select value={person.gender === "unknown" ? "" : person.gender || ""} onChange={e => update(i, { gender: (e.target.value || undefined) as Participant["gender"] })}><option value="">{t("请选择性别", "Select gender")}</option><option value="male">{t("男", "Male")}</option><option value="female">{t("女", "Female")}</option></select></label>
      <label>{t("出生年份", "Birth year")}<input type="number" min={1900} max={new Date().getFullYear()} value={person.birthYear || ""} onChange={e => update(i, { birthYear: e.target.value ? Number(e.target.value) : undefined })} /></label>
    </div>
    {i > 0 ? <button type="button" className="text-button" onClick={() => onChange(value.filter((_, n) => n !== i))}>{t("移除此人", "Remove person")}</button> : null}
  </fieldset>)} </>;
}
