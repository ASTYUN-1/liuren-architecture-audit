"use client";
import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, Files } from "lucide-react";
import type { ShowcaseCase } from "@/lib/case-showcase-types";
import { ConversationMessage } from "./conversation-message";
import "./beta-showcase.css";

export function BetaShowcase({ slug, cases: showcaseCases }: { slug?: string; cases: ShowcaseCase[] }) {
  const categories = ["全部", ...new Set(showcaseCases.map(item => item.category))];
  const [category, setCategory] = useState("全部");
  const [query, setQuery] = useState("");
  const item = slug ? showcaseCases.find(c => c.slug === slug) : undefined;
  const visible = showcaseCases.filter(c => (category === "全部" || c.category === category) && (c.title + c.messages[0].content).includes(query.trim()));
  if (slug && !item) return <section className="showcase-page"><h1>这个案例暂未收录</h1><Link href="/examples">返回案例档案</Link></section>;
  return <section className="showcase-page">
    {item ? <>
      <Link className="showcase-back" href="/examples"><ArrowLeft size={16}/>案例档案</Link>
      <header className="showcase-heading"><small>{item.category} · 对话记录</small><h1>{item.title}</h1><p>{item.scope}</p></header>
      <div className="showcase-reading-tools"><span>{item.messages.length} 条消息 · 按原顺序展示</span><a href={`#message-${item.messages.find(m => m.feedback)?.id}`}>跳到结果反馈 ↓</a></div>
      <p className="showcase-note">来自用户提供的 OpenCode 对话导出。反馈为记录中的用户原话，后续修正与初判分开展示。</p>
      {(item.category === "健康" || item.category === "胎产") && <p className="showcase-note">本页为历史对话记录，其中健康、胎产判断不作为医疗建议，实际诊疗以医生检查为准。</p>}
      <div className="showcase-dialogue">{item.messages.map(message => <ConversationMessage key={message.id} id={`message-${message.id}`} role={message.role} label={message.role === "user" ? "用户" : "AI · OpenCode"} time={message.time} feedback={message.feedback}>{message.content}</ConversationMessage>)}</div>
      <p className="showcase-note">对话正文保留；仅校正确定的错字，省略工具运行日志并隐藏内部资料地址。初判中的偏差及后续未验证内容均保留。</p>
      <footer className="showcase-footer"><Link href="/examples"><ArrowLeft size={16}/>返回案例档案</Link><Link href="/" className="button primary">问自己的事<ArrowRight size={16}/></Link></footer>
    </> : <>
      <header className="showcase-heading"><h1>AI 解卦案例</h1></header>
      <div className="list-tools"><div className="filter-tabs" role="group" aria-label="案例分类">{categories.map(value => <button key={value} type="button" className={category === value ? "selected" : ""} aria-pressed={category === value} onClick={() => setCategory(value)}>{value}</button>)}</div><input type="search" aria-label="搜索案例档案" placeholder="搜索标题或首问" value={query} onChange={event => setQuery(event.target.value)}/></div>
      <p className="showcase-count" role="status">{visible.length} 份档案 · 已有结果反馈</p>
      <div className="case-list showcase-archives">{visible.map(c => <Link href={`/examples/${c.slug}`} className="case-row" key={c.slug}><Files size={20} aria-hidden="true"/><div className="showcase-row-content"><h3>{c.title}</h3><small>{c.category} · {c.messages[0].time} · {c.messages.length} 条消息</small><p>{c.scope}</p></div><ArrowRight size={17} aria-hidden="true"/></Link>)}</div>
      {!visible.length && <div className="showcase-empty"><p>没有找到符合条件的档案。</p><button className="text-button" onClick={() => {setCategory("全部");setQuery("");}}>清除筛选</button></div>}

    </>}
  </section>;
}
