import type { CaseInput } from "@/server/contracts";
import { caseInputFields, dialogueTime } from "@/lib/case-input-display";
import { useApp } from "./app-provider";
import { ConversationMessage } from "./conversation-message";

export function CaseInputMessage({ input, askedAt, historical = false }: { input: CaseInput; askedAt?: string; historical?: boolean }) {
  const { t, locale } = useApp();
  return <ConversationMessage role="user" label={historical ? t("你 · 当时的提问", "You · Original question") : t("你 · 提问", "You · Question")}
    time={dialogueTime(askedAt, locale)}>
    <div className="preserve-lines">{input.question}</div>
    <dl className="conversation-input-fields">{caseInputFields(input, locale).map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>
  </ConversationMessage>;
}
