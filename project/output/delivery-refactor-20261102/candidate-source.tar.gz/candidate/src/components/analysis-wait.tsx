"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import type { TaskView } from "@/server/contracts";
import { estimateAnalysisProgress } from "@/lib/analysis-progress";
import { useApp } from "./app-provider";
import { GuideMascot } from "./friendly-guide";
import "./analysis-stages.css";

const preferenceCookie="wenheng-analysis-compact-v1",preferenceEvent="wenheng-analysis-preference";
let compactForSession=false;

export function AnalysisWait({ tasks, emailEnabled, showStages=false }: { tasks: TaskView[]; emailEnabled: boolean; showStages?: boolean }) {
  const active=tasks.find(task=>task.status==="running")||tasks.find(task=>task.status==="queued");
  const [observedId,setObservedId]=useState<string|null>(null);
  useEffect(()=>{if(active)setObservedId(active.id);},[active?.id]);
  // Observe completion only for a task seen running here, never replay old reports.
  const task=active||tasks.find(task=>task.id===observedId);
  return task?<TaskWait key={task.id} task={task} emailEnabled={emailEnabled} showStages={showStages}/>:null;
}

function TaskWait({ task, emailEnabled, showStages }: { task: TaskView; emailEnabled: boolean; showStages: boolean }) {
  const {t}=useApp();
  const [compact,setCompact]=useState<boolean|null>(null),[finished,setFinished]=useState(false),[estimated,setEstimated]=useState(0);
  const pending=task.status==="running"||task.status==="queued",complete=task.status==="succeeded";
  useEffect(()=>{
    const sync=()=>{
      try{setCompact(compactForSession||document.cookie.split(';').some(part=>part.trim()===`${preferenceCookie}=1`));}
      catch{setCompact(compactForSession);}
    };
    sync();window.addEventListener(preferenceEvent,sync);window.addEventListener('focus',sync);document.addEventListener('visibilitychange',sync);
    return()=>{window.removeEventListener(preferenceEvent,sync);window.removeEventListener('focus',sync);document.removeEventListener('visibilitychange',sync);};
  },[]);
  useEffect(()=>{
    if(!pending)return;
    const tick=()=>setEstimated(previous=>Math.max(previous,estimateAnalysisProgress(task.id,task.createdAt,Date.now(),showStages)));
    tick();const timer=window.setInterval(tick,showStages?1000:1500);return()=>window.clearInterval(timer);
  },[pending,task.id,task.createdAt,showStages]);
  useEffect(()=>{
    if(!complete)return;
    const timer=window.setTimeout(()=>setFinished(true),1400);return()=>window.clearTimeout(timer);
  },[complete]);
  function dismiss(){
    compactForSession=true;
    try{document.cookie=`${preferenceCookie}=1; Path=/; Max-Age=34560000; SameSite=Lax${location.protocol==='https:'?'; Secure':''}`;}catch{/* Keep the choice for this page when cookies are unavailable. */}
    setCompact(true);window.dispatchEvent(new Event(preferenceEvent));
  }
  if(finished||(!pending&&!complete))return null;
  const progress=complete?100:estimated,displayProgress=Math.floor(progress),expanded=compact===false,running=task.status==="running",followup=task.kind==="followup";
  const runtime=task.runtimeProgress,realStage=runtime?.state==='checking'?t('正在核对交付结果','Checking the result'):runtime?.state==='tool_correction'?t('正在修正分析步骤','Correcting a workflow step'):runtime?.state==='output_recovery'?t('正在恢复报告输出','Recovering the report'):runtime?.longRunning?t('分析仍在推进，用时较长','Analysis is progressing and taking longer'):runtime?.state==='model_working'?t('正在推敲问题与依据','Working through the question and evidence'):runtime?.state==='tools_progressing'||runtime?.state==='model_responded'?t('分析步骤正在推进','Analysis is progressing'):null;
  const stage=complete?t("回答已就绪","Answer ready"):!running?t("排队等待开始","Waiting in queue"):realStage??(progress<10?t("理解问题与背景","Understanding the question"):progress<30?t("查阅资料与工具辅助","Reviewing references and tools"):progress<70?t("分析问题与盘面","Analyzing the question and chart"):progress<90?t("整合分析内容","Bringing the analysis together"):t("归纳要点，准备输出","Summarizing for the answer"));
  const stageLabel=showStages?<div className="analysis-stage-label"><span role="status">{complete?stage:<><small>{t("执行状态 · 进度为预估","Status · estimated progress")} · </small>{stage}</>}</span><strong>{displayProgress}%</strong></div>:null;
  const bar=<div className="analysis-track" role="progressbar" tabIndex={-1} aria-label={t("预估分析进度","Estimated analysis progress")} aria-valuemin={0} aria-valuemax={100} aria-valuenow={displayProgress}><span style={{width:`${progress}%`}}/></div>;
  if(!expanded)return <section className={`analysis-wait analysis-wait-compact${showStages?' analysis-wait-smooth':''}${complete?' is-complete':''}`} aria-label={t("分析进度","Analysis progress")}>{stageLabel}{bar}</section>;
  return <section className={`analysis-wait${showStages?' analysis-wait-smooth':''}${complete?' is-complete':''}`} aria-label={t("分析进度","Analysis progress")}>
    {showStages?<div className="analysis-scene"><div className="analysis-orbit" aria-hidden="true"><span className="orbit-outer"/><span className="orbit-inner"/><span className="orbit-character">壬</span></div></div>:<div className="analysis-scene"><GuideMascot thinking/><div className="thinking-dots" aria-hidden="true"><i/><i/><i/></div><span className="analysis-seal" aria-hidden="true">{t("问衡","W")}</span></div>}
    <div className="analysis-copy"><span className="analysis-eyebrow">{followup?t("追问已提交","Follow-up submitted"):t("问题已提交","Question submitted")}</span><h2 aria-live="polite">{complete?t("回答已就绪","Your answer is ready"):running?t("正在认真分析这件事","Working through your question"):t("已排好队，稍候就到","In the queue, waiting to begin")}</h2><p>{showStages?t("分析需要一些时间，请稍候。","The analysis takes a little time. Please wait."):t("小先生正在忙，你可以先去忙自己的。","Your little guide is on the case. Feel free to step away.")}</p></div>
    {stageLabel}
    {!showStages?<div className="analysis-progress-label"><span>{t("预估进度","Estimated progress")}</span><strong>{progress}%</strong></div>:null}
    {bar}
    <p className="analysis-return">{t("离开页面不会中断分析，从「我的档案」可继续查看。","Leaving this page does not stop the task. Reopen it from My cases.")}</p>
    <div className="analysis-notification">{followup?t("追问完成后在本档案显示，不另发邮件。","Follow-up replies appear in this case, without another email."):emailEnabled?t("主报告完成后会发送邮件提醒，也可直接回到档案查看。","We will email you when the main report is ready. You can also check the case directly."):t("完成后在本档案显示。","The answer will appear in this case.")}</div>
    <div className="analysis-actions"><Link href="/cases">{t("去我的档案","My cases")} →</Link><button type="button" className="text-button" onClick={()=>{dismiss();window.requestAnimationFrame(()=>document.querySelector<HTMLElement>('.analysis-wait [role="progressbar"]')?.focus({preventScroll:true}));}}>{t("不再显示","Don’t show again")}</button></div>
  </section>;
}
