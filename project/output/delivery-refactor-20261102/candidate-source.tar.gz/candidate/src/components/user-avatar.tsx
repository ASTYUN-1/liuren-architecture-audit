"use client";
import { useState } from "react";
import { safeAvatarUrl } from "@/lib/avatar";
export function UserAvatar({ name, image, online = false, large = false }: { name: string; image?: string | null; online?: boolean; large?: boolean }) {
  const [failed, setFailed] = useState<string | null>(null), src = safeAvatarUrl(image);
  return <span className={`account-avatar${large ? ' account-avatar-large' : ''}`} aria-hidden="true">{src && failed !== src ? <img src={src} width={large ? 80 : 34} height={large ? 80 : 34} alt="" onError={() => setFailed(src)} /> : Array.from(name.trim() || "问")[0]}{online ? <i /> : null}</span>;
}
