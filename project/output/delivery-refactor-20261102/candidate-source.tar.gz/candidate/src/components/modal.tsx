"use client";
import {useEffect,useId,useRef,type ReactNode} from 'react';
export function Modal({title,onClose,children,className=''}:{title:string;onClose:()=>void;children:ReactNode;className?:string}){
 const dialog=useRef<HTMLDialogElement>(null),id=useId();
 useEffect(()=>{const el=dialog.current,opener=document.activeElement;el?.showModal();return()=>{el?.close();if(opener instanceof HTMLElement&&opener.isConnected)opener.focus({preventScroll:true});};},[]);
 return <dialog ref={dialog} aria-labelledby={id} className={`site-dialog ${className}`} onCancel={e=>{e.preventDefault();onClose();}} onClick={e=>{if(e.target===e.currentTarget){const r=e.currentTarget.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)onClose();}}}><div className="dialog-heading"><h2 id={id}>{title}</h2><button type="button" className="icon-button" aria-label="关闭 / Close" onClick={onClose}>×</button></div>{children}</dialog>;
}
