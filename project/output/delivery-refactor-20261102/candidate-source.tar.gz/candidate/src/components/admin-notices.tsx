"use client";
import {useCallback,useEffect,useRef,useState} from 'react';
import {api,post} from '@/lib/api';
import type {AdminNotices,AdminNoticeModule} from '@/lib/admin-notices';
import {useApp} from './app-provider';

export function useAdminNotices(operatorId:string|undefined){
 const [notices,setNotices]=useState<AdminNotices>({modules:{}}),[error,setError]=useState(''),request=useRef(0);
 const refresh=useCallback(async()=>{if(!operatorId)return;const n=++request.current;try{const next=await api<AdminNotices>('/api/admin/notices');if(n===request.current){setNotices(next);setError('');}}catch{if(n===request.current)setError('新消息暂未刷新，请稍后重试');}},[operatorId]);
 useEffect(()=>{setNotices({modules:{}});if(!operatorId)return;void refresh();const visible=()=>{if(document.visibilityState==='visible')void refresh();};const timer=setInterval(visible,15000);window.addEventListener('focus',visible);document.addEventListener('visibilitychange',visible);return()=>{request.current++;clearInterval(timer);window.removeEventListener('focus',visible);document.removeEventListener('visibilitychange',visible);};},[operatorId,refresh]);
 const read=useCallback(async(keys:string[])=>{if(!operatorId||!keys.length)return;request.current++;try{await post('/api/admin/notices',{keys});await refresh();}catch{setError('已读状态未保存，请重试');}},[operatorId,refresh]);
 return {notices,error,refresh,read};
}
export function AdminNoticeList({module,notices,onRead}:{module:string;notices:AdminNotices;onRead:(keys:string[])=>Promise<void>}){
 const {t,locale}=useApp(),[busy,setBusy]=useState(false),view=notices.modules[module as AdminNoticeModule],acknowledged=useRef(false);
 const keys=view?.items.map(i=>i.key).join('\n')??'';
 useEffect(()=>{if(acknowledged.current||!keys)return;const timer=setTimeout(()=>{if(document.visibilityState!=='visible')return;acknowledged.current=true;void onRead(keys.split('\n'));},2000);return()=>clearTimeout(timer);},[keys,onRead]);
 if(!view?.pending)return null;
 // Display the exact messages being acknowledged; opening the dashboard never
 // silently clears another section, nor messages beyond the displayed batch.
 return <aside className="admin-notice-list" aria-label={t('本栏目待办提醒','Section notifications')}><p>{t('待处理','Pending')}: {view.pending} · {t('未读新消息','Unread')}: {view.unread}</p>{view.items.length?<><ul>{view.items.map(item=><li key={item.key}>{item.label}<time dateTime={item.at}>{new Date(item.at).toLocaleString(locale==='zh'?'zh-CN':'en-US')}</time></li>)}</ul><button className="button secondary small" disabled={busy} onClick={async()=>{setBusy(true);try{await onRead(view.items.map(i=>i.key));}finally{setBusy(false);}}}>{busy?t('保存中…','Saving…'):t('这些消息已读','Mark these as read')}</button></>:<small>{t('本栏目暂无未读新消息，待办仍保留至处理完成。','No unread messages. Pending work remains until resolved.')}</small>}</aside>;
}
