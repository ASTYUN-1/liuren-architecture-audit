"use client";
import {useRef,useState} from 'react';
import {useApp} from './app-provider';
import {post} from '@/lib/api';
import {Notice} from './ui';
export function AdminQuickRedeem({onUpdated}:{onUpdated?:()=>void}){
 const {t}=useApp(),[code,setCode]=useState(''),[busy,setBusy]=useState(false),[message,setMessage]=useState(''),[error,setError]=useState(''),pending=useRef(false);
 return <section className="admin-section"><h2>{t('真人辅助核销','Redeem human service')}</h2><p className="muted">{t('服务完成后输入预约编号或分享码。核销将直接扣除该预约已冻结的积分，重复核销不会再次扣费。','After service delivery, enter its booking ID or share code. Reserved credits settle once; repeated redemption never charges twice.')}</p><form className="admin-search" onSubmit={async e=>{e.preventDefault();if(pending.current||!code.trim())return;pending.current=true;setBusy(true);setError('');setMessage('');try{const r=await post<{chargedUnits:number;alreadyCompleted:boolean}>('/api/admin/human-assists',{action:'quickRedeem',code:code.trim()});setMessage(r.alreadyCompleted?t('该预约已核销，未重复扣费。','Already redeemed; no additional charge.'):t(`核销成功，已扣除 ${(r.chargedUnits/10).toFixed(1)} 积分。`,`Redeemed ${(r.chargedUnits/10).toFixed(1)} credits.`));setCode('');onUpdated?.();}catch(e){setError(e instanceof Error?e.message:'Error');}finally{pending.current=false;setBusy(false);}}}><label>{t('预约编号或分享码','Booking ID or share code')}<input required maxLength={80} value={code} disabled={busy} onChange={e=>setCode(e.target.value)} placeholder={t('粘贴完整编号或分享码','Paste booking ID or share code')}/></label><button className="button primary" disabled={busy||!code.trim()}>{busy?t('核销中…','Redeeming…'):t('核销','Redeem')}</button></form>{error?<Notice kind="error">{error}</Notice>:null}{message?<Notice kind="success">{message}</Notice>:null}</section>;
}
