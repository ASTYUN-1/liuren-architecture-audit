"use client";
import {useEffect,useState,type FormEvent} from "react";
import {ArrowRight} from "lucide-react";
import type {CaseInput,Participant,IntentResolution} from "@/server/contracts";
import type {RandomSelection} from "@/lib/random-chart";
import {useApp} from "./app-provider";
import {Notice} from "./ui";
import {ParticipantsEditor} from "./participants-editor";
import {TimeWheel,beijingWallTime} from './time-wheel';
import {LocationPicker} from './location-picker';
import {PillarPicker} from './pillar-picker';
import {RandomChartPicker} from './random-chart-picker';
import {Modal} from './modal';
import Link from 'next/link';
import {post} from '@/lib/api';
import {IntentReview} from './intent-review';
import {VoiceInput} from './voice-input';
import {UsageNotes} from './usage-notes';
import {FriendlyGuide} from './friendly-guide';
import {ServiceScopeNotice} from './service-scope-notice';
const branches=[..."子丑寅卯辰巳午未申酉戌亥"];

export function QuestionForm({initial,onConfirm,busy,disabled,chartOnly=false,initialOutputStyle}:{initialOutputStyle?:"public"|"practitioner"|null;initial?:CaseInput;onConfirm:(input:CaseInput,options?:{outputStyle?:"public"|"practitioner"})=>void|Promise<void>;busy?:boolean;disabled?:boolean;chartOnly?:boolean}){
  const {t,locale,me,loading,authError,refresh}=useApp();
  const [outputStyle,setOutputStyle]=useState<"public"|"practitioner">(initialOutputStyle??"practitioner");
  const [reviewOpen,setReviewOpen]=useState(false),[pendingInput,setPendingInput]=useState<CaseInput|null>(null);
  const [resolving,setResolving]=useState(false),[resolved,setResolved]=useState<CaseInput|null>(null),[clarification,setClarification]=useState('');
  const [question,setQuestion]=useState(initial?.question||""),[mode,setMode]=useState<CaseInput["mode"]>(initial?.mode||"time"),[time,setTime]=useState(initial?.time?beijingWallTime(new Date(initial.time)):"2026-01-01T12:00"),[number,setNumber]=useState(String(initial?.number||"")),[longitude,setLongitude]=useState(initial?.longitude===undefined?"":String(initial.longitude)),[current,setCurrent]=useState(initial?.timeSource==='current'||!initial?.time),[readBefore,setReadBefore]=useState(false),[error,setError]=useState("");
  const [pillars,setPillars]=useState(initial?.pillars||{year:"",month:"",day:"",hour:"",monthGeneral:""}),[actualDate,setActualDate]=useState(initial?.pillars?.actualDate||"");
  const [rules,setRules]=useState<Record<string,string>>(initial?.rules||{yuejiang:"中气换将",guiren:"甲戊庚牛羊",zhouye:"自动选择",shehai:"孟仲季"});
  const [participants,setParticipants]=useState<Participant[]>(initial?.participants?.length?initial.participants:[{role:"本人"}]);
  const [random,setRandom]=useState<{ticket:string;time:string;number:number}|null>(initial?.random&&initial.time&&initial.number?{...initial.random,time:initial.time,number:initial.number}:null);
  const [randomOpen,setRandomOpen]=useState(false);
  const [timeEditing,setTimeEditing]=useState(false),[draftTime,setDraftTime]=useState(time);
  function applyRandom(selection:RandomSelection){setRandom(selection);setMode("number");setNumber(String(selection.number));setTime(beijingWallTime(new Date(selection.time)));setCurrent(false);setRules(selection.rules);setLongitude("");setError("");setRandomOpen(false);}
  useEffect(()=>{if(!current)return;const refresh=()=>setTime(beijingWallTime());refresh();const timer=setInterval(refresh,1000);return()=>clearInterval(timer);},[current]);
  function clearRandom(){setRandom(null);setMode("time");setCurrent(true);setError("");}
  function closeReview(){if(resolving||busy)return;setReviewOpen(false);setPendingInput(null);setResolved(null);setClarification('');setError('');}
  async function submit(e:FormEvent){e.preventDefault();if(resolving||busy||disabled||(!chartOnly&&loading))return;setError("");setClarification('');setResolved(null);try{
    if(!chartOnly&&authError){setReviewOpen(true);throw new Error(t('登录状态暂时无法确认，请重试后再继续。','Your sign-in status could not be checked. Retry before continuing.'));}
    if(!chartOnly&&question.trim().length<4)throw new Error(t("请写下具体的一件事，至少 4 个字。","Describe one specific question (at least 4 characters)."));
    if(chartOnly&&mode==="number"&&(!/^\d+$/.test(number)||!Number.isSafeInteger(Number(number))||Number(number)<1||Number(number)>999999999))throw new Error(t("报数须为 1 至 999999999 的整数。","Enter a whole number between 1 and 999999999."));
    if(chartOnly&&mode==="solar"&&(longitude.trim()===""||!Number.isFinite(Number(longitude))||Math.abs(Number(longitude))>180))throw new Error(t("请输入 −180 至 180 度的经度，东经为正，西经为负。","Enter longitude from −180 to 180; east positive, west negative."));
    if(chartOnly&&mode==="pillars"&&[pillars.year,pillars.month,pillars.day,pillars.hour,pillars.monthGeneral].some(v=>!v.trim()))throw new Error(t("请完整填写年、月、日、时与月将。","Complete the pillars and month general."));
    if(participants.some(p=>p.birthYear!==undefined&&(!Number.isInteger(p.birthYear)||p.birthYear<1900||p.birthYear>new Date().getFullYear())))throw new Error(t("请检查填写的出生年份。","Check the birth year entered."));
    const input:CaseInput={...(initial?.chartRequest&&question.trim()===initial.question?{chartRequest:initial.chartRequest}:{}),timeSource:current?'current':'custom',question:chartOnly?"自助排盘":question.trim(),locale,mode,timeZone:"Asia/Shanghai",participants:participants.map((p,i)=>({...p,role:p.role.trim()||(i===0?"本人":`人物${i+1}`)})),rules,
      ...(mode!=="pillars"?{time:random?.time||(current?new Date():new Date(time+":00+08:00")).toISOString()}:{}),
      ...(mode==="number"&&Number(number)>0?{number:random?.number||Number(number)}:{}),
      ...(mode==="solar"&&longitude.trim()!==""&&Number.isFinite(Number(longitude))?{longitude:Number(longitude)}:{}),
      ...(mode==="pillars"?{pillars:{...pillars,...(actualDate?{actualDate}:{})}}:{}),
      ...(random?{random:{ticket:random.ticket}}:{})};
    if(chartOnly){await onConfirm(input);return;}
    setReviewOpen(true);
    if(!me){setPendingInput(input);return;}
    setResolving(true);
    const result=await post<IntentResolution>('/api/input/resolve',{input});
    if(!result.input){setClarification(result.clarification||result.summary);return;}
    setResolved(result.input);
  }catch(err){setError(err instanceof Error?err.message:"Error");}finally{setResolving(false);}}
  return <form className="question-form" onSubmit={submit}>
    <div className="question-title"><h2>{chartOnly?t("按你的设定起盘","Create your chart"):t("你想问什么？","What would you like to ask?")}</h2>{!chartOnly?<div className="question-help"><FriendlyGuide/><button type="button" className="read-before" onClick={()=>setReadBefore(true)}>{t('用前必读','Read first')}</button></div>:null}</div>
    {!chartOnly?<p className="question-quick-start">{t("直接描述问题与起课要求，中文时间、报数或方式都可以；明确要求优先于下方设置，未指定时沿用设置或当前时间。","Describe your question and chart preferences in your own words. Explicit requests take priority over the settings below; otherwise your settings or the current time apply.")}</p>:null}
    {readBefore?<Modal title={t('用前必读','Before you start')} className="usage-dialog" onClose={()=>setReadBefore(false)}><UsageNotes/><div className="usage-actions"><Link className="text-button" href="/guide">{t('查看完整教程与示例','Full guide and examples')} →</Link><button className="button primary" type="button" onClick={()=>setReadBefore(false)}>{t('明白了，开始提问','Got it, ask a question')}</button></div></Modal>:null}
    {!chartOnly&&initial?.chartRequest?<p className="muted">{t('此前已确认的起课更正：','Previously confirmed chart correction: ')}{initial.chartRequest}</p>:null}
    {!chartOnly?<div className="question-input"><div className="question-text"><label className="sr-only" htmlFor="question">{t("问题和背景","Question and background")}</label><textarea id="question" required minLength={4} maxLength={4000} value={question} onChange={e=>setQuestion(e.target.value)} placeholder={t("写下正在困扰你的一件事，以及必要的背景。","Describe one matter and its relevant background.")}/><span>{question.length} / 4000</span></div><VoiceInput disabled={busy||resolving} onText={text=>setQuestion(value=>(value+(value?'，':'')+text).slice(0,4000))}/></div>:null}
    {!chartOnly&&me?.practitioner?.professionalOutput?<label className="reading-style">{t("解读表达","Reading style")}<select aria-label={t("解读表达","Reading style")} value={outputStyle} onChange={e=>setOutputStyle(e.target.value as "public"|"practitioner")}><option value="practitioner">{t("专业 · 保留术理依据","Professional · Technical detail")}</option><option value="public">{t("通俗 · 便于理解","Standard · Plain language")}</option></select></label>:null}<details className="participants optional-people"><summary>{t('人物信息','People')} <span>{t('选填','Optional')}</span></summary><p className="muted">{t('知道就填，不填也可开始。','Add known details, or continue without them.')}</p><ParticipantsEditor value={participants} onChange={setParticipants}/><button type="button" className="text-button" disabled={participants.length>=8} onClick={()=>setParticipants([...participants,{role:''}])}>＋ {t('添加人物','Add person')}</button></details>
    {!chartOnly?<p className="muted">{t('辅助起课设置 · 对话中的明确要求优先','Optional chart settings · Explicit text requests take priority')}</p>:null}
    <div className="mode-tabs question-method-tabs" role="tablist" aria-label={t("起课方式","Chart method")}>{(["time","number","random","solar"] as const).map((v,i)=>{const selected=v==='random'?!!random||randomOpen:!random&&!randomOpen&&mode===v;return <button key={v} type="button" role="tab" disabled={!!random&&v!=='random'} aria-selected={selected} aria-haspopup={v==='random'?'dialog':undefined} className={selected?"selected":""} onClick={()=>{if(v==='random')setRandomOpen(true);else setMode(v);}}>{[t("时间起课","By time"),t("报数起课","By number"),t("随机起课","Random chart"),t("真太阳时","True solar time")][i]}</button>;})}</div>
    <RandomChartPicker rules={rules} open={randomOpen} onClose={()=>setRandomOpen(false)} onApply={applyRandom}/>
    {random?<section className="applied-random" aria-label={t("已应用随机盘","Applied random chart")}><strong>{t("已应用随机盘 · 活时","Random chart applied · Selected hour")} {branches[(random.number-1)%12]}{t("时"," hour")}</strong><p>{t("当前已采用此随机结果；对话中明确提出更改起课要求时，会先整理并请你确认新设定。","This random selection is applied. Explicit requests to change chart settings will be reviewed before a new configuration is used.")}</p><small>{new Date(random.time).toLocaleString(locale==="zh"?"zh-CN":"en-US",{timeZone:"Asia/Shanghai"})} · {t("冻结的北京时间","Frozen Beijing time")}</small><button type="button" className="text-button" onClick={clearRandom}>{t("取消应用，改用其他方式","Clear and choose another method")}</button></section>:null}
    {!random?<div className="settings-fields compact-chart-settings">
    {mode==='number'?<label>{t('报数','Number')}<input aria-label={t('报数','Number')} inputMode="numeric" required={chartOnly} value={number} onChange={e=>setNumber(e.target.value)} placeholder={t('输入一个正整数','Enter a positive whole number')}/><small>{t('日期按下方选择，时辰由报数确定：1为子，12为亥，超过12循环。','Uses the selected date; the number selects the hour branch, cycling every 12.')}</small></label>:null}
    {mode!=='pillars'?<section className="time-picker"><div className="time-picker-heading"><strong>{t('起课时间 · 北京时间','Chart time · Beijing')}</strong><button type="button" className={`text-button ${current?'is-current':''}`} onClick={()=>{setCurrent(true);setTime(beijingWallTime());}}>{t('使用当前时间','Use current time')} ↻</button></div><p className="time-selected">{time.replace('T',' ')} <small>{current?t('当前时间','Live'):t('自定义时间','Custom')}</small></p>{chartOnly?<TimeWheel value={time} onChange={v=>{setCurrent(false);setTime(v);}}/>:<button type="button" className="button secondary small" onClick={()=>{setDraftTime(current?beijingWallTime():time);setTimeEditing(true);}}>{t('修改时间','Change time')}</button>}</section>:<PillarPicker value={pillars} onChange={setPillars}/>}
    {mode==='pillars'?<details className="actual-date"><summary>{t('补充实际日期（选填）','Actual date (optional)')}</summary><input type="date" aria-label={t('实际日期','Actual date')} value={actualDate} onChange={e=>setActualDate(e.target.value)}/></details>:null}
    {mode==='solar'?<LocationPicker value={longitude} onChange={setLongitude}/>:null}
    <details className="advanced-rules"><summary>{t("高级起课规则","Advanced chart rules")}</summary><div className="fields-grid">{Object.entries({yuejiang:["中气换将","交节换将","日躔换将"],guiren:["甲戊庚牛羊","甲羊戊庚牛"],zhouye:["自动选择","昼贵","夜贵"]}).map(([name,options])=><label key={name}>{name==="yuejiang"?t("换将规则","Month general rule"):name==="guiren"?t("贵人规则","Noble person rule"):t("昼夜贵人","Day / night noble person")}<select value={rules[name]} onChange={e=>setRules({...rules,[name]:e.target.value})}>{options.map(o=><option key={o}>{o}</option>)}</select></label>)}</div></details></div>:null}
    {timeEditing?<Modal title={t('修改起课时间','Change chart time')} onClose={()=>setTimeEditing(false)}><p className="muted">{t('选择日期和时间，确认后生效。','Choose a date and time, then confirm to apply.')} · {t('北京时间','Beijing time')}</p><TimeWheel value={draftTime} onChange={setDraftTime}/><div className="button-row"><button type="button" className="button secondary" onClick={()=>setTimeEditing(false)}>{t('取消','Cancel')}</button><button type="button" className="button primary" onClick={()=>{setTime(draftTime);setCurrent(false);setTimeEditing(false);}}>{t('确认时间','Confirm time')}</button></div></Modal>:null}
    {reviewOpen?<Modal title={pendingInput?t('登录后确认起课要求','Sign in to confirm chart settings'):t('确认起课要求','Confirm chart settings')} onClose={closeReview}>
      {resolving?<div role="status" aria-live="polite"><p>{t('正在理解你的问题与起课要求…','Understanding your question and chart preferences…')}</p><p className="muted">{t('整理好后会在这里显示，请核对后再保存。此步不扣解读积分。','Review the settings here before saving. No interpretation credits are charged for this step.')}</p></div>:null}
      {pendingInput?<><p className="preserve-lines">{pendingInput.question}</p><p>{t('请先登录。登录后会恢复这段问题，再由 AI 整理起课要求，供你核对确认。','Sign in first. Your question will be restored, then AI will organize the chart settings for your review.')}</p><div className="button-row"><button type="button" className="button secondary" disabled={busy} onClick={closeReview}>{t('返回修改','Edit')}</button><button type="button" className="button primary" disabled={busy} onClick={async()=>{setError('');try{await onConfirm(pendingInput);}catch(e){setError(e instanceof Error?e.message:'Error');}}}>{t('保留问题并登录','Keep question & sign in')}</button></div></>:null}
      {clarification?<><Notice>{clarification}<p>{t('请在输入框补充或修改后再次确认；此步不扣解读积分。','Add or edit the details above, then review again. No interpretation credits charged.')}</p></Notice><button type="button" className="button primary" onClick={closeReview}>{t('返回补充','Add details')}</button></>:null}
      {resolved?<><p className="preserve-lines">{resolved.question}</p><IntentReview input={resolved}/><div className="button-row"><button type="button" className="button secondary" disabled={busy} onClick={closeReview}>{t('返回修改','Edit')}</button><button type="button" className="button primary" disabled={busy} onClick={async()=>{setError('');try{await onConfirm(resolved,{outputStyle:me?.practitioner?.professionalOutput?outputStyle:undefined});closeReview();}catch(e){setError(e instanceof Error?e.message:'Error');}}}>{busy?t('正在保存…','Saving…'):t('采用此设定并保存','Use these settings & save')}</button></div></>:null}
      {error?<Notice kind="error">{error}</Notice>:null}
      {!resolving&&!resolved&&!pendingInput&&!clarification?<div className="button-row"><button type="button" className="button secondary" onClick={closeReview}>{t('返回修改','Edit')}</button>{authError?<button type="button" className="button primary" onClick={async()=>{await refresh();closeReview();}}>{t('重新检查登录状态','Check sign-in again')}</button>:null}</div>:null}
    </Modal>:null}
    {error&&!reviewOpen?<Notice kind="error">{error}</Notice>:null}<button className="button primary full" type="submit" disabled={busy||disabled||resolving||(!chartOnly&&loading)}>{!chartOnly&&loading?t('正在确认登录状态…','Checking sign-in…'):resolving?t("正在理解起课要求…","Understanding your request…"):busy?t("正在提交…","Submitting…"):chartOnly?t("生成盘面","Create chart"):t("确认问题","Review question")}<ArrowRight size={18}/></button>
    {!chartOnly?<ServiceScopeNotice/>:null}
  </form>;
}
