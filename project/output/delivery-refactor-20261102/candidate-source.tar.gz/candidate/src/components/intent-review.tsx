"use client";
import type {CaseInput} from '@/server/contracts';
import {useApp} from './app-provider';
export function IntentReview({input}:{input:CaseInput}){
  const {t,locale}=useApp();
  return <div className="intent-review"><p>{input.intent?.summary}</p><dl className="definition-list"><dt>{t('起课方式','Chart method')}</dt><dd>{input.random?t('随机起课','Random chart'):({time:t('时间起课','By time'),number:t('报数起课','By number'),solar:t('真太阳时','True solar time'),pillars:t('四柱起课','By pillars')})[input.mode]}</dd>
    <dt>{t('采用时间','Selected time')}</dt><dd>{input.mode==='pillars'?<>{input.pillars?.year}{t('年',' year')} · {input.pillars?.month}{t('月',' month')} · {input.pillars?.day}{t('日',' day')} · {input.pillars?.hour}{t('时',' hour')}<br/>{t('月将','Month general')}：{input.pillars?.monthGeneral}{input.pillars?.actualDate?<><br/>{t('实际公历日期','Gregorian date')}：{input.pillars.actualDate}</>:null}</>:input.time?new Date(input.time).toLocaleString(locale==='zh'?'zh-CN':'en-US',{timeZone:'Asia/Shanghai',hour12:false})+' · '+t('北京时间','Beijing time'):'—'}</dd>
    {input.mode==='number'?<><dt>{t('采用报数','Selected number')}</dt><dd>{input.number} · {t('日期取上述日期，时辰由报数确定','Uses the date above; the number determines the chart hour')}</dd></>:null}
    {input.mode==='solar'?<><dt>{t('经度','Longitude')}</dt><dd>{input.longitude}°</dd></>:null}
    <dt>{t('人物','People')}</dt><dd>{input.participants.map((p,i)=><div key={i}>{p.role}{p.gender==='male'?` · ${t('男','Male')}`:p.gender==='female'?` · ${t('女','Female')}`:''}{p.birthYear?` · ${p.birthYear}`:''}{p.lifeBranch?` · ${t('本命','Life branch')} ${p.lifeBranch}`:''}</div>)}</dd>
    <dt>{t('问题与背景','Question and background')}</dt><dd className="preserve-lines">{input.question}</dd>
    </dl><p className="muted">{t('请核对背景、人物和起卦时间是否正确；有误可返回修改，尚未开始付费解读。','Check the background, people and chart time. Go back to correct anything; paid interpretation has not started.')}</p></div>;
}
