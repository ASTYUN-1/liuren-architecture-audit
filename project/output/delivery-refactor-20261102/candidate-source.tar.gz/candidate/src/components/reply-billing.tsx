"use client";
import type {TaskBilling} from '@/server/contracts';
import {useApp} from './app-provider';
export function ReplyBilling({billing}:{billing?:TaskBilling|null}){
 const {t}=useApp();if(!billing)return null;
 return <footer className="reply-billing" aria-label={t('本轮积分结算','Credits for this reply')}>
  <span>{t('本轮消耗','Credits used')}</span><strong>{(billing.chargedUnits/10).toFixed(1)} {t('积分','credits')}</strong>
  {billing.refundedUnits>0?<small>{t('已退回','Refunded')} {(billing.refundedUnits/10).toFixed(1)} {t('积分','credits')}</small>:null}
 </footer>;
}
