"use client";
import Link from 'next/link';
import {useEffect,useState} from 'react';
import {api,post} from '@/lib/api';
import {ADVISORS} from '@/lib/advisors';
import {useApp} from './app-provider';
import {Notice} from './ui';

type Share={id:string;advisor_id:string;expires_at:string;revoked_at:string|null;code:string|null;canRenew:boolean};
export function ConversationShare({caseId}:{caseId:string}){
 const {t,locale}=useApp(),[shares,setShares]=useState<Share[]>([]),[error,setError]=useState(''),[busy,setBusy]=useState(false),[copied,setCopied]=useState('');
 async function load(){setShares(await api<Share[]>(`/api/cases/${caseId}/shares`));}
 useEffect(()=>{let active=true;api<Share[]>(`/api/cases/${caseId}/shares`).then(rows=>{if(active)setShares(rows);}).catch(e=>{if(active)setError(e.message);});return()=>{active=false;};},[caseId]);
 async function change(s:Share,action:'revoke'|'renew'){
  if(action==='renew'&&!window.confirm(t('重新授权所选卦师在7天内阅读此档案的当前问题、报告及对话？将生成新码，旧码保持失效。','Authorize this practitioner to read this case’s current question, report and dialogue for 7 days? A new code will replace the old code.')))return;
  setBusy(true);setError('');setCopied('');
  try{await post(`/api/cases/${caseId}/shares`,{action,id:s.id,...(action==='renew'?{confirmed:true}:{})});await load();}catch(e){setError(e instanceof Error?e.message:'Error');}finally{setBusy(false);}
 }
 return <details className="point-detail conversation-share"><summary>{t('真人预约 · 对话分享码','Human booking · Conversation codes')}</summary><p className="muted">{t('预约真人辅助成功后自动生成分享码。请把分享码发送给所选卦师，仅该卦师的授权账号可使用。有效期7天，期间可阅读此档案的当前问题、报告及对话；可随时撤销。过期或撤销后如仍需服务，可在下方明确重新授权，旧码不会恢复。','A conversation code is generated after booking. Send it to the selected practitioner; only their authorized account can use it. Valid for 7 days for this case’s current question, report and dialogue. Revoke anytime. If further service is needed after expiry or revocation, explicitly authorize a new code below; old codes stay invalid.')}</p><Link className="text-button" href="/assistance">{t('预约真人辅助','Book human assistance')} →</Link>{error?<Notice kind="error">{error}</Notice>:null}{copied?<Notice>{copied}</Notice>:null}
 {shares.map(s=><section className="point-detail" key={s.id}><strong>{t('请发送给','Send to ')}{ADVISORS.find(a=>a.id===s.advisor_id)?.name}</strong>{s.code?<p className="share-code">{s.code}</p>:<p>{s.revoked_at?t('已撤销','Revoked'):t('已失效','Inactive')}</p>}<small>{t('有效至','Until')} {new Date(s.expires_at).toLocaleString(locale==='en'?'en-US':'zh-CN')}</small><div className="button-row">{s.code?<><button type="button" className="text-button" onClick={async()=>{try{await navigator.clipboard.writeText(s.code!);setCopied(t('已复制，请发送给所选卦师。','Copied. Send it to your selected practitioner.'));}catch{setError(t('请长按分享码复制','Select the code to copy'));}}}>{t('复制分享码','Copy code')}</button><button type="button" className="text-button" disabled={busy} onClick={()=>void change(s,'revoke')}>{t('撤销分享','Revoke')}</button></>:s.canRenew?<button type="button" className="text-button" disabled={busy} onClick={()=>void change(s,'renew')}>{t('重新授权并生成新码','Authorize a new code')}</button>:null}</div></section>)}</details>;
}
