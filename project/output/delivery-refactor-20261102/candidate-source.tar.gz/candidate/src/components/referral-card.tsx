"use client";
import { useState } from "react";
import Link from "next/link";
import { Copy, Share2 } from "lucide-react";
import { useApp } from "./app-provider";
import { Notice } from "./ui";

export function ReferralCard() {
  const { t, me, refresh } = useApp();
  const [message, setMessage] = useState("");
  if (!me?.referral) return null;
  const r = me.referral;
  async function share(native = false) {
    setMessage("");
    try {
      if (native && navigator.share) await navigator.share({title:t("问衡 · 邀请好友享八折", "Wenheng · Invite a friend and save 20%"),text:t("通过此链接注册，首份基础解读享八折。", "Register through this link for 20% off your first base report."),url:r.shareUrl});
      else { await navigator.clipboard.writeText(r.shareUrl); setMessage(t("邀请链接已复制。发送给朋友，通过此链接注册即可参与。", "Invitation link copied. Share it with a friend to register.")); }
    } catch (error) {
      if (!(error instanceof Error && error.name === "AbortError")) setMessage(t("请长按或选中下方链接，手动复制分享。", "Select and copy the link below to share it."));
    }
  }
  return <section className="settings-section referral-card"><div className="panel-heading"><h2>{t("邀请好友，双方享八折", "Invite friends. Both save 20%.")}</h2><Share2 size={22} /></div>
    <p>{t("朋友通过专属链接注册，首份基础解读八折；朋友付费且报告成功交付后，你获一张下次基础解读八折券。", "A friend who registers through your link gets 20% off their first base report. Once their paid report is delivered, you receive a 20%-off coupon for a future base report.")}</p>
    <div className="referral-stats"><div><strong>{r.availableCoupons}</strong><span>{t("可用八折券", "Available coupons")}</span></div><div><strong>{r.invited}</strong><span>{t("已邀请注册", "Registrations")}</span></div><div><strong>{r.successful}</strong><span>{t("成功交付", "Delivered reports")}</span></div></div>
    {r.reservedCoupons ? <p className="muted">{t("待付款订单已占用优惠券", "Coupons reserved by pending orders")}: {r.reservedCoupons}</p> : null}
    <label>{t("你的专属邀请链接", "Your invitation link")}<input readOnly value={r.shareUrl} onFocus={e=>e.target.select()} /></label>
    <div className="referral-actions"><button type="button" className="button primary" onClick={()=>share()}><Copy size={17} />{t("复制链接", "Copy link")}</button><button type="button" className="button secondary" onClick={()=>share(true)}><Share2 size={17} />{t("分享给朋友", "Share")}</button><button type="button" className="text-button" onClick={()=>{ void refresh(); }}>{t("刷新奖励", "Refresh rewards")}</button></div>
    {message ? <Notice>{message}</Notice> : null}
    <small>{t("¥29.9 → ¥23.92，含报告和 2 次追问。每单自动使用一张，不叠加、不折现，追加追问不参与；运营期间无日历到期。未付款取消或未交付全额退款后退回用券机会。仅限新账户；请勿自邀或批量注册。", "¥29.9 → ¥23.92, including the report and 2 follow-ups. One coupon applies automatically per order; no stacking, cash value or add-on discounts. No calendar expiry while operating. Cancelled unpaid orders and full refunds for undelivered reports restore the coupon. New accounts only; no self-invitations or bulk registrations.")}</small>
    <p><Link href="/terms">{t("查看完整邀请规则", "Read invitation terms")}</Link></p>
  </section>;
}
