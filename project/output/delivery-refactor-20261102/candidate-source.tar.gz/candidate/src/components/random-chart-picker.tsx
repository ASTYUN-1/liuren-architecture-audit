"use client";
import {useEffect,useId,useRef,useState} from "react";
import {useApp} from "./app-provider";
import {post} from "@/lib/api";
import {DIAL_BRANCHES,rotationForNumber,secureSector,type DialChart,type RandomSeed,type RandomSelection} from "@/lib/random-chart";

const coord=(r:number,i:number)=>{const a=(i*30-90)*Math.PI/180;return {x:Number((210+r*Math.cos(a)).toFixed(3)),y:Number((210+r*Math.sin(a)).toFixed(3))};};
export function RandomChartPicker({rules,onApply,open,onClose}:{rules:Record<string,string>;onApply:(selection:RandomSelection)=>void;open:boolean;onClose:()=>void}){
  const {t}=useApp(),id=useId();
  const [phase,setPhase]=useState<"idle"|"loading"|"spinning"|"settling"|"ready">("idle"),[seed,setSeed]=useState<RandomSeed|null>(null),[selection,setSelection]=useState<RandomSelection|null>(null),[error,setError]=useState(""),[applied,setApplied]=useState(false);
  const ring=useRef<SVGGElement>(null),frame=useRef(0),angle=useRef(0),speed=useRef(0),stopRequested=useRef(false),spinPhase=useRef(false),mounted=useRef(true),dialog=useRef<HTMLDialogElement>(null);
  useEffect(()=>{mounted.current=true;return ()=>{mounted.current=false;cancelAnimationFrame(frame.current);};},[]);
  useEffect(()=>{if(open){const el=dialog.current,opener=document.activeElement;el?.showModal();return ()=>{el?.close();if(opener instanceof HTMLElement&&opener.isConnected)opener.focus({preventScroll:true});};}},[open]);
  const paint=(degrees:number)=>{angle.current=degrees;ring.current?.style.setProperty("--dial-angle",`${degrees}deg`);};
  async function start(){
    if(spinPhase.current||phase==="loading")return;
    setError("");setApplied(false);setSelection(null);setPhase("loading");stopRequested.current=false;
    try {
      const next=await post<RandomSeed>("/api/chart/random",{action:"start",rules});if(!mounted.current)return;
      setSeed(next);const base=rotationForNumber(next.chart.monthGeneral,next.chart.number);paint(base);speed.current=0;spinPhase.current=true;setPhase("spinning");
      let last=performance.now();const reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
      const tick=(now:number)=>{const dt=Math.min((now-last)/1000,.05);last=now;speed.current=Math.min(reduce?40:240,speed.current+dt*(reduce?50:270));paint(angle.current+speed.current*dt);frame.current=requestAnimationFrame(tick);};
      frame.current=requestAnimationFrame(tick);
    }catch(e){if(mounted.current){setError(e instanceof Error?e.message:"Error");setPhase("idle");}}
  }
  async function stop(){
    if(!seed||stopRequested.current||!spinPhase.current)return;
    stopRequested.current=true;spinPhase.current=false;cancelAnimationFrame(frame.current);setPhase("settling");
    // Independent uniform sector; animation never weights the outcome or jumps back.
    const sector=secureSector(),number=(DIAL_BRANCHES.indexOf(seed.chart.monthGeneral)+sector)%12+1;
    const from=angle.current,mod=((from%360)+360)%360;
    let distance=(sector*30-mod+360)%360;if(distance<120)distance+=360;
    const target=from+distance;
    // Match the initial easing velocity to the running plate, then decelerate.
    const duration=matchMedia("(prefers-reduced-motion: reduce)").matches?0:Math.max(1200,Math.min(5000,3000*distance/Math.max(speed.current,180)));
    const velocity=Math.min(3,speed.current*duration/1000/distance);
    const begin=performance.now();
    const animation=new Promise<void>(resolve=>{const tick=(now:number)=>{const p=duration?Math.min((now-begin)/duration,1):1,ease=p*p*(3-2*p)+velocity*p*(1-p)*(1-p);paint(from+distance*ease);if(p<1)frame.current=requestAnimationFrame(tick);else resolve();};frame.current=requestAnimationFrame(tick);});
    try {
      const [result]=await Promise.all([post<RandomSelection>("/api/chart/random",{action:"stop",ticket:seed.ticket,number}),animation]);
      if(!mounted.current)return;setSelection(result);setPhase("ready");
    }catch(e){if(mounted.current){setError(e instanceof Error?e.message:"Error");setPhase("idle");}}
  }
  const chart:DialChart|null=selection?.chart||seed?.chart||null,locked=phase==="loading"||phase==="spinning"||phase==="settling";
  function close(){if(locked)return;onClose();}
  const view=<div className="random-workbench" aria-busy={phase==="loading"||phase==="settling"}>
    <div className="random-heading"><span>{t("天地盘 · 随机取刻","Heaven & earth · Random hour")}</span><small>{chart?`${chart.date} · 月将${chart.monthGeneral}`:t("地盘定，天盘转","Fixed earth, turning heaven")}</small></div>
    <svg className="random-dial" viewBox="0 0 420 420" role="img" aria-label={chart?`随机天地盘，月将${chart.monthGeneral}${selection?`加${chart.hourBranch}时`:""}`:t("十二地支天地圆盘","Circular heaven and earth chart")}>
      <defs><radialGradient id={`${id}-paper`}><stop stopColor="#fcfbf8"/><stop offset="1" stopColor="#eeeade"/></radialGradient></defs>
      <circle cx="210" cy="210" r="199" fill={`url(#${id}-paper)`} className="dial-rim"/><circle cx="210" cy="210" r="192" className="dial-hairline"/>
      {Array.from({length:120},(_,i)=>{const a=coord(i%10===0?180:186,i/10),b=coord(190,i/10);return <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} className={i%10===0?"dial-tick-major":"dial-tick"}/>;})}
      <circle cx="210" cy="210" r="151" className="dial-hairline"/>
      {DIAL_BRANCHES.map((b,i)=>{const p=coord(166,i),a=coord(151,i+.5),z=coord(180,i+.5);return <g key={b}><line x1={a.x} y1={a.y} x2={z.x} y2={z.y} className="dial-sector"/><text x={p.x} y={p.y} className={selection&&chart?.hourBranch===b?"dial-earth dial-chosen":"dial-earth"}>{b}</text></g>;})}
      <g ref={ring} className="dial-heaven-ring" style={{"--dial-angle":`${angle.current}deg`} as React.CSSProperties}>
        <circle cx="210" cy="210" r="144" className="dial-inner-rim"/><circle cx="210" cy="210" r="105" className="dial-hairline"/>
        {DIAL_BRANCHES.map((b,i)=>{const p=coord(124,i),a=coord(106,i+.5),z=coord(143,i+.5);return <g key={b}><line x1={a.x} y1={a.y} x2={z.x} y2={z.y} className="dial-sector"/><g className="dial-counter" style={{transformOrigin:`${p.x}px ${p.y}px`}}><text x={p.x} y={p.y} className={chart?.monthGeneral===b?"dial-heaven dial-month":"dial-heaven"}>{b}</text>{chart?.monthGeneral===b?<text x={p.x} y={p.y+18} className="dial-month-label">月将</text>:null}</g></g>;})}
      </g>
      {selection?chart?.palaces.map((p,i)=>{const q=coord(86,i);return <text key={p.earth} x={q.x} y={q.y} className="dial-general">{p.general}</text>;}):null}
      <circle cx="210" cy="210" r="54" className="dial-center"/>
      <text x="210" y="202" className="dial-center-title">{selection?`${chart?.monthGeneral}加${chart?.hourBranch}`:"月将加时"}</text><text x="210" y="225" className="dial-center-subtitle">{selection?`活时 · ${chart?.hourBranch}时`:phase==="spinning"?t("点击停止取刻","Stop to choose"):t("天地有序","Heaven & earth")}</text>
      <path d="M204 12 L210 21 L216 12" className="dial-north"/>
    </svg>
    <div className="random-status" aria-live="polite">{phase==="spinning"?t("天盘转动中，准备好后停止。","Stop the turning heaven plate when ready."):phase==="settling"?t("正在收盘并校验课式…","Settling and checking the chart…"):selection?`${selection.chart.monthGeneral}将加${selection.chart.hourBranch}时 · 报数 ${selection.number}`:t("冻结当前日期与月将，从十二个活时中随机取一刻。","Freeze the date and month general, then choose one of twelve hours.")}</div>
    {selection?<div className="random-chart-result"><div className="random-pillars">{selection.chart.pillars.join("　")}</div><dl><dt>{t("三传","Transmissions")}</dt><dd>{selection.chart.transmissions.map(v=>v[3]).join(" → ")}</dd><dt>{t("四课上神","Upper lessons")}</dt><dd>{selection.chart.lessons.map(v=>v[1]).join("　")}</dd><dt>{t("旬空","Void")}</dt><dd>{selection.chart.voidBranches.join("、")}</dd></dl><small>{t("应用后沿用此盘分析，不按提交时刻重新起课。","Apply to retain this chart for analysis, without recasting at submission.")}</small></div>:null}
    {error?<p role="alert" className="error-text">{error}</p>:null}
    <div className="random-actions"><button type="button" className={`button ${phase==="spinning"?"accent":"secondary"}`} disabled={phase==="loading"||phase==="settling"} onClick={phase==="spinning"?stop:start}>{phase==="loading"?t("正在准备…","Preparing…"):phase==="spinning"?t("停止 · 确定盘面","Stop · Confirm chart"):phase==="settling"?t("正在定盘…","Settling…"):selection?t("重新随机","Try again"):t("随机取刻","Random hour")}</button>{selection?<button type="button" className="button primary" onClick={()=>{onApply(selection);setApplied(true);onClose();}}>{applied?t("已应用 · 再次应用","Applied · Apply again"):t("应用此盘","Apply chart")}</button>:null}</div>
  </div>;
  return open?<dialog ref={dialog} className="random-dialog" aria-labelledby={`${id}-title`} onCancel={e=>{e.preventDefault();close();}}><div className="random-dialog-header"><h2 id={`${id}-title`}>{t("随机起课","Random chart")}</h2><button className="icon-button" type="button" aria-label={t("关闭随机起课","Close random chart")} disabled={locked} onClick={close}>×</button></div>{view}</dialog>:null;
}
