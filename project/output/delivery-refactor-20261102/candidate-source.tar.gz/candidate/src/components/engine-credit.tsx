"use client";
import {ArrowUpRight} from 'lucide-react';
import {useApp} from './app-provider';
export function EngineCredit(){
 const {t}=useApp();
 return <aside className="engine-credit" aria-label={t('排盘引擎支持','Chart engine credit')}><div><span className="section-kicker">{t('排盘引擎支持','CHART ENGINE')}</span><p><strong>{t('同仁大有','Tongren Dayou')}</strong><span>{t('提供六壬排盘引擎技术支持','Liu Ren chart engine developer')}</span></p></div><div className="engine-credit-contact"><a href="https://6ren.cn/" target="_blank" rel="noopener noreferrer">{t('开发者网站','Developer website')} <ArrowUpRight size={14}/></a><span>QQ · 825941952</span></div></aside>;
}
