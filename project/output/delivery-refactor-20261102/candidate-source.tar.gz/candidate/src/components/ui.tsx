"use client";
import type { ReactNode } from "react";
import { useApp } from "./app-provider";
import type { CaseStatus, OrderStatus, TaskStatus } from "@/server/contracts";
export function Notice({ children, kind = "info" }: { children: ReactNode; kind?: "info" | "error" | "success" }) { return <div className={`notice ${kind}`} role={kind === "error" ? "alert" : "status"}>{children}</div>; }
export function Loading() { const { t } = useApp(); return <p className="loading" role="status"><span className="spinner" />{t("正在读取…", "Loading…")}</p>; }
const states: Record<string, [string, string]> = { paymentFrozen:["支付渠道核查中","Payment under review"], draft: ["待确认", "Draft"], awaitingPayment: ["待付款", "Awaiting payment"], queued: ["等待解读", "Queued"], running: ["正在解读", "Working"], needsClarification: ["需要补充信息", "Needs clarification"], ready: ["报告已完成", "Report ready"], failed: ["暂未完成", "Failed"], deleted: ["回收站", "Deleted"], pending: ["待付款", "Pending"], submitted: ["等待核验到账", "Awaiting verification"], paid: ["已到账", "Paid"], cancelled: ["已取消", "Cancelled"], refundPending: ["退款处理中", "Refund pending"], partiallyRefunded: ["部分已退款", "Partially refunded"], refunded: ["已退款", "Refunded"], succeeded: ["已完成", "Completed"] };
export function Status({ status }: { status: CaseStatus | OrderStatus | TaskStatus | string }) { const { t } = useApp(); const label = states[status] || [status, status]; return <span className={`status status-${status}`}>{t(...label)}</span>; }
export function Empty({ title, children }: { title: string; children?: ReactNode }) { return <div className="empty"><div className="empty-mark" aria-hidden="true">问</div><h2>{title}</h2>{children}</div>; }
export function PageHeading({ title, subtitle, action }: { title: ReactNode; subtitle?: string; action?: ReactNode }) { return <div className="page-heading"><div><h1>{title}</h1>{subtitle ? <p>{subtitle}</p> : null}</div>{action}</div>; }
