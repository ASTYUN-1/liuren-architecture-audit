"use client";
import {Fragment,useEffect,useRef,useState} from 'react';
import Link from 'next/link';
import {KeyRound} from 'lucide-react';
import {api,post} from '@/lib/api';
import {ADVISORS} from '@/lib/advisors';
import type {readConversationShare} from '@/server/conversation-sharing';
import {useApp} from './app-provider';
import {Notice,Loading,PageHeading} from './ui';
import {Markdown} from './markdown';
import {ConversationMessage} from './conversation-message';
import {dialogueTime} from '@/lib/case-input-display';
import './partner-redemption.css';
type Shared=Awaited<ReturnType<typeof readConversationShare>>;
function SharedArchive({data}:{data:Shared}){
 const {t,locale}=useApp();
 return <article className="shared-conversation">
  <h2>{data.title}</h2>
  <ConversationMessage role="user" label={t('用户 · 提问','User · Question')}>
   <div className="preserve-lines">{data.question}</div>
   {data.participants?.length?<dl className="conversation-input-fields">{data.participants.map((person:any,i:number)=><div key={i}><dt>{t('人物','Person')} {i+1}</dt><dd>{[person.role,person.gender==='male'?t('男','Male'):person.gender==='female'?t('女','Female'):'',person.birthYear!=null?person.birthYear+t('年生',' born'):''].filter(Boolean).join(' · ')}</dd></div>)}</dl>:null}
  </ConversationMessage>
  {data.report?<ConversationMessage role="assistant" label={t('AI · ','AI · ')+(data.report.title||t('主报告','Report'))}>{data.report.content}</ConversationMessage>:null}
  {data.turns.map((turn:any,i:number)=><Fragment key={i}>
   {turn.question?<ConversationMessage role="user" label={t('用户 · 提问或补充','User · Question or clarification')} time={dialogueTime(turn.createdAt,locale)}>{turn.question}</ConversationMessage>:null}
   {turn.clarification?<ConversationMessage role="assistant" label={t('AI · 请求补充','AI · Clarification request')}>{turn.clarification}</ConversationMessage>:null}
   {turn.answer?<ConversationMessage role="assistant" label={t('AI · 回答','AI · Answer')}>{turn.answer}</ConversationMessage>:null}
  </Fragment>)}
 </article>;
}
export function PractitionerWorkspace({allowCompletion=false,archiveStyle=false}:{allowCompletion?:boolean;archiveStyle?:boolean}){
 const {me,t,loading}=useApp(),[roles,setRoles]=useState<{advisor_id:string}[]>([]),[code,setCode]=useState(''),[data,setData]=useState<Shared|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[completing,setCompleting]=useState(false),[completion,setCompletion]=useState(''),generation=useRef(0);
 const official=!!me?.practitioner?.canReadShared;
 useEffect(()=>{generation.current++;setData(null);setCode('');setError('');setCompletion('');setRoles([]);if(!official)return;let live=true;api<{advisor_id:string}[]>('/api/practitioner').then(r=>{if(live)setRoles(r);}).catch(e=>{if(live)setError(e.message);});return()=>{live=false;};},[me?.user.id,official]);
 async function complete(){
  if(busy||!allowCompletion||!data?.booking.canComplete)return;
  const current=++generation.current;setBusy(true);setCompleting(true);setError('');setCompletion('');
  try{
   const result=await post<{status:string;chargedUnits:number;alreadyCompleted:boolean}>('/api/beta/practitioner/complete',{code,serviceCompleted:true});
   if(generation.current===current){setData(previous=>previous?{...previous,booking:{...previous.booking,status:result.status,chargedUnits:result.chargedUnits,canComplete:false}}:previous);setCompletion(t('已完成并核销，扣除','Completed and redeemed: ')+(result.chargedUnits/10)+t('积分。本次冻结积分已结算。',' credits. The reserved credits have been settled.'));}
  }catch(e){if(generation.current===current)setError(e instanceof Error?e.message:'Error');}
  finally{setBusy(false);setCompleting(false);}
 }
 if(loading)return <Loading/>;
 if(!me)return <div className="page-container narrow"><PageHeading title={t('合作工作台','Partner workspace')}/><Link className="button primary" href="/login">{t('请先登录','Sign in')}</Link></div>;
 return <div className="page-container practitioner-page"><PageHeading title={t('合作工作台','Partner workspace')} subtitle={t('验证分享码，阅读用户授权的档案。','Verify a share code to read an authorized case.')} action={<Link className="button secondary" href="/account">{t('返回个人主页','My profile')}</Link>}/>{error?<Notice kind="error">{error}</Notice>:null}
 {!official?<section className="notice"><p>{t('此工作台仅供官方合作卦师验证分享档案。个人问事与专业解读请使用网站现有入口。','This workspace is for official partners to verify shared cases. Use the existing site navigation for personal readings.')}</p><Link href="/account">{t('返回我的问衡','Back to my account')} →</Link></section>:<>
 {official?<section className="practitioner-reader"><div className="practitioner-reader-title"><KeyRound size={22}/><div><h2>{t('打开用户分享的档案','Open a shared case')}</h2><p className="muted">{roles.map(r=>ADVISORS.find(a=>a.id===r.advisor_id)?.name).join(' · ')}</p></div></div><form onSubmit={async e=>{e.preventDefault();if(busy)return;const current=++generation.current;setBusy(true);setData(null);setError('');setCompletion('');try{const result=await post<Shared>('/api/practitioner',{code});if(generation.current===current)setData(result);}catch(e){if(generation.current===current)setError(e instanceof Error?e.message:'Error');}finally{setBusy(false);}}}><label htmlFor="shared-case-code">{t('档案分享码','Case share code')}</label><div className={`share-code-entry${allowCompletion?' has-completion':''}`}><input id="shared-case-code" disabled={busy} required maxLength={80} value={code} autoComplete="off" spellCheck={false} placeholder="WHC-…" onChange={e=>{generation.current++;setCode(e.target.value);setData(null);setCompletion('');setError('');}}/><button className="button primary" disabled={busy||!code.trim()}>{busy&&!completing?t('验证中…','Verifying…'):t('验证并查看','Verify & view')}</button>{allowCompletion?<button type="button" className="button accent" disabled={busy||!data?.booking.canComplete} onClick={()=>void complete()}>{completing?t('正在核销…','Redeeming…'):data?.booking.status==='completed'?t('已完成','Completed'):t('完成并核销','Complete & redeem')}</button>:null}</div>{allowCompletion?<p className="partner-completion-note">{data?data.booking.status==='completed'?t('本预约已完成，已扣','This booking is complete. Charged: ')+(data.booking.chargedUnits/10)+t('积分。',' credits.'):data.booking.canComplete?t('已验证。服务完成后点击「完成并核销」，将扣除本次冻结的','Verified. When the service is finished, Complete & redeem will settle the reserved ')+(data.booking.units/10)+t('积分。',' credits.'):t('此预约当前不能核销，请联系运营者核对状态。','This booking cannot be redeemed. Contact the operator.'):t('先验证分享码；服务实际完成后，再点击「完成并核销」。','Verify the share code first, then complete and redeem after the service has been provided.')}</p>:null}{completion?<Notice>{completion}</Notice>:null}<p className="muted">{t('仅限指定卦师身份；已撤销、到期或取消预约的授权不能读取。','Only the assigned practitioner may read. Revoked, expired or cancelled authorizations cannot be opened.')}</p>{data?<button type="button" className="text-button" disabled={busy} onClick={()=>{generation.current++;setData(null);setCode('');setCompletion('');setError('');}}>{t('清除当前内容','Clear view')}</button>:null}</form></section>:null}
 {official&&data?archiveStyle?<SharedArchive data={data}/>:<article className="shared-conversation"><h2>{data.title}</h2><h3>{t('用户问题','Question')}</h3><p className="preserve-lines">{data.question}</p>{data.participants?.length?<p>{data.participants.map((p:any)=>[p.role,p.gender==='male'?'男':p.gender==='female'?'女':'',p.birthYear].filter(Boolean).join(' / ')).join('；')}</p>:null}{data.report?<><h3>{data.report.title||t('主报告','Report')}</h3><Markdown>{data.report.content}</Markdown></>:null}{data.turns.map((turn:any,i:number)=><section key={i}><h3>{t('对话','Dialogue')} {i+1}</h3><p className="preserve-lines">{turn.question}</p>{turn.clarification?<p>{turn.clarification}</p>:null}{turn.answer?<Markdown>{turn.answer}</Markdown>:null}</section>)}</article>:null}</>}</div>;
}
