"use client";
import {useEffect,useState} from 'react';
import {useApp} from './app-provider';
import {api,date} from '@/lib/api';
import type {adminCaseView} from '@/server/users';
import {Loading,Notice,Status} from './ui';
import {Modal} from './modal';
import {Markdown} from './markdown';
export function AdminCaseReader({id,onClose}:{id:string;onClose:()=>void}){
 const {t,locale}=useApp(),[data,setData]=useState<Awaited<ReturnType<typeof adminCaseView>>|null>(null),[error,setError]=useState('');
 useEffect(()=>{let live=true;setData(null);setError('');api<Awaited<ReturnType<typeof adminCaseView>>>('/api/admin/users?caseId='+encodeURIComponent(id)).then(v=>{if(live)setData(v);}).catch(e=>{if(live)setError(e.message);});return()=>{live=false;};},[id]);
 return <Modal title={t('档案与对话','Case conversation')} onClose={onClose}><div className="admin-case-reader">{error?<Notice kind="error">{error}</Notice>:data?<><h3>{data.title}</h3><p>{data.userName} · {data.userEmail} · <Status status={data.status}/></p><h4>{t('原始问题','Original question')}</h4><p className="preserve-lines">{data.question}</p>{data.report?<Markdown>{data.report.content}</Markdown>:<p className="muted">{t('尚无已完成报告','No completed report')}</p>}{data.turns.map(turn=><section className="turn" key={turn.id}><small>{date(String(turn.createdAt),locale)} · {t('版本','Version')} {turn.inputVersion}</small><h4>{turn.question}</h4>{turn.answer?<Markdown>{turn.answer}</Markdown>:<Status status={turn.status}/>} {turn.clarification?<Notice>{turn.clarification}</Notice>:null}</section>)}</>:<Loading/>}</div></Modal>;
}
