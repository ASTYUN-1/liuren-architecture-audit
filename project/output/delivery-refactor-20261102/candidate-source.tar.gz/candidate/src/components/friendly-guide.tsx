"use client";
import { useEffect, useState } from "react";
import { useApp } from "./app-provider";
import "./read-first-hint.css";

const dismissedKey = "wenheng-guide-dismissed-v1";
// Keep the choice during this page session even if browser storage is blocked.
let dismissedForSession = false;

export function GuideMascot({ thinking = false }: { thinking?: boolean }) {
  return <div className={`guide-mascot ${thinking ? "is-thinking" : ""}`} aria-hidden="true"><div className="mascot-body"><span className="mascot-brow"/><span className="mascot-eyes">• •</span><span className="mascot-mouth"/><span className="mascot-book">问</span></div><span className="mascot-hand">☞</span><span className="mascot-spark">✦</span></div>;
}

export function FriendlyGuide() {
  const { t } = useApp(); const [hidden, setHidden] = useState<boolean | null>(null);
  useEffect(() => {
    try { setHidden(dismissedForSession || localStorage.getItem(dismissedKey) === "1"); }
    catch { setHidden(dismissedForSession); }
    const sync = (event: StorageEvent) => { if (event.key === dismissedKey || event.key === null) { dismissedForSession = event.newValue === "1"; setHidden(dismissedForSession); } };
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, []);
  function dismiss(button: HTMLButtonElement) {
    dismissedForSession = true;
    try { localStorage.setItem(dismissedKey, "1"); } catch { /* Still dismiss when storage is unavailable. */ }
    button.closest("form")?.querySelector<HTMLButtonElement>(".read-before")?.focus();
    setHidden(true);
  }
  // Wait for the stored choice before showing animation, avoiding a return-visit flash.
  if (hidden !== false) return null;
  return <aside className="read-first-hint" aria-label={t("新手提示", "Getting started")}>
    <svg className="read-first-arrow" viewBox="0 0 72 32" fill="none" aria-hidden="true"><path d="M5 24C21 24 29 10 63 10M52 2L64 10L54 21" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
    <button type="button" className="read-first-dismiss" onClick={event => dismiss(event.currentTarget)}>{t("不再显示", "Hide tip")}</button>
  </aside>;
}
