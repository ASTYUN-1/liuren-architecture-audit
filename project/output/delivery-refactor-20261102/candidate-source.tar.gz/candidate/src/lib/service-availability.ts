export type PaymentUnavailableReason = 'paymentsPaused' | 'paymentCodeMissing' | 'aiPaused' | 'modelMissing' | 'emailUnavailable' | 'workerOffline';
export type AiUnavailableReason = 'aiPaused' | 'modelMissing' | 'workerOffline';
export interface ServiceView {
  aggregatePaymentsEnabled?: boolean;
  workerOnline: boolean;
  paymentsEnabled: boolean;
  aiEnabled: boolean;
  paymentQrUrl: string;
  paymentQrIsPlaceholder: boolean;
  smtpConfigured: boolean;
  resultNotificationsEnabled?: boolean;
  modelConfigured: boolean;
  paymentUnavailableReason?: PaymentUnavailableReason | null;
  aiUnavailableReason?: AiUnavailableReason | null;
}

export function paymentUnavailableMessage(reason: PaymentUnavailableReason | null | undefined, locale = 'zh') {
  const messages: Record<PaymentUnavailableReason, [string, string]> = {
    paymentsPaused: ['运营者暂未开放新订单；你的档案和已购买次数会保留。', 'New orders are paused. Your case and purchased credits are preserved.'],
    paymentCodeMissing: ['收款方式尚未配置完成，暂不能付款；请保留档案稍后再试。', 'The payment method is not ready. Keep your case and try again later.'],
    aiPaused: ['AI 解读暂时暂停，新订单暂不开放；已有权益保留。', 'AI interpretations are paused, so new orders are unavailable. Existing credits are preserved.'],
    modelMissing: ['解读服务正在维护，暂不接受新付款；已有权益保留。', 'Interpretations are under maintenance. New payments are unavailable and existing credits are preserved.'],
    emailUnavailable: ['账户邮件服务正在维护，暂不接受新付款；已有权益保留。', 'Account email delivery is under maintenance. New payments are unavailable and existing credits are preserved.'],
    workerOffline: ['解读处理服务暂时离线，恢复后可继续购买；已有权益保留。', 'Interpretation processing is temporarily offline. You can purchase when it recovers; existing credits are preserved.'],
  };
  return (messages[reason || 'paymentsPaused'] || messages.paymentsPaused)[locale === 'en' ? 1 : 0];
}

export function interpretationUnavailableMessage(reason: AiUnavailableReason | null | undefined, locale = 'zh') {
  const messages: Record<AiUnavailableReason, [string, string]> = {
    aiPaused: ['AI 解读暂时暂停，已有权益保留，恢复后可以继续。', 'AI interpretations are paused. Your credits are preserved and can be used when service resumes.'],
    modelMissing: ['解读服务正在维护，已有权益保留，暂不扣除追问次数。', 'Interpretations are under maintenance. Your credits are preserved and no follow-up is deducted.'],
    workerOffline: ['解读处理服务暂时离线，已有权益保留，暂不扣除追问次数。', 'Interpretation processing is temporarily offline. Your credits are preserved and no follow-up is deducted.'],
  };
  return (messages[reason || 'aiPaused'] || messages.aiPaused)[locale === 'en' ? 1 : 0];
}
