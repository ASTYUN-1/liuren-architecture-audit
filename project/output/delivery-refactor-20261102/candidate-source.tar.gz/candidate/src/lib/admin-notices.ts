export type AdminNoticeModule='users'|'practitioners'|'points'|'tasks'|'payments';
export interface AdminNotice {key:string;label:string;at:string}
export interface AdminNotices {modules:Partial<Record<AdminNoticeModule,{pending:number;unread:number;items:AdminNotice[]}>>}
