import type { CaseInput } from "../server/contracts";

export function dialogueTime(value?: string, locale = "zh"): string | undefined {
  if (!value || !Number.isFinite(Date.parse(value))) return undefined;
  return new Intl.DateTimeFormat(locale === "zh" ? "zh-CN" : "en-GB", {
    timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).format(new Date(value)) + (locale === "zh" ? "（北京时间）" : " (Beijing time)");
}

/** User-facing submitted fields only; never serialize receipts or internal chart data. */
export function caseInputFields(input: CaseInput, locale = "zh"): [string, string][] {
  const t = (zh: string, en: string) => locale === "zh" ? zh : en;
  const methods = { time: t("时间起课", "By time"), number: t("报数起课", "By number"), solar: t("真太阳时", "True solar time"), pillars: t("四柱起课", "By pillars") };
  const fields: [string, string][] = [[t("起课方式", "Chart method"), input.random ? t("随机取刻（已保存）", "Random hour (saved)") : methods[input.mode]]];
  if (input.time) fields.push([t("起课时间", "Chart time"), dialogueTime(input.time, locale) ?? input.time]);
  if (input.timeZone) fields.push([t("所选时区", "Selected time zone"), input.timeZone]);
  if (input.number != null) fields.push([t("报数", "Number"), String(input.number)]);
  if (input.longitude != null) fields.push([t("经度", "Longitude"), `${input.longitude}°`]);
  if (input.pillars) {
    const p = input.pillars;
    fields.push([t("四柱", "Four pillars"), `${p.year} / ${p.month} / ${p.day} / ${p.hour}`], [t("月将", "Monthly general"), p.monthGeneral]);
    if (p.actualDate) fields.push([t("指定日期", "Specified date"), p.actualDate]);
  }
  for (const [index, person] of (input.participants ?? []).entries()) {
    const details = [person.role, person.gender === "male" ? t("男", "Male") : person.gender === "female" ? t("女", "Female") : undefined,
      person.birthYear != null ? `${person.birthYear}${t("年生", " born")}` : undefined,
      person.birthDate, person.lifeBranch ? `${t("年命", "Life branch")} ${person.lifeBranch}` : undefined].filter(Boolean);
    fields.push([`${t("人物", "Person")} ${index + 1}`, details.join(" · ")]);
  }
  if (input.chartRequest) fields.push([t("更正要求", "Correction request"), input.chartRequest]);
  const ruleNames: Record<string, string> = { yuejiang: t("月将规则", "Monthly general rule"), guiren: t("贵人规则", "Nobleman rule"), zhouye: t("昼夜规则", "Day/night rule"), shehai: t("涉害规则", "Harm rule") };
  for (const [key, label] of Object.entries(ruleNames)) if (input.rules?.[key]) fields.push([label, input.rules[key]]);
  return fields;
}
