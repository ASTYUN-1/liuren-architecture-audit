import "server-only";
import data from "./case-showcase-data.json";
import type { ShowcaseCase } from "./case-showcase-types";

export const showcaseCases = data as ShowcaseCase[];
