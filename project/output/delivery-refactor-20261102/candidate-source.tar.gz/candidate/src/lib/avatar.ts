export const MAX_AVATAR_BYTES = 2 * 1024 * 1024;
const avatarUrl = /^\/avatars\/[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}\.webp$/;
export function safeAvatarUrl(value: unknown): string | null {
  return typeof value === "string" && avatarUrl.test(value) ? value : null;
}
