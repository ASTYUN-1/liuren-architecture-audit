export type ShowcaseMessage = {
  id: string;
  role: "user" | "assistant";
  time: string;
  content: string;
  feedback: boolean;
};
export type ShowcaseCase = {
  slug: string;
  category: string;
  title: string;
  scope: string;
  messages: ShowcaseMessage[];
};
