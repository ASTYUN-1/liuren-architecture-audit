export const ADVISORS=[{id:'congkui',name:'从魁'},{id:'liurenshi',name:'六壬师'},{id:'qing',name:'清'},{id:'wenwen',name:'温温'},{id:'ming',name:'明'}] as const;
