export const internalEmailDomain = 'account.wenheng.invalid';
export const hasRealEmail = (email: string | null | undefined) => !!email && !email.toLowerCase().endsWith('@' + internalEmailDomain);
export const validUsername = (value: string) => /^[a-z0-9_]{4,24}$/.test(value) && !['admin','administrator','root','system','support','wenheng','operator'].includes(value);
