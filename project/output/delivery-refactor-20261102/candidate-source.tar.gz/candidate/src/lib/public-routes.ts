/** Canonical site pages; API/auth/static requests are never rewritten. */
export function workspaceRoute(path:string):string|undefined{
 const exact:Record<string,string>={'/':'','/cases':'cases','/wallet':'wallet','/chart':'chart','/assistance':'assistance','/help':'help','/guide':'help','/terms':'terms','/privacy':'privacy','/account':'account','/account/settings':'account','/practitioner':'practitioner','/admin':'admin','/payments':'payments','/examples':'examples'};
 if(Object.prototype.hasOwnProperty.call(exact,path))return exact[path];
 if(/^\/cases\/[a-f0-9-]{36}$/.test(path)||/^\/examples\/[a-z0-9-]+$/.test(path))return path.slice(1);
}
export function workspacePath(route:string){return route?'/'+route:'/';}
