export const MONITOR_NODES=[
 {id:'hk',name:'香港 VPS',en:'Hong Kong VPS',role:'网站公网入口',roleEn:'Public entrance'},
 {id:'cn',name:'阿里云 VPS',en:'Alibaba Cloud VPS',role:'其他业务与备用转发',roleEn:'Other services and relay'},
 {id:'windows',name:'旧电脑 · Windows',en:'Windows host',role:'物理内存、硬盘与虚拟机',roleEn:'Physical host and VM'},
 {id:'ubuntu',name:'业务虚拟机 · Ubuntu',en:'Ubuntu business VM',role:'网站、数据库与 AI worker',roleEn:'Website, database and AI worker'},
] as const;
export type MonitorNodeId=typeof MONITOR_NODES[number]['id'];
export type ServiceState='active'|'inactive'|'failed'|'activating'|'unknown';
export interface ResourceSnapshot {
 node:MonitorNodeId;at:string;bootId:string;uptimeSeconds:number;
 cpu:{percent:number|null;cores:number;load1:number|null;iowaitPercent:number|null};
 memory:{total:number;available:number;swapTotal:number;swapUsed:number};
 disks:{id:string;total:number;available:number}[];
 network:{rxBps:number|null;txBps:number|null;dayRx:number;dayTx:number;monthRx:number;monthTx:number;trackingSince:string;interfaceCount:number};
 services:{id:string;state:ServiceState}[];
 backup?:{status:'success'|'failed'|'unknown';lastSuccessAt:string|null};
 storage?:{id:string;bytes:number}[];
 processes?:{id:string;bytes:number}[];
 vm?:{state:'running'|'off'|'other';assignedBytes:number;startupBytes:number;dynamic:boolean};
}
export interface MonitorPoint {at:string;cpu:number|null;memory:number;rx:number|null;tx:number|null}
export interface MonitorAlert {node:MonitorNodeId|'business';level:'warning'|'critical'|'unknown';code:string}
export interface MonitorNode {id:MonitorNodeId;sample:ResourceSnapshot|null;receivedAt:string|null;stale:boolean;history:MonitorPoint[]}
export interface ResourceMonitorView {at:string;range:'1h'|'24h';nodes:MonitorNode[];alerts:MonitorAlert[];business:{queued:number;running:number;failed24h:number;completed24h:number;oldestQueuedAt:string|null;workerAt:string|null;workerOnline:boolean;databaseMs:number};retentionDays:7;sampleSeconds:15}
export const MONITOR_SERVICE_NAMES:Record<string,[string,string]>={web:['网站','Website'],worker:['AI worker','AI worker'],database:['数据库','Database'],relay:['网站转发','Website relay'],nginx:['HTTPS 入口','HTTPS entrance'],frps:['FRP 转发','FRP relay'],derper:['DERP 服务','DERP service'],otherWeb:['随手记服务','Suishou service'],legacyRelay:['其他网站入口','Other website entrance']};
export const MONITOR_STORAGE_NAMES:Record<string,[string,string]>={releases:['应用发布版本','App releases'],resources:['解读资料','Reading resources'],backups:['加密备份','Encrypted backups'],database:['数据库文件','Database files'],avatars:['用户头像','Avatars'],virtualDisk:['虚拟磁盘文件','Virtual disk file']};
export function monitorPoint(s:ResourceSnapshot):MonitorPoint{return {at:s.at,cpu:s.cpu.percent,memory:100*(1-s.memory.available/s.memory.total),rx:s.network.rxBps,tx:s.network.txBps};}
/** Unknown and stale samples never count as healthy. CPU needs five sustained minutes. */
export function monitorAlerts(nodes:MonitorNode[],workerOnline:boolean):MonitorAlert[]{
 const alerts:MonitorAlert[]=[];
 for(const n of nodes){const s=n.sample;if(!s||n.stale){alerts.push({node:n.id,level:'unknown',code:'stale'});continue;}
  const available=s.memory.available/s.memory.total;if(available<.1)alerts.push({node:n.id,level:available<.05?'critical':'warning',code:'memory'});
  if(s.disks.some(d=>d.available/d.total<.15))alerts.push({node:n.id,level:s.disks.some(d=>d.available/d.total<.05)?'critical':'warning',code:'disk'});
  const end=Date.parse(s.at),recent=n.history.filter(p=>Date.parse(p.at)>=end-360000);
  if(recent.length>=6&&end-Date.parse(recent[0].at)>=300000&&recent.every(p=>p.cpu!==null&&p.cpu>=85)&&recent.every((p,i)=>i===0||Date.parse(p.at)-Date.parse(recent[i-1].at)<90000))alerts.push({node:n.id,level:'warning',code:'cpu'});
  if(s.services.some(v=>v.state!=='active'))alerts.push({node:n.id,level:'critical',code:'service'});
  if(s.vm&&s.vm.state!=='running')alerts.push({node:n.id,level:'critical',code:'vm'});
  if(s.backup?.status==='failed')alerts.push({node:n.id,level:'critical',code:'backupFailed'});
  if(n.id==='ubuntu'&&(!s.backup?.lastSuccessAt||end-Date.parse(s.backup.lastSuccessAt)>3600000))alerts.push({node:n.id,level:'warning',code:'backupLate'});
 }
 if(!workerOnline)alerts.push({node:'business',level:'critical',code:'worker'});
 return alerts;
}
