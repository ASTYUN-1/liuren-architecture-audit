// Presentation estimate only. A real delivered result is the only route to 100.
const milestones = [[0,0],[8,2],[22,9],[30,9],[55,19],[75,29],[90,29],[135,47],[165,56],[180,56],[240,72],[300,83],[360,88],[420,90]] as const;
// Keep fractional widths moving between updates. The three short intervals give
// visible advances at stage boundaries without making the whole bar jump.
const smoothMilestones = [[0,0],[12,2],[45,7],[46,10],[100,23],[130,29],[131,32],[200,49],[270,64],[285,69],[286,73],[360,84],[420,90]] as const;

export function estimateAnalysisProgress(taskId:string,createdAt:string,now:number,variedCeiling=false):number {
  const started=Date.parse(createdAt);
  if(!Number.isFinite(started)||!Number.isFinite(now))return 0;
  let seed=0;
  for(let i=0;i<taskId.length;i++)seed=(Math.imul(seed,31)+taskId.charCodeAt(i))>>>0;
  const seconds=Math.max(0,(now-started)/1000)/(0.9+(seed%21)/100);
  if(variedCeiling){
    for(let i=1;i<smoothMilestones.length;i++){
      const [end,value]=smoothMilestones[i], [start,previous]=smoothMilestones[i-1];
      if(seconds<=end)return previous+(value-previous)*(seconds-start)/(end-start);
    }
    // A random task ID gives a stable per-task stopping point; refreshes keep it.
    const ceiling=90+(seed%10);
    return Math.min(ceiling,90+(ceiling-90)*Math.min(1,(seconds-420)/180));
  }
  for(let i=1;i<milestones.length;i++){
    const [end,value]=milestones[i], [start,previous]=milestones[i-1];
    if(seconds<=end)return Math.floor(previous+(value-previous)*(seconds-start)/(end-start));
  }
  return 90;
}
