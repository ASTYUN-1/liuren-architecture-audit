export const DIAL_BRANCHES=[..."子丑寅卯辰巳午未申酉戌亥"];
export interface DialChart {
  date:string;time:string;monthGeneral:string;hourBranch:string;number:number;
  pillars:string[];voidBranches:string[];
  palaces:{earth:string;heaven:string;general:string}[];
  lessons:string[][];transmissions:string[][];
}
export interface RandomSelection {ticket:string;time:string;number:number;rules:Record<string,string>;chart:DialChart}
export interface RandomSeed {ticket:string;chart:DialChart}
export function rotationForNumber(monthGeneral:string,number:number){return ((number-1-DIAL_BRANCHES.indexOf(monthGeneral)+12)%12)*30;}
export function numberForRotation(monthGeneral:string,degrees:number){const shift=((Math.round(degrees/30)%12)+12)%12;return (DIAL_BRANCHES.indexOf(monthGeneral)+shift)%12+1;}
export function secureSector(){const a=new Uint32Array(1),limit=Math.floor(0x100000000/12)*12;do{crypto.getRandomValues(a);}while(a[0]>=limit);return a[0]%12;}
