// Server billing policy. Never import this module into client components. Old orders keep the immutable snapshot stored with their hold.
export const POINTS_PRICING={version:'points-v4',initialBase:30,followupBase:5,initialMarkup:5,followupMarkup:3,human:150,initialReserve:100,followupReserve:0} as const;
export function quotePoints(kind:'initial'|'followup',discountPercent=100){
 const initial=kind==='initial';
 return {version:POINTS_PRICING.version,pricingMode:'metered',settlementMode:initial?'reserved':'after_delivery',baseUnits:(initial?POINTS_PRICING.initialBase:POINTS_PRICING.followupBase)*10,reserveUnits:Math.ceil((initial?POINTS_PRICING.initialReserve:POINTS_PRICING.followupReserve)*10*discountPercent/100),discountPercent,markup:initial?POINTS_PRICING.initialMarkup:POINTS_PRICING.followupMarkup,priceVersion:'deepseek-flash-public-20261015',rateNote:'按API返回用量及公示价表核算'};
}
