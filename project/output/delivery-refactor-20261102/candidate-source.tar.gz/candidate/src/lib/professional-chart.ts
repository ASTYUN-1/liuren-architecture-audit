import type { Participant } from "@/server/contracts";

export const BRANCHES = [..."子丑寅卯辰巳午未申酉戌亥"];
export const STEMS = [..."甲乙丙丁戊己庚辛壬癸"];
export const MONTH_GENERALS = ["神后子", "大吉丑", "功曹寅", "太冲卯", "天罡辰", "太乙巳", "胜光午", "小吉未", "传送申", "从魁酉", "河魁戌", "登明亥"];
export type SelfChartMethod = "time" | "number" | "pillars" | "solar";
export interface SelfChartInput {
  method: SelfChartMethod;
  date: string;
  time: string;
  calendar: "solar" | "lunar";
  leapMonth: boolean;
  number?: number;
  longitude?: number;
  pillars: { year: string; month: string; day: string; hour: string; monthGeneral: string };
  rules: { guiren: string; zhouye: string; shehai: string; yuejiang: string };
  participants: Participant[];
}
export interface Palace {
  key: string; earth: string; heaven: string; general: string; stem: string;
  heavenGrowth: string; generalGrowth: string; nayin: string;
  onHeaven: { name: string; value: string }; onEarth: { name: string; value: string };
  spirits: string[]; patterns: string[]; void: boolean;
}
export interface ProfessionalChart {
  method: SelfChartMethod; date: string | null; time: string | null;
  originalTime: string | null; longitude?: number; number?: number;
  pillars: string[]; monthGeneral: string; xun: string; voidBranches: string[];
  lunar: string | null; solarTerm: string | null; rules: SelfChartInput["rules"];
  people: { name: string; gender: string; birthYear: number; life: string; annual: string }[];
  lessons: string[][]; transmissions: string[][]; palaces: Palace[];
  classics: { zhizhi: string; jiying: string; bifa: string; kejing: { key: string; value: string }[][]; licheng: string };
  spirits: { label: string; entries: [string, string[]][] }[];
}
