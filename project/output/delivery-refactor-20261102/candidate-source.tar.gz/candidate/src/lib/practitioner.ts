export interface PractitionerProfile {
  tier:'user'|'practitioner'|'official';
  professionalOutput:boolean;
  canReadShared:boolean;
  advisorIds:string[];
  certification:null|{status:'pending'|'approved'|'rejected'|'revoked';applicationNote:string;reviewNote:string;revision:number;appliedAt:string;reviewedAt:string|null};
}
