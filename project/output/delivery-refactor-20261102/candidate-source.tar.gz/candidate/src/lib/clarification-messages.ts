export type DialogueMessage = { role: "user" | "assistant"; content: string; at?: string };

/** Existing legacy user text is retained, but missing AI prompts are never invented. */
export function appendClarificationMessages(previous: DialogueMessage[] | null | undefined, savedQuestion: string | null, prompt: string, reply: string, repliedAt?: string, originalQuestionAt?: string): DialogueMessage[] {
  const history = [...(previous ?? [])];
  if (!history.length && savedQuestion?.trim()) history.push({ role: "user", content: savedQuestion, ...(originalQuestionAt ? {at: originalQuestionAt} : {}) });
  history.push({ role: "assistant", content: prompt }, { role: "user", content: reply, ...(repliedAt ? {at: repliedAt} : {}) });
  return history;
}
