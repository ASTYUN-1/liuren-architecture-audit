export class ApiException extends Error { constructor(message: string, public code: string, public status: number) { super(message); } }
const englishErrors: Record<string, string> = {
  INPUT_REVIEW_ACTIVE: "This input is already being reviewed. Wait for its result before submitting again.", INPUT_REVIEW_BUSY: "Two input reviews are already running. Wait for one to finish.",
  UNAUTHENTICATED: "Please sign in first.", EMAIL_UNVERIFIED: "Verify your email before using paid interpretations.", FORBIDDEN: "You do not have access to this action.", ADMIN_2FA_REQUIRED: "Set up and verify two-step authentication from your account page.", ORIGIN_REJECTED: "Request origin rejected. Open the service in its own browser page.", RATE_LIMITED: "Too many requests. Please try again later.", NOT_FOUND: "This record could not be found.", DRAFT_LIMIT: "You have reached the 10-draft limit. Remove an unused draft first.", CASE_LIMIT: "You have reached the 100-case limit. Export and remove an old case first.", CASE_DELETED: "Restore this case from trash before continuing.", PERMANENTLY_DELETED: "This case was permanently deleted and cannot be restored.", INPUT_FROZEN: "This case has already been submitted. Its chart settings are fixed.", PAYMENT_UNAVAILABLE: "Payments are not open yet. Your draft is saved.", AI_UNAVAILABLE: "Interpretations are not available yet. Your draft is saved.", ORDER_EXISTS: "This case already has an unfinished order.", ALREADY_PURCHASED: "This service has already been purchased.", REPORT_REQUIRED: "Wait for the main report before purchasing follow-ups.", TURN_LIMIT: "This case has reached the 8-follow-up limit.", NO_TURNS: "No follow-up credits remain. Unused credits may also be reserved by a current task or refund.", TASK_ACTIVE: "A task is already being processed. Wait for it to complete.", CLARIFICATION_LIMIT: "The clarification limit has been reached. Contact the operator with complete details.", REPORT_DELIVERED: "The main report has already been delivered and is not refundable through this action.", NO_REFUNDABLE_TURNS: "There are no unused purchased credits eligible for a refund.", MODEL_NOT_CONFIGURED: "The model connection has not been configured.", MAIL_NOT_CONFIGURED: "Email delivery has not been configured. No email was sent.", ENCRYPTION_NOT_CONFIGURED: "Server encryption is not configured. Contact the operator.", INVALID_TIMEZONE: "Use a valid IANA time zone.", TIME_OFFSET_REQUIRED: "The date and time must include a UTC offset.", NUMBER_REQUIRED: "Enter a positive whole number from 1 to 999999999.", PILLARS_REQUIRED: "Complete the four pillars and month general.", INVALID_INPUT: "Please check your inputs and try again.", INVALID_SETTINGS: "Please check the service settings and try again.", ORDER_STATE: "This order cannot be changed in its current state.", TASK_STATE: "Only a failed task can be retried.", REFUND_IN_PROGRESS: "Resolve the refund before retrying delivery.", IDEMPOTENCY_CONFLICT: "This request has changed since submission. Refresh before trying again.", INVALID_TIME: "Please enter a valid date and time."
};
export async function api<T>(path: string, options?: RequestInit): Promise<T> {
  let response:Response;
  try{response=await fetch(path, { ...options, credentials: "same-origin", headers: { ...(options?.body ? { "Content-Type": "application/json" } : {}), ...options?.headers }, cache: "no-store" });}
  catch{throw new ApiException(typeof document!=="undefined"&&document.documentElement.lang==='en'?'Network connection failed. Check your connection and try again.':'网络连接未完成，请检查网络后重试。','NETWORK_ERROR',0);}
  const body = await response.json().catch(() => null);
  // Long operations keep JSON responses alive with whitespace, so their final
  // error envelope can arrive after HTTP 200 headers have already been sent.
  if (!response.ok || body?.error) {
    const envelopeStatus = body?.error?.status;
    const status = response.ok ? (Number.isInteger(envelopeStatus) && envelopeStatus >= 400 && envelopeStatus <= 599 ? envelopeStatus : 500) : response.status;
    const code = body?.error?.code || "REQUEST_FAILED";
    const fallback:Record<number,[string,string]>={401:['登录已失效，请重新登录后继续。','Your session expired. Sign in again.'],413:['提交内容过长，请缩短后重试。','The submitted content is too large.'],429:['请求过于频繁，请稍等片刻再确认。','Too many requests. Please wait before trying again.'],502:['服务连接暂时中断，请稍后重试。','The service connection was interrupted. Please try again.'],503:['服务暂不可用，请稍后重试。','The service is temporarily unavailable.'],504:['服务响应超时，请重新确认；问题内容不会因此被保存为默认设定。','The service timed out. Review and submit again.']};
    const english=typeof document !== "undefined" && document.documentElement.lang === "en";
    const message = english ? englishErrors[code] || body?.error?.message || fallback[status]?.[1] || "Request failed. Please try again." : body?.error?.message || fallback[status]?.[0] || "请求未完成，请稍后重试。";
    throw new ApiException(message, code, status);
  }
  if(!body||!Object.prototype.hasOwnProperty.call(body,'data'))throw new ApiException('服务返回内容不完整，请重试 / Incomplete service response','INVALID_RESPONSE',502);
  return body.data as T;
}
export const post = <T,>(path: string, body: unknown) => api<T>(path, { method: "POST", body: JSON.stringify(body) });
export const patch = <T,>(path: string, body: unknown) => api<T>(path, { method: "PATCH", body: JSON.stringify(body) });
export const key = () => crypto.randomUUID();
export const money = (cents: number) => `¥${(cents / 100).toFixed(2)}`;
export const date = (value: string, locale = "zh") => new Date(value).toLocaleString(locale === "zh" ? "zh-CN" : "en-US", { dateStyle: "medium", timeStyle: "short" });
