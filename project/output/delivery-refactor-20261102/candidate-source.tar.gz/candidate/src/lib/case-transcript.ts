import type { CaseDetail } from "../server/contracts";
import { caseInputFields, dialogueTime } from "./case-input-display";

/** Export all stored questions, including pending turns and superseded inputs. */
export function formatCaseTranscript(item: CaseDetail): string {
  const lines = [item.title];
  const versions = [...(item.previousReports ?? []).map(version => ({
    version: version.inputVersion, input: version.input, askedAt: version.inputSavedAt, report: version.report, historical: true,
  })), { version: item.inputVersion, input: item.input, askedAt: item.inputSavedAt ?? (item.inputVersion === 1 ? item.createdAt : undefined), report: item.report, historical: false }]
    .sort((a, b) => a.version - b.version);
  const writtenTurns = new Set<string>();
  function appendTurn(turn: CaseDetail["turns"][number]) {
    if (dialogueTime(turn.createdAt)) lines.push("追问时间：" + dialogueTime(turn.createdAt));
    if (turn.clarificationMessages?.length) {
      for (const message of turn.clarificationMessages) lines.push((message.role === "user" ? "你 · 提问或补充：\n" : "AI · 请求补充：\n") + (message.at ? dialogueTime(message.at) + "\n" : "") + message.content);
    } else lines.push("你 · 追问：\n" + turn.question);
    lines.push(turn.answer ? "AI · 回答：\n" + turn.answer : turn.clarification
      ? "AI · 请求补充：\n" + turn.clarification : "AI · 尚未交付回答（" + turn.status + "）");
    writtenTurns.add(turn.id);
  }
  for (const version of versions) {
    lines.push((version.historical ? "已被更正的历史版本 " : "当前版本 ") + version.version);
    if (dialogueTime(version.askedAt)) lines.push("提问记录时间：" + dialogueTime(version.askedAt));
    lines.push(version.input ? "你 · 提问：\n" + version.input.question : "该历史版本的原提问不可读取。");
    if (version.input) lines.push(caseInputFields(version.input).map(([key, value]) => `${key}：${value}`).join("\n"));
    for (const task of item.tasks.filter(task => task.kind === "initial" && task.inputVersion === version.version)) {
      if (task.clarificationMessages?.length) {
        for (const message of task.clarificationMessages) lines.push((message.role === "user" ? "你 · 补充信息：\n" : "AI · 请求补充：\n") + (message.at ? dialogueTime(message.at) + "\n" : "") + message.content);
      } else if (task.question?.trim()) lines.push("你 · 补充信息：\n" + task.question);
      if (task.clarification) lines.push("AI · 请求补充：\n" + task.clarification);
    }
    lines.push(version.report ? "AI · 回答：\n" + version.report.content : "AI · 主报告尚未交付");
    item.turns.filter(turn => (turn.inputVersion ?? 1) === version.version).forEach(appendTurn);
  }
  // Keep older turns even when their input version is unavailable.
  for (const turn of item.turns.filter(turn => !writtenTurns.has(turn.id))) {
    lines.push("历史对话 · 版本 " + (turn.inputVersion ?? 1));
    appendTurn(turn);
  }
  return lines.join("\n\n");
}
