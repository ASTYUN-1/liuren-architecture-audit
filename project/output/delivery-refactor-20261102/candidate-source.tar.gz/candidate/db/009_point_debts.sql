-- Credit lots remain nonnegative; account availability subtracts outstanding debts.
ALTER TABLE point_holds ADD COLUMN debt_units integer NOT NULL DEFAULT 0
 CHECK(debt_units>=0 AND debt_units<=charged_units);
CREATE TABLE point_debts (
 hold_id uuid PRIMARY KEY REFERENCES point_holds(id),
 user_id text NOT NULL REFERENCES "user"(id),
 original_units integer NOT NULL CHECK(original_units>0),
 outstanding_units integer NOT NULL CHECK(outstanding_units>=0),
 repaid_units integer NOT NULL DEFAULT 0 CHECK(repaid_units>=0),
 cancelled_units integer NOT NULL DEFAULT 0 CHECK(cancelled_units>=0),
 allocations jsonb NOT NULL DEFAULT '[]',
 created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(outstanding_units+repaid_units+cancelled_units=original_units)
);
CREATE INDEX point_debts_unpaid_user ON point_debts(user_id,created_at,hold_id)
 WHERE outstanding_units>0;
