CREATE TABLE advisor_accounts (
  advisor_id text NOT NULL CHECK(advisor_id IN ('congkui','liurenshi','qing','wenwen','ming')),
  user_id text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(advisor_id,user_id)
);
CREATE TABLE conversation_shares (
  id uuid PRIMARY KEY,
  user_id text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
  case_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  advisor_id text NOT NULL CHECK(advisor_id IN ('congkui','liurenshi','qing','wenwen','ming')),
  token_hash text NOT NULL UNIQUE,
  encrypted_code text NOT NULL,
  booking_id uuid NOT NULL UNIQUE REFERENCES human_assists(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT now()+interval '7 days',
  revoked_at timestamptz
);
CREATE INDEX conversation_shares_owner ON conversation_shares(user_id,case_id);
