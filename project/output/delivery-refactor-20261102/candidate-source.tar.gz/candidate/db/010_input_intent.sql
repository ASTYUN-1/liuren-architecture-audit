-- Keep superseded reports with their input versions; current case remains the active view.
ALTER TABLE case_inputs ADD COLUMN IF NOT EXISTS previous_report jsonb;
ALTER TABLE case_inputs ADD COLUMN IF NOT EXISTS previous_chart jsonb;
ALTER TABLE case_inputs ADD COLUMN IF NOT EXISTS superseded_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS system_correction boolean NOT NULL DEFAULT false;
