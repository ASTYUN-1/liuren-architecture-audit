-- No email addresses, authentication URLs, questions or reports in this outbox.
CREATE TABLE IF NOT EXISTS mail_outbox (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), event_key text NOT NULL UNIQUE,
 user_id text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE, case_id uuid REFERENCES cases(id) ON DELETE SET NULL,
 kind text NOT NULL CHECK(kind IN ('resultReady','serviceUpdate','referralReward')),
 status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','sending','accepted','failed','suppressed')),
 attempts integer NOT NULL DEFAULT 0, available_at timestamptz NOT NULL DEFAULT now(),
 lease_token uuid, lease_until timestamptz, provider_message_id text, error_code text,
 created_at timestamptz NOT NULL DEFAULT now(), sent_at timestamptz
);
CREATE INDEX IF NOT EXISTS mail_outbox_pending ON mail_outbox(available_at,created_at) WHERE status='pending';
CREATE INDEX IF NOT EXISTS mail_outbox_lease ON mail_outbox(lease_until) WHERE status='sending';

CREATE OR REPLACE FUNCTION wenheng_mail_event() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE event_id text; message_kind text; target_user text; target_case uuid;
BEGIN
 IF TG_TABLE_NAME='tasks' THEN
  IF NEW.status=OLD.status OR NEW.status NOT IN ('succeeded','failed') THEN RETURN NEW; END IF;
  target_user:=NEW.user_id; target_case:=NEW.case_id;
  message_kind:=CASE WHEN NEW.status='succeeded' AND NEW.clarification IS NULL THEN 'resultReady' ELSE 'serviceUpdate' END;
  event_id:='task:'||NEW.id||':'||NEW.status||':'||NEW.clarification_count;
 ELSIF TG_TABLE_NAME='orders' THEN
  IF NEW.status=OLD.status OR NEW.status NOT IN ('refundPending','refunded','partiallyRefunded') THEN RETURN NEW; END IF;
  target_user:=NEW.user_id;
  -- A deleted case can still have a refund; link to the account, not the deleted case.
  target_case:=NULL; message_kind:='serviceUpdate';
  event_id:='order:'||NEW.id||':'||NEW.status||':'||NEW.refunded_cents||':'||NEW.refund_requested_cents;
 ELSIF TG_TABLE_NAME='referral_coupons' THEN
  IF NEW.kind<>'reward' THEN RETURN NEW; END IF;
  target_user:=NEW.user_id; target_case:=NULL; message_kind:='referralReward';
  event_id:='reward:'||NEW.id;
 END IF;
 INSERT INTO mail_outbox(event_key,user_id,case_id,kind) VALUES(event_id,target_user,target_case,message_kind) ON CONFLICT DO NOTHING;
 RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tasks_mail_event ON tasks;
CREATE TRIGGER tasks_mail_event AFTER UPDATE OF status ON tasks FOR EACH ROW EXECUTE FUNCTION wenheng_mail_event();
DROP TRIGGER IF EXISTS orders_mail_event ON orders;
CREATE TRIGGER orders_mail_event AFTER UPDATE OF status ON orders FOR EACH ROW EXECUTE FUNCTION wenheng_mail_event();
DROP TRIGGER IF EXISTS referral_mail_event ON referral_coupons;
CREATE TRIGGER referral_mail_event AFTER INSERT ON referral_coupons FOR EACH ROW EXECUTE FUNCTION wenheng_mail_event();
