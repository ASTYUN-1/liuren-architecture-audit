-- Preserve the AI clarification and the user's reply before resuming the same task.
ALTER TABLE tasks ADD COLUMN clarification_messages jsonb NOT NULL DEFAULT '[]'::jsonb
  CHECK (jsonb_typeof(clarification_messages) = 'array');
