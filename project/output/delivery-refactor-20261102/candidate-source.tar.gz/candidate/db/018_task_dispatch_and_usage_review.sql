ALTER TABLE tasks ADD COLUMN IF NOT EXISTS billing_review_status text NOT NULL DEFAULT 'none' CHECK(billing_review_status IN ('none','pending','resolved'));
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS execution_elapsed_ms bigint NOT NULL DEFAULT 0;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS execution_started_at timestamptz;
-- Preserve unresolved historical evidence without guessing charges or reopening
-- the global AI switch. Only the settled attempt contributes to this review.
UPDATE tasks t SET billing_review_status='pending'
FROM point_holds h WHERE h.id=t.point_hold_id AND h.status='settled' AND t.billing_review_status='none'
 AND EXISTS(SELECT 1 FROM point_usage_events e WHERE e.task_id=t.id AND e.attempt=t.attempts AND NOT e.verified);
UPDATE point_holds h SET snapshot=h.snapshot||'{"billingReviewPending":true}'::jsonb
FROM tasks t WHERE t.point_hold_id=h.id AND t.billing_review_status='pending';
CREATE INDEX IF NOT EXISTS tasks_billing_review_pending_idx ON tasks(updated_at) WHERE billing_review_status='pending';
CREATE INDEX IF NOT EXISTS tasks_fair_dispatch_idx ON tasks(user_id,created_at,id) WHERE status='queued';
-- Free input reviews are bounded by simultaneous work, never a daily quota.
-- Only a digest is persisted; disconnected requests release their own lease.
CREATE TABLE IF NOT EXISTS input_intent_leases (
 token uuid PRIMARY KEY,user_id text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
 request_hash text NOT NULL,expires_at timestamptz NOT NULL DEFAULT now()+interval '31 minutes',
 UNIQUE(user_id,request_hash)
);
CREATE INDEX IF NOT EXISTS input_intent_leases_expiry_idx ON input_intent_leases(expires_at);

-- Retries share one execution allowance; queue waiting never consumes it.
CREATE OR REPLACE FUNCTION track_wenheng_task_execution() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.status='running' AND (NEW.status<>'running' OR NEW.worker_token IS DISTINCT FROM OLD.worker_token) THEN
  NEW.execution_elapsed_ms=OLD.execution_elapsed_ms+CASE WHEN OLD.execution_started_at IS NULL THEN 0 ELSE greatest(0,floor(extract(epoch FROM (clock_timestamp()-OLD.execution_started_at))*1000))::bigint END;
  NEW.execution_started_at=NULL;
 END IF;
 IF NEW.status='running' AND (OLD.status<>'running' OR NEW.worker_token IS DISTINCT FROM OLD.worker_token) THEN
  NEW.execution_started_at=clock_timestamp();
 END IF;
 RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS tasks_track_execution ON tasks;
CREATE TRIGGER tasks_track_execution BEFORE UPDATE OF status,worker_token ON tasks FOR EACH ROW EXECUTE FUNCTION track_wenheng_task_execution();

CREATE OR REPLACE FUNCTION notify_wenheng_task_stopped() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.status='running' AND (NEW.status<>'running' OR NEW.worker_token IS DISTINCT FROM OLD.worker_token) THEN
  PERFORM pg_notify('wenheng_task_stopped',NEW.id::text);
 END IF;
 RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS tasks_notify_stopped ON tasks;
CREATE TRIGGER tasks_notify_stopped AFTER UPDATE OF status,worker_token ON tasks FOR EACH ROW EXECUTE FUNCTION notify_wenheng_task_stopped();
