-- Install only with the candidate web+worker, never against production during QA.
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS delivery_protocol text NOT NULL DEFAULT 'legacy' CHECK(delivery_protocol IN ('legacy','delivery-v2'));
ALTER TABLE tasks ALTER COLUMN delivery_protocol SET DEFAULT 'delivery-v2';
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS delivery_drafts jsonb;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS delivery_result jsonb;
-- Drafts are private customer business data. No public endpoint exposes them.
-- Keep at most three complete candidate versions; permanent case purge clears all.

-- Preserve erasure even if a later application rollback uses the old purge SQL.
CREATE OR REPLACE FUNCTION clear_delivery_on_case_purge() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.permanently_deleted AND NOT OLD.permanently_deleted THEN
  UPDATE public.tasks SET delivery_drafts=NULL,delivery_result=NULL WHERE case_id=NEW.id;
 END IF;
 RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS cases_clear_delivery ON cases;
CREATE TRIGGER cases_clear_delivery AFTER UPDATE OF permanently_deleted ON cases
FOR EACH ROW EXECUTE FUNCTION clear_delivery_on_case_purge();
