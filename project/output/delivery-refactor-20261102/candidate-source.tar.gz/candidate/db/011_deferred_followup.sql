-- A zero-value billing record tracks a follow-up without freezing credits.
-- Keep positive reservations for reports, human assistance and refunds.
ALTER TABLE point_holds DROP CONSTRAINT point_holds_units_check;
ALTER TABLE point_holds ADD CONSTRAINT point_holds_units_check CHECK (
 units > 0 OR (units = 0 AND kind = 'followup'
   AND snapshot->>'settlementMode' = 'after_delivery') IS TRUE
);
