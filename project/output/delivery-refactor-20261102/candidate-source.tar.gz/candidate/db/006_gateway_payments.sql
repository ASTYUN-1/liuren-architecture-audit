CREATE TABLE IF NOT EXISTS gateway_payments (
 id uuid PRIMARY KEY, user_id text NOT NULL, order_id uuid UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
 is_test boolean NOT NULL DEFAULT false, merchant_pid text NOT NULL,
 amount_cents integer NOT NULL CHECK(amount_cents>0), paytype text NOT NULL CHECK(paytype IN ('alipay','wxpay')),
 trade_no text UNIQUE, pay_url text, provider_status text NOT NULL DEFAULT 'WAIT_BUYER_PAY',
 paid_at timestamptz, checked_at timestamptz, error_code text,
 held_turns integer NOT NULL DEFAULT 0, status_before_hold text,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 CHECK ((is_test AND order_id IS NULL) OR (NOT is_test AND order_id IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS gateway_payment_user_idx ON gateway_payments(user_id,created_at DESC);
