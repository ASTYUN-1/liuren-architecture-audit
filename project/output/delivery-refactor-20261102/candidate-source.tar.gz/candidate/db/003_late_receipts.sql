ALTER TABLE orders ADD COLUMN IF NOT EXISTS fulfillment_eligible boolean NOT NULL DEFAULT true;
DROP INDEX IF EXISTS orders_active_base;
CREATE UNIQUE INDEX orders_active_base ON orders(case_id) WHERE kind='base' AND fulfillment_eligible AND status IN ('pending','submitted','paid','refundPending','partiallyRefunded');
