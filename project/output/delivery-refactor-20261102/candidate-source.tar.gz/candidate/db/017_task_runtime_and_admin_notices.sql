ALTER TABLE tasks ADD COLUMN runtime_progress jsonb NOT NULL DEFAULT '{}'::jsonb;
CREATE TABLE admin_notice_reads (
  operator_id text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
  item_key text NOT NULL,
  read_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(operator_id,item_key)
);
CREATE INDEX tasks_unfinished_age_idx ON tasks(created_at)
  WHERE status IN ('queued','running','failed') OR (status='succeeded' AND clarification IS NOT NULL);
CREATE INDEX audit_action_target_created_idx ON audit_log(action,target_id,created_at DESC);
