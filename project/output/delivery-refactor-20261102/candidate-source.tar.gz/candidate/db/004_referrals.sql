CREATE TABLE referral_profiles (
  user_id text PRIMARY KEY REFERENCES "user"(id) ON DELETE CASCADE,
  code text NOT NULL UNIQUE CHECK (code ~ '^[a-f0-9]{24}$'),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE referrals (
  invitee_id text PRIMARY KEY REFERENCES "user"(id),
  inviter_id text NOT NULL REFERENCES "user"(id),
  qualified_order_id uuid UNIQUE REFERENCES orders(id),
  qualified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (invitee_id <> inviter_id)
);
CREATE INDEX referrals_inviter_idx ON referrals(inviter_id,created_at DESC);
CREATE TABLE referral_coupons (
  id uuid PRIMARY KEY,
  user_id text NOT NULL REFERENCES "user"(id),
  referral_id text NOT NULL REFERENCES referrals(invitee_id),
  kind text NOT NULL CHECK(kind IN ('welcome','reward')),
  revoked boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(referral_id,kind)
);
CREATE INDEX referral_coupons_user_idx ON referral_coupons(user_id,created_at);
ALTER TABLE orders ADD COLUMN list_amount_cents integer;
UPDATE orders SET list_amount_cents=amount_cents;
ALTER TABLE orders ALTER COLUMN list_amount_cents SET NOT NULL;
-- Older maintenance scripts may omit this column; snapshot their actual amount.
CREATE FUNCTION order_price_snapshot() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.list_amount_cents IS NULL THEN NEW.list_amount_cents := NEW.amount_cents; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER order_price_snapshot BEFORE INSERT ON orders FOR EACH ROW EXECUTE FUNCTION order_price_snapshot();
ALTER TABLE orders ADD COLUMN referral_coupon_id uuid REFERENCES referral_coupons(id);
ALTER TABLE orders ADD CONSTRAINT orders_price_snapshot CHECK (
  list_amount_cents >= amount_cents AND
  (referral_coupon_id IS NULL OR (kind='base' AND amount_cents=(list_amount_cents*80+50)/100))
);
-- Status determines the reservation. Cancelled/full-refund orders release it
-- without a fragile second coupon update in every cancellation path.
CREATE UNIQUE INDEX orders_one_coupon_use ON orders(referral_coupon_id)
  WHERE referral_coupon_id IS NOT NULL AND status NOT IN ('cancelled','refunded');
