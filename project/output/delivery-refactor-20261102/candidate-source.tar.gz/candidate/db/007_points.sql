CREATE TABLE point_profiles(user_id text PRIMARY KEY REFERENCES "user"(id),code text NOT NULL UNIQUE);
CREATE TABLE point_lots (
 id uuid PRIMARY KEY,user_id text NOT NULL REFERENCES "user"(id),kind text NOT NULL CHECK(kind IN ('paid','bonus')),
 original_units integer NOT NULL CHECK(original_units>0),available_units integer NOT NULL CHECK(available_units>=0),frozen_units integer NOT NULL DEFAULT 0 CHECK(frozen_units>=0),
 channel text,reference text,reason text NOT NULL,actor_id text NOT NULL,idempotency_key text NOT NULL UNIQUE,created_at timestamptz NOT NULL DEFAULT now(),CHECK(available_units+frozen_units<=original_units)
);
CREATE UNIQUE INDEX point_receipt_unique ON point_lots(channel,reference) WHERE kind='paid';
CREATE INDEX point_lots_user ON point_lots(user_id,created_at);
CREATE TABLE point_holds (
 id uuid PRIMARY KEY,user_id text NOT NULL REFERENCES "user"(id),kind text NOT NULL CHECK(kind IN ('initial','followup','human','refund')),case_id uuid,task_id uuid,
 status text NOT NULL DEFAULT 'held' CHECK(status IN ('held','settled','released')),units integer NOT NULL CHECK(units>0),charged_units integer NOT NULL DEFAULT 0,refunded_units integer NOT NULL DEFAULT 0 CHECK(refunded_units>=0),
 allocations jsonb NOT NULL,snapshot jsonb NOT NULL DEFAULT '{}',coupon_id uuid REFERENCES referral_coupons(id),idempotency_key text NOT NULL,created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),UNIQUE(user_id,idempotency_key),CHECK(charged_units>=0 AND charged_units<=units)
);
CREATE UNIQUE INDEX point_task_hold ON point_holds(task_id) WHERE task_id IS NOT NULL AND status='held';
CREATE TABLE point_coupon_claims(coupon_id uuid PRIMARY KEY REFERENCES referral_coupons(id),hold_id uuid NOT NULL UNIQUE REFERENCES point_holds(id));
CREATE TABLE point_ledger (
 id uuid PRIMARY KEY,user_id text NOT NULL REFERENCES "user"(id),hold_id uuid REFERENCES point_holds(id),lot_id uuid REFERENCES point_lots(id),action text NOT NULL,
 available_delta integer NOT NULL,frozen_delta integer NOT NULL,charged_units integer NOT NULL DEFAULT 0,reason text NOT NULL,actor_id text NOT NULL,created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX point_ledger_terminal ON point_ledger(hold_id,action) WHERE hold_id IS NOT NULL;
CREATE TABLE point_usage_events (
 id uuid PRIMARY KEY,task_id uuid NOT NULL,attempt integer NOT NULL,request_id text NOT NULL,response_id text,model text NOT NULL,price_version text NOT NULL,
 input_tokens integer NOT NULL,output_tokens integer NOT NULL,cached_tokens integer NOT NULL,cost_nano_cny bigint NOT NULL,verified boolean NOT NULL,billable boolean NOT NULL,created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(task_id,attempt,request_id)
);
CREATE UNIQUE INDEX point_response_unique ON point_usage_events(task_id,attempt,response_id) WHERE response_id IS NOT NULL;
CREATE TABLE advisor_draws(id uuid PRIMARY KEY,user_id text NOT NULL REFERENCES "user"(id),advisor_id text NOT NULL,idempotency_key text NOT NULL,created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(user_id,idempotency_key));
CREATE TABLE human_assists (
 id uuid PRIMARY KEY REFERENCES point_holds(id),user_id text NOT NULL REFERENCES "user"(id),case_id uuid NOT NULL,advisor_id text NOT NULL,question text NOT NULL,
 status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','review','completed','cancelled','disputed','refunded')),summary text,deadline timestamptz NOT NULL DEFAULT now()+interval '24 hours',created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE point_refunds(id uuid PRIMARY KEY REFERENCES point_holds(id),user_id text NOT NULL REFERENCES "user"(id),status text NOT NULL DEFAULT 'pending',reason text NOT NULL,reference text UNIQUE,updated_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE tasks ADD COLUMN point_hold_id uuid REFERENCES point_holds(id);
ALTER TABLE referrals ADD COLUMN qualified_point_hold_id uuid REFERENCES point_holds(id);
