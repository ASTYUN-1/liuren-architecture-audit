ALTER TABLE "user" ADD COLUMN IF NOT EXISTS username text;
ALTER TABLE "user" ADD COLUMN IF NOT EXISTS display_username text;
CREATE UNIQUE INDEX IF NOT EXISTS user_username_unique ON "user" (lower(username)) WHERE username IS NOT NULL;
ALTER TABLE "user" ADD CONSTRAINT user_username_format CHECK (username IS NULL OR username ~ '^[a-z0-9_]{4,24}$');
CREATE TABLE account_recovery (
 user_id text PRIMARY KEY REFERENCES "user"(id) ON DELETE CASCADE,
 key_hash text NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);
