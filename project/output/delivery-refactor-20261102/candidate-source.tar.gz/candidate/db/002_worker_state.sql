ALTER TABLE cases ADD COLUMN IF NOT EXISTS internal_chart jsonb;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS internal_evidence jsonb;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS worker_token uuid;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS lease_expires_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS queued_at timestamptz;
CREATE INDEX IF NOT EXISTS tasks_dispatch_idx ON tasks(status,queued_at);
