-- Presentation choice only; private study notes remain deferred.
ALTER TABLE cases ADD COLUMN output_style text CHECK(output_style IN ('public','practitioner'));
