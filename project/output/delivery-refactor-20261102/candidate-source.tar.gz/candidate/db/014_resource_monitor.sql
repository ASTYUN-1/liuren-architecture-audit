-- Bounded operational telemetry only; no customer or financial data.
CREATE TABLE resource_monitor_samples (
 node_id text NOT NULL CHECK(node_id IN ('hk','cn','windows','ubuntu')),
 bucket timestamptz NOT NULL,
 sampled_at timestamptz NOT NULL,
 received_at timestamptz NOT NULL DEFAULT now(),
 payload jsonb NOT NULL CHECK(jsonb_typeof(payload)='object'),
 PRIMARY KEY(node_id,bucket)
);
CREATE INDEX resource_monitor_retention ON resource_monitor_samples(bucket);
