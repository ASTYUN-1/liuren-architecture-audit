CREATE TABLE practitioner_certifications (
  user_id text PRIMARY KEY REFERENCES "user"(id) ON DELETE CASCADE,
  status text NOT NULL CHECK(status IN ('pending','approved','rejected','revoked')),
  application_note text NOT NULL CHECK(char_length(application_note) BETWEEN 10 AND 1200),
  review_note text NOT NULL DEFAULT '',
  revision integer NOT NULL DEFAULT 1,
  applied_at timestamptz NOT NULL DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by text
);
CREATE INDEX practitioner_certifications_pending ON practitioner_certifications(status,applied_at);
-- Server-selected on first acquisition, then retained across retries. Existing
-- records remain NULL until acquired; this never changes historical reports.
ALTER TABLE tasks ADD COLUMN output_audience text CHECK(output_audience IN ('public','practitioner'));
