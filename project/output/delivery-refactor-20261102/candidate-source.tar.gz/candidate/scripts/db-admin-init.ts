/** Private CLI only. Run on the server with DATABASE_URL and ADMIN_INIT_EMAIL/PASSWORD. */
import {hashPassword} from "better-auth/crypto";
import {randomUUID} from "node:crypto";
import postgres from "postgres";
const email=process.env.ADMIN_INIT_EMAIL?.toLowerCase(),password=process.env.ADMIN_INIT_PASSWORD;
if(!email||!password||password.length<14||!process.env.DATABASE_URL)throw new Error("Set ADMIN_INIT_EMAIL, ADMIN_INIT_PASSWORD (>=14 chars), DATABASE_URL");
if(!(process.env.ADMIN_EMAILS||"").split(",").map(x=>x.trim().toLowerCase()).includes(email))throw new Error("Email must be listed in ADMIN_EMAILS");
const db=postgres(process.env.DATABASE_URL,{max:1});
await db.begin(async tx=>{if((await tx`SELECT id FROM "user" WHERE email=${email}`).length)throw new Error("Account already exists; CLI refuses to overwrite");const id=randomUUID();await tx`INSERT INTO "user"(id,name,email,email_verified) VALUES(${id},'网站管理员',${email},true)`;await tx`INSERT INTO account(id,account_id,provider_id,user_id,password) VALUES(${randomUUID()},${id},'credential',${id},${await hashPassword(password)})`;});
console.log("Administrator initialized. Sign in and enable two-factor verification before accessing administration.");
await db.end();
