import assert from "node:assert/strict";
import {Client} from "@modelcontextprotocol/sdk/client/index.js";
import {InMemoryTransport} from "@modelcontextprotocol/sdk/inMemory.js";
import {KnowledgeRelease} from "../src/agent/knowledge";
import {ToolAudit,createTaskTools} from "../src/agent/tools";
const release=new KnowledgeRelease();
const audit=new ToolAudit({taskId:"acceptance-only",caseId:"acceptance-only",kind:"initial",input:{question:"隔离部署验证，不创建真实任务",locale:"zh",mode:"time",time:"2026-10-15T05:00:00Z",timeZone:"Asia/Shanghai",participants:[]},history:[]},release);
const server=createTaskTools(audit),client=new Client({name:"deployment-check",version:"1"}),[a,b]=InMemoryTransport.createLinkedPair();
await Promise.all([server.connect(b),client.connect(a)]);
try{
 const call=async(name:string,args:Record<string,unknown>={})=>{const r=await client.callTool({name,arguments:args});assert(!r.isError);return JSON.parse((r.content as {text:string}[])[0].text);};
 const catalog=await call("list_knowledge");assert.equal(catalog.documents.length,26);
 const search=await call("search_knowledge",{query:"壬归",scope:"references"});assert(search.results.length);
 const page=await call("read_knowledge",{id:search.results[0].id});assert(page.complete);
 for(let i=0;i<205;i++)await call("read_case");
 assert(audit.calls>200);assert.deepEqual(audit.toolBudget(),{used:audit.calls});assert.equal(audit.candidate,undefined);
 console.log(JSON.stringify({passed:true,toolCalls:audit.calls,toolBudget:audit.toolBudget(),knowledgeVersion:release.version,skillCount:catalog.documents.length,referenceRead:true,modelRequests:0,productionTasksCreated:0}));
}finally{await client.close();await server.close();}
