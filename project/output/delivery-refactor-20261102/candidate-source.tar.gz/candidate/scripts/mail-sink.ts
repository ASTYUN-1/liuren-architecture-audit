import { SMTPServer } from "smtp-server";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

const directory = path.resolve(process.env.MAIL_SINK_DIR ?? "test-results/mail");
await mkdir(directory, { recursive: true });
const server = new SMTPServer({
  authOptional: true, disabledCommands: ["AUTH", "STARTTLS"],
  onData(stream, _session, callback) {
    const chunks: Buffer[] = [];
    stream.on("data", chunk => chunks.push(Buffer.from(chunk)));
    stream.on("end", () => {
      writeFile(path.join(directory, `${Date.now()}-${randomUUID()}.eml`), Buffer.concat(chunks))
        .then(() => callback()).catch(callback);
    });
    stream.on("error", callback);
  }
});
server.listen(12525, "127.0.0.1", () => console.log("Isolated SMTP receiver listening on loopback:12525"));
for (const signal of ["SIGINT", "SIGTERM"] as const) process.on(signal, () => server.close(() => process.exit(0)));
