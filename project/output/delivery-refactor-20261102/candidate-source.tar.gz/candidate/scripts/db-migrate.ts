import { readFile,readdir } from "node:fs/promises";
import { resolve } from "node:path";
import postgres from "postgres";
if(!process.env.DATABASE_URL)throw new Error("DATABASE_URL required");
const db=postgres(process.env.DATABASE_URL,{max:1});
await db`CREATE TABLE IF NOT EXISTS app_migrations(name text PRIMARY KEY,applied_at timestamptz NOT NULL DEFAULT now())`;
for(const name of (await readdir(resolve("db"))).filter(x=>x.endsWith(".sql")).sort()){
  const content=await readFile(resolve("db",name),"utf8");
  await db.begin(async tx=>{await tx`SELECT pg_advisory_xact_lock(823711)`;if((await tx`SELECT name FROM app_migrations WHERE name=${name}`).length)return;await tx.unsafe(content);await tx`INSERT INTO app_migrations(name) VALUES(${name})`;});
  console.log("Migration checked:",name);
}
await db.end();
