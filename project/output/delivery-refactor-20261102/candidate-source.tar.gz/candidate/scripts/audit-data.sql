\set ON_ERROR_STOP on
BEGIN READ ONLY;
SELECT count(*) AS users,count(*) FILTER(WHERE email_verified) AS verified,
 count(*) FILTER(WHERE two_factor_enabled) AS two_factor_enabled FROM "user";
SELECT count(*) AS password_accounts,
 count(*) FILTER(WHERE password ~ '^[a-fA-F0-9]{32}:[a-fA-F0-9]{128}$') AS scrypt_format_accounts
 FROM account WHERE provider_id='credential';
SELECT status,count(*) AS orders,coalesce(sum(amount_cents),0) AS cents,
 coalesce(sum(refunded_cents),0) AS refunded_cents,
 coalesce(sum(refund_requested_cents),0) AS pending_refund_cents FROM orders GROUP BY status;
SELECT status,count(*) AS cases FROM cases GROUP BY status;
SELECT status,count(*) AS tasks FROM tasks GROUP BY status;
SELECT count(*) AS entitlements,coalesce(sum(granted),0) AS granted,coalesce(sum(used),0) AS used,
 coalesce(sum(reserved),0) AS reserved,coalesce(sum(frozen),0) AS frozen,
 coalesce(sum(revoked),0) AS revoked FROM entitlements;
SELECT count(*) AS ledger_entries FROM entitlement_ledger;
SELECT 'order_case_owner_mismatch' AS check_name,count(*) AS violations FROM orders o JOIN cases c ON c.id=o.case_id WHERE c.user_id<>o.user_id
UNION ALL SELECT 'task_case_owner_mismatch',count(*) FROM tasks t JOIN cases c ON c.id=t.case_id WHERE c.user_id<>t.user_id
UNION ALL SELECT 'invalid_entitlement_balance',count(*) FROM entitlements WHERE used+reserved+frozen+revoked>granted OR least(used,reserved,frozen,revoked)<0
UNION ALL SELECT 'missing_current_case_input',count(*) FROM cases c WHERE NOT c.permanently_deleted AND NOT EXISTS(SELECT 1 FROM case_inputs i WHERE i.case_id=c.id AND i.version=c.input_version)
UNION ALL SELECT 'grant_ledger_mismatch',count(*) FROM entitlements e WHERE e.granted<>(SELECT coalesce(sum(l.quantity),0) FROM entitlement_ledger l WHERE l.entitlement_id=e.id AND l.action='grant')
UNION ALL SELECT 'consume_ledger_mismatch',count(*) FROM entitlements e WHERE e.used<>(SELECT coalesce(sum(l.quantity),0) FROM entitlement_ledger l WHERE l.entitlement_id=e.id AND l.action='consume');
SELECT pg_size_pretty(pg_database_size(current_database())) AS database_size;
COMMIT;
