import {sqlClient} from '../src/server/db';
import {nbConfig,reconcileNbPayment} from '../src/server/nbzhifu';
const db=sqlClient();
try{
 await nbConfig();
 const rows=await db`SELECT * FROM gateway_payments WHERE provider_status NOT IN ('TRADE_CLOSED','TRADE_REFUND') AND created_at>now()-interval '7 days' AND (checked_at IS NULL OR checked_at<now()-CASE WHEN paid_at IS NULL OR provider_status='TRADE_FREEZE' THEN interval '25 seconds' ELSE interval '10 minutes' END) ORDER BY (paid_at IS NULL) DESC,checked_at ASC NULLS FIRST LIMIT 12`;
 for(const p of rows){try{await reconcileNbPayment(p)}catch{await db`UPDATE gateway_payments SET error_code='RECONCILE_PENDING',checked_at=now() WHERE id=${p.id}`;}}
}finally{await db.end()}
