#!/bin/bash
set -euo pipefail
stage=/var/lib/wenheng/acceptance/delivery-refactor-20261102
cd "$stage/candidate"
export PATH=/opt/wenheng-runtime/node/bin:/usr/bin:/bin
# Turbopack confines resolution to its filesystem root. Copy dependencies into
# this isolated candidate rather than pointing its node_modules at a release.
if [ -L "$stage/candidate/node_modules" ]; then
  unlink "$stage/candidate/node_modules"
  install -d "$stage/candidate/node_modules"
  cp -a /opt/wenheng/releases/20261102-workflow-optimization-01/node_modules/. "$stage/candidate/node_modules/"
fi
node node_modules/typescript/bin/tsc --noEmit > "$stage/typecheck.log" 2>&1 || { tail -n 40 "$stage/typecheck.log"; exit 1; }
systemd-run --quiet --pipe --wait --collect --unit=wenheng-delivery-candidate-build --working-directory="$stage/candidate" -p MemoryMax=1800M -p CPUQuota=100% -p TasksMax=128 /usr/bin/env -i PATH="$PATH" HOME="$stage" NODE_OPTIONS=--max-old-space-size=384 NODE_ENV=production BETTER_AUTH_SECRET=build-only-isolated-delivery WENHENG_PROJECT_ROOT=/var/lib/wenheng/acceptance/workflow-optimization-20261102/resource-candidate-v2 WENHENG_LIUREN_PROTOCOL=liuren-v3 NEXT_TELEMETRY_DISABLED=1 node node_modules/next/dist/bin/next build > "$stage/build.log" 2>&1 || { tail -n 60 "$stage/build.log"; exit 1; }
tail -n 12 "$stage/build.log"
echo ISOLATED_CANDIDATE_BUILD_PASSED
